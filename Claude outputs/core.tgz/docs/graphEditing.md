---
type: Guide
title: Graph selection and clipboard
description: Canvas multi-selection, group movement, and JSON/clipboard copy-paste semantics.
tags: [canvas, editing, selection, clipboard]
status: stable
---

<!-- Copyright © 2026 Zenin Easa Panthakkalakath -->

# Graph selection and clipboard

Clicking a node selects it exclusively. Shift-clicking a node adds it to or removes it from the current node selection. A multi-selection can be moved as one group with either direct dragging or the move tool, and the complete movement is recorded as one undoable action.

The rectangle-selection tool in the toolstrip selects every visible node whose projected center lies inside the dragged rectangle. A normal drag replaces the current selection, while Shift-drag adds the enclosed nodes. The tool does not open inspectors or move the camera and remains active for repeated selections.

Deleting selected nodes is also one undoable action. Every relationship connected to any deleted node is hidden with it, including relationships to nodes outside the selection. Undo restores each relationship only if it was visible before deletion.

A node or relationship can also be disabled instead of deleted, from its own editor rather than as a selection operation. A disabled entity stays fully present — visible in the canvas with a muted appearance and an explicit label, and included when the project is saved — but the native engine treats it exactly as if it had been deleted: excluded from the state vector, from every contribution, and from validation. Disabling a node renders every relationship touching it as disabled too, without changing those relationships' own stored state, so re-enabling the node alone is enough to restore them; a relationship can also be disabled directly, independently of its endpoint nodes. Each toggle is one undoable action.

Right-clicking a node or relationship opens a context menu with the same disable/enable and delete actions as its editor, plus, for a single node, Connect from here to start a new edge at that node — all without opening the editor first. Right-clicking a node that belongs to an existing multi-selection keeps the whole selection rather than collapsing it, and offers Disable all/Enable all in place of the single toggle and Connect from here; each is one uniform, undoable action regardless of the selection's current mixed state. Right-clicking empty canvas still opens the existing Add-to-model menu, which now also offers Select all, matching the Ctrl/Cmd+A shortcut that selects every node in the model.

Copy and Paste are available in the toolstrip's selection-actions group and through the platform keyboard shortcuts. Copy writes a versioned Konjugate graph fragment to an application-specific operating-system clipboard format. A fragment contains the selected nodes and every visible relationship whose two endpoints are selected. Relationships crossing the selection boundary are intentionally excluded, so paste never creates dangling endpoints. The controls remain disabled when their operation has no valid input.

Paste allocates new IDs for every node, state, source term, relationship and parameter. Endpoint references, equation bindings and equation outputs are remapped to those new IDs before the fragment is applied. Relative node layout is retained with a visible position offset. One paste is one undoable action, and malformed or incomplete clipboard fragments are rejected without changing the model.

Subsystems build on these selection semantics. The Create subsystem tool in the toolstrip moves the current node selection into a navigable nested container as one undoable action, without changing any contained entity's stable ID. Relationships crossing the new boundary are neither deleted nor reparented — each is automatically recorded as a port on the subsystem, and while the subsystem is collapsed, that relationship renders as terminating at the subsystem's proxy object rather than passing through to the node it hides. Subsystems can be nested inside one another, and the breadcrumb above the canvas navigates back out. None of this is visible to the native engine: execution and validation always run against the fully flattened graph with subsystem membership stripped out, so subsystems are purely an editing and navigation layer over the same underlying model.

## Label detail

Every node and every group of relationships between the same two nodes has a label on the canvas. The Details control at the top right sets how much of each is shown, separately for Nodes and for Edges, by cycling through three states with each click: compact (name only, the default), expanded (name, type and state values), and hidden. The small glyph in each button shows the current state (one line, three lines, or a dashed empty box) and the tooltip names what the next click does. A hidden label still appears whenever it is selected, has a stability finding, is pinned open, or is needed to pick an endpoint, and pointing at a node's shape while its labels are hidden shows that node's label, so it is never hard to tell what you are pointing at. Hovering a relationship reveals its label only while Edges is hidden, because the label sits on the line it names and would otherwise intercept the click that follows.

On a model of more than 30 nodes, a node label that would overlap another is left out, the node with more relationships keeping its own: a label is a card of a fixed size on screen, so a large model seen whole would otherwise be a pile of cards. Zooming in spreads the nodes and brings the labels back; pointing at a shape or selecting it always shows its label, and the Nodes control's tooltip says how many are left out. Smaller models, and picking a relationship's endpoint, show every label.

The choices are per session and are not saved in the project. Results mode still shows node labels expanded, and restores the previous choice when the results close. A model with more than 150 relationships opens with relationship labels hidden, because a label on every one is unreadable and, being DOM elements repositioned on every frame, the largest cost of drawing such a model; a hidden group's labels are switched off in the scene entirely, so hiding them restores a smooth frame rate. Cycling the Edges button brings them back, and opening a smaller model afterwards restores compact labels only if that default is what hid them.

## Depth and distance

The canvas fades distant shapes into its background, as a cue to depth. The fade follows the camera: up to the distance the canvas opens at it is fixed, and beyond that it thins as the camera pulls back, so whatever the camera looks at keeps its colour however wide the model, while what lies behind it still fades. The far clipping plane keeps three times the viewing distance for the same reason. Before this a model wide enough to need the camera about 100 units back (80 units across, say, as an importer may lay one out) showed its labels and none of its shapes or relationships. The two rules are `fogDensityFor` and `farPlaneFor` in `src/renderer/viewportLayout.mjs`, tested in `tests/viewportLayout.test.mjs`.
