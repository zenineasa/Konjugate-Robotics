---
type: Specification
title: Embedded binary result storage
description: Format specification for storing simulation time-series arrays as an authenticated binary segment inside .kjt files.
tags: [results, binary, storage, format]
status: stable
---

<!-- Copyright © 2026 Zenin Easa Panthakkalakath -->

# Embedded binary result storage

`.kjt` is Konjugate's only user-facing project and simulation format. A project may contain only its editable model or may additionally contain the current immutable simulation result. Simulation arrays are stored as an optional binary segment inside the authenticated KJT payload; they are never converted to JSON.

The internal indexed result segment begins with the four bytes `KJR\x02`, followed by a four-byte unsigned big-endian header length and one serialized `ResultFile` header from `protocol/engineProtocol.proto`. This magic identifies an implementation section, not a supported standalone file type. The header contains metadata, the stable state table, restart checkpoints and any during-run numerical-stability-monitor findings (`repeated StabilityFindingReport stability_findings`, each carrying the flagged node/state id, a code, a message and the simulation time it fired at) -- but no sample values.

The header is followed by independently framed `SampleBatch` messages containing at most 4,096 samples. Each frame begins with a four-byte unsigned big-endian payload length. After the final batch, a serialized `ResultIndex`, its four-byte length and the footer magic `KJIX` complete the file. Index entries record each frame's absolute offset, payload length, sample count and inclusive time bounds. Readers validate that indexed frames are contiguous, within the file and dimensionally consistent before accepting the result.

Each `SampleBatch` contains packed IEEE-754 timestamps and values in sample-major state-table order. Each checkpoint stores its UUID, time, solver identity and one packed state vector in the same order. State IDs are therefore recorded once rather than repeated for every numerical value or batch.

Execution, dependency, partition and lifecycle metadata remains a UTF-8 JSON field during this migration slice. It does not contain sample or checkpoint arrays. A later protocol revision can replace that field with typed messages without changing the packed numerical layout.

Live samples use the same `SampleBatch` layout over the framed stdout event stream. The engine aggregates samples available between result publications into a representative batch of at most 256 samples, retaining both time boundaries. This live projection does not alter the complete samples written to internal result storage. Live snapshots contain metadata but do not repeatedly rewrite accumulated numerical history; stopped and completed snapshots contain the complete packed samples and checkpoints. Electron retains only the latest streamed batch for live presentation instead of repeatedly cloning a growing history. It validates dimensions before reconstructing the current renderer-facing result view.

Electron's main process owns the completed result and does not transfer its complete nested sample graph to the renderer. It retains an open read-only handle to temporary internal result storage, keeps only header and index metadata resident and reads indexed batch byte ranges on demand. The renderer receives a time-preserving playback projection bounded by both sample count and scalar value count. Broad plot ranges select their retained sample positions before materialization, so downsampling never constructs the complete requested history. A four-batch least-recently-used cache lets adjacent playback frames reuse decoded values. Closing results or shutting down clears the cache, closes the handle and then deletes the owned temporary job directory. This keeps playback and plots responsive without weakening the authoritative embedded data.

When results exist, Save offers **Model only** and **Model and results**. Both choices produce a `.kjt`. The second choice embeds the exact result segment alongside the locked producing model, and encryption authenticates both sections together. Opening such a project restores Results mode and its indexed on-demand playback session. Closing Results mode explicitly removes the samples and restart checkpoint from the current session and unlocks model editing; a saved copy containing results can restore them later.

Completed-result playback follows a wall-clock playhead rather than creating one timer for every stored sample. Numeric playback rates are literal: 1× advances one simulated second per wall-clock second. When a result completes, the UI selects 1× for durations through 300 seconds, 2× through 600 seconds, 5× through 1,800 seconds and 10× for longer results. Automatic selection is therefore never below 1× or above 10×. This presentation control remains independent from engine pacing.

The bounded renderer projection does not limit active playback cadence. While playing, the renderer advances its wall-clock playhead at a preferred 10 frames per second and requests the nearest exact full-resolution stored sample from the main process. The playhead remains time-driven, so faster rates naturally skip recorded samples instead of slowing playback to render every value. Visible state updates are limited by this presentation cadence, the configured output interval and IPC response time; no interpolated numerical values are invented.

There is intentionally no user-facing standalone result-file workflow yet, in beta.
