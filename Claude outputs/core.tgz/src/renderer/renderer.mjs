/* Copyright © 2026 Zenin Easa Panthakkalakath */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { DragControls } from 'three/addons/controls/DragControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import 'mathlive';
import { DocumentController } from './documentController.mjs';
import { parseScheduleText, scheduleError, scheduleSummary, scheduleText } from '../parameterSchedule.mjs';
import { fmiImplementation, freeKey, nodeProgramErrors, nodeProgramInputCandidates, nodeProgramInputValue } from '../nodeProgram.mjs';
import { meshFromArrays, partProblems, triangleCount } from '../meshParts.mjs';
import { pluginProviderChoices, pluginProviderValue } from '../pluginProviders.mjs';
import {
    latexForBinding,
    reconcileEquationBindings,
    timeBinding,
    validateEquationLatex
} from '../equationModel.mjs';
import {
    checkSeveralEquations,
    compileSeveralEquations,
    equationCandidates,
    isSeveralEquations,
    moved,
    newDefinitionSymbol,
    nextFreeOutput,
    severalFromSingle,
    singleFromSeveral
} from '../relationshipEquations.mjs';
import {
    causalMappingCreateValue,
    causalMappingValue,
    equationOutputValue,
    pacingFromValue,
    parseCausalMappingValue,
    parseEquationOutput,
    parseProviderReference,
    providerReferenceValue
} from '../selectValues.mjs';
import { validateProjectPassword } from './passwordValidation.mjs';
import { defaultNodeProviderSource, defaultProviderSource, replayProviderSource } from '../providerTemplate.mjs';
import { describeAssistantProgress } from '../assistantProgress.mjs';
import { targetTimeIsReachable, validateRunConfigurationValues } from './runConfigurationValidation.mjs';
import { describeOutdated, heldBackSentence, heldBackText, incompatibleText, installedTypeLabels, outdatedCountsByType, outdatedEntries, summarizeUpdateAll, updatePlan } from './extensionUpdates.mjs';
import { stateValueText } from './valueFormat.mjs';
import { declutterAbove, declutterLabels } from './labelDeclutter.mjs';
import { canvasFog, eligibleEndpointIds, farPlaneFor, fogDensityFor, labelElementOf, virtualKeyboardInset } from './viewportLayout.mjs';
import { groupRelationshipBundles } from '../relationshipBundles.mjs';
import { nearestSampleIndex, nodeResultSeries, renderMeasuredVsSimulatedComparison, resultSeriesForStateIds, ResultPlot } from './resultPlot.mjs';
import { suggestedPlaybackRate } from '../resultSession.mjs';
import { seriesToCsv } from '../resultExport.mjs';
import { generateStandaloneProgram } from '../codeExport.mjs';
import { createGraphFragment, remapGraphFragment, validateGraphFragment } from '../graphClipboard.mjs';
import { deriveSubsystemPorts, executionProjectDocument, hydrateSubsystems } from '../subsystems.mjs';
import {
    expandEdgeGroup,
    hydrateEdgeGroups,
    resolveGroupEdgeForPair,
    stripEdgeGroups,
    unresolvedGroupSymbols
} from '../edgeGroups.mjs';
import { applyAssistantProposal as buildAssistantProposal } from '../assistantOperations.mjs';
import { detectInstabilityFingerprint, recommendedSubstepFixProposal } from '../instabilityFingerprint.mjs';
import { mapColumnsToNodes, parseCsv, suggestSymbol } from '../csvImport.mjs';
import {
    CSS2DObject,
    CSS2DRenderer
} from 'three/addons/renderers/CSS2DRenderer.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
}[character]));
const modelSymbolPattern = /^[a-z][A-Za-z0-9]*$/;
const isMac = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
// The Alt key as each platform names it, for shortcut hints: Option (⌥) on a Mac.
const altKeyLabel = isMac ? '⌥' : 'Alt+';

// Backstop so any console.error/console.warn -- including ones nobody has wired up to a
// dedicated UI element -- still reaches the user via the quiet diagnostics badge/panel below,
// instead of only a devtools console most users never open.
const diagnosticsEntries = [];
const diagnosticsSeenIds = new Set();
let diagnosticsUnseenCount = 0;
let diagnosticsNextLocalId = -1;

function formatConsoleArgs(args) {
    return args.map((arg) => (
        arg instanceof Error ? (arg.stack || arg.message)
            : (typeof arg === 'string' ? arg : (() => { try { return JSON.stringify(arg); } catch { return String(arg); } })())
    )).join(' ');
}

function addDiagnosticsEntry(entry) {
    if (diagnosticsSeenIds.has(entry.id)) return;
    diagnosticsSeenIds.add(entry.id);
    diagnosticsEntries.unshift(entry);
    if (diagnosticsEntries.length > 200) diagnosticsEntries.pop();
    diagnosticsUnseenCount += 1;
    renderDiagnosticsBadge();
    if (!$('#diagnosticsPanel').classList.contains('hidden')) renderDiagnosticsList();
}

function renderDiagnosticsBadge() {
    const badge = $('#diagnosticsBadge');
    badge.hidden = diagnosticsUnseenCount === 0;
    badge.textContent = diagnosticsUnseenCount > 99 ? '99+' : String(diagnosticsUnseenCount);
}

function renderDiagnosticsList() {
    const container = $('#diagnosticsList');
    container.innerHTML = '';
    if (!diagnosticsEntries.length) {
        const empty = document.createElement('p');
        empty.className = 'diagnosticsEmpty';
        empty.textContent = 'No issues logged.';
        container.appendChild(empty);
        return;
    }
    for (const entry of diagnosticsEntries) {
        const row = document.createElement('div');
        row.className = `diagnosticsEntry diagnosticsEntry-${entry.severity}`;
        const time = document.createElement('span');
        time.className = 'diagnosticsEntryTime';
        time.textContent = new Date(entry.timestamp).toLocaleTimeString();
        const message = document.createElement('span');
        message.className = 'diagnosticsEntryMessage';
        message.textContent = entry.message;
        row.append(time, message);
        container.appendChild(row);
    }
}

const originalConsoleError = console.error.bind(console);
const originalConsoleWarn = console.warn.bind(console);
console.error = (...args) => {
    originalConsoleError(...args);
    addDiagnosticsEntry({ id: diagnosticsNextLocalId--, severity: 'error', message: formatConsoleArgs(args), timestamp: Date.now() });
};
console.warn = (...args) => {
    originalConsoleWarn(...args);
    addDiagnosticsEntry({ id: diagnosticsNextLocalId--, severity: 'warning', message: formatConsoleArgs(args), timestamp: Date.now() });
};
window.diagnostics?.list().then((entries) => entries.forEach(addDiagnosticsEntry));
window.diagnostics?.onIssue(addDiagnosticsEntry);

// Mirrors the diagnostics badge's pull-then-push pattern above: restartPending() covers a window
// opened after the flag was already set in another window, onRestartPendingChange covers it
// changing while this window stays open. Never cleared client-side -- only an actual restart does.
function renderRestartPending(pending) {
    $('#extensionsRestartBadge').hidden = !pending;
    $('#extensionsRestartPendingNotice').hidden = !pending;
}
window.extensions?.restartPending().then(renderRestartPending);
window.extensions?.onRestartPendingChange(renderRestartPending);
// Badge the Extensions button with available updates without waiting for the dialog to be opened
// (see ensurePackageUpdates/renderPackageUpdatesBadge below). Deferred past startup so it never
// competes with the window's own first load, and cached main-process side so extra windows don't
// repeat the GitHub calls. Advisory only -- a failure just leaves the badge hidden.
setTimeout(() => {
    if (window.extensions?.checkUpdates) ensurePackageUpdates().catch(() => {});
}, 5000);
$('#extensionsRestartNow').addEventListener('click', () => window.applicationInfo.restart());
const defaultWorkerThreads = Math.max(1, Math.min(256, Number(navigator.hardwareConcurrency) || 1));
let nextModelEntityId = 1;
const validModelEntityId = (value) => Number.isSafeInteger(value) && value > 0;
const allocateModelEntityId = () => nextModelEntityId++;
const normalizeExecutionConfiguration = (execution = {}) => ({
    backend: ['automatic', 'serial', 'threadPool', 'partitioned'].includes(execution.backend) ? execution.backend : 'automatic',
    partitionAlgorithm: ['automatic', 'metisKway', 'communicationAwareGreedy'].includes(execution.partitionAlgorithm)
        ? execution.partitionAlgorithm : 'automatic',
    workerThreads: Math.max(1, Math.min(256, Math.round(Number(execution.workerThreads) || defaultWorkerThreads))),
    partitionCount: Math.max(1, Math.min(256, Math.round(Number(execution.partitionCount) || defaultWorkerThreads))),
    partitionCommunicationBias: Math.max(0, Number.isFinite(Number(execution.partitionCommunicationBias))
        ? Number(execution.partitionCommunicationBias) : 4),
    automaticParallelThreshold: Math.max(1, Math.min(1000000, Math.round(Number(execution.automaticParallelThreshold) || 128))),
    automaticMaximumPartitionCutFraction: Math.max(0, Math.min(1,
        Number.isFinite(Number(execution.automaticMaximumPartitionCutFraction))
            ? Number(execution.automaticMaximumPartitionCutFraction) : 0.25))
});
const defaultRunConfiguration = () => ({
    id: allocateModelEntityId(), name: 'Default', globalTimeStep: 0.01, outputInterval: 0.1,
    execution: normalizeExecutionConfiguration()
});

const canvas = $('#canvas');
const webglContainer = $('#webglContainer');
const css2dContainer = $('#css2dContainer');

function setupVirtualKeyboardLayout() {
    const keyboard = window.mathVirtualKeyboard;
    if (!keyboard) return;

    const updateInset = (event) => {
        const visible = event?.type === 'virtual-keyboard-toggle'
            ? Boolean(event.detail?.visible)
            : Boolean(keyboard.visible);
        const bounds = event?.detail?.boundingRect ?? keyboard.boundingRect;
        const inset = virtualKeyboardInset(window.innerHeight, bounds, visible);
        document.documentElement.style.setProperty('--math-keyboard-inset', `${inset}px`);
        if (!inset) return;
        requestAnimationFrame(() => {
            const activeEquation = $$('.equationMathField').find((field) => field.matches(':focus-within'));
            activeEquation?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
        });
    };

    keyboard.addEventListener('geometrychange', updateInset);
    keyboard.addEventListener('virtual-keyboard-toggle', updateInset);
    window.addEventListener('resize', updateInset);
}

customElements.whenDefined('math-field').then(setupVirtualKeyboardLayout);

function geometryFromDocument(mesh) {
    if (!mesh?.position?.length) return null;
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(mesh.position, 3));
    if (mesh.normal?.length) geometry.setAttribute('normal', new THREE.Float32BufferAttribute(mesh.normal, 3));
    else geometry.computeVertexNormals();
    if (mesh.index?.length) geometry.setIndex(mesh.index);
    geometry.computeBoundingBox();
    geometry.computeBoundingSphere();
    return geometry;
}

function hydrateProjectDocument(document) {
    if (document?.format !== 'konjugate' || document.version !== 1) {
        throw new Error('This is not a supported Konjugate project document.');
    }
    if (!Array.isArray(document.nodes) || !Array.isArray(document.edges)) {
        throw new Error('The project must contain node and edge arrays.');
    }
    const ids = new Set();
    const nodeIds = new Set();
    const stateIdsByNode = new Map();
    nextModelEntityId = 1;
    const registerId = (id, message) => {
        if (!validModelEntityId(id) || ids.has(id)) throw new Error(message);
        ids.add(id);
        nextModelEntityId = Math.max(nextModelEntityId, id + 1);
    };
    // Project-level shared parameters: one definition that relationship and source-term parameters
    // link to (sharedParameterId), so a single value or live control drives all of them.
    const sharedParameters = (document.sharedParameters ?? []).map((shared) => {
        registerId(shared.id, 'Every shared parameter must have a unique positive integer id.');
        if (!modelSymbolPattern.test(shared.symbol)) throw new Error(`Shared parameter “${shared.name ?? shared.id}” needs a lower camel case symbol.`);
        if (!['constant', 'live'].includes(shared.mode)) throw new Error(`Shared parameter “${shared.name ?? shared.id}” mode must be constant or live.`);
        return { ...structuredClone(shared), value: Number(shared.value) || 0 };
    });
    document.nodes.forEach((node) => {
        registerId(node.id, 'Every node must have a unique positive integer id.');
        nodeIds.add(node.id);
        const stateIds = new Set();
        const stateSymbols = new Set();
        (node.states ?? []).forEach((state) => {
            registerId(state.id, `Every state in “${node.name ?? node.id}” must have a unique positive integer id.`);
            stateIds.add(state.id);
            if (!modelSymbolPattern.test(state.symbol) || stateSymbols.has(state.symbol)) {
                throw new Error(`State symbols in “${node.name ?? node.id}” must be unique lower camel case identifiers.`);
            }
            stateSymbols.add(state.symbol);
        });
        (node.sourceTerms ?? []).forEach((term) => {
            registerId(term.id, `Every source term in “${node.name ?? node.id}” must have a unique positive integer id.`);
            if (!stateSymbols.has(term.state)) {
                throw new Error(`A source term in “${node.name ?? node.id}” references a missing state symbol.`);
            }
            const parameterSymbols = new Set();
            (term.parameters ?? []).forEach((parameter) => {
                registerId(parameter.id, `Every source-term parameter in “${node.name ?? node.id}” must have a unique positive integer id.`);
                if (!modelSymbolPattern.test(parameter.symbol) || parameterSymbols.has(parameter.symbol)) {
                    throw new Error(`Source-term parameter symbols in “${node.name ?? node.id}” must be unique lower camel case identifiers.`);
                }
                if (!['constant', 'live'].includes(parameter.mode)) throw new Error('Source-term parameter mode must be constant or live.');
                parameterSymbols.add(parameter.symbol);
            });
        });
        stateIdsByNode.set(node.id, stateIds);
    });
    const subsystems = hydrateSubsystems(document, registerId);
    // Registered before the edges loop below: a group's shared parameters are registered exactly
    // once here, against the group's own definition, so a member edge's own copy of those same
    // parameter ids (see edgeGroups.mjs) is recognized and skipped rather than rejected as a
    // duplicate.
    const edgeGroups = hydrateEdgeGroups(document, registerId);
    document.edges.forEach((edge) => {
        registerId(edge.id, 'Every edge must have a unique positive integer id.');
        if (!nodeIds.has(edge.source?.nodeId) || !nodeIds.has(edge.target?.nodeId)) {
            throw new Error(`Edge “${edge.name ?? edge.id}” references a missing node.`);
        }
        if (edge.source.stateId && !stateIdsByNode.get(edge.source.nodeId)?.has(edge.source.stateId)) {
            throw new Error(`Edge “${edge.name ?? edge.id}” references a missing source state.`);
        }
        if (edge.target.stateId && !stateIdsByNode.get(edge.target.nodeId)?.has(edge.target.stateId)) {
            throw new Error(`Edge “${edge.name ?? edge.id}” references a missing target state.`);
        }
        if (edge.groupId != null) return;
        const parameterSymbols = new Set();
        (edge.parameters ?? []).forEach((parameter) => {
            registerId(parameter.id, `Every parameter in “${edge.name ?? edge.id}” must have a unique positive integer id.`);
            if (!modelSymbolPattern.test(parameter.symbol) || parameterSymbols.has(parameter.symbol)) {
                throw new Error(`Parameter symbols in “${edge.name ?? edge.id}” must be unique lower camel case identifiers.`);
            }
            if (!['constant', 'live'].includes(parameter.mode)) {
                throw new Error(`Parameter mode in “${edge.name ?? edge.id}” must be constant or live.`);
            }
            if (parameter.mode === 'live' && parameter.control && parameterControlError(Number(parameter.value), {
                minimum: Number(parameter.control.minimum),
                maximum: Number(parameter.control.maximum),
                step: Number(parameter.control.step)
            })) {
                throw new Error(`Live parameter slider settings in “${edge.name ?? edge.id}” are invalid.`);
            }
            parameterSymbols.add(parameter.symbol);
        });
    });
    (document.runConfigurations ?? []).forEach((configuration) => {
        registerId(configuration.id, 'Every run configuration must have a unique positive integer id.');
    });

    const linkedParameters = [
        ...document.edges.flatMap((edge) => edge.parameters ?? []),
        ...document.nodes.flatMap((node) => (node.sourceTerms ?? []).flatMap((term) => term.parameters ?? [])),
        ...document.nodes.flatMap((node) => nodeProviderParameterBindings(node).map((binding) => ({ ...binding, name: binding.key })))
    ].filter((parameter) => parameter.sharedParameterId !== undefined);
    for (const parameter of linkedParameters) {
        if (!sharedParameters.some((shared) => shared.id === parameter.sharedParameterId)) {
            throw new Error(`Parameter “${parameter.name ?? parameter.id}” links to a shared parameter that does not exist.`);
        }
    }

    const nodes = document.nodes.map((node) => {
        const appearance = node.appearance ?? {};
        const importedGeometry = appearance.type === 'mesh'
            ? geometryFromDocument(appearance.mesh)
            : null;
        return {
            id: node.id,
            title: node.name || 'Untitled node',
            type: node.type || 'Custom node',
            shape: importedGeometry ? 'imported' : appearance.shape || 'box',
            position: node.position?.length === 3 ? node.position : [0, 0, 0],
            rotation: node.rotation?.length === 3 ? node.rotation : [0, 0, 0],
            scale: node.scale?.length === 3 ? node.scale : [1, 1, 1],
            color: Number.parseInt(String(appearance.color ?? '#34727a').replace('#', ''), 16),
            importedGeometry,
            geometryFileName: appearance.fileName ?? null,
            badgeClass: '',
            subsystemId: node.subsystemId ?? null,
            deleted: false,
            enabled: node.enabled !== false,
            substepsPerGlobalStep: Math.max(1, Math.min(10000, Number(node.numerics?.substepsPerGlobalStep) || 1)),
            integration: node.numerics?.integration === 'semiImplicit' ? 'semiImplicit' : 'explicit',
            sourceTerms: (node.sourceTerms ?? []).map((term) => ({ ...term, parameters: term.parameters ?? [] })),
            // The node's own program: a computational-node provider, or an installed FMU's reference (edited under
            // Program in the node editor).
            implementation: node.implementation ? structuredClone(node.implementation) : null,
            // Parts of the node's shape, each a mesh in the frame of a body the node reports the pose of (a robot's
            // links, say): kept and handed to result visualizers, not drawn on the canvas.
            appearanceParts: Array.isArray(appearance.parts) ? structuredClone(appearance.parts) : null,
            states: (node.states ?? []).map((state) => ({
                id: state.id,
                label: state.name,
                symbol: state.symbol,
                initialValue: state.initialValue,
                unit: state.unit ?? '',
                value: stateValueText(state.initialValue, state.unit).text, exactValue: stateValueText(state.initialValue, state.unit).exact,
                className: ''
            }))
        };
    });
    const relationships = document.edges.map((edge) => ({
        id: edge.id,
        groupId: edge.groupId ?? null,
        title: edge.name || 'Untitled relationship',
        source: edge.source.nodeId,
        sourceStateId: edge.source.stateId ?? null,
        target: edge.target.nodeId,
        targetStateId: edge.target.stateId ?? null,
        directionality: edge.directionality ?? 'directed',
        equation: edge.equation ?? '',
        equationModel: edge.equationModel ?? {
            latex: edge.equation ?? '',
            output: { role: 'target', stateId: edge.target.stateId ?? null },
            bindings: [],
            mathJson: null
        },
        implementation: edge.implementation ?? null,
        parameters: edge.parameters ?? [],
        color: Number.parseInt(String(edge.appearance?.color ?? '#9c83c4').replace('#', ''), 16),
        offset: Number(edge.appearance?.offset) || 0,
        waypoints: Array.isArray(edge.appearance?.waypoints) ? edge.appearance.waypoints.map((point) => point.map(Number)) : [],
        deleted: false,
        enabled: edge.enabled !== false
    }));
    const runConfigurations = Array.isArray(document.runConfigurations) && document.runConfigurations.length
        ? document.runConfigurations.map((configuration) => ({
            id: configuration.id ?? allocateModelEntityId(),
            name: configuration.name || 'Untitled',
            globalTimeStep: Number(configuration.globalTimeStep) || 0.01,
            outputInterval: Number(configuration.outputInterval) || 0.1,
            execution: normalizeExecutionConfiguration(configuration.execution)
        }))
        : [defaultRunConfiguration()];
    return {
        metadata: { units: document.metadata?.units || 'SI' },
        runConfigurations,
        activeRunConfigurationId: runConfigurations.some((item) => item.id === document.activeRunConfigurationId)
            ? document.activeRunConfigurationId : runConfigurations[0].id,
        sharedParameters,
        nodes,
        relationships,
        subsystems,
        edgeGroups
    };
}

const emptyProjectDocument = {
    format: 'konjugate',
    version: 1,
    copyright: 'Copyright © 2026 Zenin Easa Panthakkalakath',
    metadata: { units: 'SI' },
    runConfigurations: [],
    sharedParameters: [],
    nodes: [],
    edges: [],
    subsystems: [],
    edgeGroups: []
};
const model = hydrateProjectDocument(emptyProjectDocument);
let currentProjectPath = null;
// Data launcher add-ons keep with the project ({ addonId: entry }; see docs/projectSchema.md). It sits beside the
// model rather than in it: it is read when a project is loaded and written when it is saved, and never reaches
// the engine, validation, copy and paste, or the undo history.
let projectAddonData = {};
// A launcher's session kept with the project since it was last saved or opened (see onKeepAddonData).
let addonDataUnsaved = false;
const addonDataOf = (document) => (document?.addonData && typeof document.addonData === 'object' && !Array.isArray(document.addonData) ? document.addonData : {});
let currentProjectFilename = 'untitled.kjt';
let currentProjectPassword = null;
let activeExampleId = null;

function filenameStem(fileName) {
    return fileName.replace(/\.kjt$/i, '');
}

function camelCaseFilename(value) {
    const words = value.trim().replace(/\.kjt$/i, '')
        .split(/[^A-Za-z0-9]+|(?=[A-Z])/).filter(Boolean);
    if (!words.length) return 'untitled.kjt';
    const stem = words.map((word, index) => {
        const lower = word.toLowerCase();
        return index ? `${lower.charAt(0).toUpperCase()}${lower.slice(1)}` : lower;
    }).join('');
    return `${stem}.kjt`;
}

function updateDocumentTitle() {
    $('.documentTitle').textContent = filenameStem(currentProjectFilename);
}

function updateEncryptionControls() {
    const encrypted = Boolean(currentProjectPassword);
    $('#encryptionStatus').hidden = !encrypted;
    $('#saveEncryptedButton').dataset.tooltip = encrypted ? 'Encryption options…' : 'Save encrypted…';
    $('#saveEncryptedButton').ariaLabel = encrypted ? 'Encryption options' : 'Save encrypted project';
}

updateDocumentTitle();
updateEncryptionControls();

const nodeObjects = new Map();
const relationshipObjects = new Map();
const subsystemObjects = new Map();
const nodePickTargets = [];
const relationshipPickTargets = [];

// Label detail per group: 'compact' (the default), 'expanded', or 'hidden'. A hidden label still shows
// while it is selected, hovered, flagged, pinned, or needed to pick an endpoint, so the canvas never
// hides what you are pointing at.
const labelModes = { nodes: 'compact', edges: 'compact' };
let hoveredNodeId = null;
let hoveredRelationshipId = null;
let labelSystemReady = false;
// The node labels left out because they would overlap another (labelDeclutter.mjs), on a model too large to show
// them all: by node id. A label that must stay is never among them.
const declutteredNodeIds = new Set();
const nodeLabelSizes = new Map();
const labelProbe = new THREE.Vector3();
let hoverFrame = null;
// Handles are pushed into nodePickTargets (not a separate DragControls instance) -- DragControls'
// internal _selected/_hovered/_plane state is module-scope, not per-instance, so two concurrent
// instances on the same domElement would race over it. Keyed by relationship id since only the
// selected relationship's waypoints get handles at all.
const waypointHandleObjects = new Map();
let selectedNode = null;
const selectedNodeIds = new Set();
let selectedRelationship = null;
let activeEdgeGroupId = null;
let activeSubsystemId = null;
let currentTool = 'select';
let currentView = 'orbit';
let is2DLocked = false;
const faceDirections = {
    front: new THREE.Vector3(0, 0, 1),
    back: new THREE.Vector3(0, 0, -1),
    right: new THREE.Vector3(1, 0, 0),
    left: new THREE.Vector3(-1, 0, 0),
    top: new THREE.Vector3(0, 1, 0),
    bottom: new THREE.Vector3(0, -1, 0)
};
let activeEndpointPick = null;
let endpointPickRestoreCard = null;
let endpointPickMaterialState = new Map();
// Set by applyEdgeTemplate to pick both endpoints from scratch (no node pre-selected) by chaining
// two single-endpoint picks -- the endpoint-pick mechanism itself is otherwise untouched.
let endpointPickContinuation = null;
let cameraAnimation = null;
let pendingImportedGeometry = null;
let pendingGeometryFileName = '';
let currentValidation = { valid: false, issues: [], executableModel: null };
let validationRevision = 0;
let engineValidationTimer = null;
let equationEditSession = null;
let providerEditTarget = null;
let selectedSourceTermNodeId = null;
let selectedSourceTermId = null;
let simulationRunning = false;
let activeResult = null;
let activeEngineJobId = null;
let activeResultPersistedInProject = false;
let liveParameterValues = new Map();
const liveParameterUpdateTimers = new Map();
let runLaunchSettings = {
    targetTime: 1,
    online: false,
    pacing: { mode: 'fastest', simulationSecondsPerWallSecond: 1 },
    stabilityMonitoring: true,
    // Numerics and execution chosen for this one run when it continues or forks a result: the model's
    // saved run configuration is left as it is. Null for an ordinary run, whose choices are saved.
    configurationOverride: null
};
let pendingRestart = null;
// A fork is structurally distinct from pendingRestart's "continue in place" flow: a fork must
// never prepend the parent's samples onto the child's (the child is a sibling branch starting
// fresh from its checkpoint's time), and the parent's ResultBranch record must stay untouched.
let pendingFork = null;
let forkOverrideValues = new Map();
// branches holds every known ResultBranch (the active one plus any parked/inactive siblings) so
// a fork's parent can remain immutable and browsable after the fork. Only the active branch's
// job is ever "live" -- see activateBranch's simulationRunning guard for why switching away from
// a still-running branch is deliberately blocked rather than silently dropping its updates.
let branches = new Map();
let activeBranchUuid = null;
// The project's validated dark-surface categorical palette (8 slots, fixed order -- assigned by
// creation order and never re-cycled by selection/rank, per the palette's own CVD-safety
// ordering). Passes every adjacent-pair gate for line-chart use against this app's actual panel
// surface (#091219); a 9th simultaneous branch folds back to slot 1 rather than generating a
// new hue, matching "a 9th series is never a generated hue."
const branchColors = ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767'];
let activeResultSampleIndex = 0;
let resultPlaybackTimer = null;
let resultPlaying = false;
let resultPlaybackStartedAt = 0;
let resultPlaybackStartedFrom = 0;
const preferredPlaybackFrameMilliseconds = 100;
let nodeDetailsBeforeResult = null;
let toolBeforeResult = null;
let addonRailContributions = [];
let pendingAssistantProposal = null;
let assistantPreviewRevision = 0;
let assistantGenerationController = null;
// Bounded conversation memory for the assistant panel: a compact { request, outcome } summary
// per turn (never the raw proposal JSON, to keep the payload small), capped at 5 and sent on
// every generateProposal call so "Revise proposal" and clarification replies have real context.
// pendingAssistantTurnRecord tracks (by reference, not index, so a later cap-trim can't shift
// it) the turn awaiting an outcome -- asked-but-not-answered, proposed-but-not-applied -- so its
// summary can be corrected in place once the user acts, rather than adding a second entry.
let assistantTurnHistory = [];
let pendingAssistantTurnRecord = null;
let assistantHasBeenPositioned = false;
let activeAssistantConfigurationUuid = null;
let assistantConfigurationCatalog = { configurations: [], providers: [], credentialStorage: null };
let assistantConfigurationBaseline = '';
let assistantDiscoveryTimer = null;
let assistantDiscoveryRevision = 0;
const nodeResultPlot = new ResultPlot($('#nodeResultPlot'), {
    onSeek: (time) => {
        if (!activeResult) return;
        stopResultPlayback();
        projectResultSample(nearestSampleIndex(activeResult.samples, time));
    }
});
const documentController = new DocumentController();

function updateHistoryControls() {
    $('#undoButton').disabled = Boolean(activeResult) || !documentController.canUndo;
    $('#redoButton').disabled = Boolean(activeResult) || !documentController.canRedo;
    // Fresh simulation results count as unsaved work (the same test the discard prompts use), so the
    // titlebar Save stays usable for them even when the model itself is clean.
    const unsaved = documentController.dirty || Boolean(activeResult && !activeResultPersistedInProject) || addonDataUnsaved;
    $('#saveButton').disabled = !unsaved && currentProjectPath !== null;
    $('.windowTitle i').style.visibility = unsaved ? 'visible' : 'hidden';
    updateSelectionActionControls();
}

function updateSelectionActionControls() {
    const locked = Boolean(activeResult);
    $('#copySelection').disabled = locked || !selectedNodeIds.size;
    $('#createSubsystem').disabled = locked || !selectedNodeIds.size;
    $('#createEdgeGroup').disabled = locked || selectedNodeIds.size < 2;
    $('[data-action="delete"]').disabled = locked || (!selectedNodeIds.size && !selectedRelationship);
    let canPaste = false;
    if (!locked) {
        try {
            canPaste = validateGraphFragment(window.modelClipboard.read());
        } catch {
            canPaste = false;
        }
    }
    $('#pasteSelection').disabled = !canPaste;
}

function recordHistory(action) {
    if (activeResult) return false;
    documentController.record(action);
    return true;
}

function undo() {
    if (activeResult) return;
    finishEquationEdit();
    clearSelection();
    hideCards();
    documentController.undo();
}

function redo() {
    if (activeResult) return;
    finishEquationEdit();
    clearSelection();
    hideCards();
    documentController.redo();
}

documentController.subscribe(updateHistoryControls);

function initializeWindowControls() {
    const updateUiZoomControls = (factor = window.uiZoom.get()) => {
        const percent = Math.round(factor * 100);
        $('#zoomOutButton').disabled = factor <= window.uiZoom.limits.minimum;
        $('#zoomInButton').disabled = factor >= window.uiZoom.limits.maximum;
        $('#zoomOutButton').dataset.tooltip = `Zoom interface out · ${percent}%`;
        $('#zoomInButton').dataset.tooltip = `Zoom interface in · ${percent}%`;
    };
    $('#zoomOutButton').addEventListener('click', () => updateUiZoomControls(window.uiZoom.decrease()));
    $('#zoomInButton').addEventListener('click', () => updateUiZoomControls(window.uiZoom.increase()));
    updateUiZoomControls();
    $('#minimizeButton').addEventListener('click', () => window.windowControls.minimize());
    $('#maximizeButton').ariaLabel = isMac ? 'Enter full screen' : 'Maximize';
    $('#maximizeButton').dataset.tooltip = isMac ? 'Enter full screen' : 'Maximize';
    $('#maximizeButton').addEventListener('click', () => window.windowControls.toggleMaximize());
    $('#closeButton').addEventListener('click', async () => {
        if ((documentController.dirty || (activeResult && !activeResultPersistedInProject) || addonDataUnsaved) &&
            !await window.projectFiles.confirmDiscard()) return;
        window.windowControls.close();
    });
    window.windowControls.onMaximizedChange((maximized) => {
        $('#maximizeIcon').textContent = maximized ? '❐' : '□';
        $('#maximizeButton').ariaLabel = isMac
            ? `${maximized ? 'Exit' : 'Enter'} full screen`
            : `${maximized ? 'Restore' : 'Maximize'} window`;
        $('#maximizeButton').dataset.tooltip = $('#maximizeButton').ariaLabel;
    });
}

initializeWindowControls();

// The Konjugate button shows the version, and a quiet dot when an update is available (see
// src/updateCoordinator.mjs and docs/updates.md). Absent in the web edition, which has no app to update.
let runningVersion = '';
let updateStatus = null;
function refreshWelcomeButton() {
    const showBadge = Boolean(updateStatus?.badge);
    $('#appUpdateBadge').hidden = !showBadge;
    $('#welcomeButton').dataset.tooltip = showBadge ? `Konjugate ${updateStatus.latest.version} is available` : `Konjugate · version ${runningVersion}`;
    $('#welcomeButton').ariaLabel = showBadge ? `Konjugate, version ${updateStatus.latest.version} is available` : 'Konjugate';
}
window.applicationInfo.get().then(({ version }) => {
    runningVersion = version;
    refreshWelcomeButton();
});
window.appUpdate?.status().then((status) => {
    updateStatus = status;
    refreshWelcomeButton();
});
window.appUpdate?.onChange((status) => {
    updateStatus = status;
    refreshWelcomeButton();
});
$('#welcomeButton').addEventListener('click', () => window.applicationInfo.openWelcome());

const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x0a131b, canvasFog.density);

const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 300);
camera.position.set(0, 7.5, 19);

const renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: true,
    powerPreference: 'high-performance'
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.35;
renderer.domElement.className = 'webglSurface';
renderer.domElement.tabIndex = 0;
renderer.domElement.ariaLabel = '3D model canvas';
webglContainer.appendChild(renderer.domElement);

const labelRenderer = new CSS2DRenderer();
labelRenderer.domElement.className = 'css2dSurface';
css2dContainer.appendChild(labelRenderer.domElement);

const orbitControls = new OrbitControls(camera, renderer.domElement);
orbitControls.enableDamping = true;
orbitControls.dampingFactor = 0.07;
orbitControls.minDistance = 8;
orbitControls.maxDistance = 5000;
orbitControls.zoomToCursor = true;
orbitControls.target.set(0, -0.7, 0);
orbitControls.listenToKeyEvents(renderer.domElement);

const transformControls = new TransformControls(camera, renderer.domElement);
transformControls.setMode('translate');
transformControls.setSpace('world');
transformControls.size = 0.72;
transformControls.enabled = false;
scene.add(transformControls.getHelper());
transformControls.addEventListener('dragging-changed', (event) => {
    orbitControls.enabled = !event.value;
});
// Tracks live Shift state from real pointer events (TransformControls' own objectChange event
// carries no native browser event to read .shiftKey from). An earlier attempt intercepted
// TransformControls' *hover* handling instead, forcing its internal `axis` to 'XYZ' (the name
// of its own centre-cube uniform-scale handle) whenever Shift was held while hovering a scale
// handle. That looked right in isolation, but broke for two real reasons: TransformControls
// re-resolves `axis` from a fresh raycast on pointerdown itself, not only on hover, silently
// reverting the override right as a drag started and leaving its internal drag-plane
// orientation stale against the axis it reverted to (Shift-before-click did nothing useful);
// and since the override only ran on hover, Shift pressed after a drag had already begun was
// never picked up at all (Shift-during-drag did nothing). Reading Shift fresh on every drag
// movement instead, and computing the uniform scale here rather than steering
// TransformControls' own internal state, works regardless of which handle started the drag or
// when Shift is pressed or released during it.
let shiftKeyHeld = false;
renderer.domElement.addEventListener('pointermove', (event) => {
    shiftKeyHeld = event.shiftKey;
});
// Same distance-ratio formula TransformControls' own centre-cube 'XYZ' handle uses internally
// (pointStart/pointEnd are the local-space drag-start and current pointer positions it already
// maintains for whichever handle was actually grabbed), so a Shift-held drag feels the same as
// dragging that handle directly, whatever handle the pointer is actually on.
function uniformScaleFactorForDrag() {
    const startLength = transformControls.pointStart.length();
    if (startLength === 0) return 1;
    const factor = transformControls.pointEnd.length() / startLength;
    return transformControls.pointEnd.dot(transformControls.pointStart) < 0 ? -factor : factor;
}
// position and scale are THREE.Vector3 (support clone/add/sub/equals/copy directly); rotation is
// a THREE.Euler, which doesn't share that API. Reading/writing through plain [x,y,z] arrays lets
// the same drag-tracking code below work for whichever of the three the active tool drives,
// rather than duplicating this whole start/drag/commit sequence three times.
const transformPropertyForTool = { move: 'position', rotate: 'rotation', scale: 'scale' };
function readXYZ(vectorLike) {
    return [vectorLike.x, vectorLike.y, vectorLike.z];
}
// Rotating a multi-node selection also needs to capture/restore each other node's position
// (revolved around the pivot -- see the objectChange handler below), on top of whichever
// property the active tool itself drives. Applied uniformly to every selected node including
// the dragged one is harmless: the dragged node's own position never changes during a rotate
// drag (TransformControls' rotate mode only ever touches quaternion), so its captured start and
// end position are always identical.
function capturedProperties(property) {
    return property === 'rotation' && selectedNodeIds.size > 1 ? [property, 'position'] : [property];
}
function snapshotNode(id, properties) {
    const node = nodeObjects.get(id);
    return Object.fromEntries(properties.map((prop) => [prop, readXYZ(node[prop])]));
}

function changeNodeTransform(node, property, values) {
    if (activeResult) return;
    const before = readXYZ(node[property]);
    if (before.every((value, index) => value === values[index])) return;
    const applyValues = (value) => {
        node[property].set(...value);
        updateRelationships();
        updateSelectionOutline();
    };
    applyValues(values);
    recordHistory({ undo: () => applyValues(before), redo: () => applyValues(values) });
}

// Keeps the Appearance tab's rotation/scale number inputs in sync with the live mesh -- called
// both when the node editor opens and continuously while a rotate/scale gizmo drag is in
// progress, so the two ways of setting these values (precise typing vs. dragging) never show
// stale numbers to each other.
function refreshNodeTransformFields(node) {
    const [rx, ry, rz] = readXYZ(node.rotation).map((radians) => Math.round(THREE.MathUtils.radToDeg(radians) * 100) / 100);
    $('#editNodeRotationX').value = rx;
    $('#editNodeRotationY').value = ry;
    $('#editNodeRotationZ').value = rz;
    const [sx, sy, sz] = readXYZ(node.scale);
    $('#editNodeScaleX').value = sx;
    $('#editNodeScaleY').value = sy;
    $('#editNodeScaleZ').value = sz;
}

transformControls.addEventListener('objectChange', () => {
    const object = transformControls.object;
    const property = transformPropertyForTool[currentTool] ?? 'position';
    if (object && property === 'scale' && shiftKeyHeld) {
        const start = transformStartValues?.get(object.userData.id)?.scale;
        if (start) {
            const factor = uniformScaleFactorForDrag();
            object.scale.set(start[0] * factor, start[1] * factor, start[2] * factor);
        }
    }
    if (object && property === 'rotation' && transformLastQuaternion && selectedNodeIds.size > 1) {
        // Revolve each other selected node's position around the pivot (the dragged node's own
        // position, fixed for the whole drag -- TransformControls' rotate mode only ever
        // touches quaternion, never position) by this frame's incremental rotation, and spin
        // its own orientation by the same amount, so the whole selection turns together as a
        // rigid body instead of each node spinning in place around its own centre. Derived from
        // the actual change in the dragged node's quaternion between frames, rather than
        // approximated from Euler-angle deltas the way the position/scale broadcast below does,
        // since that stays exact however many Euler components a given drag ends up touching at
        // once, and composes correctly across many frames without drifting.
        const deltaQuaternion = object.quaternion.clone().multiply(transformLastQuaternion.clone().invert());
        const pivot = object.position;
        selectedNodeIds.forEach((id) => {
            if (id === object.userData.id) return;
            const other = nodeObjects.get(id);
            if (!other) return;
            const offset = other.position.clone().sub(pivot).applyQuaternion(deltaQuaternion);
            other.position.copy(pivot).add(offset);
            other.quaternion.premultiply(deltaQuaternion);
        });
        transformLastQuaternion.copy(object.quaternion);
    } else if (object && transformLastValue && selectedNodeIds.size > 1) {
        const current = readXYZ(object[property]);
        const delta = current.map((value, index) => value - transformLastValue[index]);
        selectedNodeIds.forEach((id) => {
            if (id === object.userData.id) return;
            const other = nodeObjects.get(id)?.[property];
            if (other) other.set(...readXYZ(other).map((value, index) => value + delta[index]));
        });
        transformLastValue = current;
    }
    updateRelationships();
    updateSelectionOutline();
    if (object && object === selectedNode && !$('#nodeEditor').classList.contains('hidden')) refreshNodeTransformFields(object);
});
let transformStartValues = null;
let transformLastValue = null;
let transformLastQuaternion = null;
transformControls.addEventListener('mouseDown', () => {
    const object = transformControls.object;
    const property = transformPropertyForTool[currentTool] ?? 'position';
    const properties = capturedProperties(property);
    transformStartValues = object ? new Map([...selectedNodeIds].map((id) => [id, snapshotNode(id, properties)])) : null;
    transformLastValue = object ? readXYZ(object[property]) : null;
    transformLastQuaternion = object && property === 'rotation' ? object.quaternion.clone() : null;
});
transformControls.addEventListener('mouseUp', () => {
    const object = transformControls.object;
    const property = transformPropertyForTool[currentTool] ?? 'position';
    const startValue = object && transformStartValues?.get(object.userData.id)?.[property];
    const endValue = object && readXYZ(object[property]);
    if (!object || !startValue || startValue.every((value, index) => value === endValue[index])) {
        transformStartValues = null;
        transformLastValue = null;
        transformLastQuaternion = null;
        return;
    }
    const properties = capturedProperties(property);
    const from = new Map(transformStartValues);
    const to = new Map([...selectedNodeIds].map((id) => [id, snapshotNode(id, properties)]));
    const applyValues = (snapshotMap) => {
        snapshotMap.forEach((snapshot, id) => {
            const node = nodeObjects.get(id);
            if (!node) return;
            Object.entries(snapshot).forEach(([prop, value]) => node[prop].set(...value));
        });
        updateRelationships();
        updateSelectionOutline();
    };
    recordHistory({
        undo: () => applyValues(from),
        redo: () => applyValues(to)
    });
    transformStartValues = null;
    transformLastValue = null;
    transformLastQuaternion = null;
});

// Debug/test hook only; not part of the app's public surface (same pattern as
// window.__relationshipScreenPoint further down). Exposes the transform-tool state and a way
// to simulate a gizmo drag by dispatching
// TransformControls' own mouseDown/objectChange/mouseUp events directly, so interaction tests
// can exercise the rotate/scale/move commit-and-undo path without needing real pointer
// coordinates on the 3D gizmo's own handle geometry.
// The document the canvas would save, for the interaction tests to check what it keeps.
// `load` opens a project document in this window, as opening a file does, so a test can start from a model of its own
// in either edition (the web edition has no OS file open).
window.__debugProject = {
    serialize: () => serializeProjectDocument(),
    load: (document, fileName = 'test.kjt') => loadProjectDocument(structuredClone(document), { fileName })
};

window.__debugTransform = {
    mode: () => transformControls.getMode(),
    attachedId: () => transformControls.object?.userData.id ?? null,
    selectedId: () => selectedNode?.userData.id ?? null,
    simulateDragTo: (x, y, z) => {
        transformControls.dispatchEvent({ type: 'mouseDown' });
        transformControls.object[transformPropertyForTool[currentTool] ?? 'position'].set(x, y, z);
        transformControls.dispatchEvent({ type: 'objectChange' });
        transformControls.dispatchEvent({ type: 'mouseUp' });
    },
    nodeTransform: (id, property) => {
        const object = nodeObjects.get(id);
        return object ? [object[property].x, object[property].y, object[property].z] : null;
    },
    allNodeIds: () => [...nodeObjects.keys()],
    // Adds a node to the selection the same way a real Shift-click does (selectNode's own
    // additive path), without needing a real screen-coordinate mouse event -- which handle or
    // label ends up under the cursor for a Shift-click is a real-mouse/CSS2D-layout concern the
    // existing multi-selection copy/paste test already covers; this app's own group-transform
    // math is what a multi-select rotate/scale test actually needs a multi-selection *for*.
    selectAdditive: (id) => {
        const node = nodeObjects.get(id);
        if (node) selectNode(node, { additive: true });
    },
    // Replaces the whole selection with exactly these nodes, in this order (the order a bundle
    // reads as its tie-break when several assignments of nodes to endpoints would fit).
    selectExactly: (ids) => {
        clearSelection();
        ids.forEach((id) => {
            const node = nodeObjects.get(id);
            if (node) selectNode(node, { additive: true });
        });
    },
    // A lower-level, multi-step alternative to simulateDragTo for exercising the real
    // Shift-uniform-scale override in objectChange: mouseDown captures transformStartValues as
    // usual, then each move step can set the object's scale directly (standing in for whatever
    // per-axis math a real single-axis or corner-handle drag would have produced) and/or set
    // TransformControls' own pointStart/pointEnd (which is all uniformScaleFactorForDrag reads)
    // before dispatching objectChange with a chosen Shift state -- so a test can drive multiple
    // movement steps with Shift toggled on or off between them, the same way a real drag would,
    // without needing real screen coordinates raycast against the gizmo's handle geometry.
    scaleDrag: {
        mouseDown: () => transformControls.dispatchEvent({ type: 'mouseDown' }),
        move: ({ manualScale, pointStart, pointEnd, shiftHeld = false } = {}) => {
            if (manualScale) transformControls.object.scale.set(...manualScale);
            if (pointStart) transformControls.pointStart.set(...pointStart);
            if (pointEnd) transformControls.pointEnd.set(...pointEnd);
            shiftKeyHeld = shiftHeld;
            transformControls.dispatchEvent({ type: 'objectChange' });
            return readXYZ(transformControls.object.scale);
        },
        mouseUp: () => {
            transformControls.dispatchEvent({ type: 'mouseUp' });
            shiftKeyHeld = false;
        }
    }
};

scene.add(new THREE.HemisphereLight(0xbfe4f2, 0x16212a, 2.25));

const keyLight = new THREE.DirectionalLight(0xfff0d6, 3.2);
keyLight.position.set(7, 11, 9);
scene.add(keyLight);

const rimLight = new THREE.DirectionalLight(0x65d6db, 2.1);
rimLight.position.set(-8, 4, -7);
scene.add(rimLight);

const floor = new THREE.GridHelper(32, 32, 0x31505a, 0x1c3039);
floor.position.y = -4.8;
floor.material.transparent = true;
floor.material.opacity = 0.22;
scene.add(floor);

function geometryFor(definition) {
    if (definition.importedGeometry) return definition.importedGeometry.clone();
    if (definition.shape === 'cylinder') return new THREE.CylinderGeometry(1.15, 1.15, 2.9, 32);
    if (definition.shape === 'sphere') return new THREE.SphereGeometry(1.05, 32, 24);
    return new THREE.BoxGeometry(2.8, 1.8, 1.8, 2, 1, 1);
}

// A disabled node/edge stays fully present in the model and the saved file -- unlike delete, it
// is never dropped from serializeProjectDocument() -- but the engine treats it exactly as if it
// had been deleted (see compileExecutionPlan/validateModel). This blend is the visual half:
// muted toward grey and slightly transparent, so "disabled" reads clearly without hiding it.
function disabledDisplayColor(color) {
    return new THREE.Color(color).lerp(new THREE.Color(0x74808a), 0.65).getHex();
}

// An edge is effectively disabled -- and rendered as such -- if it is disabled itself, or if
// either endpoint node is, even though the edge's own `enabled` stays untouched in that case.
// Re-enabling the node alone is enough to bring every edge on it back, with no per-edge cleanup.
function isEdgeEffectivelyEnabled(edge) {
    if (edge.enabled === false) return false;
    const sourceNode = model.nodes.find((node) => node.id === edge.source);
    const targetNode = model.nodes.find((node) => node.id === edge.target);
    return sourceNode?.enabled !== false && targetNode?.enabled !== false;
}

function materialFor(definition) {
    const enabled = definition.enabled !== false;
    return new THREE.MeshStandardMaterial({
        color: enabled ? definition.color : disabledDisplayColor(definition.color),
        metalness: 0.2,
        roughness: 0.42,
        transparent: !enabled,
        opacity: enabled ? 1 : 0.55
    });
}

function nodeLabelOffset(geometry) {
    geometry.computeBoundingBox();
    const bounds = geometry.boundingBox;
    const height = bounds.max.y - bounds.min.y;
    return [
        bounds.max.x + 0.08,
        (bounds.min.y + bounds.max.y) / 2 + height * 0.24,
        (bounds.min.z + bounds.max.z) / 2
    ];
}

function createNodeLabel(definition, geometry) {
    const wrapper = document.createElement('div');
    wrapper.className = 'node-label-container';
    wrapper.classList.toggle('disabled', definition.enabled === false);
    wrapper.dataset.node = definition.id;

    const stateRows = definition.states.map((state) => `
        <div>
            <dt>${escapeHtml(state.label)}</dt>
            <dd class="${escapeHtml(state.className ?? '')}" title="${escapeHtml(state.exactValue ?? state.value)}">${escapeHtml(state.value)}</dd>
        </div>
    `).join('');

    wrapper.innerHTML = `
        <div class="objectLabel">
            <div>
                <strong>${escapeHtml(definition.title)}</strong>
                <span class="typeBadge ${escapeHtml(definition.badgeClass ?? '')}">${escapeHtml(definition.type)}</span>
                <span class="disabledBadge">Disabled</span>
                <button class="stabilityBadge" type="button" aria-label="Numerical stability findings for this node" title="Numerical stability findings for this node">⚠</button>
            </div>
            <dl>${stateRows}</dl>
            <span class="stateCount">${definition.states.length} ${definition.states.length === 1 ? 'state' : 'states'}</span>
        </div>
    `;

    wrapper.querySelector('.stabilityBadge').addEventListener('pointerdown', (event) => event.stopPropagation());
    wrapper.querySelector('.stabilityBadge').addEventListener('click', (event) => {
        event.stopPropagation();
        openStabilityFindingsForNode(definition.id);
    });

    wrapper.addEventListener('pointerdown', (event) => {
        event.stopPropagation();
        if (event.button === 0 && event.shiftKey && !activeEndpointPick) {
            event.preventDefault();
            selectNode(nodeObjects.get(definition.id), { additive: true });
        }
    });
    wrapper.addEventListener('click', (event) => {
        event.stopPropagation();
        if (activeEndpointPick) {
            chooseEndpointNode(definition.id);
            return;
        }
        if (event.shiftKey) return;
        selectNode(nodeObjects.get(definition.id));
        openNodeEditor(definition);
    });
    wrapper.addEventListener('contextmenu', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (activeResult) return;
        stageContextMenuAction(() => {
            const node = nodeObjects.get(definition.id);
            if (!(selectedNodeIds.size > 1 && selectedNodeIds.has(definition.id))) selectNode(node);
            openNodeContextMenu(event.clientX, event.clientY);
        });
    });

    const label = new CSS2DObject(wrapper);
    label.position.fromArray(nodeLabelOffset(geometry));
    label.center.set(0, 0.5);
    return label;
}

function createNode(definition) {
    const mesh = new THREE.Mesh(geometryFor(definition), materialFor(definition));
    mesh.position.fromArray(definition.position);
    mesh.rotation.fromArray(definition.rotation ?? [0, 0, 0]);
    mesh.scale.fromArray(definition.scale ?? [1, 1, 1]);
    mesh.userData = {
        kind: 'node',
        id: definition.id,
        definition
    };

    mesh.add(createNodeLabel(definition, mesh.geometry));
    scene.add(mesh);
    nodeObjects.set(definition.id, mesh);
    nodePickTargets.push(mesh);
}

function createSubsystemObject(definition) {
    const object = new THREE.Mesh(
        new THREE.BoxGeometry(2.7, 1.7, 2.1),
        new THREE.MeshStandardMaterial({ color: 0x195b60, roughness: 0.58, metalness: 0.08 })
    );
    object.position.fromArray(definition.position);
    object.userData = { kind: 'subsystem', id: definition.id, definition };
    const wrapper = document.createElement('div');
    wrapper.className = 'subsystem-label';
    wrapper.innerHTML = `<button class="subsystemLabel" type="button"><strong>${escapeHtml(definition.name)}</strong><small>${definition.ports.length} boundary ${definition.ports.length === 1 ? 'port' : 'ports'} · Open subsystem</small></button>`;
    $('.subsystemLabel', wrapper).addEventListener('click', (event) => {
        event.stopPropagation();
        enterSubsystem(definition.id);
    });
    const label = new CSS2DObject(wrapper);
    label.renderOrder = 20;
    label.position.set(0, 0.35, 0);
    object.add(label);
    scene.add(object);
    subsystemObjects.set(definition.id, object);
}

function subsystemForNodeInView(node) {
    let subsystem = model.subsystems.find((item) => item.id === node.subsystemId && !item.deleted);
    while (subsystem && subsystem.parentSubsystemId !== activeSubsystemId) {
        subsystem = model.subsystems.find((item) => item.id === subsystem.parentSubsystemId && !item.deleted);
    }
    return subsystem?.parentSubsystemId === activeSubsystemId ? subsystem : null;
}

function displayObjectForNode(nodeId) {
    const definition = model.nodes.find((node) => node.id === nodeId);
    if (!definition || definition.deleted) return null;
    if (definition.subsystemId === activeSubsystemId) return nodeObjects.get(nodeId);
    const subsystem = subsystemForNodeInView(definition);
    return subsystem ? subsystemObjects.get(subsystem.id) : null;
}

function refreshSubsystemView() {
    clearSelection();
    nodeObjects.forEach((object, id) => {
        const definition = object.userData.definition;
        object.visible = !definition.deleted && definition.subsystemId === activeSubsystemId;
    });
    subsystemObjects.forEach((object) => {
        const definition = object.userData.definition;
        object.visible = !definition.deleted && definition.parentSubsystemId === activeSubsystemId;
    });
    relationshipObjects.forEach((relationship) => {
        const source = displayObjectForNode(relationship.definition.source);
        const target = displayObjectForNode(relationship.definition.target);
        const visible = !relationship.definition.deleted && source && target && source !== target;
        relationship.line.visible = Boolean(visible);
        if (relationship.marker) relationship.marker.visible = Boolean(visible);
    });
    const breadcrumb = $('#subsystemBreadcrumb');
    breadcrumb.hidden = activeSubsystemId === null;
    if (activeSubsystemId !== null) {
        const current = model.subsystems.find((item) => item.id === activeSubsystemId);
        breadcrumb.innerHTML = `<button type="button" data-subsystem-parent>← ${current?.parentSubsystemId === null ? 'Model' : 'Parent'}</button><span>/</span><button type="button" disabled>${escapeHtml(current?.name ?? 'Subsystem')}</button>`;
        $('[data-subsystem-parent]', breadcrumb).addEventListener('click', () => enterSubsystem(current?.parentSubsystemId ?? null));
    }
    updateRelationships();
    updateModelStatus();
}

function enterSubsystem(id) {
    activeSubsystemId = id;
    hideCards();
    refreshSubsystemView();
}

model.nodes.forEach(createNode);
model.subsystems.forEach(createSubsystemObject);

const selectionOutlines = new Map();

function relationshipPoints(definition) {
    const source = displayObjectForNode(definition.source)?.position ?? nodeObjects.get(definition.source).position;
    const target = displayObjectForNode(definition.target)?.position ?? nodeObjects.get(definition.target).position;

    if (definition.waypoints?.length) {
        return {
            start: source.clone(),
            controlPoints: definition.waypoints.map(([x, y, z]) => new THREE.Vector3(x, y, z)),
            end: target.clone()
        };
    }

    const midpoint = source.clone().lerp(target, 0.5);
    const lateral = new THREE.Vector3()
        .subVectors(target, source)
        .cross(new THREE.Vector3(0, 0, 1))
        .normalize()
        .multiplyScalar(definition.offset);

    const start = source.clone().add(lateral);
    const end = target.clone().add(lateral);
    midpoint.add(lateral);
    midpoint.y -= 0.55;

    return { start, controlPoints: [midpoint], end };
}

function createDirectionMarker(definition, curve) {
    if (definition.directionality !== 'directed') return null;

    const enabled = isEdgeEffectivelyEnabled(definition);
    const marker = new THREE.Mesh(
        new THREE.ConeGeometry(0.14, 0.42, 14),
        new THREE.MeshBasicMaterial({
            color: enabled ? definition.color : disabledDisplayColor(definition.color),
            transparent: !enabled,
            opacity: enabled ? 1 : 0.4,
            depthTest: false
        })
    );
    marker.userData = {
        kind: 'relationship',
        id: definition.id,
        definition
    };
    marker.renderOrder = 8;
    positionDirectionMarker(marker, curve);
    scene.add(marker);
    return marker;
}

function positionDirectionMarker(marker, curve) {
    const position = curve.getPoint(0.64);
    const tangent = curve.getTangent(0.64).normalize();
    marker.position.copy(position);
    marker.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), tangent);
}

function createRelationship(definition) {
    const points = relationshipPoints(definition);
    const curve = new THREE.CatmullRomCurve3([
        points.start,
        ...points.controlPoints,
        points.end
    ]);
    const geometry = new THREE.BufferGeometry().setFromPoints(curve.getPoints(42));
    const enabled = isEdgeEffectivelyEnabled(definition);
    const material = new THREE.LineBasicMaterial({
        color: enabled ? definition.color : disabledDisplayColor(definition.color),
        transparent: true,
        opacity: enabled ? 0.92 : 0.4
    });
    const line = new THREE.Line(geometry, material);
    line.userData = {
        kind: 'relationship',
        id: definition.id,
        definition,
        curve
    };
    scene.add(line);

    const marker = createDirectionMarker(definition, curve);
    relationshipObjects.set(definition.id, { line, marker, definition });
    relationshipPickTargets.push(line);
    if (marker) relationshipPickTargets.push(marker);
}

function setRelationshipVisibility(id, visible) {
    const relationship = relationshipObjects.get(id);
    if (!relationship) return;
    relationship.definition.deleted = !visible;
    refreshSubsystemView();
}

function setRelationshipDirectionality(definition, directionality) {
    const relationship = relationshipObjects.get(definition.id);
    if (!relationship) return;
    if (relationship.marker) {
        scene.remove(relationship.marker);
        const markerIndex = relationshipPickTargets.indexOf(relationship.marker);
        if (markerIndex >= 0) relationshipPickTargets.splice(markerIndex, 1);
        relationship.marker.geometry.dispose();
        relationship.marker.material.dispose();
    }
    definition.directionality = directionality;
    relationship.marker = createDirectionMarker(definition, relationship.line.userData.curve);
    if (relationship.marker) relationshipPickTargets.push(relationship.marker);
    invalidateRelationshipBundles();
    syncContextualOverlays();
}

function setNodeVisibility(id, visible) {
    const node = nodeObjects.get(id);
    if (!node) return;
    node.userData.definition.deleted = !visible;
    refreshSubsystemView();
}

// Disabling is distinct from delete: the node/edge stays fully present (and, unlike delete, is
// saved in the file -- see serializeProjectDocument), just visually muted and excluded from the
// engine. Disabling a node cascades to every edge touching it via isEdgeEffectivelyEnabled --
// their own `enabled` field is left untouched, so re-enabling the node alone restores them too.
function setNodeEnabled(id, enabled) {
    const node = nodeObjects.get(id);
    if (!node) return;
    node.userData.definition.enabled = enabled;
    node.material.dispose();
    node.material = materialFor(node.userData.definition);
    const label = node.children.find((child) => child.element?.classList.contains('node-label-container'));
    label?.element.classList.toggle('disabled', !enabled);
    relationshipObjects.forEach((relationship) => {
        if (relationship.definition.source === id || relationship.definition.target === id) {
            refreshRelationshipVisual(relationship.definition);
        }
    });
    invalidateRelationshipBundles();
    syncContextualOverlays();
    // setNodeEnabled is also reached from undo/redo, not just its own button's click handler --
    // keep the open editor's button label truthful either way, same as applyEdgeModel does for
    // its own fields.
    if (selectedNode?.userData.definition.id === id && !$('#nodeEditor').classList.contains('hidden')) {
        $('#toggleNodeEnabled').textContent = enabled ? 'Disable node' : 'Enable node';
    }
}

function setRelationshipEnabled(id, enabled) {
    const relationship = relationshipObjects.get(id);
    if (!relationship) return;
    relationship.definition.enabled = enabled;
    refreshRelationshipVisual(relationship.definition);
    invalidateRelationshipBundles();
    syncContextualOverlays();
    if (selectedRelationship?.id === id && !$('#edgeEditor').classList.contains('hidden')) {
        $('#toggleEdgeEnabled').textContent = enabled ? 'Disable edge' : 'Enable edge';
    }
}

function toggleSelectedNodeEnabled() {
    if (activeResult || !selectedNode) return;
    const id = selectedNode.userData.definition.id;
    const nextEnabled = selectedNode.userData.definition.enabled === false;
    setNodeEnabled(id, nextEnabled);
    recordHistory({
        undo: () => setNodeEnabled(id, !nextEnabled),
        redo: () => setNodeEnabled(id, nextEnabled)
    });
}

function toggleSelectedEdgeEnabled() {
    if (activeResult || !selectedRelationship) return;
    const id = selectedRelationship.id;
    const nextEnabled = selectedRelationship.enabled === false;
    setRelationshipEnabled(id, nextEnabled);
    recordHistory({
        undo: () => setRelationshipEnabled(id, !nextEnabled),
        redo: () => setRelationshipEnabled(id, nextEnabled)
    });
}

// "Disable all"/"Enable all" are explicit, uni-directional bulk actions rather than a toggle --
// a mixed-state selection (some already disabled) has no sensible single "next" state to flip to.
// Undo restores each node's own prior enabled state rather than just the opposite of the target,
// so a bulk disable over a mixed selection undoes back to that same mix.
function setSelectedNodesEnabled(enabled) {
    if (activeResult || !selectedNodeIds.size) return;
    const ids = [...selectedNodeIds];
    const previous = new Map(ids.map((id) => [id, nodeObjects.get(id)?.userData.definition.enabled !== false]));
    const apply = (targetEnabled) => ids.forEach((id) => setNodeEnabled(id, targetEnabled));
    apply(enabled);
    recordHistory({
        undo: () => ids.forEach((id) => setNodeEnabled(id, previous.get(id))),
        redo: () => apply(enabled)
    });
}

function captureNodeAppearance(definition) {
    return {
        shape: definition.shape,
        importedGeometry: definition.importedGeometry?.clone() ?? null,
        geometryFileName: definition.geometryFileName ?? null,
        color: definition.color
    };
}

function applyNodeAppearance(node, appearance) {
    const definition = node.userData.definition;
    definition.importedGeometry?.dispose();
    definition.shape = appearance.shape;
    definition.importedGeometry = appearance.importedGeometry?.clone() ?? null;
    definition.geometryFileName = appearance.geometryFileName ?? null;
    // Callers that build a partial appearance object (switching just the primitive shape, or
    // just importing a file) may not specify color -- fall back to the current value rather
    // than wiping it to undefined and crashing the next time the color picker reads it.
    definition.color = appearance.color ?? definition.color;
    node.geometry.dispose();
    node.geometry = geometryFor(definition);
    node.material.dispose();
    node.material = materialFor(definition);
    const label = node.children.find((child) => child.element?.classList.contains('node-label-container'));
    label?.position.fromArray(nodeLabelOffset(node.geometry));
    updateSelectionOutline();
    updateRelationships();
}

function changeNodeAppearance(node, appearance) {
    if (activeResult) return;
    const before = captureNodeAppearance(node.userData.definition);
    applyNodeAppearance(node, appearance);
    const after = captureNodeAppearance(node.userData.definition);
    recordHistory({
        undo: () => applyNodeAppearance(node, before),
        redo: () => applyNodeAppearance(node, after)
    });
}

model.relationships.forEach(createRelationship);

const relationshipBundleObjects = new Map();

function updateRelationships() {
    relationshipObjects.forEach((relationship) => {
        const points = relationshipPoints(relationship.definition);
        const curve = new THREE.CatmullRomCurve3([
            points.start,
            ...points.controlPoints,
            points.end
        ]);
        relationship.line.geometry.dispose();
        relationship.line.geometry = new THREE.BufferGeometry().setFromPoints(curve.getPoints(42));
        relationship.line.userData.curve = curve;
        if (relationship.marker) positionDirectionMarker(relationship.marker, curve);
    });

    syncContextualOverlays();
}

updateRelationships();

const dragControls = new DragControls(
    nodePickTargets,
    camera,
    renderer.domElement
);
dragControls.recursive = false;
let dragStartPositions = null;
let dragLastPosition = null;
let waypointDragStart = null;
dragControls.addEventListener('dragstart', (event) => {
    orbitControls.enabled = false;
    if (event.object.userData.kind === 'waypoint') {
        waypointDragStart = event.object.position.clone();
        return;
    }
    if (!selectedNodeIds.has(event.object.userData.id)) selectNode(event.object);
    dragStartPositions = new Map([...selectedNodeIds].map((id) => [id, nodeObjects.get(id).position.clone()]));
    dragLastPosition = event.object.position.clone();
});
dragControls.addEventListener('drag', (event) => {
    if (event.object.userData.kind === 'waypoint') {
        const { relationshipId, index } = event.object.userData;
        const definition = relationshipObjects.get(relationshipId)?.definition;
        if (definition) {
            definition.waypoints[index] = event.object.position.toArray();
            updateRelationships();
        }
        return;
    }
    if (dragLastPosition && selectedNodeIds.size > 1) {
        const delta = event.object.position.clone().sub(dragLastPosition);
        selectedNodeIds.forEach((id) => {
            if (id !== event.object.userData.id) nodeObjects.get(id)?.position.add(delta);
        });
        dragLastPosition.copy(event.object.position);
    }
    updateRelationships();
    updateSelectionOutline();
});
dragControls.addEventListener('dragend', (event) => {
    orbitControls.enabled = true;
    if (event.object.userData.kind === 'waypoint') {
        const { relationshipId, index } = event.object.userData;
        const definition = relationshipObjects.get(relationshipId)?.definition;
        if (definition && waypointDragStart && !event.object.position.equals(waypointDragStart)) {
            const from = waypointDragStart.toArray();
            const to = event.object.position.toArray();
            const applyWaypoint = (point) => {
                definition.waypoints[index] = point;
                updateRelationships();
                if (selectedRelationship?.id === relationshipId) syncWaypointHandles(relationshipId);
            };
            recordHistory({
                undo: () => applyWaypoint(from),
                redo: () => applyWaypoint(to)
            });
        }
        waypointDragStart = null;
        return;
    }
    if (dragStartPositions && !event.object.position.equals(dragStartPositions.get(event.object.userData.id))) {
        const from = new Map([...dragStartPositions].map(([id, position]) => [id, position.clone()]));
        const to = new Map([...selectedNodeIds].map((id) => [id, nodeObjects.get(id).position.clone()]));
        const applyPositions = (positions) => {
            positions.forEach((position, id) => nodeObjects.get(id)?.position.copy(position));
            updateRelationships();
            updateSelectionOutline();
        };
        recordHistory({
            undo: () => applyPositions(from),
            redo: () => applyPositions(to)
        });
    }
    dragStartPositions = null;
    dragLastPosition = null;
});

const raycaster = new THREE.Raycaster();
raycaster.params.Line.threshold = 0.32;
const pointer = new THREE.Vector2();

function setPointerFromEvent(event) {
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
}

function firstIntersection(targets) {
    // Three.js's Raycaster does not itself check .visible (confirmed in node_modules/three/src/
    // core/Raycaster.js) -- an invisible object (soft-deleted, or hidden by subsystem scoping)
    // is exactly as raycast-hittable as a visible one. Skip hits the user can't actually see.
    return raycaster.intersectObjects(targets, true).find((hit) => hit.object.visible);
}

// Debug/test hook only; not part of the app's public surface (mirrors window.__providerEditorView
// in src/providerEditor/renderer.mjs). Exposes the on-screen point for a relationship's rendered
// line midpoint so interaction tests can click it without duplicating the camera-projection math.
function screenPointFor(worldPoint) {
    const rect = renderer.domElement.getBoundingClientRect();
    const projected = worldPoint.clone().project(camera);
    return {
        x: Math.round(rect.left + (projected.x + 1) / 2 * rect.width),
        y: Math.round(rect.top + (1 - projected.y) / 2 * rect.height)
    };
}

window.__relationshipScreenPoint = (title, t = 0.5) => {
    const relationship = [...relationshipObjects.values()].find((entry) => entry.definition.title === title);
    if (!relationship) return null;
    return screenPointFor(relationship.line.userData.curve.getPoint(t));
};

window.__waypointScreenPoint = (title, index) => {
    const relationship = [...relationshipObjects.values()].find((entry) => entry.definition.title === title);
    const handle = waypointHandleObjects.get(relationship?.definition.id)?.[index];
    return handle ? screenPointFor(handle.position) : null;
};

window.__relationshipWaypoints = (title) => {
    const relationship = [...relationshipObjects.values()].find((entry) => entry.definition.title === title);
    return relationship ? structuredClone(relationship.definition.waypoints ?? []) : null;
};

function rootNodeFromIntersection(intersection) {
    let object = intersection?.object;
    while (object && object.userData.kind !== 'node') object = object.parent;
    return object ?? null;
}

function updateSelectionOutline() {
    $$('.node-label-container').forEach((label) => {
        label.classList.toggle('selected', selectedNodeIds.has(Number(label.dataset.node)));
    });
    updateLabelPeek();
    selectionOutlines.forEach((outline, id) => {
        if (selectedNodeIds.has(id) && nodeObjects.get(id)?.visible) return;
        scene.remove(outline);
        outline.geometry.dispose();
        outline.material.dispose();
        selectionOutlines.delete(id);
    });
    selectedNodeIds.forEach((id) => {
        const node = nodeObjects.get(id);
        if (!node?.visible) return;
        let outline = selectionOutlines.get(id);
        if (!outline) {
            outline = new THREE.BoxHelper(node, 0x62e1d5);
            outline.material.depthTest = false;
            outline.material.transparent = true;
            outline.material.opacity = 0.9;
            outline.renderOrder = 20;
            selectionOutlines.set(id, outline);
            scene.add(outline);
        }
        outline.setFromObject(node);
    });
    updateSelectionActionControls();
}

function selectNode(node, { additive = false } = {}) {
    if (!node?.visible) return;
    if (additive) {
        if (selectedNodeIds.has(node.userData.id)) {
            selectedNodeIds.delete(node.userData.id);
            selectedNode = [...selectedNodeIds].map((id) => nodeObjects.get(id)).filter(Boolean).at(-1) ?? null;
        } else {
            selectedNodeIds.add(node.userData.id);
            selectedNode = node;
        }
    } else {
        selectedNodeIds.clear();
        selectedNodeIds.add(node.userData.id);
        selectedNode = node;
    }
    selectedRelationship = null;
    updateRelationshipSelection();
    updateSelectionOutline();
    if (additive && selectedNodeIds.size !== 1) hideCards();
    if (!activeResult && currentTool in transformPropertyForTool && transformControls.object &&
        !selectedNodeIds.has(transformControls.object.userData.id)) {
        if (selectedNode) transformControls.attach(selectedNode);
        else transformControls.detach();
    }
    if (!activeResult && selectedNodeIds.size > 1) $('#statusText').textContent = `${selectedNodeIds.size} nodes selected`;
    if (activeResult) window.addons.publishEvent('selection.change', selectedNodeIds.size === 1 ? selectedNode?.userData.id : null);
}

function selectRelationship(relationship) {
    selectedNode = null;
    selectedNodeIds.clear();
    selectedRelationship = relationship;
    updateSelectionOutline();
    updateRelationshipSelection();
    if (activeResult) window.addons.publishEvent('selection.change', null);
}

function clearSelection() {
    selectedNode = null;
    selectedNodeIds.clear();
    selectedRelationship = null;
    updateSelectionOutline();
    updateRelationshipSelection();
    transformControls.detach();
    if (activeResult) window.addons.publishEvent('selection.change', null);
}

function selectAllNodes() {
    if (activeResult) return;
    const nodes = [...nodeObjects.values()].filter((node) => node.visible);
    if (!nodes.length) return;
    clearSelection();
    nodes.forEach((node) => selectNode(node, { additive: true }));
    $('#statusText').textContent = `${selectedNodeIds.size} node${selectedNodeIds.size === 1 ? '' : 's'} selected`;
}

function clearWaypointHandles(relationshipId) {
    const handles = waypointHandleObjects.get(relationshipId);
    if (!handles) return;
    handles.forEach((handle) => {
        scene.remove(handle);
        const pickIndex = nodePickTargets.indexOf(handle);
        if (pickIndex >= 0) nodePickTargets.splice(pickIndex, 1);
        handle.geometry.dispose();
        handle.material.dispose();
    });
    waypointHandleObjects.delete(relationshipId);
}

// Rebuilds every handle mesh for one relationship from its current definition.waypoints --
// used both for the initial create-on-select and to resync handle positions/count after an
// undo/redo or an add/remove waypoint mutation, none of which move the handle mesh itself.
function syncWaypointHandles(relationshipId) {
    clearWaypointHandles(relationshipId);
    const definition = relationshipObjects.get(relationshipId)?.definition;
    if (!definition?.waypoints?.length) return;
    waypointHandleObjects.set(relationshipId, definition.waypoints.map(([x, y, z], index) => {
        const handle = new THREE.Mesh(
            new THREE.SphereGeometry(0.22, 12, 12),
            new THREE.MeshBasicMaterial({ color: 0xf3f7f6, depthTest: false })
        );
        handle.position.set(x, y, z);
        handle.renderOrder = 9;
        handle.userData = { kind: 'waypoint', relationshipId, index };
        scene.add(handle);
        nodePickTargets.push(handle);
        return handle;
    }));
}

function updateRelationshipSelection() {
    updateLabelPeek();
    relationshipObjects.forEach((relationship) => {
        const selected = relationship.definition.id === selectedRelationship?.id;
        const validationSeverity = relationship.line.userData.validationSeverity;
        relationship.line.material.color.setHex(
            selected ? 0x62e1d5
                : validationSeverity === 'error' ? 0xd96f78
                    : validationSeverity === 'warning' ? 0xed9f52
                        : relationship.definition.color
        );
        relationship.line.material.opacity = selected ? 1 : 0.92;
        relationship.line.renderOrder = selected ? 7 : 0;
        if (relationship.marker) {
            relationship.marker.material.color.setHex(
                selected ? 0x8cfff5 : relationship.definition.color
            );
            relationship.marker.scale.setScalar(selected ? 1.35 : 1);
        }
    });
    [...waypointHandleObjects.keys()].forEach((id) => {
        if (id !== selectedRelationship?.id) clearWaypointHandles(id);
    });
    if (selectedRelationship) syncWaypointHandles(selectedRelationship.id);
}

function hideCards(except) {
    if (activeEndpointPick && except !== $('#edgeBuilder')) finishEndpointPick();
    $$('.contextCard').forEach((card) => {
        if (card !== except) card.classList.add('hidden');
    });
}

function positionCard(card, clientX, clientY) {
    card.classList.remove('hidden');
    const canvasRect = canvas.getBoundingClientRect();
    const cardRect = card.getBoundingClientRect();
    const localX = clientX - canvasRect.left + 8;
    const localY = clientY - canvasRect.top + 8;
    card.style.left = `${Math.max(12, Math.min(localX, canvasRect.width - cardRect.width - 12))}px`;
    card.style.top = `${Math.max(12, Math.min(localY, canvasRect.height - cardRect.height - 12))}px`;
}

function captureNodeModel(node) {
    const definition = node.userData.definition;
    return {
        title: definition.title,
        type: definition.type,
        states: structuredClone(definition.states),
        sourceTerms: structuredClone(definition.sourceTerms),
        // Shared parameters ride along so linking, unlinking and editing a shared value are one
        // undoable step with the source-term edit that caused them.
        sharedParameters: structuredClone(model.sharedParameters),
        substepsPerGlobalStep: definition.substepsPerGlobalStep,
        integration: definition.integration ?? 'explicit',
        // The node's own program, if it has one (see renderNodeProgram), and its body parts (see renderNodeParts).
        implementation: structuredClone(definition.implementation ?? null),
        appearanceParts: structuredClone(definition.appearanceParts ?? null),
        bindings: model.relationships.map((edge) => ({
            id: edge.id,
            sourceStateId: edge.sourceStateId,
            targetStateId: edge.targetStateId
        }))
    };
}

function refreshNodeLabel(node) {
    const previous = node.children.find((child) => child.element?.classList.contains('node-label-container'));
    if (previous) {
        node.remove(previous);
        previous.element.remove();
    }
    node.add(createNodeLabel(node.userData.definition, node.geometry));
}

function applyNodeModel(node, snapshot) {
    const definition = node.userData.definition;
    definition.title = snapshot.title;
    definition.type = snapshot.type;
    definition.states = structuredClone(snapshot.states);
    definition.sourceTerms = structuredClone(snapshot.sourceTerms);
    if (snapshot.sharedParameters) model.sharedParameters = structuredClone(snapshot.sharedParameters);
    definition.substepsPerGlobalStep = snapshot.substepsPerGlobalStep;
    definition.integration = snapshot.integration ?? 'explicit';
    definition.implementation = structuredClone(snapshot.implementation ?? null);
    definition.appearanceParts = snapshot.appearanceParts?.length ? structuredClone(snapshot.appearanceParts) : null;
    snapshot.bindings.forEach((binding) => {
        const edge = model.relationships.find((candidate) => candidate.id === binding.id);
        if (edge) {
            edge.sourceStateId = binding.sourceStateId;
            edge.targetStateId = binding.targetStateId;
        }
    });
    refreshNodeLabel(node);
    invalidateRelationshipBundles();
    syncContextualOverlays();
    updateValidationStatus();
    if (selectedNode === node && !$('#nodeEditor').classList.contains('hidden')) {
        renderNodeEditorModel(node);
    }
    if (selectedSourceTermNodeId === node.userData.id && !$('#sourceTermEditor').classList.contains('hidden')) {
        const term = definition.sourceTerms.find((candidate) => candidate.id === selectedSourceTermId);
        if (term) renderSourceTermEditor(node, term);
        else $('#sourceTermEditor').classList.add('hidden');
    }
}

function changeNodeModel(node, mutate) {
    if (activeResult) return;
    const before = captureNodeModel(node);
    const after = structuredClone(before);
    mutate(after);
    const symbols = after.states.map((state) => state.symbol);
    if (symbols.some((symbol) => !modelSymbolPattern.test(symbol)) || new Set(symbols).size !== symbols.length) {
        const invalidSymbol = after.states.find((state) => !modelSymbolPattern.test(state.symbol));
        renderNodeEditorModel(node);
        $('#editNodeError').textContent = invalidSymbol
            ? `"${invalidSymbol.symbol}" is not a valid symbol -- symbols must start with a lowercase letter and contain only letters and digits (e.g. "temperature", not "Temperature").`
            : 'Each state needs its own unique symbol.';
        return;
    }
    const validStateIds = new Set(after.states.map((state) => state.id));
    after.bindings.forEach((binding) => {
        const edge = model.relationships.find((candidate) => candidate.id === binding.id);
        if (edge?.source === node.userData.id && !validStateIds.has(binding.sourceStateId)) binding.sourceStateId = null;
        if (edge?.target === node.userData.id && !validStateIds.has(binding.targetStateId)) binding.targetStateId = null;
    });
    applyNodeModel(node, after);
    recordHistory({
        undo: () => applyNodeModel(node, before),
        redo: () => applyNodeModel(node, after)
    });
}

// Moves a state one place up (-1) or down (1) in its node's list, as one undoable step. The order is the node's own:
// semi-implicit integration updates the states in it, each from those updated before it. `focusField` puts the
// keyboard back on the same field of the moved row.
function moveNodeState(node, stateId, offset, focusField = null) {
    const states = node.userData.definition.states;
    const from = states.findIndex((state) => state.id === stateId);
    const to = from + offset;
    if (from < 0 || to < 0 || to >= states.length) return;
    changeNodeModel(node, (snapshot) => {
        const [moved] = snapshot.states.splice(from, 1);
        snapshot.states.splice(to, 0, moved);
    });
    const row = $(`#nodeEditorStates .editorStateRow[data-state-id="${stateId}"]`);
    (focusField ? $(`[data-field="${focusField}"]`, row) : $(`.moveState[data-move="${offset}"]:not(:disabled)`, row) ?? $('input', row))?.focus();
}

function renderNodeEditorModel(node) {
    const definition = node.userData.definition;
    $('#editNodeError').textContent = '';
    $('#nodeEditorTitle').textContent = definition.title;
    $('#editNodeName').value = definition.title;
    $('#editNodeType').value = definition.type;
    $('#editNodeSubsteps').value = definition.substepsPerGlobalStep;
    $('#editNodeIntegration').value = definition.integration ?? 'explicit';
    const configuration = model.runConfigurations.find((item) => item.id === model.activeRunConfigurationId);
    $('#nodeEffectiveTimeStep').textContent = `${(configuration.globalTimeStep / definition.substepsPerGlobalStep).toPrecision(6)} s`;
    const stateContainer = $('#nodeEditorStates');
    stateContainer.replaceChildren();
    if (!definition.states.length) stateContainer.innerHTML = '<p class="emptyEditorState">No states defined</p>';
    definition.states.forEach((state, index) => {
        const row = document.createElement('div');
        row.className = 'editorStateRow';
        row.dataset.stateId = String(state.id);
        row.innerHTML = `
            <input data-field="name" value="${escapeHtml(state.label)}" aria-label="State name">
            <input data-field="symbol" value="${escapeHtml(state.symbol)}" aria-label="State symbol">
            <input data-field="value" type="number" value="${escapeHtml(state.initialValue ?? 0)}" aria-label="Initial value">
            <input data-field="unit" value="${escapeHtml(state.unit ?? '')}" aria-label="Unit">
            <button type="button" class="moveState" data-move="-1" title="Move up (${altKeyLabel}↑): earlier in the list, updated earlier by semi-implicit integration" aria-label="Move ${escapeHtml(state.symbol)} up" ${index === 0 ? 'disabled data-unavailable' : ''}>↑</button>
            <button type="button" class="moveState" data-move="1" title="Move down (${altKeyLabel}↓)" aria-label="Move ${escapeHtml(state.symbol)} down" ${index === definition.states.length - 1 ? 'disabled data-unavailable' : ''}>↓</button>
            <button type="button" class="removeState" title="Remove state">×</button>
        `;
        $$('.moveState', row).forEach((button) => button.addEventListener('click', () => moveNodeState(node, state.id, Number(button.dataset.move))));
        row.addEventListener('keydown', (event) => {
            if (!event.altKey || event.ctrlKey || event.metaKey || (event.key !== 'ArrowUp' && event.key !== 'ArrowDown')) return;
            event.preventDefault();
            moveNodeState(node, state.id, event.key === 'ArrowUp' ? -1 : 1, event.target.dataset.field);
        });
        $$('input', row).forEach((input) => input.addEventListener('change', () => {
            changeNodeModel(node, (snapshot) => {
                const target = snapshot.states.find((candidate) => candidate.id === state.id);
                const previousSymbol = target.symbol;
                const field = input.dataset.field;
                target[field === 'name' ? 'label' : field === 'value' ? 'initialValue' : field] =
                    field === 'value' ? Number(input.value) || 0 : input.value.trim();
                ({ text: target.value, exact: target.exactValue } = stateValueText(target.initialValue, target.unit));
                if (field === 'symbol') {
                    snapshot.sourceTerms.forEach((term) => {
                        if (term.state === previousSymbol) term.state = target.symbol;
                    });
                }
            });
        }));
        $('.removeState', row).addEventListener('click', () => changeNodeModel(node, (snapshot) => {
            snapshot.states = snapshot.states.filter((candidate) => candidate.id !== state.id);
            snapshot.sourceTerms = snapshot.sourceTerms.filter((term) => term.state !== state.symbol);
        }));
        stateContainer.appendChild(row);
    });

    renderNodeProgram(node);
    renderNodeParts(node);

    const sourceTermContainer = $('#nodeEditorSourceTerms');
    sourceTermContainer.replaceChildren();
    if (!definition.sourceTerms.length) sourceTermContainer.innerHTML = '<p class="emptyEditorState">No source terms defined</p>';
    definition.sourceTerms.forEach((term) => {
        const kind = term.implementation?.kind ?? 'equation';
        const stateSymbol = kind === 'equation'
            ? term.state
            : definition.states.find((state) => state.id === term.implementation?.output?.stateId)?.symbol;
        const row = document.createElement('div');
        row.className = 'sourceTermSummaryRow';
        row.innerHTML = `
            <button type="button" class="sourceTermOpen">
                <span class="kindBadge">${kind === 'equation' ? 'Equation' : kind === 'cpp' ? 'C++' : 'Python'}</span>
                <span class="sourceTermPreview">${escapeHtml(stateSymbol ? `Updates ${stateSymbol}` : 'No output state chosen')}</span>
            </button>
            <button type="button" class="removeSourceTerm" title="Remove source term">×</button>
        `;
        $('.sourceTermOpen', row).addEventListener('click', () => openSourceTermEditor(node, term));
        $('.removeSourceTerm', row).addEventListener('click', () => changeNodeModel(node, (snapshot) => {
            snapshot.sourceTerms = snapshot.sourceTerms.filter((candidate) => candidate.id !== term.id);
        }));
        sourceTermContainer.appendChild(row);
    });
}

// ---- A node's own program: a Python or C++ computational-node provider, or an installed FMU ------------------------
function nodeProgramContext(node) {
    const definition = node.userData.definition;
    const nodes = model.nodes.filter((candidate) => !candidate.deleted);
    return { definition, candidates: nodeProgramInputCandidates(definition, nodes, model.sharedParameters), nodes };
}

// The installed FMUs, cached while the node editor is open; null until read.
let installedFmus = null;

async function refreshInstalledFmus() {
    try {
        installedFmus = (await window.extensions.list()).filter((entry) => entry.packageType === 'fmu' && entry.enabled !== false);
    } catch {
        installedFmus = [];
    }
    return installedFmus;
}

function renderNodeProgram(node) {
    const { definition, candidates, nodes } = nodeProgramContext(node);
    const implementation = definition.implementation;
    const kind = implementation?.kind ?? '';
    $('#editNodeProgramKind').value = ['python', 'cpp', 'fmi'].includes(kind) ? kind : '';
    $('#nodeProgramFields').hidden = !implementation;
    if (!implementation) return;
    const isFmu = kind === 'fmi';
    $('#nodeProgramSourceFields').hidden = isFmu;
    $('#nodeProgramFmuFields').hidden = !isFmu;
    $('#editAddNodeProgramInput').hidden = isFmu;
    $('#editAddNodeProgramOutput').hidden = isFmu;
    if (!isFmu && document.activeElement !== $('#editNodeProgramSource')) $('#editNodeProgramSource').value = implementation.source ?? '';
    if (isFmu) renderNodeProgramFmus(node);
    const errors = nodeProgramErrors(implementation, definition, nodes, model.sharedParameters);
    const rowError = (messages) => {
        const element = document.createElement('div');
        element.className = 'nodeProgramRowError';
        element.textContent = messages.join(' ');
        return element;
    };
    const removeButton = (title, onClick) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.title = title;
        button.textContent = '×';
        button.hidden = isFmu;
        button.addEventListener('click', onClick);
        return button;
    };
    const keyInput = (value, label, onChange) => {
        const input = document.createElement('input');
        input.dataset.field = 'key';
        input.value = value ?? '';
        input.spellcheck = false;
        input.setAttribute('aria-label', label);
        // An FMU's keys are its own variables' names.
        input.readOnly = isFmu;
        input.addEventListener('change', () => onChange(input.value.trim()));
        return input;
    };

    const inputs = $('#nodeProgramInputs');
    inputs.replaceChildren();
    if (!(implementation.bindings ?? []).length) inputs.innerHTML = '<p class="emptyEditorState">No inputs</p>';
    (implementation.bindings ?? []).forEach((binding, index) => {
        const row = document.createElement('div');
        row.className = 'nodeProgramRow';
        row.dataset.index = String(index);
        const reads = document.createElement('select');
        reads.dataset.field = 'reads';
        reads.setAttribute('aria-label', `What input ${binding.key} reads`);
        reads.add(new Option('Choose…', ''));
        candidates.forEach((candidate) => reads.add(new Option(candidate.label, candidate.value)));
        reads.value = nodeProgramInputValue(binding, definition);
        reads.addEventListener('change', () => {
            const candidate = candidates.find((item) => item.value === reads.value);
            if (!candidate) return;
            changeNodeModel(node, (snapshot) => { snapshot.implementation.bindings[index] = { key: binding.key, ...candidate.binding }; });
        });
        row.append(
            keyInput(binding.key, 'Input key', (key) => changeNodeModel(node, (snapshot) => { snapshot.implementation.bindings[index].key = key; })),
            reads,
            removeButton('Remove this input', () => changeNodeModel(node, (snapshot) => { snapshot.implementation.bindings.splice(index, 1); })),
            rowError(errors.inputs[index] ?? [])
        );
        inputs.appendChild(row);
    });

    const outputs = $('#nodeProgramOutputs');
    outputs.replaceChildren();
    if (!(implementation.outputs ?? []).length) outputs.innerHTML = '<p class="emptyEditorState">No outputs</p>';
    (implementation.outputs ?? []).forEach((output, index) => {
        const row = document.createElement('div');
        row.className = 'nodeProgramRow';
        row.dataset.index = String(index);
        const state = document.createElement('select');
        state.dataset.field = 'state';
        state.setAttribute('aria-label', `State output ${output.key} changes`);
        state.add(new Option('Choose…', ''));
        definition.states.forEach((candidate) => state.add(new Option(`this.${candidate.symbol}`, String(candidate.id))));
        state.value = output.stateId === null || output.stateId === undefined ? '' : String(output.stateId);
        state.addEventListener('change', () => {
            if (!state.value) return;
            changeNodeModel(node, (snapshot) => { snapshot.implementation.outputs[index].stateId = Number(state.value); });
        });
        const setsLabel = document.createElement('label');
        setsLabel.className = 'nodeProgramSets';
        setsLabel.title = 'Checked, the output is the state\'s value; unchecked, it is a rate added to the state.';
        const sets = document.createElement('input');
        sets.type = 'checkbox';
        sets.dataset.field = 'setsValue';
        sets.checked = Boolean(output.setsValue) || isFmu;
        // An FMU reports values, never rates.
        if (isFmu) sets.setAttribute('data-unavailable', '');
        sets.disabled = isFmu || Boolean(activeResult);
        sets.addEventListener('change', () => changeNodeModel(node, (snapshot) => {
            if (sets.checked) snapshot.implementation.outputs[index].setsValue = true;
            else delete snapshot.implementation.outputs[index].setsValue;
        }));
        setsLabel.append(sets, document.createTextNode(' sets the value'));
        row.append(
            keyInput(output.key, 'Output key', (key) => changeNodeModel(node, (snapshot) => { snapshot.implementation.outputs[index].key = key; })),
            state,
            setsLabel,
            removeButton('Remove this output', () => changeNodeModel(node, (snapshot) => { snapshot.implementation.outputs.splice(index, 1); })),
            rowError(errors.outputs[index] ?? [])
        );
        outputs.appendChild(row);
    });
    // The engine integrates a node with a program explicitly (nodeIntegrationInvalid).
    if (definition.integration === 'semiImplicit') errors.errors.push('A node with a program is integrated explicitly: set Integration to Explicit Euler on the Numerics tab.');
    $('#nodeProgramError').textContent = errors.errors.join(' ');
}

async function renderNodeProgramFmus(node) {
    const select = $('#editNodeProgramFmu');
    const implementation = node.userData.definition.implementation;
    const fmus = installedFmus ?? await refreshInstalledFmus();
    select.replaceChildren(new Option(fmus.length ? 'Choose an installed FMU…' : 'No FMU installed: install one from Extensions', ''));
    fmus.forEach((fmu) => select.add(new Option(`${fmu.name} ${fmu.version}`, JSON.stringify([fmu.packageId, fmu.version]))));
    const current = implementation?.fmuId ? JSON.stringify([implementation.fmuId, implementation.fmuVersion]) : '';
    if (current && ![...select.options].some((option) => option.value === current)) {
        select.add(new Option(`${implementation.fmuId} ${implementation.fmuVersion} (not installed here)`, current));
    }
    select.value = current;
}

// Wires an installed FMU into the node, keeping what the earlier wiring read and wrote under the same keys.
async function useFmuForNode(node, guid, version) {
    const ports = await window.extensions.fmuPorts(guid, version);
    if (!ports || ports.error) {
        $('#nodeProgramError').textContent = ports?.error ?? 'The FMU could not be read.';
        return;
    }
    changeNodeModel(node, (snapshot) => {
        snapshot.implementation = fmiImplementation(guid, version, ports, snapshot.implementation);
    });
}

// ---- A node's body parts, for result visualizers ------------------------------------------------------------------
function renderNodeParts(node) {
    const definition = node.userData.definition;
    const parts = definition.appearanceParts ?? [];
    const container = $('#nodeParts');
    container.replaceChildren();
    if (!parts.length) container.innerHTML = '<p class="emptyEditorState">No parts</p>';
    const problems = partProblems(parts, definition.states.map((state) => state.symbol));
    parts.forEach((part, index) => {
        const row = document.createElement('div');
        row.className = 'nodePartRow';
        row.dataset.index = String(index);
        const prefix = document.createElement('input');
        prefix.dataset.field = 'prefix';
        prefix.value = part.prefix ?? '';
        prefix.placeholder = 'no prefix';
        prefix.spellcheck = false;
        prefix.setAttribute('aria-label', 'Prefix of the states that place this part');
        prefix.addEventListener('change', () => changeNodeModel(node, (snapshot) => { snapshot.appearanceParts[index].prefix = prefix.value.trim(); }));
        const color = document.createElement('input');
        color.type = 'color';
        color.dataset.field = 'color';
        color.value = /^#[0-9a-f]{6}$/i.test(part.color ?? '') ? part.color : '#888888';
        color.setAttribute('aria-label', 'Colour of this part');
        color.addEventListener('change', () => changeNodeModel(node, (snapshot) => { snapshot.appearanceParts[index].color = color.value; }));
        const mesh = document.createElement('label');
        mesh.className = 'partMesh';
        mesh.title = 'Replace this part\'s mesh with an STL or STEP file';
        const file = document.createElement('input');
        file.type = 'file';
        file.accept = '.stl,.step,.stp';
        file.addEventListener('change', async () => {
            const [chosen] = file.files;
            if (!chosen) return;
            try {
                const replacement = await partMeshFromFile(chosen);
                changeNodeModel(node, (snapshot) => { snapshot.appearanceParts[index].mesh = replacement; });
            } catch (error) {
                $('.nodePartProblem', row).textContent = error.message;
            }
        });
        mesh.append(file, document.createTextNode(`${triangleCount(part.mesh)} triangles ↥`));
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.textContent = '×';
        remove.title = 'Remove this part';
        remove.addEventListener('click', () => changeNodeModel(node, (snapshot) => { snapshot.appearanceParts.splice(index, 1); }));
        const problem = document.createElement('div');
        problem.className = 'nodePartProblem';
        problem.textContent = [...problems[index].errors, ...problems[index].notes].join(' ');
        problem.classList.toggle('note', !problems[index].errors.length);
        row.append(prefix, color, mesh, remove, problem);
        container.appendChild(row);
    });
}

// A mesh file as a part's mesh: in metres, in the file's own frame (not centred or scaled to fit, as the node's own
// shape is). STEP is read in millimetres; an STL's lengths are in the unit chosen beside the parts.
async function partMeshFromFile(file) {
    const extension = file.name.split('.').pop()?.toLowerCase();
    const buffer = await file.arrayBuffer();
    let geometry;
    let scale = Number($('#editNodePartUnit').value) || 0.001;
    if (extension === 'stl') geometry = new STLLoader().parse(buffer);
    else if (extension === 'step' || extension === 'stp') {
        if (!window.occtimportjs) throw new Error('The STEP importer is unavailable.');
        const occt = await window.occtimportjs();
        geometry = geometryFromStepResult(occt.ReadStepFile(new Uint8Array(buffer), {
            linearUnit: 'millimeter', linearDeflectionType: 'bounding_box_ratio', linearDeflection: 0.001, angularDeflection: 0.5
        }));
        scale = 0.001;
    } else throw new Error('Choose an STL, STEP, or STP file.');
    try {
        return meshFromArrays(geometry.attributes.position.array, geometry.attributes.normal?.array ?? null, geometry.index?.array ?? null, scale);
    } finally {
        geometry.dispose();
    }
}

$('#editAddNodePart').addEventListener('change', async (event) => {
    const [file] = event.target.files;
    if (!file || !selectedNode) return;
    const node = selectedNode;
    try {
        const mesh = await partMeshFromFile(file);
        changeNodeModel(node, (snapshot) => {
            const parts = snapshot.appearanceParts ??= [];
            const taken = new Set(parts.map((part) => part.prefix ?? ''));
            let prefix = taken.has('') ? 'part' : '';
            for (let index = 2; taken.has(prefix); index += 1) prefix = `part${index}`;
            parts.push({ prefix, mesh, color: '#888888' });
        });
    } catch (error) {
        $('#editGeometryStatus').textContent = error.message;
    } finally {
        event.target.value = '';
    }
});

function nodeProgramTemplate(kind, implementation, title) {
    return defaultNodeProviderSource(kind, implementation?.bindings ?? [], implementation?.outputs ?? [], title);
}

function sourceTermBindingCandidates(definition) {
    return definition.states.map((state) => ({ kind: 'state', stateId: state.id, symbol: state.symbol, label: state.symbol }));
}

function sourceTermExpressionBindingCandidates(definition, term) {
    const bindings = [
        ...sourceTermBindingCandidates(definition),
        ...(term.parameters ?? []).map((parameter) => ({
            kind: 'parameter', parameterId: parameter.id, symbol: parameter.symbol, label: parameter.symbol
        }))
    ];
    const previousTime = term.expressionModel?.bindings?.find((binding) => binding.kind === 'time');
    return [...bindings, timeBinding(new Set(bindings.map((binding) => binding.symbol)), previousTime?.symbol)];
}

function normalizeSourceTermExpressionModel(definition, term, expressionModel = term.expressionModel) {
    const bindings = sourceTermExpressionBindingCandidates(definition, term);
    const base = expressionModel ?? {
        latex: term.expression ?? '',
        output: { stateId: definition.states.find((state) => state.symbol === term.state)?.id ?? null },
        bindings: [],
        mathJson: null
    };
    const output = definition.states.some((state) => state.id === base.output?.stateId)
        ? base.output
        : { stateId: definition.states[0]?.id ?? null };
    const validation = validateEquationLatex(base.latex, bindings);
    return { latex: base.latex ?? '', output, bindings, mathJson: validation.valid ? validation.mathJson : null };
}

function renderSourceTermDiagnostics(latex, bindings) {
    const diagnostics = $('#termEquationDiagnostics');
    const validation = validateEquationLatex(latex, bindings);
    diagnostics.classList.toggle('valid', validation.valid);
    diagnostics.textContent = validation.valid ? 'Valid expression · MathJSON ready' : validation.errors.join(' ');
    return validation;
}

function insertSourceTermBinding(binding) {
    if (activeResult) return;
    const latex = latexForBinding(binding);
    if ($('#termMathField').hidden) {
        const source = $('#termEquation');
        source.setRangeText(latex, source.selectionStart, source.selectionEnd, 'end');
        source.dispatchEvent(new Event('input', { bubbles: true }));
        source.focus();
    } else {
        $('#termMathField').insert(latex);
        $('#termMathField').focus();
    }
}

function changeSourceTermModel(node, termId, mutate) {
    changeNodeModel(node, (snapshot) => {
        const term = snapshot.sourceTerms.find((candidate) => candidate.id === termId);
        if (term) mutate(term, snapshot);
    });
}

function sourceTermReferenceValue(reference) {
    return reference.kind === 'parameter' ? `parameter:${reference.parameterId}` : `state:${reference.stateId}`;
}

function sourceTermReferenceToBinding(key, reference) {
    return reference.kind === 'parameter'
        ? { key, kind: 'parameter', parameterId: reference.parameterId }
        : { key, kind: 'state', stateId: reference.stateId };
}

function renderSourceTermProviderBindingRows(node, term) {
    const definition = node.userData.definition;
    const container = $('#termProviderBindings');
    container.replaceChildren();
    const bindings = term.implementation?.bindings ?? [];
    const candidates = sourceTermExpressionBindingCandidates(definition, term);
    if (!bindings.length) container.innerHTML = '<p class="emptyEditorState">No bindings defined</p>';
    bindings.forEach((binding, index) => {
        const row = document.createElement('div');
        row.className = 'providerBindingRow';
        row.innerHTML = `
            <label class="parameterField"><span>Key</span><input data-field="key" value="${escapeHtml(binding.key ?? '')}"></label>
            <label class="parameterField"><span>Reference</span><select data-field="reference"></select></label>
            <button type="button" title="Remove binding">×</button>
        `;
        const select = $('[data-field="reference"]', row);
        select.replaceChildren(...candidates.map((candidate) => new Option(candidate.label, sourceTermReferenceValue(candidate))));
        select.value = sourceTermReferenceValue(binding);
        $('[data-field="key"]', row).addEventListener('change', (event) => {
            changeSourceTermModel(node, term.id, (snapshotTerm) => {
                snapshotTerm.implementation.bindings[index] = { ...snapshotTerm.implementation.bindings[index], key: event.target.value.trim() };
            });
        });
        select.addEventListener('change', (event) => {
            const candidate = candidates.find((option) => sourceTermReferenceValue(option) === event.target.value);
            if (!candidate) return;
            changeSourceTermModel(node, term.id, (snapshotTerm) => {
                snapshotTerm.implementation.bindings[index] = sourceTermReferenceToBinding(snapshotTerm.implementation.bindings[index].key, candidate);
            });
        });
        $(':scope > button', row).addEventListener('click', () => changeSourceTermModel(node, term.id, (snapshotTerm) => {
            snapshotTerm.implementation.bindings.splice(index, 1);
        }));
        container.appendChild(row);
    });
}

function renderSourceTermParameters(node, term) {
    const container = $('#termParameters');
    container.replaceChildren();
    $('#termParameterError').textContent = '';
    if (!(term.parameters ?? []).length) container.innerHTML = '<p class="emptyEditorState">No parameters defined</p>';
    (term.parameters ?? []).forEach((ownParameter) => {
        // Same linked-row behavior as the edge editor: value, unit, mode and slider range come from
        // (and are edited on) the shared definition; name and symbol stay local.
        const linkedShared = ownParameter.sharedParameterId !== undefined
            ? model.sharedParameters.find((shared) => shared.id === ownParameter.sharedParameterId) : null;
        const parameter = linkedShared ? { ...ownParameter, value: linkedShared.value, unit: linkedShared.unit, mode: linkedShared.mode, control: linkedShared.control } : ownParameter;
        const control = normalizedParameterControl(parameter);
        const tuning = normalizedParameterTuning(parameter);
        const row = document.createElement('div');
        row.className = 'editorParameterRow';
        row.dataset.parameterId = String(parameter.id);
        row.innerHTML = `
            <label class="parameterField"><span>Name</span><input data-field="name" value="${escapeHtml(parameter.name)}"></label>
            <label class="parameterField"><span>Symbol</span><input data-field="symbol" value="${escapeHtml(parameter.symbol)}"></label>
            <label class="parameterField"><span>Initial value</span><input data-field="value" type="number" value="${escapeHtml(parameter.value)}"></label>
            <label class="parameterField"><span>Unit</span><input data-field="unit" value="${escapeHtml(parameter.unit ?? '')}"></label>
            <label class="parameterField"><span>Mode</span><select data-field="mode"><option value="constant">Constant</option><option value="live">Live</option></select></label>
            <button type="button" title="Remove parameter">×</button>
            <div class="parameterControlFields" ${parameter.mode === 'live' ? '' : 'hidden'}>
                <label class="parameterField"><span>Slider minimum</span><input data-control-field="minimum" type="number" value="${control.minimum}"></label>
                <label class="parameterField"><span>Slider maximum</span><input data-control-field="maximum" type="number" value="${control.maximum}"></label>
                <label class="parameterField"><span>Slider step</span><input data-control-field="step" type="number" min="0" value="${control.step}"></label>
                <span class="parameterControlError" role="status"></span>
            </div>
            <label class="parameterField" title="Link this parameter to a project-level shared parameter so one value (or one live control) drives every parameter linked to it.">
                <span>Shared parameter</span>
                <select data-shared-select>${sharedParameterOptions()}</select>
            </label>
            <label class="parameterTuningToggle" title="${linkedShared ? 'A shared parameter is marked tunable in the Parameters table, and fitting it moves every parameter linked to it.' : ''}"><input data-field="tunable" type="checkbox" ${parameter.tuning ? 'checked' : ''} ${parameter.mode === 'live' || linkedShared ? 'disabled' : ''}> Tunable (fitting target)</label>
            <div class="parameterTuningFields" ${parameter.tuning ? '' : 'hidden'}>
                <label class="parameterField"><span>Fitting minimum</span><input data-tuning-field="minimum" type="number" value="${tuning.minimum}" ${parameter.mode === 'live' ? 'disabled' : ''}></label>
                <label class="parameterField"><span>Fitting maximum</span><input data-tuning-field="maximum" type="number" value="${tuning.maximum}" ${parameter.mode === 'live' ? 'disabled' : ''}></label>
                <span class="parameterTuningError" role="status"></span>
            </div>`;
        $('[data-field="mode"]', row).value = parameter.mode ?? 'constant';
        $('[data-shared-select]', row).value = linkedShared ? String(linkedShared.id) : '';
        const readControl = () => Object.fromEntries($$('[data-control-field]', row).map((input) => [input.dataset.controlField, Number(input.value)]));
        const readTuning = () => Object.fromEntries($$('[data-tuning-field]', row).map((input) => [input.dataset.tuningField, Number(input.value)]));
        $('[data-shared-select]', row).addEventListener('change', (event) => {
            changeSourceTermModel(node, term.id, (snapshotTerm, snapshot) => {
                const target = snapshotTerm.parameters.find((candidate) => candidate.id === parameter.id);
                applySharedParameterChoice(event.target.value, target, snapshot.sharedParameters,
                    { value: parameter.value, unit: parameter.unit, mode: parameter.mode, control: readControl() });
            });
        });
        const commit = (input) => {
            if (input.matches('[data-shared-select]')) return;
            const symbol = $('[data-field="symbol"]', row).value.trim();
            const siblings = (term.parameters ?? []).filter((candidate) => candidate.id !== parameter.id);
            if (!modelSymbolPattern.test(symbol) || siblings.some((candidate) => candidate.symbol === symbol)) {
                $('#termParameterError').textContent = !modelSymbolPattern.test(symbol)
                    ? `"${symbol}" is not a valid lower camel case symbol.` : 'Each parameter needs its own unique symbol.';
                return;
            }
            const mode = $('[data-field="mode"]', row).value;
            const value = Number($('[data-field="value"]', row).value) || 0;
            if (mode === 'live' && parameterControlError(value, readControl())) return;
            if ($('[data-field="tunable"]', row).checked && parameterTuningError(value, readTuning())) return;
            changeSourceTermModel(node, term.id, (snapshotTerm, snapshot) => {
                const target = snapshotTerm.parameters.find((candidate) => candidate.id === parameter.id);
                target.name = $('[data-field="name"]', row).value.trim();
                target.symbol = symbol;
                // Value, unit and mode belong to the shared definition when linked.
                const owner = target.sharedParameterId !== undefined
                    ? snapshot.sharedParameters.find((shared) => shared.id === target.sharedParameterId) : target;
                owner.value = value;
                owner.unit = $('[data-field="unit"]', row).value.trim();
                owner.mode = mode;
                if (mode === 'live') {
                    owner.control = readControl();
                    delete owner.tuning;
                } else {
                    delete owner.control;
                    if (owner === target && $('[data-field="tunable"]', row).checked) target.tuning = readTuning();
                    else delete owner.tuning;
                }
            });
        };
        $$('input, select', row).forEach((input) => input.addEventListener('change', () => commit(input)));
        $(':scope > button', row).addEventListener('click', () => changeSourceTermModel(node, term.id, (snapshotTerm) => {
            snapshotTerm.parameters = snapshotTerm.parameters.filter((candidate) => candidate.id !== parameter.id);
        }));
        container.appendChild(row);
    });
}

function renderSourceTermEditor(node, term) {
    const definition = node.userData.definition;
    $('#sourceTermEditorTitle').textContent = `${definition.title} · Source term`;
    const implementationKind = term.implementation?.kind ?? 'equation';
    const isEquation = implementationKind === 'equation';
    $('#termImplementationKind').value = implementationKind;
    $('#termSetsValue').value = term.setsValue ? 'true' : 'false';
    $('#termSetsValueHint').hidden = !term.setsValue;
    term.parameters ??= [];
    renderSourceTermParameters(node, term);
    $('h3', $('#termEquationHeading')).textContent = term.setsValue ? 'Value' : 'Equation';
    $('#termEquationHeading').hidden = !isEquation;
    $('#termEquationDiagnostics').hidden = !isEquation;
    $('#termFunctions').hidden = !isEquation;
    $('#termReferencePicker').hidden = !isEquation;
    $('#termProviderSection').hidden = isEquation;

    const output = $('#termOutputState');
    output.replaceChildren(...definition.states.map((state) => new Option(state.symbol, state.id)));

    const mathField = $('#termMathField');
    const latexSource = $('#termEquation');
    if (isEquation) {
        term.expressionModel = normalizeSourceTermExpressionModel(definition, term);
        term.expression = term.expressionModel.latex;
        const latexMode = $('[data-term-equation-mode="latex"]').classList.contains('active');
        mathField.hidden = latexMode;
        latexSource.hidden = !latexMode;
        mathField.value = term.expressionModel.latex;
        latexSource.value = term.expressionModel.latex;
        output.value = term.expressionModel.output.stateId ?? '';
        renderSourceTermDiagnostics(term.expressionModel.latex, term.expressionModel.bindings);
        const references = $('#termStateReferenceChips');
        references.replaceChildren();
        term.expressionModel.bindings.forEach((binding) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.textContent = binding.label;
            button.title = bindingInsertTitle(binding);
            button.addEventListener('click', () => insertSourceTermBinding(binding));
            references.appendChild(button);
        });
    } else {
        mathField.hidden = true;
        latexSource.hidden = true;
        output.value = term.implementation.output?.stateId ?? '';
        const fromPlugin = implementationKind === 'plugin';
        $('#termProviderCode').hidden = fromPlugin;
        $('#termPluginProviderFields').hidden = !fromPlugin;
        if (fromPlugin) fillPluginProviders($('#termPluginProvider'), term.implementation);
        $('#termProviderSource').value = term.implementation.source ?? '';
        $('#termInsertProviderTemplate').hidden = !term.implementation.source?.trim();
        $('#termProviderOutputKey').value = term.implementation.output?.key ?? '';
        renderSourceTermProviderBindingRows(node, term);
    }
}

function openSourceTermEditor(node, term) {
    const editor = $('#sourceTermEditor');
    selectedSourceTermNodeId = node.userData.id;
    selectedSourceTermId = term.id;
    hideCards(editor);
    renderSourceTermEditor(node, term);
    editor.style.removeProperty('left');
    editor.style.removeProperty('top');
    editor.classList.remove('hidden');
    applyInspectorReadOnly();
    requestAnimationFrame(avoidAssistantInspectorOverlap);
}

function previewSourceTermExpression(latex, origin) {
    if (activeResult || !selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    const definition = node?.userData.definition;
    const term = definition?.sourceTerms.find((candidate) => candidate.id === selectedSourceTermId);
    if (!term) return;
    beginEquationEditSession(`sourceTerm:${term.id}`, () => captureNodeModel(node), (snapshot) => applyNodeModel(node, snapshot));
    term.expressionModel = normalizeSourceTermExpressionModel(definition, term, { ...term.expressionModel, latex });
    term.expression = latex;
    if (origin !== 'visual') $('#termMathField').setValue(latex, { silenceNotifications: true });
    if (origin !== 'latex') $('#termEquation').value = latex;
    renderSourceTermDiagnostics(latex, term.expressionModel.bindings);
    updateValidationStatus();
}

function previewSourceTermProviderSource(source) {
    if (activeResult || !selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    const definition = node?.userData.definition;
    const term = definition?.sourceTerms.find((candidate) => candidate.id === selectedSourceTermId);
    if (!term) return;
    beginEquationEditSession(`sourceTerm:${term.id}`, () => captureNodeModel(node), (snapshot) => applyNodeModel(node, snapshot));
    term.implementation = { ...term.implementation, source };
    $('#termInsertProviderTemplate').hidden = !source.trim();
    updateValidationStatus();
}

// Shared by the active branch and every branch selected for comparison (comparisonBranchUuids) --
// branchLabel is only actually attached to the returned series when the caller passes one.
async function branchNodeSeries(branch, node, branchLabel) {
    let series = nodeResultSeries(branch.result, node.userData.definition, branchLabel);
    if (branch.jobId && branch.result?.sampleCount > branch.result.samples.length) {
        const signalIds = node.userData.definition.states.map((state) => state.id);
        const storedSeries = await window.engine.readResultSeries(branch.jobId, signalIds, {
            startTime: 0,
            endTime: branch.result.availableResultTime,
            maxPoints: 4000
        });
        const bySignal = new Map(storedSeries.map((item) => [item.signalId, item.samples]));
        series = node.userData.definition.states.map((state) => ({
            nodeId: node.userData.definition.id,
            stateId: state.id,
            name: state.label,
            symbol: state.symbol,
            unit: state.unit ?? '',
            samples: bySignal.get(state.id) ?? [],
            ...(branchLabel !== undefined ? { branchLabel } : {})
        })).filter((item) => item.samples.length);
    }
    return series;
}

async function renderNodeResults(node) {
    const panel = $('.nodeResultsPanel');
    // Keep the active branch's own record fresh before reading it -- this can run mid-live-update,
    // where the branches map entry for the active branch may still hold a stale result/jobId (only
    // activateBranch normally refreshes it, when parking a branch on switch-away).
    const activeBranchRecord = branches.get(activeBranchUuid);
    if (activeBranchRecord) { activeBranchRecord.result = activeResult; activeBranchRecord.jobId = activeEngineJobId; }
    const otherBranchUuids = [...comparisonBranchUuids].filter((uuid) => uuid !== activeBranchUuid && branches.has(uuid));
    const comparing = otherBranchUuids.length > 0;
    const activeLabel = activeBranchRecord?.label ?? 'Active';
    let series = await branchNodeSeries({ result: activeResult, jobId: activeEngineJobId }, node, comparing ? activeLabel : undefined);
    for (const uuid of otherBranchUuids) {
        series = series.concat(await branchNodeSeries(branches.get(uuid), node, branches.get(uuid).label));
    }
    panel.classList.toggle('hasResults', Boolean(series.length));
    if (!series.length) {
        nodeResultPlot.clear();
        return;
    }
    const branchColorMap = comparing ? new Map([
        [activeLabel, activeBranchRecord?.color ?? branchColors[0]],
        ...otherBranchUuids.map((uuid) => [branches.get(uuid).label, branches.get(uuid).color])
    ]) : undefined;
    await nodeResultPlot.render(series, activeResult.samples[activeResultSampleIndex]?.time ?? 0, { branchColors: branchColorMap });
}

function selectNodeEditorTab(tabName) {
    $$('[data-node-tab]').forEach((button) => {
        button.classList.toggle('active', button.dataset.nodeTab === tabName);
    });
    $$('[data-node-panel]').forEach((panel) => {
        panel.hidden = panel.dataset.nodePanel !== tabName;
    });
    $('#nodeModelActions').hidden = Boolean(activeResult) || tabName !== 'model';
    if (tabName === 'results' && selectedNode) requestAnimationFrame(() => renderNodeResults(selectedNode));
}

function openNodeEditor(definition, clientX, clientY) {
    const editor = $('#nodeEditor');
    // Read the installed FMUs again, in case one was installed since.
    installedFmus = null;
    hideCards(editor);
    const node = nodeObjects.get(definition.id);
    renderNodeEditorModel(node);
    const initialTab = activeResult ? 'results' : 'model';
    selectNodeEditorTab(initialTab);
    $('#editNodeShape').value = definition.shape === 'imported' ? '' : definition.shape;
    $('#editNodeColor').value = `#${definition.color.toString(16).padStart(6, '0')}`;
    $('#editNodeGeometryFile').value = '';
    $('#editGeometryStatus').textContent = definition.geometryFileName ?? 'Choose a CAD or mesh file, or browse the bundled library';
    $('#editGeometryStatus').classList.remove('loading', 'error');
    refreshNodeTransformFields(node);
    $('#toggleNodeEnabled').textContent = definition.enabled === false ? 'Enable node' : 'Disable node';
    editor.style.removeProperty('left');
    editor.style.removeProperty('top');
    editor.classList.remove('hidden');
    applyInspectorReadOnly();
    requestAnimationFrame(avoidAssistantInspectorOverlap);
}

function normalizeEdgeEquationModel(definition, equationModel = definition.equationModel) {
    // A relationship with several equations (equationModel.outputs) is kept as it is: its own editor
    // (renderSeveralEquations) changes it, and nothing else may rewrite its bindings or drop its equations.
    if (Array.isArray(equationModel?.outputs)) return structuredClone(equationModel);
    const sourceNode = model.nodes.find((node) => node.id === definition.source);
    const targetNode = model.nodes.find((node) => node.id === definition.target);
    const base = equationModel ?? {
        latex: definition.equation ?? '',
        output: { role: 'target', stateId: definition.targetStateId ?? null },
        bindings: [],
        mathJson: null
    };
    const bindings = reconcileEquationBindings(base.bindings, sourceNode, targetNode, definition.parameters);
    const outputNode = base.output?.role === 'source' ? sourceNode : targetNode;
    const output = outputNode?.states.some((state) => state.id === base.output?.stateId)
        ? base.output
        : { role: 'target', stateId: targetNode?.states[0]?.id ?? null };
    const validation = validateEquationLatex(base.latex, bindings);
    return { latex: base.latex ?? '', output, bindings, mathJson: validation.valid ? validation.mathJson : null };
}

function captureEdgeModel(definition) {
    const equationModel = normalizeEdgeEquationModel(definition);
    return {
        title: definition.title,
        source: definition.source,
        sourceStateId: definition.sourceStateId,
        target: definition.target,
        targetStateId: definition.targetStateId,
        directionality: definition.directionality,
        equation: definition.equation,
        equationModel: structuredClone(equationModel),
        implementation: structuredClone(definition.implementation ?? null),
        parameters: structuredClone(definition.parameters),
        // Shared parameters ride along so linking, unlinking and editing a shared value are one
        // undoable step with the edge edit that caused them.
        sharedParameters: structuredClone(model.sharedParameters),
        color: definition.color,
        waypoints: structuredClone(definition.waypoints ?? [])
    };
}

// Applies definition.color/enabled (and every connected node's enabled state, via
// isEdgeEffectivelyEnabled) to the live line and direction-marker materials, without rebuilding
// geometry. Used both when the edge's own color changes and whenever its enabled cascade does.
function refreshRelationshipVisual(definition) {
    const relationship = relationshipObjects.get(definition.id);
    if (!relationship) return;
    const enabled = isEdgeEffectivelyEnabled(definition);
    const color = enabled ? definition.color : disabledDisplayColor(definition.color);
    relationship.line.material.color.setHex(color);
    relationship.line.material.opacity = enabled ? 0.92 : 0.4;
    if (relationship.marker) {
        relationship.marker.material.color.setHex(color);
        relationship.marker.material.transparent = !enabled;
        relationship.marker.material.opacity = enabled ? 1 : 0.4;
        relationship.marker.material.needsUpdate = true;
    }
}

function setRelationshipColor(definition, color) {
    definition.color = color;
    refreshRelationshipVisual(definition);
}

function applyEdgeModel(definition, snapshot) {
    definition.title = snapshot.title;
    definition.source = snapshot.source;
    definition.sourceStateId = snapshot.sourceStateId;
    definition.target = snapshot.target;
    definition.targetStateId = snapshot.targetStateId;
    definition.parameters = structuredClone(snapshot.parameters);
    if (snapshot.sharedParameters) model.sharedParameters = structuredClone(snapshot.sharedParameters);
    definition.equationModel = normalizeEdgeEquationModel(definition, snapshot.equationModel);
    definition.equation = definition.equationModel.latex;
    definition.implementation = structuredClone(snapshot.implementation ?? null);
    definition.waypoints = structuredClone(snapshot.waypoints ?? []);
    setRelationshipDirectionality(definition, snapshot.directionality);
    setRelationshipColor(definition, snapshot.color);
    // Before updateRelationships() -- it calls syncContextualOverlays() internally, which reads
    // waypointHandleObjects to decide whether to hide this edge's label; populating the handles
    // first means that decision reflects the new waypoint count, not the pre-mutation one.
    if (selectedRelationship?.id === definition.id) syncWaypointHandles(definition.id);
    updateRelationships();
    updateValidationStatus();
    if (selectedRelationship?.id === definition.id && !$('#edgeEditor').classList.contains('hidden')) {
        renderEdgeEditor(definition);
    }
}

function changeEdgeModel(definition, mutate) {
    if (activeResult) return;
    finishEquationEdit();
    const before = captureEdgeModel(definition);
    const after = structuredClone(before);
    mutate(after);
    if (after.source === after.target) {
        renderEdgeEditor(definition);
        return;
    }
    const parameterSymbols = after.parameters.map((parameter) => parameter.symbol);
    if (parameterSymbols.some((symbol) => !modelSymbolPattern.test(symbol)) || new Set(parameterSymbols).size !== parameterSymbols.length) {
        const invalidSymbol = after.parameters.find((parameter) => !modelSymbolPattern.test(parameter.symbol));
        renderEdgeEditor(definition);
        $('#editEdgeError').textContent = invalidSymbol
            ? `"${invalidSymbol.symbol}" is not a valid symbol -- symbols must start with a lowercase letter and contain only letters and digits (e.g. "temperature", not "Temperature").`
            : 'Each parameter needs its own unique symbol.';
        return;
    }
    applyEdgeModel(definition, after);
    recordHistory({
        undo: () => applyEdgeModel(definition, before),
        redo: () => applyEdgeModel(definition, after)
    });
}

// Applies a "Shared parameter" dropdown choice to `target` (a parameter inside an edit snapshot):
// '' unlinks it, keeping the values currently in effect as its own; 'new' creates a shared
// parameter from `effective` (the row's displayed value, unit, mode and slider range) and links
// to it; anything else links to that existing shared parameter. Mutates `sharedParameters` (the
// snapshot's copy) in place.
function applySharedParameterChoice(choice, target, sharedParameters, effective) {
    if (choice === '') {
        const previous = sharedParameters.find((shared) => shared.id === target.sharedParameterId);
        if (previous) {
            Object.assign(target, { value: previous.value, unit: previous.unit, mode: previous.mode });
            if (previous.control) target.control = structuredClone(previous.control);
            else delete target.control;
        }
        delete target.sharedParameterId;
        return;
    }
    if (choice === 'new') {
        let symbol = target.symbol;
        for (let suffix = 2; sharedParameters.some((shared) => shared.symbol === symbol); suffix += 1) symbol = `${target.symbol}${suffix}`;
        const created = {
            id: allocateModelEntityId(), name: target.name, symbol,
            value: Number(effective.value) || 0, unit: effective.unit ?? '', mode: effective.mode ?? 'constant',
            ...(effective.mode === 'live' ? { control: structuredClone(effective.control) } : {})
        };
        sharedParameters.push(created);
        target.sharedParameterId = created.id;
    } else {
        target.sharedParameterId = Number(choice);
    }
    delete target.tuning;
    delete target.control;
}

function sharedParameterOptions() {
    return `<option value="">Not shared</option>
        ${model.sharedParameters.map((shared) => `<option value="${shared.id}">${escapeHtml(shared.name)} (${escapeHtml(shared.symbol)})</option>`).join('')}
        <option value="new">New shared parameter from this row…</option>`;
}

function normalizedParameterControl(parameter) {
    const { minimum, maximum, step } = liveParameterRange(parameter);
    return {
        minimum: Number(parameter.control?.minimum ?? minimum),
        maximum: Number(parameter.control?.maximum ?? maximum),
        step: Number(parameter.control?.step ?? step)
    };
}

// Digital-twin fitting bounds -- orthogonal to `control` (a "live" slider's runtime UI range):
// a parameter can be a fitting target independent of whether it's also live-adjustable during a
// run. Reuses the same "value ± its own magnitude" default heuristic as liveParameterRange()
// when no bounds have been set yet, for the same reason -- a plausible starting range beats an
// arbitrary fixed one.
function normalizedParameterTuning(parameter) {
    const value = Number(parameter.value) || 0;
    const magnitude = Math.max(Math.abs(value), 1);
    return {
        minimum: Number.isFinite(Number(parameter.tuning?.minimum)) ? Number(parameter.tuning.minimum) : Math.min(0, value - magnitude),
        maximum: Number.isFinite(Number(parameter.tuning?.maximum)) ? Number(parameter.tuning.maximum) : Math.max(0, value + magnitude)
    };
}

function parameterTuningError(value, tuning) {
    if (![value, tuning.minimum, tuning.maximum].every(Number.isFinite)) return 'Value and fitting bounds must be finite numbers.';
    if (!(tuning.minimum < tuning.maximum)) return 'Minimum must be less than maximum.';
    if (value < tuning.minimum || value > tuning.maximum) return 'The initial value must be within the fitting bounds.';
    return '';
}

function parameterControlError(value, control) {
    if (![value, control.minimum, control.maximum, control.step].every(Number.isFinite)) return 'Value and slider settings must be finite numbers.';
    if (!(control.minimum < control.maximum)) return 'Minimum must be less than maximum.';
    if (!(control.step > 0)) return 'Step must be greater than zero.';
    if (value < control.minimum || value > control.maximum) return 'The initial value must be within the slider bounds.';
    return '';
}

function renderEdgeEditor(definition) {
    $('#editEdgeError').textContent = '';
    $('.edgeEditor > header strong').textContent = definition.title;
    $('#editEdgeName').value = definition.title;
    $('#toggleEdgeEnabled').textContent = definition.enabled === false ? 'Enable edge' : 'Disable edge';
    const source = $('#editEdgeSource');
    const target = $('#editEdgeTarget');
    const options = model.nodes.filter((node) => nodeObjects.get(node.id)?.visible === true);
    source.replaceChildren(...options.map((node) => new Option(node.title, node.id)));
    target.replaceChildren(...options.map((node) => new Option(node.title, node.id)));
    source.value = definition.source;
    target.value = definition.target;
    $('#editEdgeDirectionality').value = definition.directionality;
    $('#editEdgeColor').value = `#${definition.color.toString(16).padStart(6, '0')}`;
    const parameterContainer = $('#edgeEditorParameters');
    parameterContainer.replaceChildren();
    if (!definition.parameters.length) parameterContainer.innerHTML = '<p class="emptyEditorState">No parameters defined</p>';
    definition.parameters.forEach((ownParameter) => {
        // A linked parameter shows (and edits) its shared definition's value, unit, mode and slider
        // range; only its name and symbol stay local, since the symbol is what this edge's own
        // equation refers to.
        const linkedShared = ownParameter.sharedParameterId !== undefined
            ? model.sharedParameters.find((shared) => shared.id === ownParameter.sharedParameterId) : null;
        const parameter = linkedShared ? { ...ownParameter, value: linkedShared.value, unit: linkedShared.unit, mode: linkedShared.mode, control: linkedShared.control } : ownParameter;
        const control = normalizedParameterControl(parameter);
        const tuning = normalizedParameterTuning(parameter);
        const row = document.createElement('div');
        row.className = 'editorParameterRow';
        row.dataset.parameterId = String(parameter.id);
        row.innerHTML = `
            <label class="parameterField"><span>Name</span><input data-field="name" value="${escapeHtml(parameter.name)}"></label>
            <label class="parameterField"><span>Symbol</span><input data-field="symbol" value="${escapeHtml(parameter.symbol)}"></label>
            <label class="parameterField"><span>Initial value</span><input data-field="value" type="number" value="${escapeHtml(parameter.value)}"></label>
            <label class="parameterField"><span>Unit</span><input data-field="unit" value="${escapeHtml(parameter.unit ?? '')}"></label>
            <label class="parameterField"><span>Mode</span><select data-field="mode"><option value="constant">Constant</option><option value="live">Live</option></select></label>
            <button type="button" title="Remove parameter">×</button>
            <div class="parameterControlFields" ${parameter.mode === 'live' ? '' : 'hidden'}>
                <label class="parameterField"><span>Slider minimum</span><input data-control-field="minimum" type="number" value="${control.minimum}"></label>
                <label class="parameterField"><span>Slider maximum</span><input data-control-field="maximum" type="number" value="${control.maximum}"></label>
                <label class="parameterField"><span>Slider step</span><input data-control-field="step" type="number" min="0" value="${control.step}"></label>
                <span class="parameterControlError" role="status"></span>
            </div>
            <label class="parameterField" title="Link this parameter to a project-level shared parameter so one value (or one live control) drives every parameter linked to it.">
                <span>Shared parameter</span>
                <select data-shared-select>${sharedParameterOptions()}</select>
            </label>
            <label class="parameterTuningToggle" title="${linkedShared ? 'A shared parameter is marked tunable in the Parameters table, and fitting it moves every parameter linked to it.' : parameter.mode === 'live' ? 'A live parameter is adjusted interactively during a run; fitting it against measured data doesn’t apply while Mode is Live.' : ''}">
                <input data-field="tunable" type="checkbox" ${parameter.tuning ? 'checked' : ''} ${parameter.mode === 'live' || linkedShared ? 'disabled' : ''}> Tunable (fitting target)
            </label>
            <div class="parameterTuningFields" ${parameter.tuning ? '' : 'hidden'}>
                <label class="parameterField"><span>Fitting minimum</span><input data-tuning-field="minimum" type="number" value="${tuning.minimum}" ${parameter.mode === 'live' ? 'disabled' : ''}></label>
                <label class="parameterField"><span>Fitting maximum</span><input data-tuning-field="maximum" type="number" value="${tuning.maximum}" ${parameter.mode === 'live' ? 'disabled' : ''}></label>
                <span class="parameterTuningError" role="status"></span>
            </div>
        `;
        $('[data-field="mode"]', row).value = parameter.mode ?? 'constant';
        $('[data-shared-select]', row).value = linkedShared ? String(linkedShared.id) : '';
        const readControl = () => Object.fromEntries($$('[data-control-field]', row)
            .map((input) => [input.dataset.controlField, Number(input.value)]));
        const readTuning = () => Object.fromEntries($$('[data-tuning-field]', row)
            .map((input) => [input.dataset.tuningField, Number(input.value)]));
        const showControlError = () => {
            const error = $('[data-field="mode"]', row).value === 'live'
                ? parameterControlError(Number($('[data-field="value"]', row).value), readControl()) : '';
            $('.parameterControlError', row).textContent = error;
            return error;
        };
        const showTuningError = () => {
            const error = $('[data-field="tunable"]', row).checked
                ? parameterTuningError(Number($('[data-field="value"]', row).value), readTuning()) : '';
            $('.parameterTuningError', row).textContent = error;
            return error;
        };
        $$('[data-control-field], [data-field="value"]', row).forEach((input) => input.addEventListener('input', showControlError));
        $$('[data-tuning-field], [data-field="value"]', row).forEach((input) => input.addEventListener('input', showTuningError));
        $$('[data-field]', row).forEach((input) => input.addEventListener('change', () => {
            if (input.dataset.field === 'mode') {
                $('.parameterControlFields', row).hidden = input.value !== 'live';
                // A live parameter is adjusted interactively during a run, so fitting it against
                // measured data beforehand doesn't apply -- switching to Live clears any tuning
                // bounds the same way an explicit uncheck would, rather than leaving stale,
                // uneditable data behind a disabled checkbox.
                const tunableCheckbox = $('[data-field="tunable"]', row);
                tunableCheckbox.disabled = input.value === 'live';
                tunableCheckbox.title = input.value === 'live'
                    ? 'A live parameter is adjusted interactively during a run; fitting it against measured data doesn’t apply while Mode is Live.' : '';
                if (input.value === 'live' && tunableCheckbox.checked) {
                    tunableCheckbox.checked = false;
                    $('.parameterTuningFields', row).hidden = true;
                }
                $$('[data-tuning-field]', row).forEach((tuningInput) => { tuningInput.disabled = input.value === 'live'; });
            }
            if (input.dataset.field === 'tunable') $('.parameterTuningFields', row).hidden = !input.checked;
            if (showControlError() || showTuningError()) return;
            changeEdgeModel(definition, (snapshot) => {
                const targetParameter = snapshot.parameters.find((candidate) => candidate.id === parameter.id);
                if (input.dataset.field === 'tunable') {
                    if (input.checked) targetParameter.tuning = readTuning();
                    else delete targetParameter.tuning;
                    return;
                }
                // Value, unit and mode belong to the shared definition when linked; name and symbol
                // always stay on this edge's own parameter.
                const editedShared = targetParameter.sharedParameterId !== undefined && ['value', 'unit', 'mode'].includes(input.dataset.field)
                    ? snapshot.sharedParameters.find((shared) => shared.id === targetParameter.sharedParameterId) : null;
                const edited = editedShared ?? targetParameter;
                edited[input.dataset.field] = input.dataset.field === 'value'
                    ? Number(input.value) || 0
                    : input.value.trim();
                if (edited.mode === 'live') {
                    edited.control = readControl();
                    delete edited.tuning;
                } else delete edited.control;
            });
        }));
        $$('[data-control-field]', row).forEach((input) => input.addEventListener('change', () => {
            if (showControlError()) return;
            changeEdgeModel(definition, (snapshot) => {
                const targetParameter = snapshot.parameters.find((candidate) => candidate.id === parameter.id);
                const edited = targetParameter.sharedParameterId !== undefined
                    ? snapshot.sharedParameters.find((shared) => shared.id === targetParameter.sharedParameterId) : targetParameter;
                edited.value = Number($('[data-field="value"]', row).value) || 0;
                edited.control = readControl();
            });
        }));
        $$('[data-tuning-field]', row).forEach((input) => input.addEventListener('change', () => {
            if (showTuningError()) return;
            changeEdgeModel(definition, (snapshot) => {
                const targetParameter = snapshot.parameters.find((candidate) => candidate.id === parameter.id);
                targetParameter.value = Number($('[data-field="value"]', row).value) || 0;
                targetParameter.tuning = readTuning();
            });
        }));
        $('[data-shared-select]', row).addEventListener('change', (event) => {
            changeEdgeModel(definition, (snapshot) => {
                const targetParameter = snapshot.parameters.find((candidate) => candidate.id === parameter.id);
                applySharedParameterChoice(event.target.value, targetParameter, snapshot.sharedParameters,
                    { value: parameter.value, unit: parameter.unit, mode: parameter.mode, control: readControl() });
            });
        });
        $(':scope > button', row).addEventListener('click', () => changeEdgeModel(definition, (snapshot) => {
            snapshot.parameters = snapshot.parameters.filter((candidate) => candidate.id !== parameter.id);
        }));
        parameterContainer.appendChild(row);
    });
    const implementationKind = definition.implementation?.kind ?? 'equation';
    const isEquation = implementationKind === 'equation';
    $('#editEdgeImplementationKind').value = implementationKind;
    // A relationship with several equations, each setting a state of one of the two nodes: edited row by row below.
    const several = isSeveralEquations(definition.equationModel);
    $('#editEdgeEquationsList').hidden = !several;
    $('#editEquationOutput').closest('label').hidden = several;
    if (several) $('#editEdgeImplementationKind').value = 'equations';
    // Such a relationship is directed: what it sets on each node is written out, one equation per state.
    const directionality = $('#editEdgeDirectionality');
    directionality.toggleAttribute('data-unavailable', several);
    directionality.disabled = several || Boolean(activeResult);
    directionality.title = several ? 'A relationship with several equations is directed: each equation names the state it sets.' : '';
    $('#editEdgeEquationHeading h3').textContent = several ? 'Equations' : 'Equation';
    if (several) {
        for (const id of ['#equationDiagnostics', '#editEdgeProviderSection', '#editEdgeMathField', '#editEdgeEquation']) $(id).hidden = true;
        for (const id of ['#editEdgeEquationHeading', '#edgeFunctions', '#editEdgeReferencePicker']) $(id).hidden = false;
        renderSeveralEquations(definition);
        return;
    }
    // The math-field/latex-textarea toggle their own `hidden` directly (matching the existing
    // Visual/LaTeX mode toggle) rather than through a hidden ancestor: MathLive's custom element
    // does not reliably accept focus again once an ancestor of it has been display:none'd.
    $('#editEdgeEquationHeading').hidden = !isEquation;
    $('#equationDiagnostics').hidden = !isEquation;
    $('#edgeFunctions').hidden = !isEquation;
    $('#editEdgeReferencePicker').hidden = !isEquation;
    $('#editEdgeProviderSection').hidden = isEquation;

    const output = $('#editEquationOutput');
    output.replaceChildren();
    [['source', definition.source], ['target', definition.target]].forEach(([role, nodeId]) => {
        const node = model.nodes.find((candidate) => candidate.id === nodeId);
        node?.states.forEach((state) => {
            output.add(new Option(`${role}.${state.symbol}`, equationOutputValue(role, state.id)));
        });
    });

    const mathField = $('#editEdgeMathField');
    const latexSource = $('#editEdgeEquation');
    if (isEquation) {
        definition.equationModel = normalizeEdgeEquationModel(definition);
        definition.equation = definition.equationModel.latex;
        const latexMode = $('[data-equation-mode="latex"]').classList.contains('active');
        mathField.hidden = latexMode;
        latexSource.hidden = !latexMode;
        mathField.value = definition.equationModel.latex;
        latexSource.value = definition.equationModel.latex;
        output.value = equationOutputValue(definition.equationModel.output.role, definition.equationModel.output.stateId);
        renderEquationDiagnostics(definition.equationModel.latex, definition.equationModel.bindings);
        const references = $('#editStateReferenceChips');
        references.replaceChildren();
        definition.equationModel.bindings.forEach((binding) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.textContent = binding.label;
            button.title = bindingInsertTitle(binding);
            button.addEventListener('click', () => insertEquationBinding(binding));
            references.appendChild(button);
        });
    } else {
        mathField.hidden = true;
        latexSource.hidden = true;
        const fromPlugin = implementationKind === 'plugin';
        $('#editEdgeProviderCode').hidden = fromPlugin;
        $('#editEdgePluginProviderFields').hidden = !fromPlugin;
        if (fromPlugin) fillPluginProviders($('#editEdgePluginProvider'), definition.implementation);
        output.value = equationOutputValue(definition.implementation.output?.role ?? 'target', definition.implementation.output?.stateId);
        $('#editEdgeProviderSource').value = definition.implementation.source ?? '';
        $('#editInsertProviderTemplate').hidden = !definition.implementation.source?.trim();
        $('#editProviderOutputKey').value = definition.implementation.output?.key ?? '';
        renderProviderBindingRows(definition);
    }
}

// ---- A relationship with several equations ------------------------------------------------------------------------
// Each equation sets a state of the relationship's source or target node; intermediate quantities (definitions) are
// worked out first, each from those above it. Every structural change (add, remove, move, rename, the state an
// equation sets) is one undoable step; typing into an equation is one step per field, as for a single equation.

// The relationship's two nodes and what its equations may read.
function severalContext(snapshot) {
    const sourceNode = model.nodes.find((node) => node.id === snapshot.source);
    const targetNode = model.nodes.find((node) => node.id === snapshot.target);
    return { sourceNode, targetNode, candidates: equationCandidates(snapshot.equationModel, sourceNode, targetNode, snapshot.parameters) };
}

function compileSeveral(snapshot) {
    const { sourceNode, targetNode, candidates } = severalContext(snapshot);
    snapshot.equationModel = compileSeveralEquations(snapshot.equationModel, candidates, sourceNode, targetNode);
}

// Which field of which row the reference chips insert into: the one last focused.
let severalFocus = null;

function severalLatexMode() {
    return $('[data-equation-mode="latex"]').classList.contains('active');
}

function renderSeveralEquations(definition) {
    const { sourceNode, targetNode, candidates } = severalContext(definition);
    const equationModel = definition.equationModel;
    const check = checkSeveralEquations(equationModel, candidates, sourceNode, targetNode);
    const list = $('#editEdgeEquationsList');
    list.replaceChildren();
    const hint = document.createElement('p');
    hint.className = 'builderHint';
    hint.textContent = 'Each equation sets a state of the source or target node to its value at every step, rather than adding a rate to it. '
        + 'Where several relationships set the same state, their values are added. Intermediate quantities are worked out first, each from those above it.';
    list.appendChild(hint);
    const section = (title, kind, items) => {
        const heading = document.createElement('h3');
        heading.textContent = title;
        const add = document.createElement('button');
        add.type = 'button';
        add.dataset.addSeveral = kind;
        add.textContent = '＋';
        add.title = kind === 'definition' ? 'Add an intermediate quantity' : 'Add an equation';
        add.addEventListener('click', () => addSeveralRow(definition, kind));
        heading.appendChild(add);
        list.appendChild(heading);
        if (!items.length) {
            const empty = document.createElement('p');
            empty.className = 'emptyEditorState';
            empty.textContent = kind === 'definition' ? 'None' : 'No equations yet';
            list.appendChild(empty);
        }
        items.forEach((item, index) => list.appendChild(severalRow(definition, kind, item, index, items.length,
            (kind === 'definition' ? check.definitions : check.outputs)[index], sourceNode, targetNode)));
    };
    section('Intermediate quantities', 'definition', equationModel.definitions ?? []);
    section('Equations', 'output', equationModel.outputs ?? []);
    const summary = document.createElement('div');
    summary.className = 'severalSummary';
    summary.setAttribute('role', 'status');
    summary.textContent = check.errors.join(' ');
    list.appendChild(summary);
    // The chips insert a state, parameter, time or intermediate quantity into the field last focused.
    const references = $('#editStateReferenceChips');
    references.replaceChildren();
    [...candidates, ...(equationModel.definitions ?? []).map(({ symbol }) => ({ kind: 'definition', symbol, label: symbol }))].forEach((binding) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = binding.label;
        button.title = binding.kind === 'definition' ? 'Insert intermediate quantity' : bindingInsertTitle(binding);
        button.addEventListener('click', () => insertSeveralReference(binding));
        references.appendChild(button);
    });
}

function severalRow(definition, kind, item, index, count, check, sourceNode, targetNode) {
    const row = document.createElement('div');
    row.className = 'severalRow';
    row.dataset.kind = kind;
    row.dataset.index = String(index);
    const head = document.createElement('div');
    head.className = 'severalRowHead';
    if (kind === 'definition') {
        const symbol = document.createElement('input');
        symbol.dataset.field = 'symbol';
        symbol.value = item.symbol ?? '';
        symbol.setAttribute('aria-label', 'Name of the intermediate quantity');
        symbol.spellcheck = false;
        symbol.addEventListener('change', () => renameSeveralDefinition(definition, index, symbol.value.trim()));
        head.appendChild(symbol);
    } else {
        const sets = document.createElement('select');
        sets.dataset.field = 'sets';
        sets.setAttribute('aria-label', 'State this equation sets');
        [['source', sourceNode], ['target', targetNode]].forEach(([role, node]) => {
            node?.states.forEach((state) => sets.add(new Option(`${role}.${state.symbol}`, equationOutputValue(role, state.id))));
        });
        sets.value = equationOutputValue(item.role, item.stateId);
        sets.addEventListener('change', () => {
            const picked = parseEquationOutput(sets.value);
            if (!picked) return;
            changeEdgeModel(definition, (snapshot) => {
                Object.assign(snapshot.equationModel.outputs[index], picked);
                compileSeveral(snapshot);
            });
        });
        head.appendChild(sets);
    }
    const equals = document.createElement('span');
    equals.className = 'severalEquals';
    equals.textContent = '=';
    head.appendChild(equals);
    const button = (text, title, onClick, unavailable = false) => {
        const element = document.createElement('button');
        element.type = 'button';
        element.textContent = text;
        element.title = title;
        if (unavailable) element.setAttribute('data-unavailable', '');
        element.disabled = unavailable || Boolean(activeResult);
        element.addEventListener('click', onClick);
        head.appendChild(element);
        return element;
    };
    const what = kind === 'definition' ? 'quantity' : 'equation';
    button('↑', `Move this ${what} up (${altKeyLabel}↑)`, () => moveSeveralRow(definition, kind, index, -1), index === 0).dataset.move = '-1';
    button('↓', `Move this ${what} down (${altKeyLabel}↓)`, () => moveSeveralRow(definition, kind, index, 1), index === count - 1).dataset.move = '1';
    button('×', `Remove this ${what}`, () => removeSeveralRow(definition, kind, index)).dataset.remove = '';
    row.appendChild(head);

    const latex = check?.latex ?? item.latex ?? '';
    const visual = document.createElement('math-field');
    visual.className = 'equationMathField';
    visual.setAttribute('aria-label', kind === 'definition' ? `Value of ${item.symbol}` : 'Equation expression');
    const source = document.createElement('textarea');
    source.className = 'equationSource';
    source.rows = 2;
    source.spellcheck = false;
    source.value = latex;
    const latexMode = severalLatexMode();
    visual.hidden = latexMode;
    source.hidden = !latexMode;
    row.appendChild(visual);
    row.appendChild(source);
    visual.value = latex;
    for (const [field, origin] of [[visual, 'visual'], [source, 'latex']]) {
        field.addEventListener('focus', () => { severalFocus = { kind, index }; });
        field.addEventListener('input', () => previewSeveralEquation(kind, index, field.value, origin));
        field.addEventListener('change', () => finishEquationEdit());
        field.dataset.several = origin;
    }
    const diagnostics = document.createElement('div');
    diagnostics.className = 'equationDiagnostics';
    diagnostics.setAttribute('role', 'status');
    showSeveralDiagnostics(diagnostics, check);
    row.appendChild(diagnostics);
    row.addEventListener('keydown', (event) => {
        if (!event.altKey || event.ctrlKey || event.metaKey || (event.key !== 'ArrowUp' && event.key !== 'ArrowDown')) return;
        event.preventDefault();
        moveSeveralRow(definition, kind, index, event.key === 'ArrowUp' ? -1 : 1);
    });
    return row;
}

function showSeveralDiagnostics(element, check) {
    const errors = check?.errors ?? [];
    element.classList.toggle('valid', !errors.length);
    element.textContent = errors.length ? errors.join(' ') : 'Valid expression · MathJSON ready';
}

function severalItems(equationModel, kind) {
    return kind === 'definition' ? (equationModel.definitions ??= []) : (equationModel.outputs ??= []);
}

function addSeveralRow(definition, kind) {
    changeEdgeModel(definition, (snapshot) => {
        const { sourceNode, targetNode, candidates } = severalContext(snapshot);
        const items = severalItems(snapshot.equationModel, kind);
        if (kind === 'definition') items.push({ symbol: newDefinitionSymbol(snapshot.equationModel, candidates), latex: '0' });
        else items.push({ ...nextFreeOutput(snapshot.equationModel, sourceNode, targetNode), latex: '0' });
        compileSeveral(snapshot);
    });
    focusSeveralRow(kind, severalItems(definition.equationModel, kind).length - 1);
}

function removeSeveralRow(definition, kind, index) {
    changeEdgeModel(definition, (snapshot) => {
        severalItems(snapshot.equationModel, kind).splice(index, 1);
        compileSeveral(snapshot);
    });
}

function moveSeveralRow(definition, kind, index, offset) {
    const items = severalItems(definition.equationModel, kind);
    if (moved(items, index, offset) === items) return;
    changeEdgeModel(definition, (snapshot) => {
        const list = severalItems(snapshot.equationModel, kind);
        list.splice(0, list.length, ...moved(list, index, offset));
        compileSeveral(snapshot);
    });
    focusSeveralRow(kind, index + offset);
}

// Renames an intermediate quantity, and every use of it in the rows below.
function renameSeveralDefinition(definition, index, symbol) {
    const previous = definition.equationModel.definitions[index]?.symbol;
    if (!previous || symbol === previous) return;
    const spelled = (name) => latexForBinding({ symbol: name });
    const pattern = new RegExp(spelled(previous).replace(/[\\{}]/g, '\\$&') + (previous.length === 1 ? '(?![A-Za-z0-9])' : ''), 'g');
    changeEdgeModel(definition, (snapshot) => {
        const equations = snapshot.equationModel;
        equations.definitions[index].symbol = symbol;
        const rename = (item) => {
            if (typeof item.latex !== 'string') return;
            const latex = item.latex.replace(pattern, spelled(symbol));
            if (latex !== item.latex) { item.latex = latex; delete item.mathJson; }
        };
        equations.definitions.slice(index + 1).forEach(rename);
        equations.outputs.forEach(rename);
        compileSeveral(snapshot);
    });
}

function focusSeveralRow(kind, index) {
    const row = $(`#editEdgeEquationsList .severalRow[data-kind="${kind}"][data-index="${index}"]`);
    if (!row) return;
    severalFocus = { kind, index };
    const field = severalLatexMode() ? $('textarea', row) : $('math-field', row);
    field?.focus();
}

function previewSeveralEquation(kind, index, latex, origin) {
    if (activeResult || !selectedRelationship) return;
    const definition = selectedRelationship;
    beginEquationEditSession(`edge:${definition.id}:${kind}:${index}`, () => captureEdgeModel(definition), (snapshot) => applyEdgeModel(definition, snapshot));
    const snapshot = { source: definition.source, target: definition.target, parameters: definition.parameters, equationModel: structuredClone(definition.equationModel) };
    const item = severalItems(snapshot.equationModel, kind)[index];
    if (!item) return;
    item.latex = latex;
    // What the user typed is what counts now: no MathJSON from before stands in for it.
    delete item.mathJson;
    compileSeveral(snapshot);
    definition.equationModel = snapshot.equationModel;
    const row = $(`#editEdgeEquationsList .severalRow[data-kind="${kind}"][data-index="${index}"]`);
    if (row && origin !== 'visual') $('math-field', row).setValue(latex, { silenceNotifications: true });
    if (row && origin !== 'latex') $('textarea', row).value = latex;
    // One change can make another row read or stop reading: every row's diagnostics are shown again.
    const { sourceNode, targetNode, candidates } = severalContext(definition);
    const check = checkSeveralEquations(definition.equationModel, candidates, sourceNode, targetNode);
    $$('#editEdgeEquationsList .severalRow').forEach((element) => {
        const results = element.dataset.kind === 'definition' ? check.definitions : check.outputs;
        showSeveralDiagnostics($('.equationDiagnostics', element), results[Number(element.dataset.index)]);
    });
    $('#editEdgeEquationsList .severalSummary').textContent = check.errors.join(' ');
    updateRelationships();
    updateValidationStatus();
}

function insertSeveralReference(binding) {
    if (activeResult || !severalFocus) return;
    const row = $(`#editEdgeEquationsList .severalRow[data-kind="${severalFocus.kind}"][data-index="${severalFocus.index}"]`);
    if (!row) return;
    const latex = latexForBinding(binding);
    if (severalLatexMode()) {
        const source = $('textarea', row);
        source.setRangeText(latex, source.selectionStart, source.selectionEnd, 'end');
        source.dispatchEvent(new Event('input', { bubbles: true }));
        source.focus();
    } else {
        const visual = $('math-field', row);
        visual.insert(latex);
        visual.focus();
    }
}

// ---- A relationship provider an installed plugin contributes ---------------------------------------------------
// An implementation of `kind` (a program in C++ or Python, or an installed plugin's provider), keeping the bindings
// and output, and the source or the plugin reference the implementation already had.
function pluginOrProgram(kind, previous, bindings, output, title) {
    if (kind === 'plugin') {
        return {
            kind, providerApiVersion: 1,
            pluginId: previous?.pluginId ?? '', pluginVersion: previous?.pluginVersion ?? '', providerId: previous?.providerId ?? '',
            bindings, output
        };
    }
    return {
        kind, providerApiVersion: 1,
        source: (previous?.kind === kind || previous?.kind === 'cpp' || previous?.kind === 'python') && previous.source
            ? previous.source : defaultProviderSource(kind, bindings, output.key, title),
        bindings, output
    };
}

async function fillPluginProviders(select, implementation) {
    let choices = [];
    try {
        choices = pluginProviderChoices(await window.extensions.list());
    } catch { /* none to offer */ }
    const current = pluginProviderValue(implementation);
    select.replaceChildren(new Option(choices.length ? 'Choose an installed provider…' : 'No plugin provider installed: install one from Extensions', ''));
    choices.forEach((choice) => select.add(new Option(choice.label, choice.value)));
    if (current && !choices.some((choice) => choice.value === current)) {
        select.add(new Option(`${implementation.pluginId} ${implementation.pluginVersion}: ${implementation.providerId} (not installed here)`, current));
    }
    select.value = current;
}

function pluginReferenceOf(value) {
    try {
        const [pluginId, pluginVersion, providerId] = JSON.parse(value);
        return { pluginId, pluginVersion, providerId };
    } catch {
        return null;
    }
}

$('#editEdgePluginProvider').addEventListener('change', (event) => {
    const reference = pluginReferenceOf(event.target.value);
    if (!selectedRelationship?.implementation || !reference) return;
    changeEdgeModel(selectedRelationship, (snapshot) => Object.assign(snapshot.implementation, reference));
});
$('#groupPluginProvider').addEventListener('change', (event) => {
    const reference = pluginReferenceOf(event.target.value);
    const group = currentEdgeGroup();
    if (!group?.definition.implementation || !reference) return;
    changeEdgeGroupModel(group, (snapshot) => Object.assign(snapshot.definition.implementation, reference));
});
$('#termPluginProvider').addEventListener('change', (event) => {
    const reference = pluginReferenceOf(event.target.value);
    if (!selectedSourceTermNodeId || !reference) return;
    changeSourceTermModel(nodeObjects.get(selectedSourceTermNodeId), selectedSourceTermId, (term) => Object.assign(term.implementation, reference));
});

function bindingInsertTitle(binding) {
    if (binding.kind === 'time') return 'Insert simulation time (seconds)';
    return binding.kind === 'parameter' ? 'Insert parameter' : 'Insert state reference';
}

// Providers get simulation time from their evaluation context, so time is not a bindable input.
function providerReferenceCandidates(definition) {
    const sourceNode = model.nodes.find((node) => node.id === definition.source);
    const targetNode = model.nodes.find((node) => node.id === definition.target);
    return reconcileEquationBindings([], sourceNode, targetNode, definition.parameters).filter((binding) => binding.kind !== 'time');
}

function providerBindingToReference(binding) {
    return {
        kind: binding.kind,
        role: binding.role,
        nodeId: binding.nodeId,
        stateId: binding.stateId,
        parameterId: binding.parameterId
    };
}

function referenceToProviderBinding(key, reference) {
    return reference.kind === 'parameter'
        ? { key, kind: 'parameter', parameterId: reference.parameterId }
        : { key, kind: 'state', role: reference.role, nodeId: reference.nodeId, stateId: reference.stateId };
}

function renderProviderBindingRows(definition) {
    const container = $('#editEdgeProviderBindings');
    container.replaceChildren();
    const bindings = definition.implementation?.bindings ?? [];
    const candidates = providerReferenceCandidates(definition);
    if (!bindings.length) container.innerHTML = '<p class="emptyEditorState">No bindings defined</p>';
    bindings.forEach((binding, index) => {
        const row = document.createElement('div');
        row.className = 'providerBindingRow';
        row.innerHTML = `
            <label class="parameterField"><span>Key</span><input data-field="key" value="${escapeHtml(binding.key ?? '')}"></label>
            <label class="parameterField"><span>Reference</span><select data-field="reference"></select></label>
            <button type="button" title="Remove binding">×</button>
        `;
        const select = $('[data-field="reference"]', row);
        select.replaceChildren(...candidates.map((candidate) => new Option(candidate.label, providerReferenceValue(candidate))));
        select.value = providerReferenceValue(providerBindingToReference(binding));
        $('[data-field="key"]', row).addEventListener('change', (event) => {
            changeEdgeModel(definition, (snapshot) => {
                snapshot.implementation.bindings[index] = { ...snapshot.implementation.bindings[index], key: event.target.value.trim() };
            });
        });
        select.addEventListener('change', (event) => {
            const candidate = candidates.find((option) => providerReferenceValue(option) === event.target.value);
            if (!candidate) return;
            changeEdgeModel(definition, (snapshot) => {
                snapshot.implementation.bindings[index] = referenceToProviderBinding(snapshot.implementation.bindings[index].key, candidate);
            });
        });
        $(':scope > button', row).addEventListener('click', () => changeEdgeModel(definition, (snapshot) => {
            snapshot.implementation.bindings.splice(index, 1);
        }));
        container.appendChild(row);
    });
}

function renderEquationDiagnostics(latex, bindings) {
    const diagnostics = $('#equationDiagnostics');
    const validation = validateEquationLatex(latex, bindings);
    diagnostics.classList.toggle('valid', validation.valid);
    diagnostics.textContent = validation.valid
        ? 'Valid expression · MathJSON ready'
        : validation.errors.join(' ');
    return validation;
}

function insertEquationBinding(binding) {
    if (activeResult) return;
    const latex = latexForBinding(binding);
    if ($('#editEdgeMathField').hidden) {
        const source = $('#editEdgeEquation');
        source.setRangeText(latex, source.selectionStart, source.selectionEnd, 'end');
        source.dispatchEvent(new Event('input', { bubbles: true }));
        source.focus();
    } else {
        $('#editEdgeMathField').insert(latex);
        $('#editEdgeMathField').focus();
    }
}

// A group-member edge is never edited on its own -- no override without detaching, per
// docs/edgeGroups.md -- so every path that would otherwise open the single-edge editor
// on one routes here to the group's own editor instead.
function openRelationshipEditor(definition, clientX, clientY) {
    if (definition.groupId != null) {
        openEdgeGroupEditor(definition.groupId);
        return;
    }
    const editor = $('#edgeEditor');
    selectRelationship(definition);
    hideCards(editor);
    renderEdgeEditor(definition);
    editor.style.removeProperty('left');
    editor.style.removeProperty('top');
    editor.classList.remove('hidden');
    applyInspectorReadOnly();
    requestAnimationFrame(avoidAssistantInspectorOverlap);
}

function openAddPalette(clientX, clientY) {
    const palette = $('#addPalette');
    hideCards(palette);
    positionCard(palette, clientX, clientY);
}

function openNodeContextMenu(clientX, clientY) {
    const menu = $('#nodeContextMenu');
    hideCards(menu);
    const multi = selectedNodeIds.size > 1;
    $('#nodeContextConnect').hidden = multi;
    $('#nodeContextToggle').hidden = multi;
    $('#nodeContextDisableAll').hidden = !multi;
    $('#nodeContextEnableAll').hidden = !multi;
    $('#nodeContextCreateEdgeGroup').hidden = !multi;
    // Scoped to whichever group is currently open for editing -- a node can technically belong
    // to more than one group, but a single context click can only unambiguously mean "this one".
    const activeGroup = currentEdgeGroup();
    const soleSelectedId = !multi ? selectedNode?.userData.id : null;
    $('#nodeContextAddToGroup').hidden = multi || !activeGroup || activeGroup.memberNodeIds.includes(soleSelectedId);
    $('#nodeContextDetachFromGroup').hidden = multi || !activeGroup || !activeGroup.memberNodeIds.includes(soleSelectedId);
    if (multi) {
        $('#nodeContextDeleteLabel').textContent = `Delete ${selectedNodeIds.size} nodes`;
    } else {
        const enabled = selectedNode?.userData.definition.enabled !== false;
        $('#nodeContextToggleLabel').textContent = enabled ? 'Disable node' : 'Enable node';
        $('#nodeContextDeleteLabel').textContent = 'Delete node';
    }
    positionCard(menu, clientX, clientY);
}

function openEdgeContextMenu(clientX, clientY) {
    const menu = $('#edgeContextMenu');
    hideCards(menu);
    const grouped = selectedRelationship?.groupId != null;
    const enabled = selectedRelationship?.enabled !== false;
    $('#edgeContextToggleLabel').textContent = enabled ? 'Disable edge' : 'Enable edge';
    $('#edgeContextAddWaypoint').hidden = grouped || !pendingWaypoint;
    $('#edgeContextToggle').hidden = grouped;
    $('#edgeContextDelete').hidden = grouped;
    $('#edgeContextOpenGroup').hidden = !grouped;
    positionCard(menu, clientX, clientY);
}

function openWaypointContextMenu(clientX, clientY) {
    const menu = $('#waypointContextMenu');
    hideCards(menu);
    positionCard(menu, clientX, clientY);
}

function addStateVariableRow(values = {}) {
    const row = document.createElement('div');
    row.className = 'builderRow stateVariableRow';
    row.innerHTML = `
        <input data-field="name" placeholder="Name" value="${values.name ?? ''}">
        <input data-field="symbol" placeholder="Symbol" value="${values.symbol ?? ''}">
        <input data-field="value" type="number" placeholder="Initial" value="${values.value ?? ''}">
        <input data-field="unit" placeholder="Unit" value="${values.unit ?? ''}">
        <button class="removeBuilderRow" type="button" title="Remove">×</button>
    `;
    $('#stateVariableRows').appendChild(row);
    row.querySelector('.removeBuilderRow').addEventListener('click', () => {
        row.remove();
        refreshSourceStateOptions();
    });
    row.querySelectorAll('input').forEach((input) => input.addEventListener('input', refreshSourceStateOptions));
    refreshSourceStateOptions();
}

function normalizeImportedGeometry(geometry) {
    if (!geometry.attributes.normal) geometry.computeVertexNormals();
    geometry.computeBoundingBox();
    const size = geometry.boundingBox.getSize(new THREE.Vector3());
    const largestDimension = Math.max(size.x, size.y, size.z);
    if (!Number.isFinite(largestDimension) || largestDimension <= 0) {
        throw new Error('The file contains no usable geometry.');
    }
    geometry.scale(2.8 / largestDimension, 2.8 / largestDimension, 2.8 / largestDimension);
    geometry.computeBoundingBox();
    const center = geometry.boundingBox.getCenter(new THREE.Vector3());
    geometry.translate(-center.x, -center.y, -center.z);
    geometry.computeBoundingSphere();
    return geometry;
}

function geometryFromStepResult(result) {
    if (!result.success || !result.meshes?.length) throw new Error('OpenCascade could not read this STEP file.');
    const geometries = result.meshes.map((resultMesh) => {
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute(
            'position',
            new THREE.Float32BufferAttribute(resultMesh.attributes.position.array, 3)
        );
        if (resultMesh.attributes.normal) {
            geometry.setAttribute(
                'normal',
                new THREE.Float32BufferAttribute(resultMesh.attributes.normal.array, 3)
            );
        } else {
            geometry.computeVertexNormals();
        }
        geometry.setIndex(resultMesh.index.array);
        return geometry.toNonIndexed();
    });
    const merged = mergeGeometries(geometries, false);
    geometries.forEach((geometry) => geometry.dispose());
    if (!merged) throw new Error('The STEP meshes could not be combined.');
    return merged;
}

// Shared by both the on-disk "Import STL or STEP" flow and the bundled shape library, since
// a library entry is parsed exactly like a user-supplied file once its bytes are in hand.
async function geometryFromBytes(buffer, extension) {
    if (extension === 'stl') return normalizeImportedGeometry(new STLLoader().parse(buffer));
    if (extension === 'step' || extension === 'stp') {
        if (!window.occtimportjs) throw new Error('The STEP importer is unavailable.');
        const occt = await window.occtimportjs();
        const result = occt.ReadStepFile(new Uint8Array(buffer), {
            linearUnit: 'millimeter',
            linearDeflectionType: 'bounding_box_ratio',
            linearDeflection: 0.001,
            angularDeflection: 0.5
        });
        return normalizeImportedGeometry(geometryFromStepResult(result));
    }
    throw new Error('Choose an STL, STEP, or STP file.');
}

async function importNodeGeometry(file) {
    const extension = file.name.split('.').pop()?.toLowerCase();
    return geometryFromBytes(await file.arrayBuffer(), extension);
}

// Persists a successfully-imported shape file into the user's own shape library (userData/shapes,
// separate from the read-only bundled one) so it's reusable on other nodes without re-uploading --
// a File's arrayBuffer() can be read more than once, so this doesn't disturb the geometry import
// that already consumed it. Deliberately non-fatal: failing to save to the library shouldn't
// undo an otherwise-successful shape import, so this only ever appends to the status text.
async function saveUploadToShapeLibrary(file, status) {
    try {
        const bytes = new Uint8Array(await file.arrayBuffer());
        await window.shapeLibrary.saveUpload(file.name, bytes);
        shapeLibraryEntries = null;
        // A re-upload could reuse a filename (and therefore id) that already has a cached
        // thumbnail from a different, previously-deleted file -- clear rather than diff.
        shapeLibraryThumbnailCache.clear();
        status.textContent += ' · saved to shape library';
    } catch (error) {
        console.error(error);
    }
}

async function importLibraryShape(id) {
    const shape = await window.shapeLibrary.load(id);
    // shape.data crosses the IPC boundary as a plain Uint8Array (structured clone), not a
    // Node Buffer -- pull out a real ArrayBuffer the same way STLLoader/occt-import-js expect.
    const bytes = shape.data;
    const buffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
    const geometry = await geometryFromBytes(buffer, shape.format);
    return { geometry, name: shape.name };
}

let shapeLibraryEntries = null;
let shapeLibraryTarget = null;
let shapeLibraryDomain = 'all';

function domainLabel(domain) {
    if (domain === 'userUploaded') return 'User uploaded';
    return `${domain.charAt(0).toUpperCase()}${domain.slice(1)}`;
}

function shapeDomains(shape) {
    if (Array.isArray(shape?.domains) && shape.domains.length) return shape.domains;
    if (shape?.domain) return [shape.domain];
    return ['general'];
}

function shapeLibraryThumbnailMarkup(id) {
    if (shapeLibraryThumbnailCache.has(id)) {
        const dataUrl = shapeLibraryThumbnailCache.get(id);
        return dataUrl
            ? `<img class="examplesExplorerThumb" src="${escapeHtml(dataUrl)}" alt="">`
            : '<span class="examplesExplorerThumbPlaceholder">No preview</span>';
    }
    return '<img class="examplesExplorerThumb" alt="">';
}

function renderShapeLibraryResults() {
    const query = $('#shapeLibrarySearch').value.trim().toLowerCase();
    const matches = shapeLibraryEntries.filter((shape) => {
        const domains = shapeDomains(shape);
        if (shapeLibraryDomain !== 'all' && !domains.includes(shapeLibraryDomain)) return false;
        if (!query) return true;
        const haystack = [shape.name, ...domains, ...(shape.tags ?? [])].join(' ').toLowerCase();
        return haystack.includes(query);
    });
    // Old buttons are about to be discarded -- drop the observer's references to them first so
    // it doesn't accumulate entries for detached elements across repeated search keystrokes.
    const observer = ensureShapeLibraryThumbnailObserver();
    observer.disconnect();
    $('#shapeLibraryResults').replaceChildren(...matches.map((shape) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'shapeLibraryItem';
        button.dataset.shapeId = shape.id;
        button.classList.toggle('selected', shape.id === shapeLibrarySelectedId);
        const domains = shapeDomains(shape);
        const domainText = domains.map(domainLabel).join(', ');
        button.innerHTML = `${shapeLibraryThumbnailMarkup(shape.id)}<b>${escapeHtml(shape.name)}</b><small>${escapeHtml(domainText)}<span class="shapeFormatBadge">${escapeHtml(shape.format.toUpperCase())}</span></small>`;
        if (!shapeLibraryThumbnailCache.has(shape.id)) observer.observe(button);
        return button;
    }));
    $('#shapeLibraryEmpty').hidden = matches.length > 0;
}

async function openShapeLibrary(target) {
    shapeLibraryTarget = target;
    if (!shapeLibraryEntries) shapeLibraryEntries = await window.shapeLibrary.list();
    shapeLibraryDomain = 'all';
    shapeLibrarySelectedId = null;
    $('#shapeLibrarySearch').value = '';
    $('#shapeLibraryDetailEmpty').hidden = false;
    $('#shapeLibraryDetailContent').hidden = true;
    const domains = ['all', ...new Set(shapeLibraryEntries.flatMap((shape) => shapeDomains(shape)))];
    $('#shapeLibraryDomains').replaceChildren(...domains.map((domain) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = domain === 'all' ? 'All' : domainLabel(domain);
        button.classList.toggle('active', domain === shapeLibraryDomain);
        button.addEventListener('click', () => {
            shapeLibraryDomain = domain;
            $$('#shapeLibraryDomains button').forEach((chip) => chip.classList.toggle('active', chip === button));
            renderShapeLibraryResults();
        });
        return button;
    }));
    renderShapeLibraryResults();
    $('#shapeLibraryDialog').showModal();
    $('#shapeLibrarySearch').focus();
}

async function applyLibraryShape(id) {
    const { geometry, name } = await importLibraryShape(id);
    if (shapeLibraryTarget === 'editor' && selectedNode) {
        changeNodeAppearance(selectedNode, {
            ...captureNodeAppearance(selectedNode.userData.definition),
            shape: 'imported',
            importedGeometry: geometry,
            geometryFileName: name
        });
        $('#editNodeShape').value = '';
        $('#editGeometryStatus').textContent = `${name} applied`;
    } else if (shapeLibraryTarget === 'builder') {
        pendingImportedGeometry?.dispose();
        pendingImportedGeometry = geometry;
        pendingGeometryFileName = name;
        $('#newNodeShape').value = 'imported';
        $('#geometryImportStatus').textContent = `${name} ready`;
    }
    geometry.dispose();
    $('#shapeLibraryDialog').close();
}

// A second, small, permanent three.js scene/renderer for the shape library's own detail pane --
// the main canvas (this file, ~517-535) is otherwise the only one in the renderer process.
// Created lazily on first use and kept alive for the app's lifetime, the same way the main
// canvas is a persistent singleton, rather than being rebuilt on every dialog open.
let shapeLibraryPreviewScene = null;
let shapeLibraryPreviewCamera = null;
let shapeLibraryPreviewRenderer = null;
let shapeLibraryPreviewOrbit = null;
let shapeLibraryPreviewMesh = null;
let shapeLibraryPreviewRevision = 0;
let shapeLibraryPreviewAnimating = false;
let shapeLibrarySelectedId = null;

function ensureShapeLibraryPreview() {
    if (shapeLibraryPreviewRenderer) return;
    const canvas = $('#shapeLibraryPreviewCanvas');
    shapeLibraryPreviewScene = new THREE.Scene();
    shapeLibraryPreviewScene.background = new THREE.Color(0x060d12);
    shapeLibraryPreviewCamera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
    shapeLibraryPreviewRenderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    shapeLibraryPreviewRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    // Same light rig as the main canvas (~779-787), minus its floor grid -- keeps a previewed
    // shape's shading consistent with how it will actually look once applied to a node.
    shapeLibraryPreviewScene.add(new THREE.HemisphereLight(0xbfe4f2, 0x16212a, 2.25));
    const keyLight = new THREE.DirectionalLight(0xfff0d6, 3.2);
    keyLight.position.set(7, 11, 9);
    shapeLibraryPreviewScene.add(keyLight);
    const rimLight = new THREE.DirectionalLight(0x65d6db, 2.1);
    rimLight.position.set(-8, 4, -7);
    shapeLibraryPreviewScene.add(rimLight);
    // Rotate only -- zoom/pan would let this small canvas capture page scroll/drag gestures it
    // has no real need for, since normalizeImportedGeometry already frames every shape into the
    // same consistent bounding box regardless of its original size.
    shapeLibraryPreviewOrbit = new OrbitControls(shapeLibraryPreviewCamera, shapeLibraryPreviewRenderer.domElement);
    shapeLibraryPreviewOrbit.enableZoom = false;
    shapeLibraryPreviewOrbit.enablePan = false;
    new ResizeObserver(resizeShapeLibraryPreview).observe(canvas);
}

function resizeShapeLibraryPreview() {
    const canvas = $('#shapeLibraryPreviewCanvas');
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    shapeLibraryPreviewCamera.aspect = rect.width / rect.height;
    shapeLibraryPreviewCamera.updateProjectionMatrix();
    shapeLibraryPreviewRenderer.setSize(rect.width, rect.height, false);
}

function animateShapeLibraryPreview() {
    if (!shapeLibraryPreviewAnimating) return;
    requestAnimationFrame(animateShapeLibraryPreview);
    shapeLibraryPreviewOrbit.update();
    shapeLibraryPreviewRenderer.render(shapeLibraryPreviewScene, shapeLibraryPreviewCamera);
}

function disposeShapeLibraryPreviewMesh() {
    if (!shapeLibraryPreviewMesh) return;
    shapeLibraryPreviewScene.remove(shapeLibraryPreviewMesh);
    shapeLibraryPreviewMesh.geometry.dispose();
    shapeLibraryPreviewMesh.material.dispose();
    shapeLibraryPreviewMesh = null;
}

// Stops the render loop and disposes the previewed mesh -- called on every dialog-close path
// (Cancel, Escape, and Apply's own close()) via the dialog's native 'close' event, so there's
// one single cleanup point rather than duplicating this in each button handler.
function stopShapeLibraryPreview() {
    shapeLibraryPreviewAnimating = false;
    disposeShapeLibraryPreviewMesh();
}

// Resets to the same canonical framing for every newly-selected shape, rather than carrying
// over whatever angle the user last rotated to -- so each shape starts from a consistent,
// predictable view instead of an awkward angle inherited from the previous one.
function frameShapeLibraryPreview() {
    shapeLibraryPreviewCamera.position.set(3, 2.4, 3);
    shapeLibraryPreviewOrbit.target.set(0, 0, 0);
    shapeLibraryPreviewOrbit.update();
}

async function selectShapeLibraryPreview(id) {
    const shape = shapeLibraryEntries.find((entry) => entry.id === id);
    $('#shapeLibraryDetailEmpty').hidden = true;
    $('#shapeLibraryDetailContent').hidden = false;
    const domains = shapeDomains(shape);
    const domainText = domains.map(domainLabel).join(' · ');
    $('#shapeLibraryDetailTitle').textContent = shape?.name ?? '';
    $('#shapeLibraryDetailMeta').textContent = shape ? `${domainText} · ${shape.format.toUpperCase()} · Loading…` : '';
    ensureShapeLibraryPreview();
    resizeShapeLibraryPreview();
    // A later click while this load is still in flight must win -- discard a now-stale result
    // rather than overwriting whatever the user has since selected.
    const revision = ++shapeLibraryPreviewRevision;
    let geometry;
    try {
        ({ geometry } = await importLibraryShape(id));
    } catch (error) {
        if (revision === shapeLibraryPreviewRevision) $('#shapeLibraryDetailMeta').textContent = `Could not preview this shape: ${error.message}`;
        return;
    }
    if (revision !== shapeLibraryPreviewRevision) {
        geometry.dispose();
        return;
    }
    disposeShapeLibraryPreviewMesh();
    const material = new THREE.MeshStandardMaterial({ color: 0x42c9bc, roughness: 0.55, metalness: 0.1 });
    shapeLibraryPreviewMesh = new THREE.Mesh(geometry, material);
    shapeLibraryPreviewScene.add(shapeLibraryPreviewMesh);
    frameShapeLibraryPreview();
    $('#shapeLibraryDetailMeta').textContent = shape ? `${domainText} · ${shape.format.toUpperCase()}` : '';
    // Guarded so switching between several shapes never spawns more than one concurrent
    // requestAnimationFrame chain -- animateShapeLibraryPreview() re-schedules itself as long as
    // this stays true, so it only needs to be (re)started when nothing is running yet.
    if (!shapeLibraryPreviewAnimating) {
        shapeLibraryPreviewAnimating = true;
        animateShapeLibraryPreview();
    }
}

// Static per-card thumbnails for the shape library grid, distinct from the live rotating preview
// above -- one shared offscreen renderer (never inserted into the DOM) renders each shape exactly
// once, caches the resulting PNG, and stops. This keeps WebGL context/render-loop cost constant
// regardless of how many shapes exist: no per-card context, no continuous rendering.
let shapeLibraryThumbnailCache = new Map(); // id -> dataURL (success) | null (permanent failure)
let shapeLibraryThumbnailQueue = [];
let shapeLibraryThumbnailQueued = new Set();
let shapeLibraryThumbnailBusy = false;
let shapeLibraryThumbnailObserver = null;
let shapeLibraryThumbnailScene = null;
let shapeLibraryThumbnailCamera = null;
let shapeLibraryThumbnailRenderer = null;

function ensureShapeLibraryThumbnailRenderer() {
    if (shapeLibraryThumbnailRenderer) return;
    const canvas = document.createElement('canvas');
    canvas.width = 160;
    canvas.height = 100;
    shapeLibraryThumbnailScene = new THREE.Scene();
    shapeLibraryThumbnailScene.background = new THREE.Color(0x060d12);
    shapeLibraryThumbnailCamera = new THREE.PerspectiveCamera(42, canvas.width / canvas.height, 0.1, 100);
    shapeLibraryThumbnailCamera.position.set(3, 2.4, 3);
    shapeLibraryThumbnailCamera.lookAt(0, 0, 0);
    // preserveDrawingBuffer is required for toDataURL() to read back a framebuffer that would
    // otherwise be cleared right after this single render call.
    shapeLibraryThumbnailRenderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
    shapeLibraryThumbnailRenderer.setSize(canvas.width, canvas.height, false);
    // Same light rig as ensureShapeLibraryPreview (~2411-2419), for shading consistency between
    // a shape's card thumbnail and its live detail-pane preview.
    shapeLibraryThumbnailScene.add(new THREE.HemisphereLight(0xbfe4f2, 0x16212a, 2.25));
    const keyLight = new THREE.DirectionalLight(0xfff0d6, 3.2);
    keyLight.position.set(7, 11, 9);
    shapeLibraryThumbnailScene.add(keyLight);
    const rimLight = new THREE.DirectionalLight(0x65d6db, 2.1);
    rimLight.position.set(-8, 4, -7);
    shapeLibraryThumbnailScene.add(rimLight);
}

async function generateShapeLibraryThumbnail(id) {
    try {
        ensureShapeLibraryThumbnailRenderer();
        const { geometry } = await importLibraryShape(id);
        const material = new THREE.MeshStandardMaterial({ color: 0x42c9bc, roughness: 0.55, metalness: 0.1 });
        const mesh = new THREE.Mesh(geometry, material);
        shapeLibraryThumbnailScene.add(mesh);
        shapeLibraryThumbnailRenderer.render(shapeLibraryThumbnailScene, shapeLibraryThumbnailCamera);
        const dataUrl = shapeLibraryThumbnailRenderer.domElement.toDataURL('image/png');
        shapeLibraryThumbnailScene.remove(mesh);
        geometry.dispose();
        material.dispose();
        return dataUrl;
    } catch (error) {
        console.error(error);
        return null;
    }
}

function shapeLibraryItemButton(id) {
    return $$('#shapeLibraryResults .shapeLibraryItem').find((item) => item.dataset.shapeId === id);
}

// The queue's only real job is bounding work to one shape at a time (STEP parsing runs on this
// thread and would jank the UI if several ran concurrently) -- staleness is handled by simply
// re-checking whether a matching card still exists right before doing the work, rather than a
// revision counter, since a shape scrolled/filtered away and back is still valid to thumbnail.
async function runShapeLibraryThumbnailQueue() {
    if (shapeLibraryThumbnailBusy) return;
    shapeLibraryThumbnailBusy = true;
    while (shapeLibraryThumbnailQueue.length) {
        const id = shapeLibraryThumbnailQueue.shift();
        shapeLibraryThumbnailQueued.delete(id);
        if (shapeLibraryThumbnailCache.has(id) || !shapeLibraryItemButton(id)) continue;
        const dataUrl = await generateShapeLibraryThumbnail(id);
        shapeLibraryThumbnailCache.set(id, dataUrl);
        const button = shapeLibraryItemButton(id);
        const img = button?.querySelector('img.examplesExplorerThumb');
        if (dataUrl && img) img.src = dataUrl;
    }
    shapeLibraryThumbnailBusy = false;
}

function enqueueShapeLibraryThumbnail(id) {
    if (shapeLibraryThumbnailCache.has(id) || shapeLibraryThumbnailQueued.has(id)) return;
    shapeLibraryThumbnailQueued.add(id);
    shapeLibraryThumbnailQueue.push(id);
    runShapeLibraryThumbnailQueue();
}

function ensureShapeLibraryThumbnailObserver() {
    if (shapeLibraryThumbnailObserver) return shapeLibraryThumbnailObserver;
    shapeLibraryThumbnailObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            shapeLibraryThumbnailObserver.unobserve(entry.target);
            enqueueShapeLibraryThumbnail(entry.target.dataset.shapeId);
        });
    }, { root: $('#shapeLibraryResults'), rootMargin: '200px 0px' });
    return shapeLibraryThumbnailObserver;
}

let componentLibraryEntries = null;
let componentLibraryDomains = new Set();
let componentLibraryType = 'all';
let componentLibraryPlacementCount = 0;
let pendingEdgeTemplate = null;

function renderComponentLibraryItem(template) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'componentLibraryItem';
    button.dataset.templateId = template.id;
    button.title = template.description ?? '';
    button.innerHTML = `<span class="componentLibrarySwatch" style="background:${escapeHtml(template.color ?? '#42c9bc')}"></span><span><b>${escapeHtml(template.name)}</b><small>${template.kind === 'bundle' ? `Bundle · ${template.edges.length} edges` : template.kind === 'node' ? 'Node' : 'Edge'} · ${escapeHtml(template.domains.map(domainLabel).join(', '))}</small></span>`;
    button.addEventListener('click', () => applyComponentTemplate(template));
    return button;
}

function renderComponentLibraryResults() {
    const query = $('#componentLibrarySearch').value.trim().toLowerCase();
    const matches = componentLibraryEntries.filter((template) => {
        if (componentLibraryType !== 'all' && template.kind !== componentLibraryType) return false;
        if (componentLibraryDomains.size && !template.domains.some((domain) => componentLibraryDomains.has(domain))) return false;
        if (!query) return true;
        const haystack = [template.name, template.description ?? '', ...template.domains].join(' ').toLowerCase();
        return haystack.includes(query);
    });
    const container = $('#componentLibraryResults');
    if (query || componentLibraryDomains.size) {
        container.replaceChildren(...matches.map(renderComponentLibraryItem));
    } else {
        const domains = [...new Set(componentLibraryEntries.flatMap((template) => template.domains))].sort();
        container.replaceChildren(...domains.map((domain) => {
            const items = matches.filter((template) => template.domains.includes(domain));
            if (!items.length) return null;
            const section = document.createElement('div');
            section.className = 'componentLibrarySection';
            section.innerHTML = `<h3>${escapeHtml(domainLabel(domain))}</h3>`;
            items.forEach((template) => section.appendChild(renderComponentLibraryItem(template)));
            return section;
        }).filter(Boolean));
    }
    $('#componentLibraryEmpty').hidden = matches.length > 0;
}

function renderComponentLibraryChips() {
    const types = [['all', 'All'], ['node', 'Nodes'], ['edge', 'Edges'], ['bundle', 'Bundles']];
    $('#componentLibraryTypeChips').replaceChildren(...types.map(([type, label]) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = label;
        button.classList.toggle('active', type === componentLibraryType);
        button.addEventListener('click', () => {
            componentLibraryType = type;
            $$('#componentLibraryTypeChips button').forEach((chip) => chip.classList.toggle('active', chip === button));
            renderComponentLibraryResults();
        });
        return button;
    }));
    const domains = [...new Set(componentLibraryEntries.flatMap((template) => template.domains))].sort();
    $('#componentLibraryDomainChips').replaceChildren(...domains.map((domain) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = domainLabel(domain);
        button.classList.toggle('active', componentLibraryDomains.has(domain));
        button.addEventListener('click', () => {
            if (componentLibraryDomains.has(domain)) componentLibraryDomains.delete(domain);
            else componentLibraryDomains.add(domain);
            button.classList.toggle('active', componentLibraryDomains.has(domain));
            renderComponentLibraryResults();
        });
        return button;
    }));
}

async function openComponentLibraryPanel() {
    componentLibraryEntries = await window.componentLibrary.list();
    componentLibraryDomains = new Set();
    componentLibraryType = 'all';
    $('#componentLibrarySearch').value = '';
    renderComponentLibraryChips();
    renderComponentLibraryResults();
    $('#componentLibraryPanel').hidden = false;
    $('#componentLibraryButton').classList.add('active');
    $('#componentLibraryButton').ariaExpanded = 'true';
}

function closeComponentLibraryPanel() {
    $('#componentLibraryPanel').hidden = true;
    $('#componentLibraryButton').classList.remove('active');
    $('#componentLibraryButton').ariaExpanded = 'false';
}

// Canonical renderer-side insertion commands. Every interactive creation workflow supplies a
// fully resolved definition, then comes through these functions for model insertion, scene
// creation, selection, status refresh and undo/redo. Callers may still own workflow-specific
// concerns such as placement, endpoint picking and imported-geometry cleanup, but must not
// reproduce the actual commit sequence.
// `history` adds to this insertion's undo step whatever else the caller changed alongside it.
function insertNodeDefinition(definition, { attachCurrentTransform = false, openInspector = true, history = null } = {}) {
    model.nodes.push(definition);
    createNode(definition);
    updateModelStatus();
    const object = nodeObjects.get(definition.id);
    selectNode(object);
    if (attachCurrentTransform && currentTool in transformPropertyForTool) transformControls.attach(object);
    recordHistory({
        undo: () => { history?.undo(); setNodeVisibility(definition.id, false); },
        redo: () => { history?.redo(); setNodeVisibility(definition.id, true); }
    });
    if (openInspector) openNodeEditor(definition);
    return object;
}

function insertRelationshipDefinition(definition, { openInspector = true } = {}) {
    model.relationships.push(definition);
    createRelationship(definition);
    updateRelationships();
    updateModelStatus();
    selectRelationship(definition);
    recordHistory({
        undo: () => setRelationshipVisibility(definition.id, false),
        redo: () => setRelationshipVisibility(definition.id, true)
    });
    if (openInspector) openRelationshipEditor(definition);
    return definition;
}

// Places the new node with a small, deterministic per-application offset so repeated placements
// from the sidebar don't stack exactly on top of one another -- there is no drag-to-position
// interaction yet (see docs/proposals/componentLibrary.md), so this mirrors "Add node"'s own
// fixed-position default as closely as possible while staying usable for several placements in a row.
function applyNodeTemplate(template) {
    const id = allocateModelEntityId();
    const resolvedStates = template.states.map((state) => ({
        id: allocateModelEntityId(),
        label: state.label,
        symbol: state.symbol,
        initialValue: state.initialValue,
        unit: state.unit ?? '',
        value: stateValueText(state.initialValue, state.unit).text, exactValue: stateValueText(state.initialValue, state.unit).exact
    }));
    componentLibraryPlacementCount += 1;
    const definition = {
        id,
        title: template.name,
        type: 'Custom node',
        shape: template.shape ?? 'box',
        importedGeometry: null,
        geometryFileName: null,
        // X is deliberately biased toward positive and cascaded, not plane-matched: the component
        // library sidebar docks over the left side of the canvas while it's open, so placing new
        // nodes there would put them behind it on screen, and successive drops need to not land
        // exactly on top of each other. Y/Z still follow whatever plane the rest of the model is
        // already in, the same as the "Add node" builder.
        position: [
            1.5 + ((componentLibraryPlacementCount - 1) % 5) * 1.6,
            sharedVisibleNodeAxisValue(1) ?? -0.7,
            sharedVisibleNodeAxisValue(2) ?? 0
        ],
        subsystemId: activeSubsystemId,
        deleted: false,
        enabled: true,
        color: Number.parseInt((template.color ?? '#34727a').replace('#', ''), 16),
        states: resolvedStates,
        sourceTerms: [],
        substepsPerGlobalStep: 1
    };
    // Built against `definition` after its states are resolved, via the same function the node
    // editor's own source term UI uses -- a self-referencing coupling (e.g. displacement's rate
    // equals velocity) needs no cross-node binding, just a symbol match against this node's own states.
    const sharedBefore = structuredClone(model.sharedParameters);
    const { sharedAfter, sharedByKey } = resolveTemplateSharedParameters(template.sharedParameters, sharedBefore);
    definition.sourceTerms = (template.sourceTerms ?? []).map((term) => {
        const built = {
            id: allocateModelEntityId(), state: term.state, expression: term.expression,
            ...(term.setsValue ? { setsValue: true } : {}),
            ...(term.parameters?.length ? { parameters: term.parameters.map((parameter) => templateParameter(parameter, sharedByKey)) } : {})
        };
        built.expressionModel = normalizeSourceTermExpressionModel(definition, built);
        built.expression = built.expressionModel.latex;
        return built;
    });
    hideCards();
    model.sharedParameters = sharedAfter;
    insertNodeDefinition(definition, {
        history: {
            undo: () => { model.sharedParameters = structuredClone(sharedBefore); },
            redo: () => { model.sharedParameters = structuredClone(sharedAfter); }
        }
    });
}

// Arms the existing endpoint-pick flow for both endpoints in sequence (no node needs to be
// pre-selected), pre-loading the builder with the template's equation and parameters first. Binding
// is automatic: the latex already references role-prefixed state symbols (e.g. sourceTemperature),
// so reconcileEquationBindings/normalizeEdgeEquationModel resolve it exactly like a hand-typed
// equation would -- a state named differently just leaves that symbol unresolved, which the builder's
// own live diagnostics and the model validator already surface, with no separate binding step to build.
function applyEdgeTemplate(template) {
    openEdgeBuilder();
    $('#newEdgeName').value = template.name;
    $('#newEdgeDirectionality').value = template.bidirectional ? 'bidirectional' : 'directed';
    if (template.color) $('#newEdgeColor').value = template.color;
    $('#edgeParameterRows').replaceChildren();
    (template.parameters ?? []).forEach((parameter) => addEdgeParameterRow(parameter));
    $('#edgeEquation').value = template.latex;
    $('#edgeMathField').setValue(template.latex, { silenceNotifications: true });
    renderBuilderEquationDiagnostics();
    const hint = $('#componentLibraryHint');
    const portList = (port) => [port].flat().map((symbol) => `"${symbol}"`).join('/');
    hint.textContent = `Pick a source and target node for "${template.name}". States named ${portList(template.ports.source)} (source) and ${portList(template.ports.target)} (target) bind automatically; anything else is left for you to fix afterward.`;
    hint.hidden = false;
    startEndpointPick('source');
    endpointPickContinuation = () => {
        startEndpointPick('target');
        endpointPickContinuation = () => {
            hint.hidden = true;
            // Most templates are happy with the builder's own default output (the target's first
            // state), but one whose relevant state isn't the target's first -- e.g. a rod's
            // correction lands on velocity while position is declared first -- names it explicitly
            // instead. Required on every template (see validateComponentTemplate), since that
            // default is not reliable across a chained two-endpoint pick to begin with.
            const roleNode = model.nodes.find((node) => node.id === Number($(`#edge${template.output.role[0].toUpperCase()}${template.output.role.slice(1)}`).value));
            const state = roleNode?.states.find((candidate) => candidate.symbol === template.output.state);
            const option = state && [...$('#edgeEquationOutput').options].find((candidate) => candidate.value === equationOutputValue(template.output.role, state.id));
            if (option) $('#edgeEquationOutput').value = option.value;
            pendingEdgeTemplate = template;
        };
    };
}

// Assigns the selected nodes to a bundle's endpoints. A node fits an endpoint when it has every
// state symbol that endpoint's edge ports name, so the assignment is normally forced by the nodes
// themselves and the order they were selected in only breaks ties -- a user need not remember
// which node to click first. Returns { assignment: Map(endpointId -> node) } or { error }.
function assignBundleEndpoints(template, nodes) {
    const required = new Map(template.endpoints.map((endpoint) => [endpoint.id, new Set()]));
    for (const edge of template.edges) {
        [edge.ports.source].flat().forEach((symbol) => required.get(edge.from).add(symbol));
        [edge.ports.target].flat().forEach((symbol) => required.get(edge.to).add(symbol));
    }
    const fits = (endpoint, node) => [...required.get(endpoint.id)].every((symbol) => node.states.some((state) => state.symbol === symbol));
    const permutations = (items) => items.length <= 1 ? [items] : items.flatMap((item, index) =>
        permutations([...items.slice(0, index), ...items.slice(index + 1)]).map((rest) => [item, ...rest]));
    // Permutations come out with the identity (selection) order first, so a tie keeps the user's order.
    const match = permutations(nodes).find((candidate) => template.endpoints.every((endpoint, index) => fits(endpoint, candidate[index])));
    if (match) return { assignment: new Map(template.endpoints.map((endpoint, index) => [endpoint.id, match[index]])) };
    const missing = template.endpoints.filter((endpoint) => !nodes.some((node) => fits(endpoint, node)))
        .map((endpoint) => `${endpoint.label} (needs states ${[...required.get(endpoint.id)].map((symbol) => `"${symbol}"`).join(', ')})`);
    return { error: missing.length
        ? `The selected nodes don't fit: nothing matches ${missing.join('; ')}.`
        : 'The selected nodes cannot be matched to the bundle\'s endpoints one-to-one.' };
}

// A template's declared shared parameters, added to a copy of the project's: a project-scoped one
// reuses an existing shared parameter with the same symbol, anything else gets a fresh one (with a
// numeric suffix if its symbol is taken), so each placement of an instance-scoped one is its own.
function resolveTemplateSharedParameters(declaredList, sharedBefore) {
    const sharedAfter = structuredClone(sharedBefore);
    const sharedByKey = new Map();
    for (const declared of declaredList ?? []) {
        const existing = declared.scope === 'project' ? sharedAfter.find((shared) => shared.symbol === declared.symbol) : null;
        if (existing) {
            sharedByKey.set(declared.key, existing);
            continue;
        }
        let symbol = declared.symbol;
        for (let suffix = 2; sharedAfter.some((shared) => shared.symbol === symbol); suffix += 1) symbol = `${declared.symbol}${suffix}`;
        const created = {
            id: allocateModelEntityId(), name: declared.name, symbol, value: declared.value, unit: declared.unit ?? '',
            mode: declared.mode ?? 'constant',
            ...(declared.mode === 'live' ? { control: structuredClone(declared.control) } : {})
        };
        sharedAfter.push(created);
        sharedByKey.set(declared.key, created);
    }
    return { sharedAfter, sharedByKey };
}

// A template parameter as placed in the model, linked to its shared parameter when it names one.
function templateParameter(parameter, sharedByKey) {
    const shared = parameter.shared === undefined ? null : sharedByKey.get(parameter.shared);
    const source = shared ?? parameter;
    return {
        id: allocateModelEntityId(), name: parameter.name, symbol: parameter.symbol,
        value: Number(source.value) || 0, unit: source.unit ?? '', mode: source.mode ?? 'constant',
        ...(source.mode === 'live' ? { control: structuredClone(source.control) } : {}),
        ...(shared ? { sharedParameterId: shared.id } : {})
    };
}

// Stamps out every edge of a bundle between the selected nodes as one undoable step. Shared
// parameters the bundle declares are created once and linked from each edge parameter that names
// them; a "project"-scoped one reuses an existing shared parameter with the same symbol instead,
// so constants that belong to the whole model (a reserve target) stay a single definition across
// bundle applications.
function applyBundleTemplate(template) {
    const hint = $('#componentLibraryHint');
    const fail = (message) => {
        hint.textContent = message;
        hint.hidden = false;
        $('#statusText').textContent = message;
    };
    const selected = [...selectedNodeIds].map((id) => model.nodes.find((node) => node.id === id)).filter((node) => node && !node.deleted);
    const labels = template.endpoints.map((endpoint) => endpoint.label).join(', ');
    if (selected.length !== template.endpoints.length) {
        fail(`Select ${template.endpoints.length} nodes first (${labels}), then click "${template.name}" again.`);
        return;
    }
    const { assignment, error } = assignBundleEndpoints(template, selected);
    if (error) {
        fail(error);
        return;
    }

    const sharedBefore = structuredClone(model.sharedParameters);
    const { sharedAfter, sharedByKey } = resolveTemplateSharedParameters(template.sharedParameters, sharedBefore);

    const definitions = [];
    for (const [index, edge] of template.edges.entries()) {
        const fromNode = assignment.get(edge.from);
        const toNode = assignment.get(edge.to);
        const stateFor = (node, role, ports) => {
            const symbol = edge.output.role === role ? edge.output.state : [ports].flat()[0];
            return node.states.find((state) => state.symbol === symbol);
        };
        const outputNode = edge.output.role === 'source' ? fromNode : toNode;
        const parameters = (edge.parameters ?? []).map((parameter) => templateParameter(parameter, sharedByKey));
        const definition = {
            id: allocateModelEntityId(), title: edge.name, source: fromNode.id, target: toNode.id,
            sourceStateId: stateFor(fromNode, 'source', edge.ports.source)?.id ?? null,
            targetStateId: stateFor(toNode, 'target', edge.ports.target)?.id ?? null,
            directionality: edge.bidirectional ? 'bidirectional' : 'directed',
            color: Number.parseInt((edge.color ?? template.color ?? '#9c83c4').replace('#', ''), 16),
            // Edges sharing an endpoint pair fan out sideways so they stay individually clickable.
            offset: (index - (template.edges.length - 1) / 2) * 0.3,
            enabled: true, equation: edge.latex, parameters
        };
        definition.equationModel = normalizeEdgeEquationModel(definition);
        const outputState = outputNode.states.find((state) => state.symbol === edge.output.state);
        if (!outputState || definition.equationModel.mathJson === null) {
            fail(`"${template.name}" could not build its "${edge.name}" edge: ${!outputState ? `${outputNode.title} has no state "${edge.output.state}"` : 'its equation did not resolve'}.`);
            return;
        }
        definition.equationModel.output = { role: edge.output.role, stateId: outputState.id };
        definitions.push(definition);
    }

    hint.hidden = true;
    hideCards();
    model.sharedParameters = sharedAfter;
    for (const definition of definitions) {
        model.relationships.push(definition);
        createRelationship(definition);
    }
    updateRelationships();
    updateModelStatus();
    updateValidationStatus();
    $('#statusText').textContent = `Added ${definitions.length} edges from "${template.name}".`;
    recordHistory({
        undo: () => {
            definitions.forEach((definition) => setRelationshipVisibility(definition.id, false));
            model.sharedParameters = structuredClone(sharedBefore);
            updateRelationships();
            updateModelStatus();
        },
        redo: () => {
            definitions.forEach((definition) => setRelationshipVisibility(definition.id, true));
            model.sharedParameters = structuredClone(sharedAfter);
            updateRelationships();
            updateModelStatus();
        }
    });
}

function applyComponentTemplate(template) {
    if (activeResult) return;
    if (template.kind === 'node') applyNodeTemplate(template);
    else if (template.kind === 'bundle') applyBundleTemplate(template);
    else applyEdgeTemplate(template);
}

$('#componentLibraryButton').addEventListener('click', () => {
    if ($('#componentLibraryPanel').hidden) openComponentLibraryPanel();
    else closeComponentLibraryPanel();
});
$('#closeComponentLibraryPanel').addEventListener('click', closeComponentLibraryPanel);
$('#componentLibrarySearch').addEventListener('input', renderComponentLibraryResults);

function stateVariablesFromBuilder() {
    return $$('.stateVariableRow').map((row) => ({
        name: $('[data-field="name"]', row).value.trim(),
        symbol: $('[data-field="symbol"]', row).value.trim(),
        value: $('[data-field="value"]', row).value,
        unit: $('[data-field="unit"]', row).value.trim()
    })).filter((state) => state.name && state.symbol);
}

function refreshSourceStateOptions() {
    const states = stateVariablesFromBuilder();
    $$('.sourceState').forEach((select) => {
        const selected = select.value;
        select.replaceChildren(...states.map((state) => new Option(`${state.name} (${state.symbol})`, state.symbol)));
        if ([...select.options].some((option) => option.value === selected)) select.value = selected;
    });
    $$('#sourceTermRows .providerBindingRow [data-field="reference"]').forEach((select) => {
        const selected = select.value;
        select.replaceChildren(...states.map((state) => new Option(state.symbol, `state:${state.symbol}`)));
        if ([...select.options].some((option) => option.value === selected)) select.value = selected;
    });
}

function addSourceTermRow() {
    const row = document.createElement('div');
    row.className = 'builderRow sourceTermRow';
    row.innerHTML = `
        <select class="sourceState" aria-label="Updated state"></select>
        <select class="sourceTermKind" aria-label="Implementation">
            <option value="equation">Equation</option>
            <option value="cpp">C++ program</option>
            <option value="python">Python program</option>
        </select>
        <input class="sourceExpression" placeholder="Source expression, e.g. qDot / heatCapacity">
        <button class="removeBuilderRow" type="button" title="Remove">×</button>
        <div class="sourceTermProviderFields" hidden>
            <textarea class="sourceTermProviderSource" rows="8" spellcheck="false" placeholder="#include &lt;konjugate/relationshipProvider.hpp&gt;…"></textarea>
            <div class="templateButtonGroup">
                <button type="button" class="openSourceTermProviderEditor templateButton">Open code editor</button>
                <button type="button" class="insertSourceTermTemplate templateButton" hidden>Reset template</button>
            </div>
            <div class="sourceTermProviderBindingRows"></div>
            <button type="button" class="addSourceTermBinding templateButton">＋ Add binding</button>
            <label class="editorField"><span>Output key</span><input class="sourceTermProviderOutputKey" placeholder="e.g. rateGradient"></label>
        </div>
    `;
    $('#sourceTermRows').appendChild(row);
    refreshSourceStateOptions();

    const kindSelect = $('.sourceTermKind', row);
    const expressionInput = $('.sourceExpression', row);
    const providerFields = $('.sourceTermProviderFields', row);
    const providerSource = $('.sourceTermProviderSource', row);
    const resetTemplateButton = $('.insertSourceTermTemplate', row);
    const outputKeyInput = $('.sourceTermProviderOutputKey', row);

    const bindingCandidates = () => stateVariablesFromBuilder().map((state) => ({ symbol: state.symbol, label: state.symbol }));
    const refreshBindingRowOptions = () => {
        const candidates = bindingCandidates();
        $$('.providerBindingRow', providerFields).forEach((bindingRow) => {
            const select = $('[data-field="reference"]', bindingRow);
            const previous = select.value;
            select.replaceChildren(...candidates.map((candidate) => new Option(candidate.label, `state:${candidate.symbol}`)));
            if ([...select.options].some((option) => option.value === previous)) select.value = previous;
        });
    };
    const currentBindingKeys = () => $$('.providerBindingRow [data-field="key"]', providerFields).map((input) => ({ key: input.value }));
    const regenerateTemplate = () => {
        providerSource.value = defaultProviderSource(kindSelect.value, currentBindingKeys(), outputKeyInput.value, $('#newNodeName').value);
        resetTemplateButton.hidden = !providerSource.value.trim();
    };
    const addBindingRow = () => {
        const bindingRow = document.createElement('div');
        bindingRow.className = 'providerBindingRow';
        bindingRow.innerHTML = `
            <label class="parameterField"><span>Key</span><input data-field="key"></label>
            <label class="parameterField"><span>Reference</span><select data-field="reference"></select></label>
            <button type="button" title="Remove binding">×</button>
        `;
        $('.sourceTermProviderBindingRows', providerFields).appendChild(bindingRow);
        refreshBindingRowOptions();
        bindingRow.querySelector('button').addEventListener('click', () => bindingRow.remove());
    };

    kindSelect.addEventListener('change', () => {
        const isEquation = kindSelect.value === 'equation';
        expressionInput.hidden = !isEquation;
        providerFields.hidden = isEquation;
        if (!isEquation && !providerSource.value.trim()) regenerateTemplate();
    });
    resetTemplateButton.addEventListener('click', () => {
        if (providerSource.value.trim() && !window.confirm('Replace the current provider source with a freshly generated template?')) return;
        regenerateTemplate();
    });
    providerSource.addEventListener('input', () => { resetTemplateButton.hidden = !providerSource.value.trim(); });
    $('.addSourceTermBinding', row).addEventListener('click', addBindingRow);
    $('.openSourceTermProviderEditor', row).addEventListener('click', () => {
        providerEditTarget = { type: 'builderSourceTerm', sourceElement: providerSource };
        window.providerEditor.openWindow({ source: providerSource.value, kind: kindSelect.value, title: $('#newNodeName').value });
    });

    row.querySelector('.removeBuilderRow').addEventListener('click', () => { row.remove(); refreshSourceStateOptions(); });
}

function addEdgeParameterRow(values = {}) {
    const control = normalizedParameterControl({ value: Number(values.value) || 0, control: values.control });
    const row = document.createElement('div');
    row.className = 'builderRow parameterRow';
    row.innerHTML = `
        <label class="parameterField"><span>Name</span><input data-field="name" value="${values.name ?? ''}"></label>
        <label class="parameterField"><span>Symbol</span><input data-field="symbol" value="${values.symbol ?? ''}"></label>
        <label class="parameterField"><span>Initial value</span><input data-field="value" type="number" value="${values.value ?? ''}"></label>
        <label class="parameterField"><span>Unit</span><input data-field="unit" value="${values.unit ?? ''}"></label>
        <label class="parameterField"><span>Mode</span><select data-field="mode"><option value="constant">Constant</option><option value="live">Live</option></select></label>
        <button class="removeBuilderRow" type="button" title="Remove">×</button>
        <div class="parameterControlFields" ${values.mode === 'live' ? '' : 'hidden'}>
            <label class="parameterField"><span>Slider minimum</span><input data-control-field="minimum" type="number" value="${control.minimum}"></label>
            <label class="parameterField"><span>Slider maximum</span><input data-control-field="maximum" type="number" value="${control.maximum}"></label>
            <label class="parameterField"><span>Slider step</span><input data-control-field="step" type="number" min="0" value="${control.step}"></label>
            <span class="parameterControlError" role="status"></span>
        </div>
    `;
    $('[data-field="mode"]', row).value = values.mode ?? 'constant';
    $('#edgeParameterRows').appendChild(row);
    const validateControl = () => {
        $('.parameterControlFields', row).hidden = $('[data-field="mode"]', row).value !== 'live';
        const controlValues = Object.fromEntries($$('[data-control-field]', row)
            .map((input) => [input.dataset.controlField, Number(input.value)]));
        const error = $('[data-field="mode"]', row).value === 'live'
            ? parameterControlError(Number($('[data-field="value"]', row).value), controlValues) : '';
        $('.parameterControlError', row).textContent = error;
        return error;
    };
    $$('input, select', row).forEach((input) => input.addEventListener('input', () => {
        validateControl();
        refreshStateReferences();
    }));
    row.querySelector('.removeBuilderRow').addEventListener('click', () => {
        row.remove();
        refreshStateReferences();
    });
    refreshStateReferences();
}

function refreshEndpointOptions() {
    const nodeOptions = model.nodes
        .filter((node) => nodeObjects.get(node.id)?.visible !== false)
        .map((node) => new Option(node.title, node.id));
    const source = $('#edgeSource');
    const target = $('#edgeTarget');
    const previousSource = source.value;
    const previousTarget = target.value;
    source.replaceChildren(new Option('Choose a node…', ''), ...nodeOptions.map((option) => option.cloneNode(true)));
    target.replaceChildren(new Option('Choose a node…', ''), ...nodeOptions.map((option) => option.cloneNode(true)));
    if (model.nodes.some((node) => node.id === Number(previousSource))) source.value = previousSource;
    if (model.nodes.some((node) => node.id === Number(previousTarget))) target.value = previousTarget;
    refreshStateReferences();
}

function finishEndpointPick() {
    activeEndpointPick = null;
    endpointPickContinuation = null;
    $('#componentLibraryHint').hidden = true;
    canvas.classList.remove('pickingEndpoint');
    $('#endpointPickBanner').hidden = true;
    $$('[data-pick-endpoint]').forEach((button) => button.classList.remove('active'));
    $$('.node-label-container').forEach((label) => label.classList.remove('endpointEligible'));
    endpointPickMaterialState.forEach((state, nodeId) => {
        const material = nodeObjects.get(nodeId)?.material;
        if (!material) return;
        material.emissive.copy(state.emissive);
        material.emissiveIntensity = state.emissiveIntensity;
        material.opacity = state.opacity;
        material.transparent = state.transparent;
        material.needsUpdate = true;
    });
    endpointPickMaterialState = new Map();
    dragControls.enabled = !activeResult && currentTool === 'select';
    $('.edgeBuilder > header strong').textContent = 'Connect stateful nodes';
    if (endpointPickRestoreCard?.isConnected) endpointPickRestoreCard.classList.remove('hidden');
    endpointPickRestoreCard = null;
}

function chooseEndpointNode(nodeId) {
    if (!activeEndpointPick) return;
    const otherEndpoint = Number(activeEndpointPick === 'source' ? $('#edgeTarget').value : $('#edgeSource').value);
    if (nodeId === otherEndpoint) return;
    $(`#edge${activeEndpointPick[0].toUpperCase()}${activeEndpointPick.slice(1)}`).value = nodeId;
    refreshStateReferences();
    const continuation = endpointPickContinuation;
    endpointPickContinuation = null;
    finishEndpointPick();
    continuation?.();
}

function startEndpointPick(endpoint) {
    finishEndpointPick();
    activeEndpointPick = endpoint;
    dragControls.enabled = false;
    canvas.classList.add('pickingEndpoint');
    const button = $(`[data-pick-endpoint="${endpoint}"]`);
    button.classList.add('active');
    const otherEndpoint = Number(endpoint === 'source' ? $('#edgeTarget').value : $('#edgeSource').value);
    const eligibleIds = new Set(eligibleEndpointIds(
        model.nodes,
        otherEndpoint,
        (node) => nodeObjects.get(node.id)?.visible !== false
    ));
    nodeObjects.forEach((node, nodeId) => {
        endpointPickMaterialState.set(nodeId, {
            emissive: node.material.emissive.clone(),
            emissiveIntensity: node.material.emissiveIntensity,
            opacity: node.material.opacity,
            transparent: node.material.transparent
        });
        const eligible = eligibleIds.has(nodeId);
        node.material.emissive.setHex(eligible ? 0x174d49 : 0x000000);
        node.material.emissiveIntensity = eligible ? 0.85 : 0;
        node.material.opacity = eligible ? 1 : 0.28;
        node.material.transparent = !eligible;
        node.material.needsUpdate = true;
        node.children.find((child) => child.isCSS2DObject)?.element.classList.toggle('endpointEligible', eligible);
    });
    endpointPickRestoreCard = $('#edgeBuilder').classList.contains('hidden') ? null : $('#edgeBuilder');
    endpointPickRestoreCard?.classList.add('hidden');
    const endpointLabel = endpoint === 'source' ? 'source' : 'target';
    $('#endpointPickTitle').textContent = `Choose the ${endpointLabel} node`;
    $('#endpointPickHint').textContent = eligibleIds.size
        ? 'Select a highlighted node on the canvas'
        : 'No eligible nodes are available';
    $('#endpointPickBanner').hidden = false;
}

function refreshStateReferences() {
    const container = $('#stateReferenceChips');
    container.replaceChildren();
    const sourceNode = model.nodes.find((node) => node.id === Number($('#edgeSource').value));
    const targetNode = model.nodes.find((node) => node.id === Number($('#edgeTarget').value));
    const parameters = $$('.parameterRow').map((row, index) => ({
        id: `builderParameter${index}`,
        symbol: $('[data-field="symbol"]', row).value.trim()
    })).filter((parameter) => modelSymbolPattern.test(parameter.symbol));
    const bindings = reconcileEquationBindings([], sourceNode, targetNode, parameters);
    bindings.forEach((binding) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = binding.label;
        button.title = bindingInsertTitle(binding);
        button.addEventListener('click', () => insertBuilderEquationBinding(binding));
        container.appendChild(button);
    });
    const output = $('#edgeEquationOutput');
    const selectedOutput = output.value;
    output.replaceChildren();
    for (const [role, node] of [['source', sourceNode], ['target', targetNode]]) {
        node?.states.forEach((state) => output.add(new Option(`${role}.${state.symbol}`, equationOutputValue(role, state.id))));
    }
    if ([...output.options].some((option) => option.value === selectedOutput)) output.value = selectedOutput;
    else if (targetNode?.states[0]) output.value = equationOutputValue('target', targetNode.states[0].id);
    renderBuilderEquationDiagnostics(bindings);
    refreshProviderBindingRowOptions(bindings);
}

function refreshProviderBindingRowOptions(candidates) {
    $$('#providerBindingRows .providerBindingRow').forEach((row) => {
        const select = $('[data-field="reference"]', row);
        const previous = select.value;
        select.replaceChildren(...candidates.map((candidate) => new Option(candidate.label, providerReferenceValue(candidate))));
        if ([...select.options].some((option) => option.value === previous)) select.value = previous;
    });
}

function addProviderBindingRow(values = {}) {
    const row = document.createElement('div');
    row.className = 'builderRow providerBindingRow';
    row.innerHTML = `
        <label class="parameterField"><span>Key</span><input data-field="key" value="${escapeHtml(values.key ?? '')}"></label>
        <label class="parameterField"><span>Reference</span><select data-field="reference"></select></label>
        <button class="removeBuilderRow" type="button" title="Remove binding">×</button>
    `;
    $('#providerBindingRows').appendChild(row);
    const sourceNode = model.nodes.find((node) => node.id === Number($('#edgeSource').value));
    const targetNode = model.nodes.find((node) => node.id === Number($('#edgeTarget').value));
    const parameters = $$('.parameterRow').map((parameterRow, index) => ({
        id: `builderParameter${index}`,
        symbol: $('[data-field="symbol"]', parameterRow).value.trim()
    })).filter((parameter) => modelSymbolPattern.test(parameter.symbol));
    const candidates = reconcileEquationBindings([], sourceNode, targetNode, parameters).filter((binding) => binding.kind !== 'time');
    refreshProviderBindingRowOptions(candidates);
    if (values.referenceValue) $('[data-field="reference"]', row).value = values.referenceValue;
    row.querySelector('.removeBuilderRow').addEventListener('click', () => row.remove());
}

function renderBuilderEquationDiagnostics(bindings = null) {
    const availableBindings = bindings ?? (() => {
        const sourceNode = model.nodes.find((node) => node.id === Number($('#edgeSource').value));
        const targetNode = model.nodes.find((node) => node.id === Number($('#edgeTarget').value));
        const parameters = $$('.parameterRow').map((row, index) => ({
            id: `builderParameter${index}`,
            symbol: $('[data-field="symbol"]', row).value.trim()
        })).filter((parameter) => modelSymbolPattern.test(parameter.symbol));
        return reconcileEquationBindings([], sourceNode, targetNode, parameters);
    })();
    const validation = validateEquationLatex($('#edgeMathField').value, availableBindings);
    const diagnostics = $('#builderEquationDiagnostics');
    diagnostics.classList.toggle('valid', validation.valid);
    diagnostics.textContent = validation.valid ? 'Valid expression · MathJSON ready' : validation.errors.join(' ');
}

function insertBuilderEquationBinding(binding) {
    const latex = latexForBinding(binding);
    if ($('#edgeMathField').hidden) {
        const source = $('#edgeEquation');
        source.setRangeText(latex, source.selectionStart, source.selectionEnd, 'end');
        source.dispatchEvent(new Event('input', { bubbles: true }));
        source.focus();
    } else {
        $('#edgeMathField').insert(latex);
        $('#edgeMathField').focus();
    }
}

function updateModelStatus() {
    const status = $$('.modelStatus span');
    const visibleNodes = model.nodes.filter((node) => !node.deleted).length;
    const visibleRelationships = model.relationships.filter((relationship) => !relationship.deleted).length;
    status[0].textContent = `${visibleNodes} nodes`;
    status[1].textContent = `${visibleRelationships} relationships`;
    status[2].textContent = `${model.metadata.units} units`;
    syncContextualOverlays();
    updateValidationStatus();
}

function navigateToValidationIssue(item) {
    $('#validationPanel').hidden = true;
    $('#validationSummary').ariaExpanded = 'false';
    if (item.location.kind === 'runConfiguration') {
        openRunDialog();
        return;
    }
    // A resolved attributed parameter (see resolveAttributedParameter in modelValidator.cpp) is a
    // strictly more useful destination than the issue's own generic `location` -- jump straight to
    // it instead, focusing the row's value input specifically rather than its first (Name) field.
    if (item.attributedParameter?.kind === 'edge') {
        const relationship = model.relationships.find((candidate) => candidate.id === Number(item.attributedParameter.ownerId));
        if (relationship) {
            openRelationshipEditor(relationship);
            requestAnimationFrame(() => $(`#edgeEditorParameters [data-parameter-id="${item.attributedParameter.parameterId}"] input[data-field="value"]`)?.focus());
            return;
        }
    } else if (item.attributedParameter?.kind === 'sourceTerm') {
        const termId = Number(item.attributedParameter.ownerId);
        const owningNode = [...nodeObjects.values()].find((candidate) => candidate.userData.definition.sourceTerms?.some((term) => term.id === termId));
        const term = owningNode?.userData.definition.sourceTerms.find((candidate) => candidate.id === termId);
        if (owningNode && term) {
            // Opening the node editor first matches the real click path -- .sourceTermOpen's own
            // handler is only ever reachable from within an already-open node editor.
            selectNode(owningNode);
            openNodeEditor(owningNode.userData.definition);
            openSourceTermEditor(owningNode, term);
            requestAnimationFrame(() => $(`#termParameters [data-parameter-id="${item.attributedParameter.parameterId}"] input[data-field="value"]`)?.focus());
            return;
        }
    }
    if (item.location.kind === 'node') {
        const node = nodeObjects.get(Number(item.location.entityId));
        if (!node) return;
        selectNode(node);
        openNodeEditor(node.userData.definition);
        const field = { name: '#editNodeName', states: '#nodeEditorStates input', sourceTerms: '#nodeEditorSourceTerms input' }[item.location.field];
        if (field) requestAnimationFrame(() => $(field)?.focus());
    } else if (item.location.kind === 'edge') {
        const relationship = model.relationships.find((candidate) => candidate.id === Number(item.location.entityId));
        if (!relationship) return;
        openRelationshipEditor(relationship);
        const field = { source: '#editEdgeSource', target: '#editEdgeTarget', equation: '#editEdgeMathField', output: '#editEquationOutput', parameters: '#edgeEditorParameters input' }[item.location.field];
        if (field) requestAnimationFrame(() => $(field)?.focus());
    }
}

function updateValidationStatus() {
    scheduleEngineValidation();
}

// Resolves when the model's validation has settled. Waiters are released only by the latest validation
// (a superseded one returns early), so what they then read from currentValidation is current.
let validationWaiters = [];
function validationSettled() {
    if ($('#validationSummary').dataset.validationSource === 'engine') return Promise.resolve();
    return new Promise((resolve) => validationWaiters.push(resolve));
}
function releaseValidationWaiters() {
    const waiters = validationWaiters;
    validationWaiters = [];
    waiters.forEach((resolve) => resolve());
}

function scheduleEngineValidation(projectDocument = null) {
    const revision = ++validationRevision;
    clearTimeout(engineValidationTimer);
    renderValidationPending();
    engineValidationTimer = setTimeout(async () => {
        try {
            const result = await window.engine.validate(JSON.stringify(stripEdgeGroups(executionProjectDocument(projectDocument ?? serializeProjectDocument()))), { supersede: 'model' });
            // A cancelled validation was superseded by a newer one, which will render its own result.
            if (result.cancelled || revision !== validationRevision) return;
            if (!result.available) {
                renderValidationFailure('The C++ validation engine is unavailable. Build the engine before editing or running models.');
                releaseValidationWaiters();
                return;
            }
            currentValidation = {
                valid: result.report.valid,
                issues: result.report.issues,
                executableModel: null
            };
            $('#validationSummary').dataset.validationSource = 'engine';
            renderValidationStatus();
            releaseValidationWaiters();
        } catch (error) {
            if (revision !== validationRevision) return;
            console.error('C++ model validation failed.', error);
            renderValidationFailure(`The C++ validation engine failed: ${error.message}`);
            releaseValidationWaiters();
        }
    }, 180);
}

// Run opens the Run dialog, so model errors do not disable it: they only stop Start, inside the dialog
// (see openRunDialog), and the dialog is where a rejected run configuration is corrected. It is
// disabled when there is nothing to set up: a result is on screen, a run is going, or validation is
// still pending or unavailable.
function runButtonDisabled() {
    return Boolean(activeResult) || simulationRunning || $('#validationSummary').dataset.validationSource !== 'engine';
}

function renderValidationPending() {
    const summary = $('#validationSummary');
    delete summary.dataset.validationSource;
    summary.classList.remove('error', 'warning');
    summary.classList.add('pending');
    $('#statusText').textContent = 'Validating…';
    $('#runButton').disabled = true;
    $('#runButton').title = 'Wait for model validation to finish';
    $('#validationPanelTitle').textContent = 'Validating…';
    $('#validationIssues').innerHTML = '<p class="validationEmpty">The C++ engine is validating this model.</p>';
}

function renderValidationFailure(message) {
    currentValidation = {
        valid: false,
        issues: [{
            code: 'validationEngineUnavailable',
            severity: 'error',
            message,
            location: { kind: 'model', entityId: '', field: '' }
        }],
        executableModel: null
    };
    $('#validationSummary').dataset.validationSource = 'engineError';
    renderValidationStatus();
}

function renderValidationStatus() {
    const errors = currentValidation.issues.filter((item) => item.severity === 'error').length;
    const warnings = currentValidation.issues.filter((item) => item.severity === 'warning').length;
    const summary = $('#validationSummary');
    summary.classList.remove('pending');
    summary.classList.toggle('error', errors > 0);
    summary.classList.toggle('warning', !errors && warnings > 0);
    $('#statusText').textContent = errors ? `${errors} model ${errors === 1 ? 'error' : 'errors'}`
        : warnings ? `${warnings} model ${warnings === 1 ? 'warning' : 'warnings'}` : 'Model valid';
    $('#runButton').disabled = runButtonDisabled();
    $('#runButton').title = errors ? 'Run settings (resolve model errors before starting)' : 'Run simulation';

    const severityByEntity = new Map();
    currentValidation.issues.forEach((item) => {
        const entityId = Number(item.location.entityId);
        if (!validModelEntityId(entityId)) return;
        const previous = severityByEntity.get(entityId);
        if (!previous || item.severity === 'error') severityByEntity.set(entityId, item.severity);
    });
    nodeObjects.forEach((node, id) => {
        const label = node.children.find((child) => child.isCSS2DObject)?.element;
        label?.classList.toggle('validationError', severityByEntity.get(id) === 'error');
        label?.classList.toggle('validationWarning', severityByEntity.get(id) === 'warning');
    });
    relationshipObjects.forEach((relationship, id) => {
        relationship.line.userData.validationSeverity = severityByEntity.get(id) ?? null;
    });
    relationshipBundleObjects.forEach((overlay, key) => {
        const bundle = activeRelationshipBundles().find((candidate) => candidate.key === key);
        const severities = bundle?.relationships.map((item) => severityByEntity.get(item.id)).filter(Boolean) ?? [];
        overlay.element.classList.toggle('validationError', severities.includes('error'));
        overlay.element.classList.toggle('validationWarning', !severities.includes('error') && severities.includes('warning'));
    });
    updateRelationshipSelection();

    $('#validationPanelTitle').textContent = currentValidation.issues.length
        ? `${errors} errors · ${warnings} warnings` : 'No issues';
    const container = $('#validationIssues');
    container.replaceChildren();
    if (!currentValidation.issues.length) container.innerHTML = '<p class="validationEmpty">This model is structurally valid and ready for a simulation runtime.</p>';
    currentValidation.issues.forEach((item) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `validationIssue ${item.severity}`;
        button.innerHTML = `<i></i><span><strong>${escapeHtml(item.message)}</strong><small>${escapeHtml(item.location.kind)}${item.location.field ? ` · ${escapeHtml(item.location.field)}` : ''}</small></span>`;
        button.addEventListener('click', () => navigateToValidationIssue(item));
        container.appendChild(button);
    });
}

function formatResultTime(time) {
    return `${Number(time).toLocaleString(undefined, { maximumSignificantDigits: 6 })} s`;
}

function updateResultExtent() {
    if (!activeResult) return;
    const targetTime = Number(activeResult.targetTime);
    const availableTime = Number(activeResult.availableResultTime);
    const extent = Math.max(targetTime, availableTime, activeResult.samples.at(-1)?.time ?? 0, Number.EPSILON);
    $('#resultTimeline').max = String(extent);
    $('#resultTimeline').style.setProperty('--available-progress', `${100 * Math.min(availableTime, extent) / extent}%`);
    $('#resultExtent').value = `available ${formatResultTime(availableTime)} · target ${formatResultTime(targetTime)}`;
    $('#simulationProgress').value = `${formatResultTime(availableTime)} / ${formatResultTime(targetTime)}`;
}

function updateDisplayedState(stateId, numericValue) {
    const node = model.nodes.find((candidate) => candidate.states.some((state) => state.id === stateId));
    const state = node?.states.find((candidate) => candidate.id === stateId);
    if (!state) return;
    const { text, exact } = stateValueText(numericValue, state.unit);
    state.value = text;
    state.exactValue = exact;
    // From the node's own label, which exists before its first frame puts it in the page.
    const value = labelElementOf(nodeObjects.get(node.id), 'node-label-container')?.querySelectorAll('dd')[node.states.indexOf(state)];
    if (value) { value.textContent = state.value; value.title = state.exactValue; }
}

function projectResultSample(index) {
    if (!activeResult?.samples.length) return;
    activeResultSampleIndex = Math.max(0, Math.min(index, activeResult.samples.length - 1));
    projectResultSampleValue(activeResult.samples[activeResultSampleIndex]);
    if (!$('#branchesPanel').hidden) updateForkHereLabel();
}

function projectResultSampleValue(sample) {
    if (!sample) return;
    sample.states.forEach((state) => updateDisplayedState(state.stateId, state.value));
    $('#resultTimeline').value = String(sample.time);
    $('#resultCurrentTime').value = formatResultTime(sample.time);
    $('#statusText').textContent = `Result · ${formatResultTime(sample.time)}`;
    nodeResultPlot.setCursor(sample.time);
    window.addons.publishEvent('timeline.change', sample.time);
}

function stopResultPlayback() {
    clearTimeout(resultPlaybackTimer);
    resultPlaybackTimer = null;
    resultPlaying = false;
    $('#resultPlayPause').textContent = '▶';
    $('#resultPlayPause').ariaLabel = 'Play results';
}

function scheduleResultPlayback() {
    if (!resultPlaying || !activeResult) return;
    const rate = Number($('#resultPlaybackRate').value) || 1;
    const finalTime = Number(activeResult.samples.at(-1).time);
    resultPlaybackTimer = setTimeout(async () => {
        const elapsed = (performance.now() - resultPlaybackStartedAt) / 1000;
        const targetTime = Math.min(finalTime, resultPlaybackStartedFrom + elapsed * rate);
        const reachedEnd = targetTime >= finalTime;
        const projectedIndex = nearestSampleIndex(activeResult.samples, targetTime);
        activeResultSampleIndex = projectedIndex;
        const fullResolutionSample = activeEngineJobId && activeResult.sampleCount > activeResult.samples.length
            ? await window.engine.readResultSample(activeEngineJobId, targetTime) : null;
        if (!resultPlaying) return;
        projectResultSampleValue(fullResolutionSample ?? activeResult.samples[projectedIndex]);
        if (reachedEnd) stopResultPlayback();
        else scheduleResultPlayback();
    }, preferredPlaybackFrameMilliseconds);
}

function selectSuggestedPlaybackRate() {
    const selector = $('#resultPlaybackRate');
    selector.querySelector('[data-suggested]')?.remove();
    const samples = activeResult?.samples ?? [];
    const duration = samples.length > 1 ? Number(samples.at(-1).time) - Number(samples[0].time) : 0;
    const rate = suggestedPlaybackRate(duration);
    let option = [...selector.options].find((candidate) => Number(candidate.value) === rate);
    if (!option) {
        option = document.createElement('option');
        option.value = String(rate);
        option.dataset.suggested = '';
        option.textContent = `${rate.toLocaleString()}× · fit`;
        selector.appendChild(option);
    }
    selector.value = option.value;
}

function applyInspectorReadOnly() {
    const locked = Boolean(activeResult);
    $$('[data-result-readonly]').forEach((notice) => { notice.hidden = !locked; });
    $$('#nodeEditor [data-node-panel]:not([data-node-panel="results"]) :is(input, select, textarea, button), #nodeEditor > footer button, #edgeEditor section :is(input, select, textarea, button), #edgeEditor > footer button, #edgeGroupEditor section :is(input, select, textarea, button), #edgeGroupEditor > footer button').forEach((control) => {
        // A control that is off for a reason of its own (the first row cannot move up) stays off outside results too.
        control.disabled = locked || control.hasAttribute('data-unavailable');
    });
    $$('#nodeEditor math-field, #edgeEditor math-field, #edgeGroupEditor math-field').forEach((field) => {
        field.readOnly = locked;
        field.toggleAttribute('read-only', locked);
    });
}

function setResultModeLocked(locked) {
    canvas.classList.toggle('resultModeLocked', locked);
    $('#addButton').disabled = locked;
    $('#componentLibraryButton').disabled = locked;
    if (locked) closeComponentLibraryPanel();
    $('#assistantButton').disabled = locked;
    $('[data-action="delete"]').disabled = locked;
    $('[data-tool="move"]').disabled = locked;
    $('[data-tool="rotate"]').disabled = locked;
    $('[data-tool="scale"]').disabled = locked;
    $('#runButton').disabled = locked || runButtonDisabled();
    $('#exportCsvButton').disabled = !locked;
    transformControls.detach();
    if (locked) {
        discardAssistantProposal();
        hideAssistantPanel();
        $$('.toolstrip [data-tool]').forEach((button) => button.classList.toggle('active', button.dataset.tool === 'select'));
        setTool('select');
    } else if (toolBeforeResult) {
        const restoredTool = toolBeforeResult;
        toolBeforeResult = null;
        $$('.toolstrip [data-tool]').forEach((button) => button.classList.toggle('active', button.dataset.tool === restoredTool));
        setTool(restoredTool);
    }
    $('#nodeModelActions').hidden = locked || !$('[data-node-tab="model"]').classList.contains('active');
    applyInspectorReadOnly();
    updateHistoryControls();
    refreshAddonRailContributions();
}

function registerActiveBranch({ parentBranchUuid = null, forkTime = null } = {}) {
    const existing = branches.get(activeBranchUuid);
    if (existing) {
        existing.result = activeResult;
        existing.jobId = activeEngineJobId;
        return;
    }
    branches.set(activeBranchUuid, {
        branchUuid: activeBranchUuid,
        parentBranchUuid,
        forkTime,
        jobId: activeEngineJobId,
        result: activeResult,
        sampleIndex: activeResult.samples.length - 1,
        label: parentBranchUuid ? `Fork at ${formatResultTime(forkTime)}` : 'Baseline',
        color: branchColors[branches.size % branchColors.length]
    });
    renderBranchSwitcher();
}

// Branches selected for the N-way comparison overlay (workstream F), in addition to whichever is
// active (the active branch is always implicitly compared -- see renderNodeResults). Pruned of
// stale UUIDs whenever the tree re-renders so a closed/replaced branch can't linger here.
let comparisonBranchUuids = new Set();

function toggleComparisonBranch(branchUuid, enabled) {
    if (enabled) comparisonBranchUuids.add(branchUuid);
    else comparisonBranchUuids.delete(branchUuid);
    if (selectedNode) renderNodeResults(selectedNode);
}

// All branch UI lives behind one transport-bar button (#branchesButton), which shows the active
// branch and opens #branchesPanel: the "Fork at <time>" action on top, then the real nested tree
// (docs/resultExploration.md's "Baseline / fork / fork-of-fork" example) with per-branch compare
// checkboxes -- branches already nest correctly via parentBranchUuid (a fork's parent is whichever
// branch was active when the fork was made; this function only visualizes it). This used to be
// inline chips plus separate tree and fork buttons, which crowded the transport bar until its
// controls overlapped.
function canForkActiveResult() {
    return !simulationRunning && ['stopped', 'completed'].includes(activeResult?.lifecycle) && Boolean(activeResult?.checkpoints?.length);
}

function updateForkHereLabel() {
    const time = Number(activeResult?.samples[activeResultSampleIndex]?.time ?? 0);
    $('#forkHereLabel').textContent = `Fork at ${formatResultTime(time)}`;
}

// Anchors a branch-related panel just above #branchesButton, right edges aligned, so it opens
// where the click happened instead of at a fixed dock position. Clamped to stay inside its
// positioning container on narrow windows.
function anchorPanelToBranchesButton(panel) {
    const button = $('#branchesButton');
    const container = panel.offsetParent;
    if (!container || button.hidden) return;
    const buttonRect = button.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();
    const margin = 18;
    const left = Math.min(buttonRect.right - containerRect.left, containerRect.width - margin) - panel.offsetWidth;
    panel.style.left = `${Math.max(margin, left)}px`;
    panel.style.right = 'auto';
    panel.style.bottom = `${containerRect.bottom - buttonRect.top + 8}px`;
}

function setBranchesPanelOpen(open) {
    $('#branchesPanel').hidden = !open;
    $('#branchesButton').ariaExpanded = String(open);
    if (open) anchorPanelToBranchesButton($('#branchesPanel'));
}
window.addEventListener('resize', () => {
    for (const panel of [$('#branchesPanel'), $('#forkParameterPanel')]) {
        if (!panel.hidden) anchorPanelToBranchesButton(panel);
    }
});

function renderBranchSwitcher() {
    comparisonBranchUuids = new Set([...comparisonBranchUuids].filter((uuid) => branches.has(uuid)));
    const hasMultiple = branches.size > 1;
    const canFork = canForkActiveResult();
    const button = $('#branchesButton');
    button.hidden = !hasMultiple && !canFork;
    if (button.hidden) setBranchesPanelOpen(false);
    const active = branches.get(activeBranchUuid);
    button.style.setProperty('--branch-color', active?.color ?? '#758a95');
    $('#branchesButtonLabel').textContent = active?.parentBranchUuid ? `Fork · ${formatResultTime(active.forkTime)}` : active?.label ?? 'Baseline';
    $('#branchesButtonCount').textContent = hasMultiple ? String(branches.size) : '';
    $('#forkHereButton').hidden = !canFork;
    updateForkHereLabel();
    $('#branchesPanelHint').textContent = hasMultiple ? 'Click a branch to view it · check others to compare' : 'Fork to try a what-if from the current time';

    const container = $('#branchTree');
    container.replaceChildren();
    if (!hasMultiple) return;
    const byParent = new Map();
    for (const branch of branches.values()) {
        const key = branch.parentBranchUuid ?? 'root';
        if (!byParent.has(key)) byParent.set(key, []);
        byParent.get(key).push(branch);
    }
    for (const siblings of byParent.values()) siblings.sort((a, b) => (a.forkTime ?? -1) - (b.forkTime ?? -1));
    const renderLevel = (parentKey) => {
        const level = document.createElement('div');
        level.className = 'branchTreeLevel';
        (byParent.get(parentKey) ?? []).forEach((branch) => {
            const item = document.createElement('div');
            item.className = 'branchTreeItem';
            const isActive = branch.branchUuid === activeBranchUuid;
            const compareCheckbox = document.createElement('input');
            compareCheckbox.type = 'checkbox';
            compareCheckbox.className = 'branchCompareToggle';
            compareCheckbox.checked = isActive || comparisonBranchUuids.has(branch.branchUuid);
            compareCheckbox.disabled = isActive;
            compareCheckbox.title = isActive ? 'The active branch is always shown' : `Compare ${branch.label}`;
            compareCheckbox.setAttribute('aria-label', compareCheckbox.title);
            compareCheckbox.addEventListener('change', () => toggleComparisonBranch(branch.branchUuid, compareCheckbox.checked));
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'branchTreeButton';
            button.classList.toggle('active', isActive);
            button.disabled = simulationRunning && !isActive;
            button.style.setProperty('--branch-color', branch.color);
            button.title = branch.label;
            button.textContent = branch.label;
            button.addEventListener('click', () => activateBranch(branch.branchUuid));
            item.append(compareCheckbox, button);
            level.appendChild(item);
            if (byParent.has(branch.branchUuid)) level.appendChild(renderLevel(branch.branchUuid));
        });
        return level;
    };
    container.appendChild(renderLevel('root'));
}
$('#branchesButton').addEventListener('click', () => {
    if ($('#branchesPanel').hidden) updateForkHereLabel();
    setBranchesPanelOpen($('#branchesPanel').hidden);
});
$('#closeBranchesPanel').addEventListener('click', () => setBranchesPanelOpen(false));
// Behaves like a menu: a click anywhere else dismisses it.
document.addEventListener('pointerdown', (event) => {
    if (!$('#branchesPanel').hidden && !event.target.closest('#branchesPanel, #branchesButton')) setBranchesPanelOpen(false);
});

// Switching branches is only safe when nothing is live: only the active branch's job ever
// streams updates (applyLiveResult drops anything whose jobId isn't activeEngineJobId), so
// flipping activeEngineJobId to a parked branch mid-run would silently lose the running child's
// samples. The branch switcher's buttons are disabled for this same reason while a run is live.
function activateBranch(targetUuid) {
    if (targetUuid === activeBranchUuid || simulationRunning) return;
    const current = branches.get(activeBranchUuid);
    if (current) {
        current.result = activeResult;
        current.jobId = activeEngineJobId;
        current.sampleIndex = activeResultSampleIndex;
    }
    const target = branches.get(targetUuid);
    if (!target) return;
    stopResultPlayback();
    activeBranchUuid = targetUuid;
    activeResult = target.result;
    activeEngineJobId = target.jobId;
    updateResultExtent();
    projectResultSample(target.sampleIndex ?? target.result.samples.length - 1);
    updateLiveResultControls();
    renderBranchSwitcher();
    if (selectedNode) renderNodeResults(selectedNode);
}

function activateResult(result) {
    stopResultPlayback();
    if (!activeResult) nodeDetailsBeforeResult = labelModes.nodes;
    if (!activeResult) toolBeforeResult = currentTool;
    activeResult = result;
    const forkInfo = pendingFork ? { parentBranchUuid: pendingFork.parentBranchUuid, forkTime: pendingFork.forkTime } : {};
    if (pendingFork || !activeBranchUuid) activeBranchUuid = crypto.randomUUID();
    registerActiveBranch(forkInfo);
    pendingFork = null;
    setResultModeLocked(true);
    setLabelDetail('nodes', true);
    $('#resultTransport').hidden = false;
    updateLiveResultControls();
    updateResultExtent();
    projectResultSample(result.samples.length - 1);
    if (selectedNode && !$('#nodeEditor').classList.contains('hidden')) selectNodeEditorTab('results');
}

function formatExecutionDuration(nanoseconds) {
    const milliseconds = Number(nanoseconds || 0) / 1e6;
    return milliseconds < 0.01 ? `${Math.round(Number(nanoseconds || 0) / 1000)} µs` : `${milliseconds.toFixed(milliseconds < 10 ? 2 : 1)} ms`;
}

function formatExecutionBytes(bytes) {
    const value = Number(bytes || 0);
    if (value < 1024) return `${value} B`;
    if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KiB`;
    return `${(value / (1024 * 1024)).toFixed(1)} MiB`;
}

function renderExecutionSummary() {
    const execution = activeResult?.execution;
    const partitionPlan = activeResult?.partitionPlan;
    const available = Boolean(execution && partitionPlan);
    $('#executionSummaryButton').hidden = !available;
    if (!available) {
        $('#executionSummaryCard').classList.add('hidden');
        $('#executionSummaryButton').ariaExpanded = 'false';
        return;
    }
    const backendNames = { serial: 'Serial', threadPool: 'Thread pool', partitioned: 'Partitioned' };
    const reasonDescriptions = {
        explicitSelection: 'This backend was selected explicitly in the run configuration.',
        singleNode: 'Serial execution was selected because the model has only one node.',
        belowParallelWorkThreshold: 'Serial execution was selected because the estimated work is below the parallel threshold.',
        independentParallelWork: 'Partitioned execution was selected because the heavy node workloads are independent.',
        partitionCutWithinLimit: 'Partitioned execution was selected because the communication cut remains within the configured limit.',
        partitionCommunicationCutTooHigh: 'The shared thread pool was selected to avoid an expensive partition communication cut.'
    };
    const backendName = backendNames[execution.backend] ?? execution.backend;
    $('#executionSummaryBackend').textContent = backendName;
    $('#executionSummaryTitle').textContent = `${backendName} · ${execution.workerThreads} worker${execution.workerThreads === 1 ? '' : 's'}`;
    $('#executionSummaryReason').textContent = reasonDescriptions[execution.selectionReason] ?? 'The engine selected this execution strategy for the current model.';
    const communication = execution.partitionCommunication ?? {};
    const selected = partitionPlan.selected ?? partitionPlan.greedy ?? {};
    const algorithmNames = { metisKway: 'METIS k-way', communicationAwareGreedy: 'Built-in greedy' };
    const fallbackNames = { metisUnavailable: 'METIS unavailable', metisPartitioningFailed: 'METIS planning failed' };
    const roundRobin = partitionPlan.roundRobin ?? {};
    const nodeComputeNanoseconds = (execution.nodeMetrics ?? []).reduce((total, item) => total + Number(item.computeNanoseconds || 0), 0);
    const metrics = [
        ['Planning', formatExecutionDuration(execution.planningNanoseconds)],
        ['Node computation', formatExecutionDuration(nodeComputeNanoseconds)],
        ['Synchronization', formatExecutionDuration(execution.synchronizationComputeNanoseconds)],
        ['Partitioner', `${algorithmNames[partitionPlan.algorithm] ?? partitionPlan.algorithm}${partitionPlan.fallbackReason
            ? ` · ${fallbackNames[partitionPlan.fallbackReason] ?? partitionPlan.fallbackReason}` : ''}`],
        ['Compute imbalance', `${Number(selected.computeImbalance || 1).toFixed(2)}×`],
        ['Communication cut', `${selected.communicationCutWeight ?? 0} · round robin ${roundRobin.communicationCutWeight ?? 0}`],
        ['Boundary messages', Number(communication.boundaryMessages || 0).toLocaleString()],
        ['Boundary payload', formatExecutionBytes(communication.boundaryPayloadBytes)],
        ['Message preparation', formatExecutionDuration(communication.messagePreparationNanoseconds)],
        ['Transport publishing', formatExecutionDuration(communication.transportPublishNanoseconds)],
        ['Partition waiting', formatExecutionDuration(communication.boundaryWaitNanoseconds)]
    ];
    const list = $('#executionSummaryMetrics');
    list.replaceChildren();
    metrics.forEach(([label, value]) => {
        const term = document.createElement('dt');
        const description = document.createElement('dd');
        term.textContent = label;
        description.textContent = value;
        list.append(term, description);
    });
}

// Post-run phase (docs/proposals/numericalStabilityDiagnostics.md) computed lazily, only once a
// result is "completed" (re-running it on every live-poll tick would mean repeated O(samples) work
// for no benefit -- during-run monitoring already covers the live case), and cached per result
// object so scrubbing the timeline or reopening the card doesn't recompute it.
let cachedFingerprintFindings = { result: null, findings: [] };
// "Check convergence" (docs/proposals/numericalStabilityDiagnostics.md's post-run phase) is
// deliberately not automatic -- it costs real extra engine runs -- so this only tracks per-node
// state a user explicitly asked for, keyed by nodeId: { status: 'idle'|'checking'|'done'|'error',
// finding, error }. Reset whenever the active result itself changes (see
// renderStabilityConvergenceSection), same lifecycle as cachedFingerprintFindings above.
let convergenceCheckState = new Map();
let convergenceCheckResultRef = null;

function resolvedStabilityFindings() {
    if (!activeResult) return [];
    const duringRun = activeResult.stabilityFindings ?? [];
    let postRun = [];
    if (activeResult.lifecycle === 'completed') {
        if (cachedFingerprintFindings.result !== activeResult) {
            const document_ = stripEdgeGroups(executionProjectDocument(serializeProjectDocument()));
            cachedFingerprintFindings = {
                result: activeResult,
                findings: detectInstabilityFingerprint(activeResult, document_).map((finding) => ({
                    nodeId: finding.nodeId, stateId: finding.stateId,
                    code: finding.classicSawtoothFingerprint ? 'postRunSawtoothFingerprint' : 'postRunGrowthFingerprint',
                    message: finding.classicSawtoothFingerprint
                        ? 'This state shows the classic Explicit Euler instability signature -- growing, alternating sign every step -- across the completed run.'
                        : 'This state grew substantially across the completed run, without ever settling.',
                    globalTime: null
                }))
            };
        }
        postRun = cachedFingerprintFindings.findings;
    }
    return [...duringRun, ...postRun].sort((a, b) => (a.globalTime ?? Infinity) - (b.globalTime ?? Infinity));
}

function describeStabilityFinding(finding) {
    // Node display names live on the Three.js object's own userData.definition.title (the same
    // source navigateToValidationIssue's openNodeEditor(node.userData.definition) call already
    // trusts), not on model.nodes[] directly -- state lookups (symbol) still use model.nodes[],
    // which does carry real per-state data.
    const node = model.nodes.find((candidate) => candidate.id === finding.nodeId);
    const nodeTitle = nodeObjects.get(finding.nodeId)?.userData?.definition?.title;
    const state = finding.stateId ? node?.states.find((candidate) => candidate.id === finding.stateId) : null;
    const subject = state ? `${nodeTitle ?? 'Node'} · ${state.symbol}` : (nodeTitle ?? `Node ${finding.nodeId}`);
    const when = Number.isFinite(finding.globalTime) ? `at ${formatResultTime(finding.globalTime)}` : 'across the run';
    return { subject, when };
}

function renderStabilityFindings() {
    const findings = resolvedStabilityFindings();
    $('#stabilitySummaryButton').hidden = !findings.length;
    $('#stabilitySummaryButton').classList.toggle('hasFindings', findings.length > 0);
    $('#stabilityFindingsCount').textContent = findings.length ? String(findings.length) : '';
    if (!findings.length) {
        $('#stabilityFindingsCard').classList.add('hidden');
        $('#stabilitySummaryButton').ariaExpanded = 'false';
    }
    $('#stabilityFindingsTitle').textContent = findings.length === 1 ? '1 finding' : `${findings.length} findings`;

    const list = $('#stabilityFindingsList');
    list.replaceChildren();
    if (!findings.length) {
        const empty = document.createElement('p');
        empty.className = 'stabilityFindingsEmpty';
        empty.textContent = 'No numerical stability findings for this result.';
        list.appendChild(empty);
    }
    findings.forEach((finding) => {
        const { subject, when } = describeStabilityFinding(finding);
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'stabilityFinding';
        button.dataset.nodeId = String(finding.nodeId);
        button.innerHTML = `<i></i><span><strong>${escapeHtml(subject)}</strong><small>${escapeHtml(finding.message)} · ${escapeHtml(when)}</small></span>`;
        button.addEventListener('click', () => navigateToStabilityFinding(finding));
        list.appendChild(button);
    });

    const nodeIdsWithFindings = new Set(findings.map((finding) => finding.nodeId));
    $$('.node-label-container').forEach((label) => {
        label.classList.toggle('hasStabilityFinding', nodeIdsWithFindings.has(Number(label.dataset.node)));
    });
    renderStabilityConvergenceSection(nodeIdsWithFindings);

    const extent = Math.max(Number(activeResult?.targetTime) || 0, Number(activeResult?.availableResultTime) || 0,
        activeResult?.samples.at(-1)?.time ?? 0, Number.EPSILON);
    const timedFindings = findings.filter((finding) => Number.isFinite(finding.globalTime));
    if (timedFindings.length) {
        const marks = timedFindings.map((finding) => {
            const percent = Math.min(100, Math.max(0, 100 * finding.globalTime / extent));
            return `linear-gradient(to right, transparent calc(${percent}% - 1px), var(--orange) calc(${percent}% - 1px), var(--orange) calc(${percent}% + 1px), transparent calc(${percent}% + 1px))`;
        });
        $('#resultTimeline').style.setProperty('--stability-marks', marks.join(', '));
    } else {
        $('#resultTimeline').style.removeProperty('--stability-marks');
    }
}

function renderStabilityConvergenceSection(nodeIdsWithFindings) {
    if (convergenceCheckResultRef !== activeResult) {
        convergenceCheckState = new Map();
        convergenceCheckResultRef = activeResult;
    }
    $('#stabilityConvergenceSection').hidden = !nodeIdsWithFindings.size;
    const rows = $('#stabilityConvergenceRows');
    rows.replaceChildren();
    [...nodeIdsWithFindings].forEach((nodeId) => {
        const nodeTitle = nodeObjects.get(nodeId)?.userData?.definition?.title ?? `Node ${nodeId}`;
        const state = convergenceCheckState.get(nodeId) ?? { status: 'idle' };
        const row = document.createElement('div');
        row.className = 'stabilityConvergenceRow';
        const title = document.createElement('strong');
        title.textContent = nodeTitle;
        row.appendChild(title);

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'stabilityCheckConvergence';
        button.textContent = state.status === 'checking' ? 'Checking…' : state.status === 'idle' ? 'Check convergence' : 'Re-check';
        button.disabled = state.status === 'checking';
        button.addEventListener('click', () => checkNodeConvergence(nodeId));
        row.appendChild(button);

        if (state.status === 'done' || state.status === 'error') {
            const result = document.createElement('span');
            result.className = 'stabilityConvergenceResult';
            if (state.status === 'error') {
                result.textContent = state.error;
            } else if (state.finding.converged) {
                result.classList.add('converged');
                result.textContent = state.finding.recommendedSubsteps === state.finding.baseSubsteps
                    ? `Converged already, at the current ${state.finding.baseSubsteps} substep${state.finding.baseSubsteps === 1 ? '' : 's'}.`
                    : `Converged at ${state.finding.recommendedSubsteps} substeps (currently ${state.finding.baseSubsteps}).`;
                if (state.finding.recommendedSubsteps !== state.finding.baseSubsteps) {
                    const apply = document.createElement('button');
                    apply.type = 'button';
                    apply.className = 'stabilityApplyConvergenceFix';
                    apply.textContent = `Apply: ${state.finding.recommendedSubsteps} substeps`;
                    apply.addEventListener('click', () => applyConvergenceFix(nodeId, state.finding.recommendedSubsteps));
                    row.appendChild(apply);
                }
            } else {
                result.classList.add('notConverged');
                result.textContent = `Did not converge within the search bound (tried up to ${state.finding.multiplierReached * state.finding.baseSubsteps} substeps).`;
            }
            row.appendChild(result);
        }
        rows.appendChild(row);
    });
}

async function checkNodeConvergence(nodeId) {
    if (!activeResult) return;
    convergenceCheckState.set(nodeId, { status: 'checking' });
    renderStabilityFindings();
    const document_ = stripEdgeGroups(executionProjectDocument(serializeProjectDocument()));
    const runConfiguration = {
        name: 'stabilityConvergenceCheck',
        targetTime: activeResult.targetTime, globalTimeStep: activeResult.globalTimeStep, outputInterval: activeResult.outputInterval
    };
    try {
        const response = await window.engine.checkSubstepConvergence(JSON.stringify(document_), runConfiguration, [nodeId]);
        if (!response.available) throw new Error('The numerical engine is unavailable.');
        const finding = response.findings.find((candidate) => candidate.nodeId === nodeId);
        if (!finding) throw new Error('The engine did not return a result for this node.');
        convergenceCheckState.set(nodeId, { status: 'done', finding });
    } catch (error) {
        convergenceCheckState.set(nodeId, { status: 'error', error: error.message });
    }
    if (activeResult === convergenceCheckResultRef) renderStabilityFindings();
}

async function applyConvergenceFix(nodeId, substeps) {
    // Applying an operation mutates the live model, which the app keeps locked while a result is
    // shown (see e.g. commitCausalInference's own `if (activeResult) return` guard) -- closing the
    // result first is this action's own equivalent of that same rule, not a special case.
    await discardResultPlayback();
    const baseDocument = serializeProjectDocument();
    let prepared;
    try {
        prepared = buildAssistantProposal(baseDocument, recommendedSubstepFixProposal(nodeId, substeps));
    } catch (error) {
        console.error('Applying the recommended substep count failed:', error);
        return;
    }
    const before = baseDocument;
    const after = prepared.document;
    replaceModelContents(after);
    recordHistory({ undo: () => replaceModelContents(before), redo: () => replaceModelContents(after) });
}

function navigateToStabilityFinding(finding) {
    $('#stabilityFindingsCard').classList.remove('hidden');
    $('#stabilitySummaryButton').ariaExpanded = 'true';
    const node = nodeObjects.get(finding.nodeId);
    if (node) {
        selectNode(node);
        openNodeEditor(node.userData.definition);
    }
    if (Number.isFinite(finding.globalTime) && activeResult?.samples.length) {
        projectResultSample(nearestSampleIndex(activeResult.samples, finding.globalTime));
    }
}

function openStabilityFindingsForNode(nodeId) {
    $('#stabilityFindingsCard').classList.remove('hidden');
    $('#stabilitySummaryButton').ariaExpanded = 'true';
    $(`.stabilityFinding[data-node-id="${nodeId}"]`, $('#stabilityFindingsList'))?.scrollIntoView({ block: 'nearest' });
}

$('#stabilitySummaryButton').addEventListener('click', () => {
    const opening = $('#stabilityFindingsCard').classList.contains('hidden');
    $('#stabilityFindingsCard').classList.toggle('hidden', !opening);
    $('#stabilitySummaryButton').ariaExpanded = String(opening);
});
$('#closeStabilityFindings').addEventListener('click', () => {
    $('#stabilityFindingsCard').classList.add('hidden');
    $('#stabilitySummaryButton').ariaExpanded = 'false';
});

function updateLiveResultControls() {
    // The parameters table locks while results are open (the model is read-only then).
    refreshParametersPanel();
    const lifecycle = activeResult?.lifecycle;
    const live = simulationRunning && ['running', 'paused'].includes(lifecycle);
    const paused = lifecycle === 'paused';
    $('#resultTransport').classList.toggle('liveMode', live);
    $('#simulationProgress').hidden = !live;
    $('.resultMode b').textContent = live ? 'Simulation' : 'Results';
    $('.resultMode small').textContent = live ? `${paused ? 'Paused' : 'Running'} · model locked` : `${lifecycle === 'stopped' ? 'Stopped · ' : ''}Model locked`;
    $('#simulationExecutionControls').hidden = !live;
    $('#resultPlaybackControls').hidden = live;
    $('#simulationPauseResume').innerHTML = paused ? '<span aria-hidden="true">▶</span> Resume' : '<span aria-hidden="true">❚❚</span> Pause';
    $('#simulationPauseResume').ariaLabel = paused ? 'Resume simulation' : 'Pause simulation';
    const canContinue = ['stopped', 'completed'].includes(lifecycle) && !live && Boolean(activeResult?.checkpoints?.length);
    $('#continueRun').hidden = !canContinue;
    $('#continueRun').textContent = lifecycle === 'completed' ? 'Extend simulation' : 'Continue';
    $('#continueRun').ariaLabel = lifecycle === 'completed' ? 'Extend simulation from the final checkpoint' : 'Continue simulation from the latest checkpoint';
    renderBranchSwitcher();
    $$('.reviewControl').forEach((control) => { control.hidden = live; });
    $('#resultPlaybackRate').hidden = live;
    $('#simulationPacing').hidden = !live || activeResult?.pacing?.mode === 'fastest';
    const liveParameters = parameterOwnersInModel().filter(({ parameter }) => parameter.mode === 'live');
    const hasLiveControls = live && runLaunchSettings.online && liveParameters.length > 0;
    $('#liveParameterButton').hidden = !hasLiveControls;
    $('#liveParameterCount').textContent = liveParameters.length ? String(liveParameters.length) : '';
    if (!hasLiveControls) {
        $('#liveParameterPanel').hidden = true;
        $('#liveParameterButton').ariaExpanded = 'false';
    }
    $('#closeResults').lastChild.textContent = 'Close and edit';
    if (activeResult?.pacing) {
        const { mode, simulationSecondsPerWallSecond: ratio } = activeResult.pacing;
        const value = mode === 'limitedRatio' ? `limitedRatio:${ratio}` : mode;
        if ([...$('#simulationPacing').options].some((option) => option.value === value)) $('#simulationPacing').value = value;
    }
    renderExecutionSummary();
    renderStabilityFindings();
}

$('#executionSummaryButton').addEventListener('click', () => {
    const opening = $('#executionSummaryCard').classList.contains('hidden');
    $('#executionSummaryCard').classList.toggle('hidden', !opening);
    $('#executionSummaryButton').ariaExpanded = String(opening);
});
$('#closeExecutionSummary').addEventListener('click', () => {
    $('#executionSummaryCard').classList.add('hidden');
    $('#executionSummaryButton').ariaExpanded = 'false';
});

function liveParameterRange(parameter) {
    const value = Number(parameter.value) || 0;
    const magnitude = Math.max(Math.abs(value), 1);
    const minimum = Number.isFinite(Number(parameter.control?.minimum))
        ? Number(parameter.control.minimum) : Math.min(0, value - magnitude);
    const maximum = Number.isFinite(Number(parameter.control?.maximum))
        ? Number(parameter.control.maximum) : Math.max(0, value + magnitude);
    const fallbackStep = Math.max((maximum - minimum) / 100, 0.001);
    const step = Number(parameter.control?.step) > 0 ? Number(parameter.control.step) : fallbackStep;
    return { minimum, maximum, step };
}

function scheduleLiveParameterUpdate(parameterId, value, immediate = false) {
    liveParameterValues.set(parameterId, value);
    clearTimeout(liveParameterUpdateTimers.get(parameterId));
    const apply = async () => {
        liveParameterUpdateTimers.delete(parameterId);
        if (!activeEngineJobId || !simulationRunning) return;
        try {
            await window.engine.setParameterValue(activeEngineJobId, parameterId, value);
        } catch (error) {
            $('#statusText').textContent = error.message;
        }
    };
    if (immediate) apply();
    else liveParameterUpdateTimers.set(parameterId, setTimeout(apply, 50));
}

// startTime anchors a live intervention to the latest known sample time rather than the exact
// instant the engine receives it -- close enough for a ramp/pulse authored interactively (not a
// hard real-time requirement), and the same convention a fork's overrides use with the
// checkpoint's own time (see openForkLaunchDialog).
async function sendLiveParameterSchedule(parameterId, schedule) {
    if (!activeEngineJobId || !simulationRunning) return;
    const startTime = Number(activeResult?.samples?.at(-1)?.time ?? 0);
    try {
        await window.engine.scheduleParameterValue(activeEngineJobId, parameterId, { ...schedule, startTime });
    } catch (error) {
        $('#statusText').textContent = error.message;
    }
}

// A parameter linked to a shared one is controlled through the shared definition (one entry,
// whichever relationships use it), so live/fork controls list the shared parameter once and skip
// its linked copies.
function parameterOwnersInModel() {
    const own = [
        ...model.relationships.filter((relationship) => !relationship.deleted).flatMap((relationship) => (relationship.parameters ?? [])
            .map((parameter) => ({ parameter, ownerLabel: relationship.title }))),
        ...model.nodes.filter((node) => !node.deleted).flatMap((node) => (node.sourceTerms ?? []).flatMap((term) => (term.parameters ?? [])
            .map((parameter) => ({ parameter, ownerLabel: `${node.title} · source term` })))),
        ...model.nodes.filter((node) => !node.deleted).flatMap((node) => nodeProviderParameterBindings(node)
            .map((binding) => ({ parameter: binding, ownerLabel: `${node.title} · provider` })))
    ];
    const users = new Map();
    own.filter(({ parameter }) => parameter.sharedParameterId !== undefined).forEach(({ parameter }) => {
        users.set(parameter.sharedParameterId, (users.get(parameter.sharedParameterId) ?? 0) + 1);
    });
    return [
        ...own.filter(({ parameter }) => parameter.sharedParameterId === undefined),
        ...model.sharedParameters.filter((shared) => users.has(shared.id)).map((shared) => ({
            parameter: shared,
            ownerLabel: `Shared · ${users.get(shared.id)} ${users.get(shared.id) === 1 ? 'use' : 'uses'}`
        }))
    ];
}

// ---- Parameters table -------------------------------------------------------------------------
// One row per shared parameter (with an expandable list of what links to it) and per ordinary
// edge / source-term parameter; linked parameters appear only under their shared row. Value, unit
// and mode edit inline through the same undoable paths as the owning editor. Edge-group member
// edges are omitted: their parameters belong to the group definition, edited in its own editor.

const expandedSharedParameters = new Set();

function edgeOwnerLabel(relationship) {
    const source = model.nodes.find((node) => node.id === relationship.source)?.title ?? '?';
    const target = model.nodes.find((node) => node.id === relationship.target)?.title ?? '?';
    return `${relationship.title} (${source} → ${target})`;
}

function collectParameterRows() {
    const ordinary = [];
    const usersByShared = new Map();
    const place = (entry) => {
        if (entry.parameter.sharedParameterId === undefined) ordinary.push(entry);
        else {
            const users = usersByShared.get(entry.parameter.sharedParameterId) ?? [];
            users.push(entry);
            usersByShared.set(entry.parameter.sharedParameterId, users);
        }
    };
    model.relationships.filter((relationship) => !relationship.deleted && relationship.groupId == null).forEach((relationship) => {
        (relationship.parameters ?? []).forEach((parameter) => place({
            kind: 'edge', parameter, relationship, ownerLabel: edgeOwnerLabel(relationship)
        }));
    });
    model.nodes.filter((node) => !node.deleted).forEach((node) => {
        (node.sourceTerms ?? []).forEach((term) => (term.parameters ?? []).forEach((parameter) => place({
            kind: 'sourceTerm', parameter, node, term, ownerLabel: `${node.title} · source term`
        })));
        // Shown under the shared parameter it reads, by the provider's input key; edited there.
        nodeProviderParameterBindings(node).forEach((binding) => place({
            kind: 'nodeProvider', parameter: { name: binding.key, symbol: binding.key, sharedParameterId: binding.sharedParameterId }, node,
            ownerLabel: `${node.title} · provider`
        }));
    });
    const shared = model.sharedParameters.filter((definition) => usersByShared.has(definition.id)).map((definition) => ({
        kind: 'shared', parameter: definition, users: usersByShared.get(definition.id)
    }));
    return [...shared, ...ordinary];
}

// Validates and applies a value/unit/mode edit; returns an error string when the edit is refused.
// `patch.tuning` is a { minimum, maximum } to mark the parameter as a fitting target, or null to clear it.
function editParameterRow(entry, patch) {
    if (activeResult) return 'Close results to edit parameters.';
    const current = entry.parameter;
    const { tuning: tuningPatch, ...fields } = patch;
    const next = { ...current, ...fields };
    if (fields.value !== undefined && !Number.isFinite(fields.value)) return 'Enter a number.';
    const control = next.mode === 'live' ? normalizedParameterControl({ ...next, control: current.control }) : null;
    // Live and tunable are exclusive: a live parameter is adjusted during a run, not fitted beforehand.
    const tuning = tuningPatch === undefined ? current.tuning : tuningPatch;
    if (control) {
        const error = parameterControlError(next.value, control);
        if (error) return error;
        if (tuningPatch) return 'A live parameter cannot be a fitting target.';
    } else if (tuning) {
        const error = parameterTuningError(next.value, tuning);
        if (error) return error;
    }
    const assign = (target) => {
        Object.assign(target, fields);
        if (target.mode === 'live') {
            target.control = control;
            delete target.tuning;
        } else {
            delete target.control;
            if (tuning) target.tuning = structuredClone(tuning);
            else delete target.tuning;
        }
    };
    if (entry.kind === 'shared') changeSharedParameter(current.id, assign);
    else if (entry.kind === 'edge') {
        changeEdgeModel(entry.relationship, (snapshot) => assign(snapshot.parameters.find((candidate) => candidate.id === current.id)));
    } else {
        changeSourceTermModel(nodeObjects.get(entry.node.id), entry.term.id, (snapshotTerm) => {
            assign(snapshotTerm.parameters.find((candidate) => candidate.id === current.id));
        });
    }
    return '';
}

// ---- A shared parameter's stored schedule ------------------------------------------------------------------------
let scheduleDialogParameterId = null;

function openScheduleDialog(parameterId) {
    if (activeResult) return;
    const parameter = model.sharedParameters.find((candidate) => candidate.id === parameterId);
    if (!parameter) return;
    scheduleDialogParameterId = parameterId;
    $('#scheduleDialogTitle').textContent = `${parameter.name} over time`;
    $('#scheduleInterpolation').value = parameter.schedule?.interpolation ?? 'linear';
    // A new schedule starts from the constant it replaces, held from time zero.
    $('#scheduleSamples').value = parameter.schedule ? scheduleText(parameter.schedule.samples) : `0, ${parameter.value}`;
    $('#scheduleRemove').hidden = !parameter.schedule;
    refreshScheduleDialog();
    $('#scheduleDialog').showModal();
    $('#scheduleSamples').focus();
}

// The schedule as typed, or the reason it cannot be saved.
function readScheduleDialog() {
    const parsed = parseScheduleText($('#scheduleSamples').value);
    if (parsed.error) return { error: parsed.error };
    const schedule = { interpolation: $('#scheduleInterpolation').value, samples: parsed.samples };
    const error = scheduleError(schedule);
    return error ? { error } : { schedule };
}

function refreshScheduleDialog() {
    const { schedule, error } = readScheduleDialog();
    $('#scheduleSummary').textContent = schedule ? scheduleSummary(schedule) : '';
    $('#scheduleError').textContent = error ?? '';
    $('#scheduleSave').disabled = Boolean(error);
}

function saveScheduleDialog() {
    const { schedule, error } = readScheduleDialog();
    if (error || scheduleDialogParameterId === null) return;
    changeSharedParameter(scheduleDialogParameterId, (target) => {
        target.schedule = schedule;
        // A scheduled parameter is not a fitting target (parameterScheduleTuned).
        delete target.tuning;
    });
    $('#scheduleDialog').close();
}

$('#scheduleSamples').addEventListener('input', refreshScheduleDialog);
$('#scheduleInterpolation').addEventListener('change', refreshScheduleDialog);
$('#scheduleDialog form').addEventListener('submit', (event) => {
    event.preventDefault();
    saveScheduleDialog();
});
$('#scheduleSamples').addEventListener('keydown', (event) => {
    // The samples are typed one per line, so Enter is a new line; Ctrl+Enter (⌘Return on a Mac) saves.
    if (event.key === 'Enter' && (isMac ? event.metaKey : event.ctrlKey)) {
        event.preventDefault();
        saveScheduleDialog();
    }
});
$('#scheduleCancel').addEventListener('click', () => $('#scheduleDialog').close());
$('#scheduleRemove').addEventListener('click', () => {
    if (scheduleDialogParameterId !== null) changeSharedParameter(scheduleDialogParameterId, (target) => { delete target.schedule; });
    $('#scheduleDialog').close();
});

function changeSharedParameter(id, mutate) {
    if (activeResult) return;
    const before = structuredClone(model.sharedParameters);
    const after = structuredClone(before);
    mutate(after.find((candidate) => candidate.id === id));
    const apply = (list) => {
        model.sharedParameters = structuredClone(list);
        updateValidationStatus();
        refreshOpenParameterEditors();
        refreshParametersPanel();
    };
    apply(after);
    recordHistory({ undo: () => apply(before), redo: () => apply(after) });
}

// Re-renders whichever parameter-bearing editor is open, so it shows a shared value that was just
// changed from the table (or undone) rather than a stale one.
function refreshOpenParameterEditors() {
    if (selectedRelationship && !$('#edgeEditor').classList.contains('hidden')) renderEdgeEditor(selectedRelationship);
    if (selectedSourceTermNodeId != null && !$('#sourceTermEditor').classList.contains('hidden')) {
        const node = nodeObjects.get(selectedSourceTermNodeId);
        const term = node?.userData.definition.sourceTerms.find((candidate) => candidate.id === selectedSourceTermId);
        if (node && term) renderSourceTermEditor(node, term);
    }
}

function jumpToParameterOwner(entry) {
    const parameterId = entry.parameter.id;
    if (entry.kind === 'edge') {
        openRelationshipEditor(entry.relationship);
        requestAnimationFrame(() => $(`#edgeEditorParameters [data-parameter-id="${parameterId}"] input[data-field="value"]`)?.focus());
    } else if (entry.kind === 'nodeProvider') {
        const node = nodeObjects.get(entry.node.id);
        if (!node) return;
        selectNode(node);
        openNodeEditor(node.userData.definition);
    } else if (entry.kind === 'sourceTerm') {
        const node = nodeObjects.get(entry.node.id);
        if (!node) return;
        selectNode(node);
        openNodeEditor(node.userData.definition);
        openSourceTermEditor(node, entry.term);
        requestAnimationFrame(() => $(`#termParameters [data-parameter-id="${parameterId}"] input[data-field="value"]`)?.focus());
    }
}

function parameterRowCells(entry, { locked, indent = false }) {
    const parameter = entry.parameter;
    const row = document.createElement('tr');
    if (entry.kind === 'shared') row.className = 'sharedRow';
    if (indent) row.className = 'sharedUserRow';
    const cell = (content) => {
        const td = document.createElement('td');
        if (content instanceof Node) td.appendChild(content);
        else td.textContent = content;
        row.appendChild(td);
        return td;
    };
    if (indent) {
        cell(`↳ ${parameter.name}`);
        cell(parameter.symbol).className = 'symbolCell';
        ['', '', '', ''].forEach(() => cell(''));
        const link = document.createElement('button');
        link.type = 'button';
        link.className = 'ownerLink';
        link.textContent = entry.ownerLabel;
        link.addEventListener('click', () => jumpToParameterOwner(entry));
        cell(link);
        return row;
    }
    cell(parameter.name);
    cell(parameter.symbol).className = 'symbolCell';

    const showError = (control, message) => {
        control.classList.toggle('invalid', Boolean(message));
        control.title = message;
    };
    // A shared parameter with a stored schedule follows its samples over time: the table shows a
    // summary instead of a value, and removing the schedule makes the stored value the constant again.
    if (entry.kind === 'shared' && parameter.schedule) {
        const samples = parameter.schedule.samples ?? [];
        const values = samples.map((sample) => sample[1]);
        const summary = document.createElement('span');
        summary.className = 'scheduleCell';
        summary.dataset.field = 'schedule';
        const label = document.createElement('button');
        label.type = 'button';
        label.className = 'scheduleOpen';
        label.disabled = locked;
        label.addEventListener('click', () => openScheduleDialog(parameter.id));
        label.textContent = `Schedule · ${samples.length} sample${samples.length === 1 ? '' : 's'}`;
        label.title = samples.length
            ? `${parameter.schedule.interpolation === 'hold' ? 'Each value held until the next sample' : 'Linearly interpolated'}, from t = ${formatFittedNumber(samples[0][0])} to ${formatFittedNumber(samples.at(-1)[0])}, values ${formatFittedNumber(Math.min(...values))} to ${formatFittedNumber(Math.max(...values))}. Removing the schedule makes ${formatFittedNumber(parameter.value)} the constant value.`
            : 'An empty schedule.';
        label.title += ' Click to edit it.';
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'scheduleRemove';
        remove.textContent = '×';
        remove.title = 'Remove the schedule';
        remove.setAttribute('aria-label', `Remove the schedule of ${parameter.name}`);
        remove.disabled = locked;
        remove.addEventListener('click', () => changeSharedParameter(parameter.id, (target) => { delete target.schedule; }));
        summary.append(label, remove);
        cell(summary);
    } else {
        const value = document.createElement('input');
        value.type = 'number';
        value.step = 'any';
        value.value = parameter.value;
        value.dataset.field = 'value';
        value.setAttribute('aria-label', `${parameter.name} value`);
        value.disabled = locked;
        value.addEventListener('change', () => {
            const error = editParameterRow(entry, { value: value.value.trim() === '' ? NaN : Number(value.value) });
            showError(value, error);
        });
        if (entry.kind === 'shared') {
            // A shared parameter may follow a schedule over time instead of a constant. (Any parameter can: link it to a
            // shared one from its editor first.)
            const wrapper = document.createElement('span');
            wrapper.className = 'valueWithSchedule';
            const schedule = document.createElement('button');
            schedule.type = 'button';
            schedule.className = 'scheduleAdd';
            schedule.textContent = '⏱';
            schedule.title = 'Follow a schedule over time instead of this constant…';
            schedule.setAttribute('aria-label', `Give ${parameter.name} a schedule`);
            schedule.disabled = locked;
            schedule.addEventListener('click', () => openScheduleDialog(parameter.id));
            wrapper.append(value, schedule);
            cell(wrapper);
        } else cell(value);
    }

    const unit = document.createElement('input');
    unit.value = parameter.unit ?? '';
    unit.dataset.field = 'unit';
    unit.setAttribute('aria-label', `${parameter.name} unit`);
    unit.disabled = locked;
    unit.addEventListener('change', () => showError(unit, editParameterRow(entry, { unit: unit.value.trim() })));
    cell(unit);

    const mode = document.createElement('select');
    mode.dataset.field = 'mode';
    mode.setAttribute('aria-label', `${parameter.name} mode`);
    mode.append(new Option('Constant', 'constant'), new Option('Live', 'live'));
    mode.value = parameter.mode ?? 'constant';
    mode.disabled = locked;
    mode.addEventListener('change', () => {
        const error = editParameterRow(entry, { mode: mode.value });
        showError(mode, error);
        if (error) mode.value = parameter.mode ?? 'constant';
    });
    cell(mode);

    // Fit: mark the parameter as a digital-twin fitting target with bounds. Not for live parameters
    // (adjusted during a run, not fitted beforehand); a shared parameter carries the bounds for every
    // parameter linked to it.
    const fit = document.createElement('span');
    fit.className = 'fitCell';
    const tunable = document.createElement('input');
    tunable.type = 'checkbox';
    tunable.dataset.field = 'tunable';
    tunable.checked = Boolean(parameter.tuning);
    tunable.setAttribute('aria-label', `${parameter.name} is a fitting target`);
    tunable.disabled = locked || parameter.mode === 'live' || Boolean(parameter.schedule);
    tunable.title = parameter.schedule ? 'A parameter that follows a schedule is not fitted.'
        : parameter.mode === 'live' ? 'A live parameter is adjusted during a run, not fitted.' : 'Mark as a fitting target for digital-twin tuning';
    const bound = (field) => {
        const input = document.createElement('input');
        input.type = 'number';
        input.step = 'any';
        input.dataset.field = `tuning-${field}`;
        input.value = parameter.tuning?.[field] ?? '';
        input.hidden = !parameter.tuning;
        input.disabled = locked;
        input.setAttribute('aria-label', `${parameter.name} fitting ${field}`);
        return input;
    };
    const minimumInput = bound('minimum');
    const maximumInput = bound('maximum');
    const commitTuning = (input) => {
        const error = editParameterRow(entry, { tuning: { minimum: Number(minimumInput.value), maximum: Number(maximumInput.value) } });
        showError(input, error);
    };
    tunable.addEventListener('change', () => {
        if (!tunable.checked) {
            editParameterRow(entry, { tuning: null });
            return;
        }
        const error = editParameterRow(entry, { tuning: normalizedParameterTuning(parameter) });
        if (error) {
            tunable.checked = false;
            showError(tunable, error);
        }
    });
    minimumInput.addEventListener('change', () => commitTuning(minimumInput));
    maximumInput.addEventListener('change', () => commitTuning(maximumInput));
    fit.append(tunable, minimumInput, maximumInput);
    cell(fit);

    const owner = document.createElement('span');
    if (entry.kind === 'shared') {
        const badge = document.createElement('span');
        badge.className = 'sharedBadge';
        badge.textContent = 'Shared';
        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'ownerLink';
        toggle.dataset.toggleShared = String(parameter.id);
        const expanded = expandedSharedParameters.has(parameter.id);
        toggle.textContent = `${expanded ? '▾' : '▸'} ${entry.users.length} ${entry.users.length === 1 ? 'use' : 'uses'}`;
        toggle.addEventListener('click', () => {
            if (expandedSharedParameters.has(parameter.id)) expandedSharedParameters.delete(parameter.id);
            else expandedSharedParameters.add(parameter.id);
            refreshParametersPanel();
        });
        owner.append(badge, toggle);
    } else {
        const link = document.createElement('button');
        link.type = 'button';
        link.className = 'ownerLink';
        link.textContent = entry.ownerLabel;
        link.addEventListener('click', () => jumpToParameterOwner(entry));
        owner.appendChild(link);
    }
    cell(owner);
    return row;
}

function refreshParametersPanel() {
    const panel = $('#parametersPanel');
    if (panel.hidden) return;
    const query = $('#parametersSearch').value.trim().toLowerCase();
    const filter = $('#parametersFilter').value;
    const locked = Boolean(activeResult);
    const all = collectParameterRows();
    const matches = (entry) => {
        const parameter = entry.parameter;
        if (filter === 'shared' && entry.kind !== 'shared') return false;
        if (filter === 'tunable' && !parameter.tuning) return false;
        if ((filter === 'live' || filter === 'constant') && (parameter.mode ?? 'constant') !== filter) return false;
        if (!query) return true;
        const owners = entry.kind === 'shared' ? entry.users.map((user) => user.ownerLabel) : [entry.ownerLabel];
        return [parameter.name, parameter.symbol, ...owners].join(' ').toLowerCase().includes(query);
    };
    const visible = all.filter(matches);
    const body = $('#parametersBody');
    // Keep keyboard focus stable across the re-render an edit triggers.
    const focused = document.activeElement;
    body.replaceChildren();
    for (const entry of visible) {
        body.appendChild(parameterRowCells(entry, { locked }));
        if (entry.kind === 'shared' && expandedSharedParameters.has(entry.parameter.id)) {
            entry.users.forEach((user) => body.appendChild(parameterRowCells(user, { locked, indent: true })));
        }
    }
    if (focused && focused !== document.body && panel.contains(focused) && focused.dataset?.toggleShared) {
        $(`[data-toggle-shared="${focused.dataset.toggleShared}"]`, body)?.focus();
    }
    const sharedCount = all.filter((entry) => entry.kind === 'shared').length;
    $('#parametersSummary').textContent = `${all.length} ${all.length === 1 ? 'parameter' : 'parameters'}${sharedCount ? ` · ${sharedCount} shared` : ''}`;
    $('#parametersEmpty').hidden = visible.length > 0;
    $('#parametersReadOnly').hidden = !locked;
}

function setParametersPanelOpen(open) {
    $('#parametersPanel').hidden = !open;
    $('#parametersButton').ariaExpanded = String(open);
    if (open) refreshParametersPanel();
}

$('#parametersButton').addEventListener('click', () => setParametersPanelOpen($('#parametersPanel').hidden));
$('#closeParametersPanel').addEventListener('click', () => setParametersPanelOpen(false));
$('#parametersSearch').addEventListener('input', refreshParametersPanel);
$('#parametersFilter').addEventListener('change', refreshParametersPanel);
documentController.subscribe(refreshParametersPanel);

// allowSchedule adds a transition-mode selector (step/ramp/pulse -- docs/resultExploration.md's
// piecewise and externally-sampled modes need a {time,value} table editor this pass does not
// build; enable/disable and controller-setpoint are UI labels for the same step evaluation, so
// they need no distinct mode here). Step keeps the exact instant-apply behavior every existing
// caller already relies on; ramp/pulse route through onSchedule instead of onChange, carrying the
// row's pre-edit value as the schedule's baseValue.
function buildParameterRow(parameter, ownerLabel, value, onChange, { allowSchedule = false, onSchedule = null } = {}) {
    const { minimum, maximum, step } = liveParameterRange(parameter);
    const normalizedValue = Number.isFinite(Number(value)) ? Number(value) : 0;
    const baseValue = normalizedValue;
    const row = document.createElement('div');
    row.className = 'liveParameterRow';
    row.innerHTML = `
        <div class="liveParameterLabel"><strong>${escapeHtml(parameter.name)}</strong><small>${escapeHtml(ownerLabel)}${parameter.unit ? ` · ${escapeHtml(parameter.unit)}` : ''}</small></div>
        <button data-adjust="-1" type="button" aria-label="Decrease ${escapeHtml(parameter.name)}">−</button>
        <input type="range" min="${minimum}" max="${maximum}" step="${step}" value="${normalizedValue}" aria-label="${escapeHtml(parameter.name)}">
        <button data-adjust="1" type="button" aria-label="Increase ${escapeHtml(parameter.name)}">+</button>
        <input type="number" step="${step}" value="${normalizedValue}" aria-label="${escapeHtml(parameter.name)} value">
        ${allowSchedule ? `
        <div class="parameterScheduleRow">
            <select data-schedule-mode aria-label="Transition mode for ${escapeHtml(parameter.name)}">
                <option value="step">Step</option>
                <option value="ramp">Ramp</option>
                <option value="pulse">Pulse</option>
            </select>
            <input type="number" data-schedule-duration min="0" step="any" placeholder="Duration (s)" hidden aria-label="Duration for ${escapeHtml(parameter.name)}">
        </div>` : ''}
    `;
    const slider = $('input[type="range"]', row);
    const numberInput = $('input[type="number"]:not([data-schedule-duration])', row);
    const modeSelect = allowSchedule ? $('[data-schedule-mode]', row) : null;
    const durationInput = allowSchedule ? $('[data-schedule-duration]', row) : null;
    if (modeSelect) modeSelect.addEventListener('change', () => { durationInput.hidden = modeSelect.value === 'step'; });
    const setValue = (nextValue, immediate = false) => {
        const normalized = Math.min(maximum, Math.max(minimum, Number(nextValue)));
        slider.value = normalized;
        numberInput.value = normalized;
        if (!immediate) return;
        const mode = modeSelect?.value ?? 'step';
        if (mode === 'step' || !onSchedule) {
            onChange(normalized, immediate);
            return;
        }
        const duration = Number(durationInput.value);
        if (!(duration > 0)) { durationInput.focus(); return; }
        onSchedule({ mode, duration, targetValue: normalized, baseValue });
    };
    slider.addEventListener('input', () => setValue(slider.value));
    slider.addEventListener('change', () => setValue(slider.value, true));
    numberInput.addEventListener('change', () => setValue(numberInput.value, true));
    $$('[data-adjust]', row).forEach((button) => button.addEventListener('click', () =>
        setValue((Number(numberInput.value) || 0) + Number(button.dataset.adjust) * step, true)));
    return row;
}

function renderLiveParameterControls() {
    const container = $('#liveParameterRows');
    container.replaceChildren();
    parameterOwnersInModel().filter(({ parameter }) => parameter.mode === 'live')
        .forEach(({ parameter, ownerLabel }) => {
            const value = (liveParameterValues.get(parameter.id) ?? Number(parameter.value)) || 0;
            container.appendChild(buildParameterRow(parameter, ownerLabel, value,
                (normalized, immediate) => scheduleLiveParameterUpdate(parameter.id, normalized, immediate), {
                    allowSchedule: true,
                    onSchedule: (schedule) => sendLiveParameterSchedule(parameter.id, schedule)
                }));
        });
}

// Values are only committed once the fork is confirmed (see openForkLaunchDialog) -- unlike the
// live panel, edits here must not reach a running job because there isn't one yet. Each map entry
// is {kind:'instant', value} or {kind:'schedule', schedule}; openForkLaunchDialog dispatches on
// kind when building the child run's post-spawn command sequence.
function renderForkParameterControls() {
    const container = $('#forkParameterRows');
    container.replaceChildren();
    forkOverrideValues = new Map();
    parameterOwnersInModel().filter(({ parameter }) => parameter.mode === 'live')
        .forEach(({ parameter, ownerLabel }) => {
            const baseValue = Number(parameter.value) || 0;
            forkOverrideValues.set(parameter.id, { kind: 'instant', value: baseValue });
            container.appendChild(buildParameterRow(parameter, ownerLabel, baseValue,
                (normalized) => forkOverrideValues.set(parameter.id, { kind: 'instant', value: normalized }), {
                    allowSchedule: true,
                    onSchedule: (schedule) => forkOverrideValues.set(parameter.id, { kind: 'schedule', schedule })
                }));
        });
}

function applyLiveResult(jobId, result) {
    if (!simulationRunning || (activeEngineJobId && jobId !== activeEngineJobId)) return;
    activeEngineJobId ??= jobId;
    const followLatest = !activeResult || activeResultSampleIndex >= activeResult.samples.length - 1;
    if (pendingRestart) {
        result = {
            ...result,
            samples: [...pendingRestart.samples, ...result.samples],
            checkpoints: [...pendingRestart.checkpoints, ...result.checkpoints]
        };
    }
    if (!activeResult || pendingRestart?.starting || pendingFork) {
        if (pendingRestart) pendingRestart.starting = false;
        activateResult(result);
    }
    else {
        activeResult = result;
        updateResultExtent();
        projectResultSample(followLatest ? result.samples.length - 1 : Math.min(activeResultSampleIndex, result.samples.length - 1));
        updateLiveResultControls();
    }
}

async function discardResultPlayback({ markProjectChanged = false } = {}) {
    if (!activeResult) return;
    if (simulationRunning) return;
    stopResultPlayback();
    const jobIds = new Set([...branches.values()].map((branch) => branch.jobId).filter(Boolean));
    if (activeEngineJobId) jobIds.add(activeEngineJobId);
    await Promise.all([...jobIds].map((jobId) => window.engine.releaseResult(jobId).catch((error) => {
        console.error('A branch result session could not be released.', error);
    })));
    window.addons.closeContext('resultSession');
    activeResult = null;
    activeEngineJobId = null;
    activeResultPersistedInProject = false;
    branches = new Map();
    activeBranchUuid = null;
    pendingFork = null;
    renderBranchSwitcher();
    simulationRunning = false;
    $('#liveParameterPanel').hidden = true;
    $('#executionSummaryCard').classList.add('hidden');
    $('#executionSummaryButton').ariaExpanded = 'false';
    $('#stabilityFindingsCard').classList.add('hidden');
    $('#stabilitySummaryButton').ariaExpanded = 'false';
    $('#stabilitySummaryButton').hidden = true;
    $('#resultTimeline').style.removeProperty('--stability-marks');
    $$('.node-label-container').forEach((label) => label.classList.remove('hasStabilityFinding'));
    cachedFingerprintFindings = { result: null, findings: [] };
    setResultModeLocked(false);
    nodeResultPlot.clear();
    $('.nodeResultsPanel').classList.remove('hasResults');
    $('#resultTransport').hidden = true;
    model.nodes.forEach((node) => node.states.forEach((state) => updateDisplayedState(state.id, state.initialValue)));
    if (nodeDetailsBeforeResult !== null) setLabelDetail('nodes', nodeDetailsBeforeResult);
    nodeDetailsBeforeResult = null;
    if (markProjectChanged) documentController.setSupplementalDirty(true);
    renderValidationStatus();
}

async function exportResultsCsv() {
    if (!activeResult || !activeEngineJobId) return;
    const signals = model.nodes.filter((node) => !node.deleted).flatMap((node) => node.states.map((state) => ({
        signalId: state.id,
        header: `${node.title} — ${state.label}${state.unit ? ` (${state.unit})` : ''}`
    })));
    if (!signals.length) return;
    $('#exportCsvButton').disabled = true;
    try {
        const series = await window.engine.readResultSeries(activeEngineJobId, signals.map((signal) => signal.signalId), {
            startTime: 0,
            endTime: activeResult.availableResultTime ?? Infinity,
            maxPoints: Infinity
        });
        const csv = seriesToCsv(series, signals);
        const outcome = await window.projectFiles.exportResultsCsv(`${filenameStem(currentProjectFilename)}.csv`, csv);
        if (outcome) $('#statusText').textContent = `Exported ${outcome.fileName}`;
    } catch (error) {
        console.error('Results could not be exported as CSV.', error);
        $('#statusText').textContent = 'CSV export failed';
    } finally {
        $('#exportCsvButton').disabled = !activeResult;
    }
}

async function exportGeneratedProgram(kind, parallelism) {
    try {
        const document_ = stripEdgeGroups(executionProjectDocument(serializeProjectDocument()));
        document_.exportDefaultTargetTime = runLaunchSettings.targetTime;
        const source = generateStandaloneProgram(document_, kind, { parallelism });
        const extension = kind === 'cpp' ? 'cpp' : 'py';
        const outcome = await window.projectFiles.exportGeneratedProgram(`${filenameStem(currentProjectFilename)}.${extension}`, source, kind);
        $('#exportCodeDialog').close();
        if (outcome) $('#statusText').textContent = `Exported ${outcome.fileName}`;
    } catch (error) {
        console.error('The simulation could not be exported as code.', error);
        $('#exportCodeError').textContent = error.message || 'Code export failed.';
    }
}

async function exportFmu() {
    try {
        const document_ = stripEdgeGroups(executionProjectDocument(serializeProjectDocument()));
        const modelName = filenameStem(currentProjectFilename);
        // Unlike exportGeneratedProgram, the document itself (not a pre-rendered source string) is
        // sent over IPC: generateFmuPackage runs in the main process, since it needs to spawn the
        // engine binary to actually compile the model into a shared library (see src/fmiExport.mjs).
        const outcome = await window.projectFiles.exportFmu(`${modelName}.fmu`, document_, modelName);
        $('#exportCodeDialog').close();
        if (outcome) $('#statusText').textContent = `Exported ${outcome.fileName}`;
    } catch (error) {
        console.error('The simulation could not be exported as an FMU.', error);
        $('#exportCodeError').textContent = error.message || 'FMU export failed.';
    }
}

function requestCloseResultsConfirmation() {
    const dialog = $('#closeResultsDialog');
    const form = $('form', dialog);
    const cancel = $('#closeResultsCancel');
    $('#closeResultsMessage').textContent = activeResultPersistedInProject
        ? 'Closing the results panel will remove these results from the current session. You can load them again by reopening the saved project.'
        : 'If you want to load these results again later, save the project with simulation results before closing. Once the results panel is closed, the results will be removed from this session and cannot be reopened unless they were saved.';
    return new Promise((resolve) => {
        const finish = (confirmed) => {
            form.removeEventListener('submit', onSubmit);
            dialog.removeEventListener('cancel', onCancel);
            cancel.removeEventListener('click', onCancelClick);
            dialog.close();
            resolve(confirmed);
        };
        const onSubmit = (event) => { event.preventDefault(); finish(true); };
        const onCancel = (event) => { event.preventDefault(); finish(false); };
        const onCancelClick = () => finish(false);
        form.addEventListener('submit', onSubmit);
        dialog.addEventListener('cancel', onCancel);
        cancel.addEventListener('click', onCancelClick);
        dialog.showModal();
    });
}

async function closeResultPlayback() {
    if (!activeResult || simulationRunning || !await requestCloseResultsConfirmation()) return;
    await discardResultPlayback({ markProjectChanged: activeResultPersistedInProject });
    $('#statusText').textContent = 'Results removed · model editing enabled';
}

$('#resultTimeline').addEventListener('input', (event) => {
    stopResultPlayback();
    projectResultSample(nearestSampleIndex(activeResult.samples, Number(event.target.value)));
    updateLiveResultControls();
});
$('#resultStart').addEventListener('click', () => { stopResultPlayback(); projectResultSample(0); });
$('#resultPrevious').addEventListener('click', () => { stopResultPlayback(); projectResultSample(activeResultSampleIndex - 1); });
$('#resultNext').addEventListener('click', () => { stopResultPlayback(); projectResultSample(activeResultSampleIndex + 1); });
$('#resultEnd').addEventListener('click', () => { stopResultPlayback(); projectResultSample(activeResult.samples.length - 1); });
$('#resultPlayPause').addEventListener('click', () => {
    if (resultPlaying) {
        stopResultPlayback();
        return;
    }
    if (activeResultSampleIndex >= activeResult.samples.length - 1) projectResultSample(0);
    resultPlaying = true;
    resultPlaybackStartedAt = performance.now();
    resultPlaybackStartedFrom = Number(activeResult.samples[activeResultSampleIndex].time);
    $('#resultPlayPause').textContent = '❚❚';
    $('#resultPlayPause').ariaLabel = 'Pause results';
    scheduleResultPlayback();
});
$('#resultPlaybackRate').addEventListener('change', () => {
    if (resultPlaying) {
        clearTimeout(resultPlaybackTimer);
        resultPlaybackStartedAt = performance.now();
        resultPlaybackStartedFrom = Number(activeResult.samples[activeResultSampleIndex].time);
        scheduleResultPlayback();
    }
});
$('#simulationPacing').addEventListener('change', async (event) => {
    if (!activeEngineJobId) return;
    await window.engine.setPacing(activeEngineJobId, pacingFromValue(event.target.value));
});
$('#liveParameterButton').addEventListener('click', () => {
    const panel = $('#liveParameterPanel');
    panel.hidden = !panel.hidden;
    $('#liveParameterButton').ariaExpanded = String(!panel.hidden);
    if (!panel.hidden) renderLiveParameterControls();
});
$('#closeLiveParameterPanel').addEventListener('click', () => {
    $('#liveParameterPanel').hidden = true;
    $('#liveParameterButton').ariaExpanded = 'false';
});
$('#simulationPauseResume').addEventListener('click', async () => {
    if (!activeEngineJobId || !simulationRunning) return;
    const nextState = activeResult?.lifecycle === 'paused' ? 'running' : 'paused';
    await window.engine.setExecutionState(activeEngineJobId, nextState);
});
$('#simulationStop').addEventListener('click', async () => {
    if (!activeEngineJobId || !simulationRunning) return;
    await window.engine.setExecutionState(activeEngineJobId, 'stopped');
});
$('#continueRun').addEventListener('click', () => {
    const checkpoint = activeResult.checkpoints.at(-1);
    if (!checkpoint) return;
    pendingFork = null;
    pendingRestart = {
        starting: true,
        checkpoint: structuredClone(checkpoint),
        samples: structuredClone(activeResult.samples.slice(0, -1)),
        checkpoints: structuredClone(activeResult.checkpoints.slice(0, -1))
    };
    const continueSource = fillRunConfigurationFields({ continuing: true });
    runLaunchSettings.targetTime = Math.max(runLaunchSettings.targetTime, checkpoint.time + continueSource.globalTimeStep);
    $('#runLaunchDescription').textContent = `Continue from ${formatResultTime(checkpoint.time)}.`;
    $('#runTargetTime').value = runLaunchSettings.targetTime;
    $('#runOnlineMode').checked = runLaunchSettings.online;
    $('#runPacingMode').value = runLaunchSettings.pacing.mode === 'limitedRatio' ? 'limitedRatio' : 'realTime';
    $('#runPacingRatio').value = runLaunchSettings.pacing.simulationSecondsPerWallSecond;
    $('#runStabilityMonitoring').checked = runLaunchSettings.stabilityMonitoring;
    updateRunModeFields();
    $('#runLaunchError').textContent = '';
    $('#runLaunchDialog').showModal();
});

// "Fork here" fetches the authoritative checkpoint by time rather than reconstructing one from
// activeResult.samples, which may be downsampled for display -- see engineReadCheckpoint in
// main.mjs, which reads the full in-memory checkpoint list rather than the trimmed one this
// renderer normally receives.
$('#forkHereButton').addEventListener('click', async () => {
    if (!activeResult || !activeEngineJobId || simulationRunning) return;
    setBranchesPanelOpen(false);
    const scrubTime = Number(activeResult.samples[activeResultSampleIndex]?.time ?? 0);
    let checkpoint;
    try {
        checkpoint = await window.engine.readCheckpoint(activeEngineJobId, scrubTime);
    } catch (error) {
        console.error('The checkpoint could not be read.', error);
    }
    if (!checkpoint) {
        $('#statusText').textContent = 'No checkpoint is available at this time.';
        return;
    }
    pendingFork = { parentBranchUuid: activeBranchUuid, forkTime: checkpoint.time, checkpoint, overrides: [] };
    $('#forkParameterDescription').textContent = `Fork from ${formatResultTime(checkpoint.time)}`;
    renderForkParameterControls();
    if ($('#forkParameterRows').children.length > 0) {
        $('#forkParameterPanel').hidden = false;
        anchorPanelToBranchesButton($('#forkParameterPanel'));
    }
    else openForkLaunchDialog();
});
$('#closeForkParameterPanel').addEventListener('click', () => {
    $('#forkParameterPanel').hidden = true;
    pendingFork = null;
});
$('#confirmForkParameters').addEventListener('click', () => {
    $('#forkParameterPanel').hidden = true;
    openForkLaunchDialog();
});
function openForkLaunchDialog() {
    if (!pendingFork) return;
    const owners = parameterOwnersInModel();
    pendingFork.overrides = [...forkOverrideValues.entries()]
        .filter(([parameterId, entry]) => entry.kind === 'schedule' ||
            Number(owners.find(({ parameter }) => parameter.id === parameterId)?.parameter.value) !== entry.value)
        .map(([parameterId, entry]) => ({ parameterId, entry }));
    pendingRestart = null;
    const forkSource = fillRunConfigurationFields({ continuing: true });
    runLaunchSettings.targetTime = Math.max(runLaunchSettings.targetTime, pendingFork.checkpoint.time + forkSource.globalTimeStep);
    $('#runLaunchDescription').textContent = `Fork from ${formatResultTime(pendingFork.checkpoint.time)}${pendingFork.overrides.length ? ' with parameter changes' : ''}.`;
    $('#runTargetTime').value = runLaunchSettings.targetTime;
    $('#runOnlineMode').checked = runLaunchSettings.online;
    $('#runPacingMode').value = runLaunchSettings.pacing.mode === 'limitedRatio' ? 'limitedRatio' : 'realTime';
    $('#runPacingRatio').value = runLaunchSettings.pacing.simulationSecondsPerWallSecond;
    $('#runStabilityMonitoring').checked = runLaunchSettings.stabilityMonitoring;
    updateRunModeFields();
    $('#runLaunchError').textContent = '';
    $('#runLaunchDialog').showModal();
}
$('#closeResults').addEventListener('click', closeResultPlayback);
$('#exportCsvButton').addEventListener('click', () => exportResultsCsv());
// Python has no thread-based parallel option (the GIL means threads would not actually run this
// CPU-bound loop in parallel -- see src/codeExport.mjs), but it does support mpi via mpi4py. An
// FMU is a compiled binary loaded as a single shared library by one host process, so it is C++
// only (no Python option) and has no MPI mode either (see src/fmiCodeGen.mjs/docs/codeExport.md).
function updateExportCodeFields() {
    const isFmu = $('#exportCodeFormat').value === 'fmu';
    const languageField = $('#exportCodeLanguage');
    const parallelismField = $('#exportCodeParallelism');
    $('#exportCodeLanguagePython').disabled = isFmu;
    if (isFmu && languageField.value === 'python') languageField.value = 'cpp';
    const isPython = languageField.value === 'python';
    $('#exportCodeParallelismOpenmp').disabled = isPython;
    $('#exportCodeParallelismStdThread').disabled = isPython;
    $('#exportCodeParallelismMpi').disabled = isFmu;
    if (isPython && (parallelismField.value === 'openmp' || parallelismField.value === 'stdThread')) parallelismField.value = 'serial';
    if (isFmu && parallelismField.value === 'mpi') parallelismField.value = 'serial';
    parallelismField.closest('label').hidden = isFmu;
    $('#mergeFmuButton').hidden = !isFmu;
}
$('#exportCodeButton').addEventListener('click', () => {
    $('#exportCodeFormat').value = 'source';
    $('#exportCodeLanguage').value = 'cpp';
    $('#exportCodeParallelism').value = 'serial';
    updateExportCodeFields();
    $('#exportCodeError').textContent = '';
    $('#exportCodeDialog').showModal();
});
$('#exportCodeFormat').addEventListener('change', updateExportCodeFields);
$('#mergeFmuButton').addEventListener('click', async () => {
    $('#exportCodeError').textContent = '';
    try {
        const outcome = await window.projectFiles.mergeFmus();
        if (outcome) $('#statusText').textContent = `Merged ${outcome.mergedCount} FMUs into ${outcome.fileName}`;
    } catch (error) {
        console.error('The FMUs could not be merged.', error);
        $('#exportCodeError').textContent = error.message || 'Merging the FMUs failed.';
    }
});
$('#exportCodeLanguage').addEventListener('change', updateExportCodeFields);
$('#exportCodeCancel').addEventListener('click', () => $('#exportCodeDialog').close());
$('#exportCodeDialog form').addEventListener('submit', (event) => {
    event.preventDefault();
    if ($('#exportCodeFormat').value === 'fmu') exportFmu();
    else exportGeneratedProgram($('#exportCodeLanguage').value, $('#exportCodeParallelism').value);
});
window.addons.onRequest('timeline.seek', (time) => {
    if (!activeResult) return;
    stopResultPlayback();
    projectResultSample(nearestSampleIndex(activeResult.samples, Number(time)));
});

function createAddonContext(contextNames) {
    const contexts = {};
    for (const contextName of contextNames) {
        if (contextName !== 'resultSession' || !activeResult) return null;
        contexts.resultSession = {
            projectName: filenameStem(currentProjectFilename),
            engineJobId: activeEngineJobId,
            result: activeResult,
            nodes: model.nodes.map((node) => {
                const object = nodeObjects.get(node.id);
                return {
                    id: node.id,
                    title: node.title,
                    shape: node.shape,
                    color: node.color,
                    rotation: object ? [object.rotation.x, object.rotation.y, object.rotation.z] : [0, 0, 0],
                    scale: object ? [object.scale.x, object.scale.y, object.scale.z] : [1, 1, 1],
                    mesh: node.importedGeometry ? {
                        position: Array.from(node.importedGeometry.getAttribute('position').array),
                        normal: node.importedGeometry.getAttribute('normal') ? Array.from(node.importedGeometry.getAttribute('normal').array) : null,
                        index: node.importedGeometry.getIndex() ? Array.from(node.importedGeometry.getIndex().array) : null
                    } : null,
                    parts: node.appearanceParts ?? null,
                    states: node.states.map(({ id, label, symbol, unit }) => ({ id, label, symbol, unit }))
                };
            }),
            edges: model.relationships.filter((edge) => edge.enabled && !edge.deleted).map((edge) => ({
                id: edge.id,
                title: edge.title,
                sourceNodeId: edge.source,
                targetNodeId: edge.target
            })),
            selectedNodeId: selectedNode?.userData.id ?? null,
            time: activeResult.samples[activeResultSampleIndex]?.time ?? 0
        };
    }
    return contexts;
}

function addonConditionMatches(condition) {
    return condition === 'always' || (condition === 'resultsActive' && Boolean(activeResult));
}

function refreshAddonRailContributions() {
    addonRailContributions.forEach(({ contribution, button }) => {
        button.hidden = !addonConditionMatches(contribution.when);
    });
}

async function initializeAddonRailContributions() {
    try {
        const contributions = await window.addons.listToolstripContributions();
        const container = $('#addonRailButtons');
        container.replaceChildren();
        addonRailContributions = contributions.map((contribution) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'toolButton addonTool railTool';
            button.ariaLabel = contribution.tooltip;
            button.dataset.tooltip = contribution.tooltip;
            button.dataset.addonId = contribution.addonId;
            button.dataset.commandId = contribution.commandId;
            const symbol = document.createElement('span');
            symbol.textContent = contribution.symbol;
            symbol.className = 'railToolSymbol';
            const label = document.createElement('span');
            label.textContent = contribution.label;
            label.className = 'railToolLabel';
            button.append(symbol, label);
            button.addEventListener('click', async () => {
                const contexts = createAddonContext(contribution.contexts);
                if (!contexts) return;
                try {
                    await window.addons.invokeCommand(contribution.addonId, contribution.commandId, contexts);
                } catch (error) {
                    console.error(`Add-on command ${contribution.addonId}.${contribution.commandId} failed.`, error);
                    $('#statusText').textContent = `${contribution.addonName} unavailable`;
                }
            });
            container.appendChild(button);
            return { contribution, button };
        });
        refreshAddonRailContributions();
    } catch (error) {
        console.error('Add-on contributions could not be loaded.', error);
    }
}

async function startSimulation() {
    if (simulationRunning || !currentValidation.valid) return;
    simulationRunning = true;
    liveParameterValues = new Map(parameterOwnersInModel()
        .filter(({ parameter }) => parameter.mode === 'live')
        .map(({ parameter }) => [parameter.id, Number(parameter.value) || 0]));
    // A fork must not mark the parent's (still displayed, still immutable) result as "running" --
    // the child is what's starting, and activateResult only swaps activeResult to the child once
    // its first sample arrives.
    if (pendingRestart && activeResult && !pendingFork) {
        activeResult = { ...activeResult, lifecycle: 'running' };
        updateLiveResultControls();
    }
    $('#runButton').disabled = true;
    $('#runButton').title = 'Simulation is running';
    $('#statusText').textContent = pendingFork ? 'Starting fork…' : 'Running simulation…';
    const previousResultSessionId = activeEngineJobId;
    const forkingFromSessionId = pendingFork ? previousResultSessionId : null;
    try {
        const configuration = { ...activeRunConfiguration(), ...runLaunchSettings.configurationOverride };
        const execution = await window.engine.start(JSON.stringify(stripEdgeGroups(executionProjectDocument(serializeProjectDocument()))), {
            ...configuration,
            targetTime: runLaunchSettings.targetTime,
            pacing: runLaunchSettings.pacing,
            // Checked (the default) omits the field so engineAdapter.mjs's own "monitor every
            // node" default applies unchanged; unchecked explicitly disables it for this run.
            ...(runLaunchSettings.stabilityMonitoring ? {} : { stabilityMonitoring: { nodeIds: [] } }),
            ...(pendingFork ? { startCheckpoint: pendingFork.checkpoint } : pendingRestart ? { startCheckpoint: pendingRestart.checkpoint } : {})
        });
        if (!execution.available) throw new Error('The C++ simulation engine is unavailable.');
        activeEngineJobId = execution.jobId;
        // A fork must keep the parent's job/result alive as an immutable sibling branch rather
        // than releasing it the way an ordinary new run replaces its predecessor.
        if (previousResultSessionId && previousResultSessionId !== execution.jobId && !forkingFromSessionId) {
            window.engine.releaseResult(previousResultSessionId).catch((error) => {
                console.error('Previous result session could not be released.', error);
            });
        }
        const overrides = pendingFork?.overrides ?? [];
        if (overrides.length) {
            // Pause -> apply overrides -> run, all awaited in order onto the same ordered stdin
            // pipe (see engineAdapter.mjs's sendCommand), guarantees the child's first
            // synchronization step already has these values: the engine always drains queued
            // control commands before integrating step 0 (simulationRunner.cpp), regardless of
            // scheduling, so this ordering -- not timing -- is what makes it race-free.
            await window.engine.setExecutionState(execution.jobId, 'paused');
            for (const { parameterId, entry } of overrides) {
                if (entry.kind === 'schedule') {
                    await window.engine.scheduleParameterValue(execution.jobId, parameterId, { ...entry.schedule, startTime: pendingFork.checkpoint.time });
                } else {
                    await window.engine.setParameterValue(execution.jobId, parameterId, entry.value);
                }
            }
            await window.engine.setExecutionState(execution.jobId, 'running');
        }
    } catch (error) {
        console.error('C++ simulation failed.', error);
        $('#statusText').textContent = 'Simulation failed';
        $('#runButton').title = error.message;
        simulationRunning = false;
        pendingFork = null;
        $('#runButton').disabled = runButtonDisabled();
        if (currentValidation.valid) $('#runButton').title = 'Run simulation';
    }
}

// The Run dialog for an ordinary run. Opens whatever the model's state, so a run configuration the
// validator rejects (an output interval that is not a multiple of the timestep, say) can be corrected
// here: Save settings always works; only Start waits for the model to be valid. An error in the
// validation panel also opens it (see navigateToValidationIssue).
function openRunDialog() {
    if (simulationRunning || activeResult) return;
    pendingRestart = null;
    pendingFork = null;
    fillRunConfigurationFields({ continuing: false });
    $('#runLaunchDescription').textContent = "Run from the model's initial state.";
    $('#runTargetTime').value = runLaunchSettings.targetTime;
    $('#runOnlineMode').checked = runLaunchSettings.online;
    $('#runPacingMode').value = runLaunchSettings.pacing.mode === 'limitedRatio' ? 'limitedRatio' : 'realTime';
    $('#runPacingRatio').value = runLaunchSettings.pacing.simulationSecondsPerWallSecond;
    $('#runStabilityMonitoring').checked = runLaunchSettings.stabilityMonitoring;
    updateRunModeFields();
    $('#runLaunchError').textContent = currentValidation.valid ? '' : 'The model has errors. Settings can be saved now; a run can start once the errors are fixed.';
    $('#runLaunchDialog').showModal();
}
$('#runButton').addEventListener('click', openRunDialog);
$('#runLaunchCancel').addEventListener('click', () => $('#runLaunchDialog').close());
function updateRunModeFields() {
    const online = $('#runOnlineMode').checked;
    $('#runModeName').textContent = online ? 'Online' : 'Offline';
    $('#runModeDescription').textContent = online
        ? 'Synchronize the run with wall-clock time for live interaction.'
        : 'Run at maximum speed without wall-clock synchronization.';
    $('#runPacingModeField').hidden = !online;
    $('#runPacingRatioField').hidden = !online || $('#runPacingMode').value !== 'limitedRatio';
}
$('#runOnlineMode').addEventListener('change', updateRunModeFields);
$('#runPacingMode').addEventListener('change', (event) => {
    $('#runPacingRatioField').hidden = !$('#runOnlineMode').checked || event.target.value !== 'limitedRatio';
});
// The numerics and execution fields of the Run dialog. A fresh run starts from, and saves to, the model's
// active run configuration. Continuing or forking a result starts from what that result ran with (so a
// second extension defaults to the timestep the first one chose) and applies to that run only.
function activeRunConfiguration() {
    return model.runConfigurations.find((item) => item.id === model.activeRunConfigurationId);
}

function fillRunConfigurationFields({ continuing }) {
    const saved = activeRunConfiguration();
    const source = continuing && activeResult
        ? { ...saved, globalTimeStep: activeResult.globalTimeStep ?? saved.globalTimeStep, outputInterval: activeResult.outputInterval ?? saved.outputInterval }
        : saved;
    $('#runGlobalTimeStep').value = source.globalTimeStep;
    $('#runOutputInterval').value = source.outputInterval;
    const execution = normalizeExecutionConfiguration(source.execution);
    $('#runExecutionBackend').value = execution.backend;
    $('#runWorkerThreads').value = execution.workerThreads;
    $('#runPartitionAlgorithm').value = execution.partitionAlgorithm;
    $('#runPartitionCount').value = execution.partitionCount;
    $('#runPartitionCommunicationBias').value = execution.partitionCommunicationBias;
    $('#runAutomaticParallelThreshold').value = execution.automaticParallelThreshold;
    $('#runAutomaticMaximumPartitionCutFraction').value = execution.automaticMaximumPartitionCutFraction;
    updateExecutionConfigurationFields();
    $('#runConfigurationScope').textContent = continuing
        ? 'Applies from this point on, to this run only; the model keeps its own settings. A different timestep gives one result that changes step size here.'
        : 'Saved with the model, and used by the command line and code export.';
    $('#saveRunConfiguration').hidden = continuing;
    $('#startRun').disabled = !continuing && !currentValidation.valid;
    return source;
}

function readRunConfigurationFields() {
    return {
        globalTimeStep: Number($('#runGlobalTimeStep').value),
        outputInterval: Number($('#runOutputInterval').value),
        execution: {
            backend: $('#runExecutionBackend').value,
            partitionAlgorithm: $('#runPartitionAlgorithm').value,
            workerThreads: Number($('#runWorkerThreads').value),
            partitionCount: Number($('#runPartitionCount').value),
            partitionCommunicationBias: Number($('#runPartitionCommunicationBias').value),
            automaticParallelThreshold: Number($('#runAutomaticParallelThreshold').value),
            automaticMaximumPartitionCutFraction: Number($('#runAutomaticMaximumPartitionCutFraction').value)
        }
    };
}

// Saves the dialog's numerics to the model's active run configuration, as one undoable step, when they
// changed. Only ever used for an ordinary run: a result on screen keeps the model locked.
function saveRunConfigurationFields(values) {
    const before = structuredClone(activeRunConfiguration());
    const after = { ...before, ...structuredClone(values) };
    if (JSON.stringify(before) === JSON.stringify(after)) return false;
    applyRunConfiguration(after);
    recordHistory({ undo: () => applyRunConfiguration(before), redo: () => applyRunConfiguration(after) });
    return true;
}

$('#saveRunConfiguration').addEventListener('click', () => {
    if (activeResult || pendingFork || pendingRestart) return;
    const values = readRunConfigurationFields();
    const problem = validateRunConfigurationValues(values);
    if (problem) {
        $('#runLaunchError').textContent = problem;
        return;
    }
    saveRunConfigurationFields(values);
    $('#runLaunchDialog').close();
});
$('#runLaunchDialog form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const continuing = Boolean(pendingFork || pendingRestart);
    const values = readRunConfigurationFields();
    const targetTime = Number($('#runTargetTime').value);
    const online = $('#runOnlineMode').checked;
    const pacingMode = online ? $('#runPacingMode').value : 'fastest';
    const pacingRatio = pacingMode === 'realTime' ? 1 : Number($('#runPacingRatio').value);
    const startTime = pendingFork?.checkpoint.time ?? pendingRestart?.checkpoint.time ?? 0;
    const problem = validateRunConfigurationValues(values);
    if (problem) {
        $('#runLaunchError').textContent = problem;
        return;
    }
    if (!targetTimeIsReachable(targetTime, startTime, values.globalTimeStep) ||
        (pacingMode === 'limitedRatio' && (!(pacingRatio > 0) || !Number.isFinite(pacingRatio)))) {
        $('#runLaunchError').textContent = `Target time must be at least one global timestep after ${formatResultTime(startTime)}; limited pacing requires a positive ratio.`;
        return;
    }
    const configurationChanged = !continuing && saveRunConfigurationFields(values);
    runLaunchSettings = {
        targetTime,
        online,
        pacing: { mode: pacingMode, simulationSecondsPerWallSecond: pacingRatio },
        stabilityMonitoring: $('#runStabilityMonitoring').checked,
        configurationOverride: continuing ? values : null
    };
    $('#runLaunchDialog').close();
    // Saving new numerics revalidates the model; a run must not start on settings that validation has
    // not yet accepted (startSimulation then declines, and the status line shows the errors).
    if (configurationChanged) await validationSettled();
    startSimulation();
});

window.engine.onUpdate(({ jobId, result }) => applyLiveResult(jobId, result));
window.engine.onComplete(({ jobId, result }) => {
    if (jobId !== activeEngineJobId) return;
    applyLiveResult(jobId, result);
    simulationRunning = false;
    activeResultPersistedInProject = false;
    documentController.setSupplementalDirty(true);
    selectSuggestedPlaybackRate();
    updateLiveResultControls();
    $('#statusText').textContent = result.lifecycle === 'stopped' ? 'Simulation stopped · partial results retained' : 'Simulation complete';
});
window.engine.onError(({ jobId, message }) => {
    if (jobId !== activeEngineJobId) return;
    console.error(`[Simulation Error] Job ${jobId} failed:`, message);
    simulationRunning = false;
    updateLiveResultControls();
    $('#statusText').textContent = 'Simulation failed';
    $('#runButton').title = message;
    if (!activeResult) {
        activeEngineJobId = null;
        $('#runButton').disabled = runButtonDisabled();
    }
});

function applyRunConfiguration(configuration) {
    const index = model.runConfigurations.findIndex((item) => item.id === configuration.id);
    model.runConfigurations[index] = structuredClone(configuration);
    if (selectedNode && !$('#nodeEditor').classList.contains('hidden')) renderNodeEditorModel(selectedNode);
    updateValidationStatus();
}

function updateExecutionConfigurationFields() {
    const backend = $('#runExecutionBackend').value;
    $('#runWorkerThreads').disabled = backend === 'serial';
    const partitionControlsEnabled = backend === 'automatic' || backend === 'partitioned';
    $('#runPartitionAlgorithm').disabled = !partitionControlsEnabled;
    $('#runPartitionCount').disabled = !partitionControlsEnabled;
    $('#runPartitionCommunicationBias').disabled = !partitionControlsEnabled || $('#runPartitionAlgorithm').value === 'metisKway';
    $('#runAutomaticParallelThreshold').disabled = backend !== 'automatic';
    $('#runAutomaticMaximumPartitionCutFraction').disabled = backend !== 'automatic';
}

$('#runExecutionBackend').addEventListener('change', updateExecutionConfigurationFields);
$('#runPartitionAlgorithm').addEventListener('change', updateExecutionConfigurationFields);

function toolchainFields(kind) {
    const prefix = kind === 'python' ? 'toolchainPython' : 'toolchainCpp';
    return { path: $(`#${prefix}Path`), detected: $(`#${prefix}Detected`), status: $(`#${prefix}Status`) };
}

async function refreshToolchainField(kind) {
    const { path, detected, status } = toolchainFields(kind);
    const { overridePath, detectedPath } = await window.providerToolchains.get(kind);
    path.value = overridePath ?? '';
    path.placeholder = detectedPath ? `Auto-detected: ${detectedPath}` : 'Leave blank to auto-detect';
    detected.textContent = detectedPath ? `Auto-detected: ${detectedPath}` : 'Not auto-detected on this machine.';
    status.textContent = '';
    status.className = 'assistantConfigurationStatus';
}

async function testToolchainField(kind) {
    const { path, status } = toolchainFields(kind);
    status.textContent = 'Testing…';
    status.className = 'assistantConfigurationStatus';
    const result = await window.providerToolchains.test(kind, path.value);
    status.textContent = result.message;
    status.className = `assistantConfigurationStatus ${result.valid ? '' : 'error'}`;
}

async function browseToolchainField(kind) {
    const path = await window.providerToolchains.browse(kind);
    if (path) toolchainFields(kind).path.value = path;
}

function updateProviderExecutionModeWarning() {
    $('#providerExecutionModeWarning').hidden = $('#providerExecutionMode').value !== 'inProcess';
}

async function refreshProviderExecutionMode() {
    const { executionMode } = await window.providerToolchains.executionMode.get();
    $('#providerExecutionMode').value = executionMode;
    updateProviderExecutionModeWarning();
}

$('#providerToolchainsButton').addEventListener('click', async () => {
    $('#providerToolchainsError').textContent = '';
    await Promise.all([refreshToolchainField('cpp'), refreshToolchainField('python'), refreshProviderExecutionMode()]);
    $('#providerToolchainsDialog').showModal();
});
$('#providerToolchainsCancel').addEventListener('click', () => $('#providerToolchainsDialog').close());
$('#toolchainCppBrowse').addEventListener('click', () => browseToolchainField('cpp'));
$('#toolchainPythonBrowse').addEventListener('click', () => browseToolchainField('python'));
$('#toolchainCppTest').addEventListener('click', () => testToolchainField('cpp'));
$('#toolchainPythonTest').addEventListener('click', () => testToolchainField('python'));
$('#providerExecutionMode').addEventListener('change', updateProviderExecutionModeWarning);
$('#providerToolchainsDialog').addEventListener('submit', async (event) => {
    event.preventDefault();
    const error = $('#providerToolchainsError');
    error.textContent = '';
    try {
        await window.providerToolchains.set('cpp', $('#toolchainCppPath').value);
        await window.providerToolchains.set('python', $('#toolchainPythonPath').value);
        await window.providerToolchains.executionMode.set($('#providerExecutionMode').value);
        $('#providerToolchainsDialog').close();
    } catch (submitError) {
        error.textContent = submitError.message;
    }
});

function syncContextualOverlays() {
    const bundles = activeRelationshipBundles();
    const activeKeys = new Set(bundles.map((bundle) => bundle.key));
    relationshipBundleObjects.forEach((overlay, key) => {
        if (activeKeys.has(key)) return;
        scene.remove(overlay.anchor);
        overlay.element.remove();
        relationshipBundleObjects.delete(key);
    });
    bundles.forEach((bundle) => {
        let overlay = relationshipBundleObjects.get(bundle.key);
        if (!overlay) {
            overlay = createRelationshipBundleOverlay(bundle.key);
            relationshipBundleObjects.set(bundle.key, overlay);
        }
        const sourceObject = nodeObjects.get(bundle.source);
        const targetObject = nodeObjects.get(bundle.target);
        // A CSS2D overlay always wins DOM hit-testing over the WebGL canvas beneath it, even
        // though 3D raycasting ignores it entirely -- so a visible label can silently block
        // clicks meant for a waypoint handle it happens to sit near or on top of. Hiding it
        // while any of its relationships has waypoint handles showing (i.e. is the selected
        // relationship and has at least one waypoint) keeps that whole editing gesture clear.
        const editingWaypoints = bundle.relationships.some((relationship) => waypointHandleObjects.has(relationship.id));
        overlay.baseVisible = Boolean(sourceObject?.visible && targetObject?.visible) && !editingWaypoints;
        overlay.anchor.visible = overlay.baseVisible && bundleLabelAllowed(overlay);
        const curveMidpoints = bundle.relationships
            .map((relationship) => relationshipObjects.get(relationship.id)?.line.userData.curve?.getPoint(0.5))
            .filter(Boolean);
        if (curveMidpoints.length) {
            overlay.anchor.position.set(0, 0, 0);
            curveMidpoints.forEach((point) => overlay.anchor.position.add(point));
            overlay.anchor.position.multiplyScalar(1 / curveMidpoints.length);
        } else {
            overlay.anchor.position.copy(sourceObject.position).lerp(targetObject.position, 0.5);
        }
        renderRelationshipBundle(overlay, bundle);
    });
}

function createRelationshipBundleOverlay(key) {
    const element = $('#relationshipBundleTemplate').content.firstElementChild.cloneNode(true);
    element.dataset.bundle = key;
    const anchor = new THREE.Object3D();
    const object = new CSS2DObject(element);
    object.center.set(0.5, 0.5);
    anchor.add(object);
    scene.add(anchor);
    element.addEventListener('pointerdown', (event) => event.stopPropagation());
    element.addEventListener('click', (event) => {
        if (event.shiftKey) return;
        const row = event.target.closest('.relationshipRow');
        const bundle = activeRelationshipBundles().find((candidate) => candidate.key === key);
        const definition = row
            ? model.relationships.find((relationship) => relationship.id === Number(row.dataset.relationship))
            : bundle?.relationships[0];
        if (definition) openRelationshipEditor(definition);
    });
    element.addEventListener('contextmenu', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (activeResult) return;
        stageContextMenuAction(() => {
            const row = event.target.closest('.relationshipRow');
            const bundle = activeRelationshipBundles().find((candidate) => candidate.key === key);
            const definition = row
                ? model.relationships.find((relationship) => relationship.id === Number(row.dataset.relationship))
                : bundle?.relationships[0];
            if (!definition) return;
            selectRelationship(definition);
            openEdgeContextMenu(event.clientX, event.clientY);
        });
    });
    $('.collapseBundle', element).addEventListener('click', (event) => {
        event.stopPropagation();
        element.classList.toggle('pinned');
        const pinned = element.classList.contains('pinned');
        event.currentTarget.textContent = pinned ? '−' : '＋';
        event.currentTarget.title = pinned ? 'Use automatic detail' : 'Keep expanded';
    });
    return { anchor, element, signature: '' };
}

function renderRelationshipBundle(overlay, bundle) {
    const source = model.nodes.find((node) => node.id === bundle.source);
    const target = model.nodes.find((node) => node.id === bundle.target);
    $('header strong', overlay.element).textContent = `${source.title} ↔ ${target.title}`;
    $('header span', overlay.element).textContent = `${bundle.relationships.length} ${bundle.relationships.length === 1 ? 'relationship' : 'relationships'}`;
    const signature = JSON.stringify(bundle.relationships.map((relationship) => ({
        id: relationship.id,
        title: relationship.title,
        directionality: relationship.directionality,
        equation: relationship.equation,
        parameter: relationship.parameters?.[0],
        enabled: isEdgeEffectivelyEnabled(relationship)
    })));
    if (overlay.signature === signature) return;
    overlay.signature = signature;
    $$('.relationshipRow', overlay.element).forEach((row) => row.remove());
    bundle.relationships.forEach((relationship) => {
        const row = document.createElement('button');
        const parameter = relationship.parameters?.[0];
        const summary = parameter
            ? `${parameter.value}${parameter.unit ? ` ${parameter.unit}` : ''}`
            : relationship.equation ? 'Equation' : 'No equation';
        const enabled = isEdgeEffectivelyEnabled(relationship);
        row.className = 'relationshipRow';
        row.classList.toggle('disabled', !enabled);
        row.dataset.relationship = relationship.id;
        row.type = 'button';
        row.innerHTML = `
            <i class="relationColor" style="background:#${relationship.color.toString(16).padStart(6, '0')}"></i>
            <span><b>${relationship.directionality === 'directed' ? '→' : '⇄'}</b> ${escapeHtml(relationship.title)}</span>
            <em>${enabled ? escapeHtml(summary) : 'Disabled'}</em>
        `;
        overlay.element.appendChild(row);
    });
}

function invalidateRelationshipBundles() {
    relationshipBundleObjects.forEach((overlay) => {
        overlay.signature = '';
    });
}

function activeRelationshipBundles() {
    return groupRelationshipBundles(model.relationships, (relationship) => (
        relationshipObjects.get(relationship.id)?.line.visible === true &&
        nodeObjects.get(relationship.source)?.visible === true &&
        nodeObjects.get(relationship.target)?.visible === true
    ));
}

function serializeGeometry(geometry) {
    return {
        position: Array.from(geometry.attributes.position.array),
        normal: geometry.attributes.normal ? Array.from(geometry.attributes.normal.array) : [],
        index: geometry.index ? Array.from(geometry.index.array) : []
    };
}

// A shared parameter is written only while something visible still links to it, so unlinking
// (or deleting) the last user of one never leaves an orphan definition in the saved file.
// A computational-node provider's bindings to shared parameters (a node has no parameters of its own, so its
// provider reads project-level ones): uses of those shared parameters, like a linked parameter is.
function nodeProviderParameterBindings(node) {
    return (node.implementation?.bindings ?? []).filter((binding) => binding.kind === 'parameter' && binding.sharedParameterId !== undefined);
}

function serializedSharedParameters(visibleNodeIds) {
    const linkedIds = new Set([
        ...model.relationships.filter((relationship) => !relationship.deleted)
            .flatMap((relationship) => relationship.parameters ?? []),
        ...model.nodes.filter((node) => visibleNodeIds.has(node.id))
            .flatMap((node) => [...(node.sourceTerms ?? []).flatMap((term) => term.parameters ?? []), ...nodeProviderParameterBindings(node)])
    ].map((parameter) => parameter.sharedParameterId).filter((id) => id !== undefined));
    const written = model.sharedParameters.filter((shared) => linkedIds.has(shared.id));
    return written.length ? { sharedParameters: structuredClone(written) } : {};
}

function serializeProjectDocument() {
    const visibleNodes = model.nodes.filter((node) => !node.deleted);
    const visibleNodeIds = new Set(visibleNodes.map((node) => node.id));
    return {
        format: 'konjugate',
        version: 1,
        copyright: 'Copyright © 2026 Zenin Easa Panthakkalakath',
        metadata: { units: model.metadata.units },
        runConfigurations: structuredClone(model.runConfigurations),
        activeRunConfigurationId: model.activeRunConfigurationId,
        ...serializedSharedParameters(visibleNodeIds),
        nodes: visibleNodes.map((node) => {
            const object = nodeObjects.get(node.id);
            return {
                id: node.id,
                name: node.title,
                type: node.type,
                ...(node.subsystemId === null ? {} : { subsystemId: node.subsystemId }),
                enabled: node.enabled !== false,
                // integration is written only when it is not the default, so other models save exactly as before.
                numerics: { substepsPerGlobalStep: node.substepsPerGlobalStep, ...(node.integration === 'semiImplicit' ? { integration: 'semiImplicit' } : {}) },
                position: object.position.toArray(),
                // Omitted when at the identity value, like subsystemId above -- keeps a node
                // that was never rotated/scaled serializing exactly as it did before these
                // fields existed, rather than growing every node's JSON with inert zeros/ones.
                ...(object.rotation.x === 0 && object.rotation.y === 0 && object.rotation.z === 0
                    ? {} : { rotation: object.rotation.toArray().slice(0, 3) }),
                ...(object.scale.x === 1 && object.scale.y === 1 && object.scale.z === 1
                    ? {} : { scale: object.scale.toArray() }),
                states: node.states.map((state) => ({
                    id: state.id ?? allocateModelEntityId(),
                    name: state.label,
                    symbol: state.symbol,
                    initialValue: (state.initialValue ?? Number.parseFloat(state.value)) || 0,
                    unit: state.unit ?? ''
                })),
                sourceTerms: (node.sourceTerms ?? []).map((term) => {
                    const normalized = normalizeSourceTermExpressionModel(node, term);
                    return {
                        ...term,
                        parameters: term.parameters ?? [],
                        ...(!term.implementation ? { expressionModel: normalized } : {})
                    };
                }),
                ...(node.implementation ? { implementation: structuredClone(node.implementation) } : {}),
                appearance: {
                    ...(node.importedGeometry
                        ? {
                            type: 'mesh',
                            fileName: node.geometryFileName,
                            color: `#${node.color.toString(16).padStart(6, '0')}`,
                            mesh: serializeGeometry(node.importedGeometry)
                        }
                        : {
                            type: 'primitive',
                            shape: node.shape,
                            color: `#${node.color.toString(16).padStart(6, '0')}`
                        }),
                    ...(node.appearanceParts ? { parts: structuredClone(node.appearanceParts) } : {})
                }
            };
        }),
        edges: model.relationships
            .filter((edge) => (
                !edge.deleted &&
                visibleNodeIds.has(edge.source) && visibleNodeIds.has(edge.target)
            ))
            .map((edge) => ({
                id: edge.id,
                ...(edge.groupId == null ? {} : { groupId: edge.groupId }),
                name: edge.title,
                source: { nodeId: edge.source, stateId: edge.sourceStateId ?? '' },
                target: { nodeId: edge.target, stateId: edge.targetStateId ?? '' },
                directionality: edge.directionality,
                enabled: edge.enabled !== false,
                equation: edge.equationModel?.latex ?? edge.equation ?? '',
                equationModel: normalizeEdgeEquationModel(edge),
                ...(edge.implementation ? { implementation: edge.implementation } : {}),
                parameters: edge.parameters ?? [],
                appearance: {
                    color: `#${edge.color.toString(16).padStart(6, '0')}`,
                    offset: edge.offset,
                    waypoints: edge.waypoints ?? []
                }
            })),
        subsystems: model.subsystems.filter((subsystem) => !subsystem.deleted).map((subsystem) => ({
            id: subsystem.id,
            name: subsystem.name,
            parentSubsystemId: subsystem.parentSubsystemId,
            position: subsystemObjects.get(subsystem.id)?.position.toArray() ?? subsystem.position,
            ports: structuredClone(subsystem.ports)
        })),
        // Node deletion (deleteSelected) only toggles visibility -- it has no reason to know
        // about edgeGroups, and doesn't touch group.memberNodeIds -- so a group whose members
        // were deleted directly (rather than via "detach"/"delete group") would otherwise still
        // list now-invisible node ids here. hydrateEdgeGroups() throws on a member id that isn't
        // in the exported nodes array, which single-edge/node edits never re-trigger mid-session,
        // but any full-document round trip does -- a save+reload, or (already possible today,
        // independent of this) the AI assistant's own commit path, both call
        // hydrateProjectDocument() on exactly this output. Filtering to currently-visible members
        // here keeps every serialization self-consistent regardless of how a member became
        // invisible, without needing every hiding path to separately know about group membership.
        edgeGroups: model.edgeGroups
            .filter((group) => !group.deleted)
            .map((group) => ({
                id: group.id,
                name: group.name,
                memberNodeIds: group.memberNodeIds.filter((id) => visibleNodeIds.has(id)),
                color: `#${group.color.toString(16).padStart(6, '0')}`,
                definition: structuredClone(group.definition)
            }))
            .filter((group) => group.memberNodeIds.length >= 2)
    };
}

function clearRenderedModel() {
    clearSelection();
    relationshipBundleObjects.forEach((overlay) => {
        scene.remove(overlay.anchor);
        overlay.element.remove();
    });
    relationshipBundleObjects.clear();
    relationshipObjects.forEach((relationship) => {
        scene.remove(relationship.line);
        relationship.line.geometry.dispose();
        relationship.line.material.dispose();
        if (relationship.marker) {
            scene.remove(relationship.marker);
            relationship.marker.geometry.dispose();
            relationship.marker.material.dispose();
        }
    });
    nodeObjects.forEach((node) => {
        node.traverse((child) => child.element?.remove());
        scene.remove(node);
        node.geometry.dispose();
        node.material.dispose();
        node.userData.definition.importedGeometry?.dispose();
    });
    subsystemObjects.forEach((object) => {
        object.traverse((child) => child.element?.remove());
        scene.remove(object);
        object.geometry.dispose();
        object.material.dispose();
    });
    relationshipObjects.clear();
    nodeObjects.clear();
    subsystemObjects.clear();
    relationshipPickTargets.length = 0;
    nodePickTargets.length = 0;
}

// Reconstructs the full branch tree from a saved multi-branch project (projectFile.mjs's
// resultSections). Real saved UUIDs are preserved -- unlike a fresh run or fork, which always
// mints a new one -- so parent/child references still resolve. Returns the root branch's result;
// the caller passes that straight into activateResult, which detects the pre-populated
// branches.get(activeBranchUuid) entry this function just set and skips creating a new one,
// running only its UI-activation tail (registerActiveBranch's existing-branch early return).
function restoreBranchesFromSave(embeddedBranches) {
    branches = new Map();
    embeddedBranches.forEach((branch, index) => {
        const branchUuid = branch.branchUuid ?? crypto.randomUUID();
        branches.set(branchUuid, {
            branchUuid,
            parentBranchUuid: branch.parentBranchUuid ?? null,
            forkTime: branch.forkTime ?? null,
            jobId: branch.sessionId,
            result: branch.result,
            sampleIndex: branch.result.samples.length - 1,
            label: branch.label ?? (index === 0 ? 'Baseline' : `Fork at ${formatResultTime(branch.forkTime)}`),
            color: branchColors[index % branchColors.length]
        });
    });
    const [rootUuid] = branches.keys();
    activeBranchUuid = rootUuid;
    const rootBranch = branches.get(rootUuid);
    activeEngineJobId = rootBranch.jobId;
    return rootBranch.result;
}

async function loadProjectDocument(document, {
    path = null,
    fileName = 'untitled.kjt',
    saved = true,
    password = null,
    embeddedResult = null,
    embeddedBranches = null
} = {}) {
    await discardResultPlayback();
    discardAssistantProposal();
    hideAssistantPanel();
    const nextModel = hydrateProjectDocument(document);
    projectAddonData = addonDataOf(document);
    addonDataUnsaved = false;
    clearRenderedModel();
    model.metadata = nextModel.metadata;
    model.runConfigurations = nextModel.runConfigurations;
    model.activeRunConfigurationId = nextModel.activeRunConfigurationId;
    model.nodes.splice(0, model.nodes.length, ...nextModel.nodes);
    model.relationships.splice(0, model.relationships.length, ...nextModel.relationships);
    model.subsystems.splice(0, model.subsystems.length, ...nextModel.subsystems);
    model.sharedParameters = nextModel.sharedParameters;
    model.nodes.forEach(createNode);
    model.subsystems.forEach(createSubsystemObject);
    model.relationships.forEach(createRelationship);
    activeSubsystemId = null;
    refreshSubsystemView();
    invalidateRelationshipBundles();
    updateRelationships();
    updateModelStatus();
    currentProjectPath = path;
    window.projectFiles.pathChanged(currentProjectPath);
    currentProjectFilename = fileName;
    currentProjectPassword = password;
    documentController.reset({ saved });
    updateDocumentTitle();
    updateEncryptionControls();
    setCameraView('orbit', false);
    fitCurrentView();
    applyLargeModelLabelDefault();
    if (embeddedResult) {
        activeResultPersistedInProject = true;
        const rootResult = embeddedBranches ? restoreBranchesFromSave(embeddedBranches) : embeddedResult.result;
        if (!embeddedBranches) activeEngineJobId = embeddedResult.sessionId;
        activateResult(rootResult);
        selectSuggestedPlaybackRate();
    }
}

function replaceModelContents(document) {
    const nextModel = hydrateProjectDocument(document);
    clearRenderedModel();
    model.metadata = nextModel.metadata;
    model.runConfigurations = nextModel.runConfigurations;
    model.activeRunConfigurationId = nextModel.activeRunConfigurationId;
    model.nodes.splice(0, model.nodes.length, ...nextModel.nodes);
    model.relationships.splice(0, model.relationships.length, ...nextModel.relationships);
    model.subsystems.splice(0, model.subsystems.length, ...nextModel.subsystems);
    model.sharedParameters = nextModel.sharedParameters;
    model.nodes.forEach(createNode);
    model.subsystems.forEach(createSubsystemObject);
    model.relationships.forEach(createRelationship);
    activeSubsystemId = null;
    refreshSubsystemView();
    invalidateRelationshipBundles();
    updateRelationships();
    updateModelStatus();
}

function showAssistantPanel() {
    $('#validationPanel').hidden = true;
    $('#validationSummary').ariaExpanded = 'false';
    $('#assistantPanel').hidden = false;
    $('#assistantButton').ariaExpanded = 'true';
    if (!assistantHasBeenPositioned) positionAssistantPanel();
    else clampAssistantPanel();
    requestAnimationFrame(avoidAssistantInspectorOverlap);
    refreshAssistantConfigurations();
}

function hideAssistantPanel() {
    // Cancels the request but leaves its controller in place: requestAssistantProposal's own cleanup runs
    // when the cancellation lands, and only does its job (re-enabling the button, stopping the progress
    // display) for the controller that is still current. Dropping the controller here made it skip that,
    // leaving the button disabled on "Preparing…" when the panel was reopened.
    assistantGenerationController?.abort();
    $('#assistantPanel').hidden = true;
    $('#assistantButton').ariaExpanded = 'false';
}

function visibleModelInspector() {
    return [$('#nodeEditor'), $('#edgeEditor'), $('#edgeGroupEditor')].find((editor) => !editor.classList.contains('hidden')) ?? null;
}

function assistantBounds(left, top) {
    const panel = $('#assistantPanel');
    const canvasRect = canvas.getBoundingClientRect();
    return {
        left: Math.max(10, Math.min(left, window.innerWidth - panel.offsetWidth - 10)),
        top: Math.max(canvasRect.top + 10, Math.min(top, window.innerHeight - panel.offsetHeight - 10))
    };
}

function setAssistantPosition(left, top) {
    const panel = $('#assistantPanel');
    const bounds = assistantBounds(left, top);
    panel.style.left = `${bounds.left}px`;
    panel.style.top = `${bounds.top}px`;
    panel.style.removeProperty('right');
    panel.style.removeProperty('bottom');
    assistantHasBeenPositioned = true;
}

function positionAssistantPanel() {
    const panel = $('#assistantPanel');
    const inspector = visibleModelInspector();
    const rightBoundary = inspector ? inspector.getBoundingClientRect().left - 10 : window.innerWidth - 10;
    setAssistantPosition(rightBoundary - panel.offsetWidth, canvas.getBoundingClientRect().top + 10);
}

function clampAssistantPanel() {
    const panel = $('#assistantPanel');
    if (panel.hidden) return;
    const rect = panel.getBoundingClientRect();
    setAssistantPosition(rect.left, rect.top);
}

function avoidAssistantInspectorOverlap() {
    const panel = $('#assistantPanel');
    const inspector = visibleModelInspector();
    if (panel.hidden || !inspector) return;
    const panelRect = panel.getBoundingClientRect();
    const inspectorRect = inspector.getBoundingClientRect();
    const overlaps = panelRect.right > inspectorRect.left && panelRect.left < inspectorRect.right &&
        panelRect.bottom > inspectorRect.top && panelRect.top < inspectorRect.bottom;
    if (overlaps) setAssistantPosition(inspectorRect.left - panelRect.width - 10, panelRect.top);
}

function setAssistantCollapsed(collapsed) {
    const panel = $('#assistantPanel');
    panel.classList.toggle('collapsed', collapsed);
    $('#collapseAssistantPanel').textContent = collapsed ? '□' : '−';
    $('#collapseAssistantPanel').ariaLabel = collapsed ? 'Expand model assistant' : 'Collapse model assistant';
    $('#collapseAssistantPanel').ariaExpanded = String(!collapsed);
    requestAnimationFrame(clampAssistantPanel);
}

function updateAssistantCollapsedStatus(text) {
    $('#assistantCollapsedStatus').textContent = text;
}

function installAssistantDragging() {
    const panel = $('#assistantPanel');
    const header = $('#assistantPanelHeader');
    let drag = null;
    header.addEventListener('pointerdown', (event) => {
        if (event.button !== 0 || event.target.closest('button')) return;
        const rect = panel.getBoundingClientRect();
        drag = { pointerId: event.pointerId, offsetX: event.clientX - rect.left, offsetY: event.clientY - rect.top };
        header.setPointerCapture(event.pointerId);
    });
    header.addEventListener('pointermove', (event) => {
        if (!drag || event.pointerId !== drag.pointerId) return;
        setAssistantPosition(event.clientX - drag.offsetX, event.clientY - drag.offsetY);
    });
    const finish = (event) => {
        if (!drag || event.pointerId !== drag.pointerId) return;
        if (header.hasPointerCapture(event.pointerId)) header.releasePointerCapture(event.pointerId);
        drag = null;
    };
    header.addEventListener('pointerup', finish);
    header.addEventListener('pointercancel', finish);
}

function renderAssistantProposal(proposal, prepared) {
    $('#assistantEmpty').hidden = true;
    $('#assistantClarification').hidden = true;
    $('#assistantProposal').hidden = false;
    $('#assistantProposalSummary').textContent = proposal.summary?.trim() || 'Proposed model changes';
    const assumptions = Array.isArray(proposal.assumptions) ? proposal.assumptions.filter((item) => typeof item === 'string' && item.trim()) : [];
    $('#assistantAssumptionsSection').hidden = !assumptions.length;
    $('#assistantAssumptions').replaceChildren(...assumptions.map((assumption) => {
        const item = document.createElement('li');
        item.textContent = assumption;
        return item;
    }));
    $('#assistantChanges').replaceChildren(...prepared.changes.map((change) => {
        const item = document.createElement('li');
        item.className = `assistantChange ${change.action ?? 'update'}`;
        const content = document.createElement(change.focusEntityId ? 'button' : 'div');
        if (change.focusEntityId) {
            content.type = 'button';
            content.dataset.focusEntity = change.focusEntityId;
            content.setAttribute('aria-label', `${change.label}. Inspect this object in the current model.`);
        }
        const heading = document.createElement('span');
        const badge = document.createElement('b');
        badge.textContent = change.action === 'remove' ? 'Remove' : change.action === 'add' ? 'Add' : 'Update';
        const label = document.createElement('strong');
        label.textContent = change.label;
        heading.append(badge, label);
        content.append(heading);
        if (change.fields?.length) {
            const details = document.createElement('dl');
            change.fields.forEach((field) => {
                const row = document.createElement('div');
                const name = document.createElement('dt');
                const values = document.createElement('dd');
                name.textContent = field.field;
                values.textContent = `${formatAssistantValue(field.before)} → ${formatAssistantValue(field.after)}`;
                row.append(name, values);
                details.append(row);
            });
            content.append(details);
        }
        item.append(content);
        return item;
    }));
    $('#assistantError').hidden = true;
    $('#assistantProposalStatus').className = 'pending';
    $('#assistantProposalStatus').textContent = 'Validating the candidate model with the C++ engine…';
    $('#applyAssistantProposal').disabled = true;
}

function formatAssistantValue(value) {
    if (value === null || value === undefined || value === '') return '—';
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
}

function renderAssistantTranscript() {
    const transcript = $('#assistantTranscript');
    transcript.hidden = assistantTurnHistory.length === 0;
    transcript.replaceChildren(...assistantTurnHistory.map((turn) => {
        const item = document.createElement('li');
        item.className = 'assistantTranscriptTurn';
        const you = document.createElement('p');
        you.className = 'assistantTranscriptYou';
        you.textContent = turn.request;
        const outcome = document.createElement('p');
        outcome.className = 'assistantTranscriptOutcome';
        outcome.textContent = turn.outcome;
        item.append(you, outcome);
        return item;
    }));
    // Keep the most recent exchange in view rather than wherever the scroll position happened
    // to be left (replaceChildren doesn't move it on its own), the same way a chat log would.
    transcript.scrollTop = transcript.scrollHeight;
}

function pushAssistantTurn(request, outcome) {
    const record = { request, outcome };
    assistantTurnHistory = [...assistantTurnHistory, record].slice(-5);
    renderAssistantTranscript();
    return record;
}

function updateAssistantTurnOutcome(record, outcome) {
    if (!record || !assistantTurnHistory.includes(record)) return;
    record.outcome = outcome;
    renderAssistantTranscript();
}

function resetAssistantConversation() {
    assistantTurnHistory = [];
    pendingAssistantTurnRecord = null;
    renderAssistantTranscript();
}

function renderAssistantClarification(response) {
    $('#assistantEmpty').hidden = true;
    $('#assistantProposal').hidden = true;
    $('#assistantClarification').hidden = false;
    $('#assistantClarificationQuestion').textContent = response.question;
    const suggestions = Array.isArray(response.suggestions) ? response.suggestions : [];
    $('#assistantClarificationOptions').hidden = !suggestions.length;
    $('#assistantClarificationOptions').replaceChildren(...suggestions.map((suggestion) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'assistantClarificationOption';
        button.textContent = suggestion;
        button.dataset.suggestion = suggestion;
        return button;
    }));
    updateAssistantCollapsedStatus('Needs clarification');
}

function dismissAssistantClarification() {
    updateAssistantTurnOutcome(pendingAssistantTurnRecord, 'You did not answer.');
    pendingAssistantTurnRecord = null;
    $('#assistantClarification').hidden = true;
    $('#assistantEmpty').hidden = false;
    $('#generateAssistantProposal').textContent = 'Generate proposal';
    updateAssistantCollapsedStatus('Your model remains unchanged');
}

function inspectAssistantEntity(entityId) {
    const node = nodeObjects.get(entityId);
    if (node?.visible) {
        selectNode(node);
        openNodeEditor(node.userData.definition);
        return true;
    }
    const relationship = relationshipObjects.get(entityId);
    if (relationship?.line.visible) {
        openRelationshipEditor(relationship.definition);
        return true;
    }
    return false;
}

async function previewAssistantProposal(proposal) {
    if (activeResult) throw new Error('Close simulation results before preparing model changes.');
    const revision = ++assistantPreviewRevision;
    showAssistantPanel();
    try {
        const baseDocument = serializeProjectDocument();
        const prepared = buildAssistantProposal(baseDocument, proposal);
        renderAssistantProposal(proposal, prepared);
        const validation = await window.engine.validate(JSON.stringify(prepared.document));
        if (validation.cancelled || revision !== assistantPreviewRevision) return { valid: false, superseded: true };
        if (!validation.available) throw new Error('The native validation engine is unavailable.');
        if (!validation.report.valid) {
            const message = validation.report.issues
                .filter((issue) => issue.severity === 'error')
                .map((issue) => issue.message)
                .join(' ') || 'The native validator rejected this proposal.';
            throw new Error(message);
        }
        pendingAssistantProposal = {
            proposal: structuredClone(proposal),
            document: prepared.document,
            baseDocument: JSON.stringify(baseDocument),
            changes: prepared.changes
        };
        $('#assistantProposalStatus').className = 'valid';
        $('#assistantProposalStatus').textContent = `Native validation passed · ${prepared.changes.length} ${prepared.changes.length === 1 ? 'change' : 'changes'}`;
        $('#applyAssistantProposal').disabled = false;
        $('#generateAssistantProposal').textContent = 'Revise proposal';
        updateAssistantCollapsedStatus('Proposal ready to review');
        return { valid: true, changes: structuredClone(prepared.changes) };
    } catch (error) {
        if (revision !== assistantPreviewRevision) return { valid: false, superseded: true };
        pendingAssistantProposal = null;
        $('#assistantEmpty').hidden = true;
        $('#assistantClarification').hidden = true;
        $('#assistantProposal').hidden = false;
        $('#assistantProposalStatus').className = '';
        $('#assistantProposalStatus').textContent = 'Proposal rejected';
        $('#assistantError').textContent = error.message;
        $('#assistantError').hidden = false;
        $('#applyAssistantProposal').disabled = true;
        updateAssistantTurnOutcome(pendingAssistantTurnRecord, `Rejected: ${error.message}`);
        pendingAssistantTurnRecord = null;
        return { valid: false, error: error.message };
    }
}

// General "back to the empty state" reset, used both for an explicit Discard click and whenever
// something else (switching model configuration, a hard generation error) needs to clear
// whatever the panel was showing -- proposal or clarification -- without assuming which.
function discardAssistantProposal() {
    assistantPreviewRevision += 1;
    pendingAssistantProposal = null;
    pendingAssistantTurnRecord = null;
    // Nothing is pending any more, so Apply must not look available until the next proposal has
    // been prepared and validated.
    $('#applyAssistantProposal').disabled = true;
    $('#assistantProposal').hidden = true;
    $('#assistantClarification').hidden = true;
    $('#assistantEmpty').hidden = false;
    $('#generateAssistantProposal').textContent = 'Generate proposal';
    updateAssistantCollapsedStatus('Your model remains unchanged');
}

function commitAssistantProposal() {
    if (!pendingAssistantProposal || activeResult) return false;
    const currentDocument = serializeProjectDocument();
    if (JSON.stringify(currentDocument) !== pendingAssistantProposal.baseDocument) {
        $('#assistantError').textContent = 'The model changed after this proposal was prepared. Preview it again against the current model.';
        $('#assistantError').hidden = false;
        $('#applyAssistantProposal').disabled = true;
        pendingAssistantProposal = null;
        return false;
    }
    const before = currentDocument;
    const after = structuredClone(pendingAssistantProposal.document);
    updateAssistantTurnOutcome(pendingAssistantTurnRecord, `Applied: ${pendingAssistantProposal.proposal.summary?.trim() || 'the proposed changes'}`);
    replaceModelContents(after);
    recordHistory({
        undo: () => replaceModelContents(before),
        redo: () => replaceModelContents(after)
    });
    discardAssistantProposal();
    hideAssistantPanel();
    return true;
}

// { csvContent, mapping: [{columnName, nodeId|null, stateId|null, createNew, suggestedSymbol?}],
//   candidates: [{sourceColumn, targetColumn, lag, coefficient, intercept, score, provenance, accepted}] | null }
let causalInferenceState = null;

function existingNodesForMapping() {
    // A plain-data projection decoupled from the live Three.js-backed model, matching what
    // src/csvImport.mjs's pure functions expect -- state.label is this app's live-model field
    // for what csvImport.mjs (and the on-disk document) call "name".
    return model.nodes.filter((node) => !node.deleted).map((node) => ({
        id: node.id,
        name: node.title,
        states: node.states.map((state) => ({ id: state.id, symbol: state.symbol, name: state.label }))
    }));
}

// Every footer button below follows the same rule as the section it belongs to: hidden until
// the step it acts on is actually reachable (there is nothing to click yet, so don't show a
// button for it), disabled only once reachable but currently inactionable (e.g. candidates exist
// but none are checked). "Run inference" appears together with the mapping section and then
// stays available for as long as it's shown, since re-running with different settings once you've
// reached that point is a real, ongoing capability, not a one-shot step.
function resetCausalInference() {
    causalInferenceState = null;
    $('#causalInferenceFile').value = '';
    $('#causalInferenceStatus').className = 'equationDiagnostics';
    $('#causalInferenceStatus').textContent = '';
    $('#causalInferenceMappingSection').hidden = true;
    $('#causalInferenceMappingRows').replaceChildren();
    $('#causalInferenceDegreeMode').value = 'linear';
    $('#causalInferenceDegreeValueField').hidden = true;
    $('#causalInferenceDegreeValue').value = '3';
    $('#causalInferenceIncludeInteractionTerms').checked = false;
    $('#runCausalInference').hidden = true;
    $('#runCausalInference').disabled = true;
    $('#causalInferenceCandidatesSection').hidden = true;
    $('#causalInferenceCandidateRows').replaceChildren();
    $('#causalInferenceSelfTermSection').hidden = true;
    $('#causalInferenceSelfTermRows').replaceChildren();
    $('#causalInferenceInputSection').hidden = true;
    $('#causalInferenceInputRows').replaceChildren();
    $('#commitCausalInference').hidden = true;
    $('#commitCausalInference').disabled = true;
}

function openCausalInference() {
    if (activeResult) return;
    hideCards($('#causalInference'));
    resetCausalInference();
    $('#causalInference').classList.remove('hidden');
}

function renderCausalInferenceMapping() {
    const container = $('#causalInferenceMappingRows');
    container.replaceChildren();
    const nodesForMapping = existingNodesForMapping();
    causalInferenceState.mapping.forEach((entry, index) => {
        const row = document.createElement('div');
        row.className = 'causalInferenceMappingRow';
        const label = document.createElement('span');
        label.textContent = entry.columnName;
        row.append(label);
        const select = document.createElement('select');
        select.append(new Option(`Create node “${entry.suggestedSymbol ?? suggestSymbol(entry.columnName)}”`, causalMappingCreateValue));
        nodesForMapping.forEach((node) => {
            const modelNode = model.nodes.find((candidate) => candidate.id === node.id);
            node.states.forEach((state) => {
                select.append(new Option(`${modelNode.title} · ${state.name}`, causalMappingValue(node.id, state.id)));
            });
        });
        select.value = entry.createNew ? causalMappingCreateValue : causalMappingValue(entry.nodeId, entry.stateId);
        select.addEventListener('change', () => {
            const choice = parseCausalMappingValue(select.value);
            if (choice?.createNew) {
                causalInferenceState.mapping[index] =
                    { columnName: entry.columnName, nodeId: null, stateId: null, createNew: true, suggestedSymbol: suggestSymbol(entry.columnName) };
            } else if (choice) {
                causalInferenceState.mapping[index] = { columnName: entry.columnName, nodeId: choice.nodeId, stateId: choice.stateId, createNew: false };
            }
        });
        row.append(select);
        container.append(row);
    });
}

// Nothing is accepted unless at least one candidate edge OR self term is checked -- either
// render function can leave the other's items unaffected, so this always looks at both rather
// than each function only reasoning about its own list.
function updateCommitCausalInferenceEnabled() {
    const hasAcceptedCandidate = causalInferenceState.candidates.some((item) => item.accepted);
    const hasAcceptedSelfTerm = (causalInferenceState.selfTerms ?? []).some((item) => item.accepted);
    const hasAcceptedInput = (causalInferenceState.inputs ?? []).some((item) => item.accepted);
    $('#commitCausalInference').disabled = !hasAcceptedCandidate && !hasAcceptedSelfTerm && !hasAcceptedInput;
}

// Every mapped column can be replayed instead of modeled -- not just ones causal inference found
// no predictors for. Deliberately not filtered to "root" columns only: a user may want to hold
// *any* column to its exact recorded trajectory regardless of what was fitted for it (isolating
// one part of the system, distrusting a particular fit, or a genuine root the tool didn't manage
// to leave fully unexplained -- see below). See docs/proposals/causalInferenceInputReplay.md.
//
// The 8-node validation system is why this isn't restricted to structurally rootless columns:
// all 3 genuinely independent root columns still get a self term (an accurately recovered AR(1)
// decay rate) even though nothing predicts them, because self-persistence is a real, separately
// fittable property -- and a deterministic self-decay term only ever settles toward equilibrium,
// never reproducing the noise-driven fluctuation the real column actually has. Restricting
// eligibility to "no self term either" would have missed exactly the columns this feature exists
// for; not filtering at all is simpler and correct for every case, not just that one.

// True once a column has an accepted input: committing both an input and a self term/edge for
// the same column would double-count, since Konjugate sums every source term/edge targeting the
// same state additively. Checking "input" for a column is meant to *replace* whatever else was
// targeting it, not add to it -- drives the two-way UI mutual exclusion in
// renderCausalInferenceInputs/renderCausalInferenceCandidates/renderCausalInferenceSelfTerms
// below, and commitCausalInference() also excludes any edge/self term whose column has an
// accepted input as a defensive second check independent of UI state.
function causalInferenceInputAcceptedFor(columnName) {
    return (causalInferenceState.inputs ?? []).some((entry) => entry.columnName === columnName && entry.accepted);
}

function renderCausalInferenceInputs() {
    const container = $('#causalInferenceInputRows');
    container.replaceChildren();
    const inputs = causalInferenceState.inputs ?? [];
    $('#causalInferenceInputSection').hidden = inputs.length === 0;
    inputs.forEach((entry, index) => {
        const row = document.createElement('label');
        row.className = 'causalInferenceCandidateRow';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = entry.accepted;
        checkbox.addEventListener('change', () => {
            causalInferenceState.inputs[index].accepted = checkbox.checked;
            // Mutual exclusion: accepting a replay for this column supersedes whatever else
            // targets it -- uncheck its self term and every accepted incoming edge rather than
            // leave them alongside it (see causalInferenceInputAcceptedFor's comment for why
            // that would double-count).
            if (checkbox.checked) {
                const selfTerm = (causalInferenceState.selfTerms ?? []).find((term) => term.targetColumn === entry.columnName);
                if (selfTerm) selfTerm.accepted = false;
                for (const candidate of causalInferenceState.candidates ?? []) {
                    if (candidate.targetColumn === entry.columnName) candidate.accepted = false;
                }
            }
            updateCommitCausalInferenceEnabled();
            renderCausalInferenceSelfTerms();
            renderCausalInferenceCandidates();
        });
        const main = document.createElement('span');
        main.className = 'causalInferenceCandidateMain';
        main.textContent = entry.columnName;
        const supersededEdgeCount = (causalInferenceState.candidates ?? [])
            .filter((candidate) => candidate.targetColumn === entry.columnName && candidate.accepted).length;
        const supersedesSelfTerm = (causalInferenceState.selfTerms ?? []).some((term) => term.targetColumn === entry.columnName);
        const supersedes = [
            supersededEdgeCount ? `${supersededEdgeCount} edge${supersededEdgeCount === 1 ? '' : 's'}` : null,
            supersedesSelfTerm ? 'its self term' : null
        ].filter(Boolean).join(' and ');
        if (supersedes) {
            const meta = document.createElement('span');
            meta.className = 'causalInferenceCandidateMeta';
            meta.textContent = `replaces ${supersedes}`;
            main.append(meta);
        }
        row.append(checkbox, main);
        container.append(row);
    });
    updateCommitCausalInferenceEnabled();
}

function renderCausalInferenceCandidates() {
    const container = $('#causalInferenceCandidateRows');
    container.replaceChildren();
    if (!causalInferenceState.candidates.length) {
        const empty = document.createElement('p');
        empty.className = 'builderHint';
        empty.textContent = 'No candidate relationships were found.';
        container.append(empty);
        updateCommitCausalInferenceEnabled();
        return;
    }
    causalInferenceState.candidates.forEach((candidate, index) => {
        const row = document.createElement('label');
        row.className = 'causalInferenceCandidateRow';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        // Mutual exclusion with an accepted input for the same target column -- see
        // causalInferenceInputAcceptedFor's comment.
        const supersededByInput = causalInferenceInputAcceptedFor(candidate.targetColumn);
        checkbox.checked = candidate.accepted && !supersededByInput;
        checkbox.disabled = supersededByInput;
        checkbox.addEventListener('change', () => {
            causalInferenceState.candidates[index].accepted = checkbox.checked;
            if (checkbox.checked) {
                const input = (causalInferenceState.inputs ?? []).find((entry) => entry.columnName === candidate.targetColumn);
                if (input) input.accepted = false;
            }
            updateCommitCausalInferenceEnabled();
            renderCausalInferenceInputs();
        });
        const main = document.createElement('span');
        main.className = 'causalInferenceCandidateMain';
        main.textContent = `${candidate.sourceColumn} → ${candidate.targetColumn}`;
        const meta = document.createElement('span');
        meta.className = 'causalInferenceCandidateMeta';
        meta.textContent = supersededByInput ? 'replaced by input replay' : ((candidate.provenance === 'correlationOnly'
            ? `score ${candidate.score.toFixed(2)}`
            : `lag ${candidate.lag} · score ${candidate.score.toFixed(2)}`)
            + (candidate.interaction ? ' · includes interaction term' : ''));
        main.append(meta);
        const tag = document.createElement('span');
        tag.className = `causalInferenceCandidateTag ${candidate.provenance}`;
        tag.textContent = candidate.provenance === 'correlationOnly' ? 'Correlation-only' : 'Lagged';
        row.append(checkbox, main, tag);
        container.append(row);
    });
    updateCommitCausalInferenceEnabled();
}

function renderCausalInferenceSelfTerms() {
    const container = $('#causalInferenceSelfTermRows');
    container.replaceChildren();
    const selfTerms = causalInferenceState.selfTerms ?? [];
    $('#causalInferenceSelfTermSection').hidden = selfTerms.length === 0;
    selfTerms.forEach((term, index) => {
        const row = document.createElement('label');
        row.className = 'causalInferenceCandidateRow';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        // Mutual exclusion with an accepted input for the same column -- see
        // causalInferenceInputAcceptedFor's comment. Disabled (not just unchecked) so it's
        // visually clear this isn't independently choosable while the input replay is active.
        const supersededByInput = causalInferenceInputAcceptedFor(term.targetColumn);
        checkbox.checked = term.accepted && !supersededByInput;
        checkbox.disabled = supersededByInput;
        checkbox.addEventListener('change', () => {
            causalInferenceState.selfTerms[index].accepted = checkbox.checked;
            if (checkbox.checked) {
                const input = (causalInferenceState.inputs ?? []).find((entry) => entry.columnName === term.targetColumn);
                if (input) input.accepted = false;
            }
            updateCommitCausalInferenceEnabled();
            renderCausalInferenceInputs();
        });
        const main = document.createElement('span');
        main.className = 'causalInferenceCandidateMain';
        main.textContent = `${term.targetColumn} (self)`;
        const meta = document.createElement('span');
        meta.className = 'causalInferenceCandidateMeta';
        meta.textContent = supersededByInput ? 'replaced by input replay' : `rate ${formatFittedNumber(term.rate)}`;
        main.append(meta);
        const tag = document.createElement('span');
        tag.className = 'causalInferenceCandidateTag continuousLagged';
        tag.textContent = 'Self';
        row.append(checkbox, main, tag);
        container.append(row);
    });
    updateCommitCausalInferenceEnabled();
}

function upperFirst(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
}

function formatFittedNumber(value) {
    if (value === 0) return '0';
    return String(Number(value.toPrecision(6)));
}

// symbolLatex is null for a bare constant term (the intercept).
function signedTermLatex(value, symbolLatex) {
    const magnitude = formatFittedNumber(Math.abs(value));
    const term = symbolLatex ? `${magnitude} \\cdot ${symbolLatex}` : magnitude;
    return value < 0 ? `- ${term}` : `+ ${term}`;
}

// Generates LaTeX text, not a hand-built mathJson tree -- validateEquationLatex()/ComputeEngine
// already parses programmatically-interpolated numeric literals (decimals, negatives,
// scientific notation) with no special-casing, and every symbol reference here is one of
// reconcileEquationBindings()'s own auto-generated role-prefixed names (e.g. "sourceTemperature"),
// which are always multi-letter by construction and so never trip the \mathrm{} single-letter
// "_upright" parsing quirk documented in docs/proposals/causalInference.md. candidate.terms is one
// entry per fitted polynomial degree (always at least a degree-1 entry); degree 1 renders as the
// bare source symbol, degree >= 2 as the symbol raised to that power -- Power is already a
// supported mathJson primitive, so no equation-engine changes are needed for this.
//
// candidate.interaction (present only when the engine's includeInteractionTerms recovered a
// genuinely non-separable coupling -- see docs/proposals/causalInferenceInteractionTerms.md) adds
// one further term referencing *both* endpoints' own symbols, the same pattern the shipped
// rodX/rodY/rodZ component-library templates already use for a hand-authored relative term
// (e.g. "targetX - sourceX"). reconcileEquationBindings() already auto-binds every one of the
// target node's own states under a "target"-prefixed symbol for every edge, whether or not the
// hand-authored LaTeX happens to reference one -- so targetStateSymbol needs no new binding work,
// only a caller that knows to pass it in.
function latexForFittedEdge(candidate, sourceStateSymbol, targetStateSymbol) {
    const sourceSymbol = `\\mathrm{source${upperFirst(sourceStateSymbol)}}`;
    const termsLatex = candidate.terms
        .slice()
        .sort((a, b) => a.degree - b.degree)
        .map((term) => signedTermLatex(term.coefficient, term.degree === 1 ? sourceSymbol : `${sourceSymbol}^{${term.degree}}`))
        .join(' ');
    const interceptTerm = signedTermLatex(candidate.intercept, null);
    let combined = `${termsLatex} ${interceptTerm}`;
    if (candidate.interaction) {
        const targetSymbol = `\\mathrm{target${upperFirst(targetStateSymbol)}}`;
        combined += ` ${signedTermLatex(candidate.interaction.coefficient, `${sourceSymbol} \\cdot ${targetSymbol}`)}`;
    }
    return combined.replace(/^\s*\+ /, '');
}

// A self-term's rate applies to the node's own state directly -- an addSourceTerm's bindings
// expose every one of that node's states by its raw symbol (unlike an edge's source/target-
// prefixed synthesized symbols), and there's no intercept (see SelfTerm's doc comment in
// causalInference.hpp for why: extending self-terms with their own intercept share would mean
// propagating or fixing a pre-existing gap in how the discrete path already splits intercepts,
// out of scope here). Needs the same \mathrm{} wrapping latexForFittedEdge uses for a multi-letter
// symbol -- a bare multi-letter LaTeX token like "componentTemperature" parses as implicit
// multiplication of single-letter variables (c*o*m*p*o*n*e*n*t...) unless wrapped -- but NOT for a
// single-letter one: ComputeEngine's \mathrm{} handling parses \mathrm{k} to the symbol
// "k_upright", not "k" (see latexForBinding in equationModel.mjs for the same reasoning), while a
// bare single letter needs no wrapping and parses straight to itself.
function latexForSelfTerm(selfTerm, targetStateSymbol) {
    const symbol = targetStateSymbol.length === 1 ? targetStateSymbol : `\\mathrm{${targetStateSymbol}}`;
    return signedTermLatex(selfTerm.rate, symbol).replace(/^\+ /, '');
}

async function commitCausalInference() {
    if (!causalInferenceState?.candidates || activeResult) return;
    const acceptedInputs = (causalInferenceState.inputs ?? []).filter((entry) => entry.accepted);
    const acceptedInputColumns = new Set(acceptedInputs.map((entry) => entry.columnName));
    // Defensive second check, independent of the UI's own mutual exclusion above: never commit an
    // edge or a self term alongside an input-replay provider for the same target column -- see
    // causalInferenceInputAcceptedFor's comment for why that would double-count.
    const acceptedCandidates = causalInferenceState.candidates
        .filter((candidate) => candidate.accepted && !acceptedInputColumns.has(candidate.targetColumn));
    const acceptedSelfTerms = (causalInferenceState.selfTerms ?? [])
        .filter((term) => term.accepted && !acceptedInputColumns.has(term.targetColumn));
    if (!acceptedCandidates.length && !acceptedSelfTerms.length && !acceptedInputs.length) return;
    const status = $('#causalInferenceStatus');

    // Parsed once up front: every newly created state's initialValue is seeded from this column's
    // own first recorded row (see docs/proposals/causalInferenceInputReplay.md's bug writeup --
    // hardcoding 0 here regardless of the CSV meant a committed, freshly-created node never
    // actually started where its own data said it should), and an accepted input's replay
    // provider embeds this same column's full recorded series below.
    const parsedCsv = parseCsv(causalInferenceState.csvContent);
    const columnSeries = (columnName) => {
        const columnIndex = parsedCsv.columnNames.indexOf(columnName);
        return parsedCsv.rows.map((row) => ({ time: row.time, value: row.values[columnIndex] }));
    };

    // New nodes land on a circle -- every edge between two imported nodes is then a chord inside
    // it, so nothing crosses through the middle of an unrelated node the way the generic 4-column
    // grid default (assistantOperations.mjs's defaultPosition) can. Existing nodes the CSV matched
    // keep whatever position they already have; only genuinely new nodes are placed, and the
    // circle is centered on those existing nodes (if any) so the new ones appear near what they
    // actually connect to rather than at an unrelated part of the model.
    const newEntryCount = causalInferenceState.mapping.filter((entry) => entry.createNew).length;
    const existingPositions = causalInferenceState.mapping
        .filter((entry) => !entry.createNew)
        .map((entry) => model.nodes.find((node) => node.id === entry.nodeId)?.position)
        .filter((position) => position?.length === 3);
    const circleCenter = existingPositions.length
        ? existingPositions.reduce((sum, position) => [0, 1, 2].map((axis) => sum[axis] + position[axis] / existingPositions.length), [0, 0, 0])
        : [0, 0, 0];
    // Radius derived from the chord-length formula (chord = 2*radius*sin(pi/n)) so adjacent new
    // nodes stay a constant ~3.6 units apart -- the same spacing defaultPosition's grid columns
    // use -- regardless of how many columns this CSV creates.
    const nodeSpacing = 3.6;
    const circleRadius = newEntryCount > 1 ? nodeSpacing / (2 * Math.sin(Math.PI / newEntryCount)) : 0;
    let newNodeIndex = 0;
    const nextCirclePosition = () => {
        const angle = (2 * Math.PI * newNodeIndex) / newEntryCount;
        newNodeIndex += 1;
        return [circleCenter[0] + circleRadius * Math.cos(angle), circleCenter[1] + circleRadius * Math.sin(angle), circleCenter[2]];
    };

    const operations = [];
    const resolvedColumns = new Map();
    causalInferenceState.mapping.forEach((entry, mappingIndex) => {
        if (entry.createNew) {
            const symbol = entry.suggestedSymbol ?? suggestSymbol(entry.columnName);
            const nodeRef = `causalInferenceNode${mappingIndex}`;
            const stateRef = `${nodeRef}State`;
            operations.push({ kind: 'addNode', ref: nodeRef, name: entry.columnName, position: nextCirclePosition(), shape: 'sphere' });
            operations.push({
                kind: 'addState', nodeRef, ref: stateRef, name: symbol, symbol,
                initialValue: columnSeries(entry.columnName)[0].value, unit: ''
            });
            resolvedColumns.set(entry.columnName, { nodeRef, stateRef, symbol });
        } else {
            const node = model.nodes.find((candidate) => candidate.id === entry.nodeId);
            const state = node.states.find((candidate) => candidate.id === entry.stateId);
            resolvedColumns.set(entry.columnName, { nodeId: entry.nodeId, stateId: entry.stateId, symbol: state.symbol });
        }
    });
    acceptedCandidates.forEach((candidate, index) => {
        const source = resolvedColumns.get(candidate.sourceColumn);
        const target = resolvedColumns.get(candidate.targetColumn);
        const edgeRef = `causalInferenceEdge${index}`;
        operations.push({
            kind: 'addEdge', ref: edgeRef, name: `${candidate.sourceColumn} → ${candidate.targetColumn}`,
            sourceNodeRef: source.nodeRef ?? source.nodeId, targetNodeRef: target.nodeRef ?? target.nodeId,
            directionality: 'directed'
        });
        operations.push({
            kind: 'setEdgeEquation', edgeRef, outputStateRef: target.stateRef ?? target.stateId,
            latex: latexForFittedEdge(candidate, source.symbol, target.symbol)
        });
    });
    acceptedSelfTerms.forEach((term, index) => {
        const target = resolvedColumns.get(term.targetColumn);
        operations.push({
            kind: 'addSourceTerm', ref: `causalInferenceSelfTerm${index}`,
            nodeRef: target.nodeRef ?? target.nodeId, outputStateRef: target.stateRef ?? target.stateId,
            latex: latexForSelfTerm(term, target.symbol)
        });
    });
    // No bindings needed -- the generated provider only reads context.simulationTime, the same
    // no-bindings, time-driven pattern already used for a hand-authored kinematic driver source
    // term. setsValue: true marks this as a genuine algebraic state (docs/projectSchema.md) --
    // the engine writes the provider's value directly into the state every substep rather than
    // integrating it as a derivative, which is why this is exact at any substep count with no
    // dependency on the state's starting value being exactly right. See
    // docs/proposals/causalInferenceInputReplay.md for the full design history.
    acceptedInputs.forEach((input, index) => {
        const target = resolvedColumns.get(input.columnName);
        operations.push({
            kind: 'addSourceTerm', ref: `causalInferenceInput${index}`,
            nodeRef: target.nodeRef ?? target.nodeId, outputStateRef: target.stateRef ?? target.stateId,
            implementation: { kind: 'cpp', source: replayProviderSource(input.columnName, columnSeries(input.columnName), input.columnName) },
            setsValue: true
        });
    });

    const baseDocument = serializeProjectDocument();
    let prepared;
    try {
        prepared = buildAssistantProposal(baseDocument, { proposalVersion: 1, operations });
    } catch (error) {
        status.className = 'equationDiagnostics';
        status.textContent = error.message;
        return;
    }
    const validation = await window.engine.validate(JSON.stringify(prepared.document));
    if (validation.cancelled) return;
    if (!validation.available || !validation.report.valid) {
        status.className = 'equationDiagnostics';
        status.textContent = validation.available
            ? (validation.report.issues.filter((issue) => issue.severity === 'error').map((issue) => issue.message).join(' ')
                || 'The native validator rejected this import.')
            : 'The native validation engine is unavailable.';
        return;
    }

    const before = baseDocument;
    const after = prepared.document;
    replaceModelContents(after);
    recordHistory({ undo: () => replaceModelContents(before), redo: () => replaceModelContents(after) });
    resetCausalInference();
    $('#causalInference').classList.add('hidden');
}

$('#causalInferenceButton').addEventListener('click', openCausalInference);

async function loadCausalInferenceCsv(content) {
    const status = $('#causalInferenceStatus');
    try {
        const parsed = parseCsv(content);
        causalInferenceState = {
            csvContent: content,
            mapping: mapColumnsToNodes(parsed.columnNames, existingNodesForMapping()),
            candidates: null
        };
        status.className = 'equationDiagnostics valid';
        status.textContent = `Parsed ${parsed.columnNames.length} column${parsed.columnNames.length === 1 ? '' : 's'}, ${parsed.rows.length} rows.`;
        $('#causalInferenceMappingSection').hidden = false;
        $('#causalInferenceCandidatesSection').hidden = true;
        $('#causalInferenceCandidateRows').replaceChildren();
        $('#commitCausalInference').hidden = true;
        $('#commitCausalInference').disabled = true;
        renderCausalInferenceMapping();
        $('#runCausalInference').hidden = false;
        $('#runCausalInference').disabled = false;
    } catch (error) {
        causalInferenceState = null;
        status.className = 'equationDiagnostics';
        status.textContent = error.message;
        $('#causalInferenceMappingSection').hidden = true;
        $('#runCausalInference').hidden = true;
        $('#runCausalInference').disabled = true;
    }
}

$('#causalInferenceFile').addEventListener('change', async () => {
    const file = $('#causalInferenceFile').files[0];
    if (!file) return;
    await loadCausalInferenceCsv(await file.text());
});

// A real OS file-picker dialog behind <input type="file"> can't be driven by this app's
// interaction-test harness (a raw Electron BrowserWindow driven via webContents.executeJavaScript
// -- no Playwright setInputFiles/CDP bridge here, and .files can't be set from page-context JS
// for security reasons). This exposes the exact same CSV-loading path the real file input's
// change handler calls above, so a test can exercise parsing, column mapping, inference and
// commit end to end without a real file-picker -- the same reasoning as window.__debugTransform
// above for the 3D transform gizmo.
window.__debugCausalInference = {
    loadCsv: (content) => loadCausalInferenceCsv(content),
    // A candidate's fitted polynomial terms have no dedicated review-list UI to assert against
    // (renderCausalInferenceCandidates only shows source/target/lag/score/provenance) and the
    // resulting edge's equation is otherwise only readable by clicking its canvas line open --
    // fragile this deep into the interaction suite, where accumulated camera/geometry state from
    // 60+ prior tests can leave a relationship's projected midpoint raycasting to the wrong
    // object. Exposing the raw candidate data lets a test verify a fitted term (e.g. a degree >=
    // 2 one) reached the UI without depending on canvas hit-testing at all.
    candidates: () => structuredClone(causalInferenceState?.candidates ?? null),
    selfTerms: () => structuredClone(causalInferenceState?.selfTerms ?? null),
    inputs: () => structuredClone(causalInferenceState?.inputs ?? null),
    // Committed source terms have no node/edge-style count in .modelStatus to assert against, and
    // (like candidates() above) reading them back via a node's own editor is fragile this deep
    // into the interaction suite -- the serialized document is the only reliable place to check
    // one actually landed.
    document: () => serializeProjectDocument()
};

$('#causalInferenceDegreeMode').addEventListener('change', () => {
    $('#causalInferenceDegreeValueField').hidden = $('#causalInferenceDegreeMode').value === 'linear';
});

$('#causalInferenceInteractionHelpButton').addEventListener('click', () => window.projectFiles.openCausalInferenceInteractionHelp());

function causalInferenceDegreesFromUi() {
    const mode = $('#causalInferenceDegreeMode').value;
    if (mode === 'linear') return [1];
    const degree = Number($('#causalInferenceDegreeValue').value);
    return mode === 'auto' ? [1, degree] : [degree];
}

$('#runCausalInference').addEventListener('click', async () => {
    if (!causalInferenceState || activeResult) return;
    const button = $('#runCausalInference');
    const status = $('#causalInferenceStatus');
    button.disabled = true;
    status.className = 'equationDiagnostics';
    status.textContent = 'Running inference…';
    try {
        // No candidateLags override -- the engine's own default (and only accepted value) is
        // {1}: every fitted coefficient becomes a continuous-time rate (rate = coefficient/Δt),
        // and a predictor from 2+ CSV rows back has no single-Euler-step interpretation for that
        // transform, so it was never representable as a working equation regardless.
        const config = {
            candidateDegrees: causalInferenceDegreesFromUi(),
            includeInteractionTerms: $('#causalInferenceIncludeInteractionTerms').checked
        };
        const result = await window.engine.infer(causalInferenceState.csvContent, config);
        if (!result.available) throw new Error('The native inference engine is unavailable.');
        causalInferenceState.candidates = result.report.edges.map((edge) => ({ ...edge, accepted: true }));
        causalInferenceState.selfTerms = (result.report.selfTerms ?? []).map((term) => ({ ...term, accepted: true }));
        // One entry per mapped column, every column eligible -- see the comment above
        // causalInferenceInputAcceptedFor for why this isn't filtered to "root" columns only.
        causalInferenceState.inputs = causalInferenceState.mapping.map((entry) => ({ columnName: entry.columnName, accepted: false }));
        const selfTermCount = causalInferenceState.selfTerms.length;
        status.className = 'equationDiagnostics valid';
        status.textContent = `Found ${causalInferenceState.candidates.length} candidate relationship${causalInferenceState.candidates.length === 1 ? '' : 's'}`
            + (selfTermCount ? ` and ${selfTermCount} self term${selfTermCount === 1 ? '' : 's'}.` : '.');
        $('#causalInferenceCandidatesSection').hidden = false;
        $('#commitCausalInference').hidden = false;
        renderCausalInferenceCandidates();
        renderCausalInferenceSelfTerms();
        renderCausalInferenceInputs();
    } catch (error) {
        status.className = 'equationDiagnostics';
        status.textContent = error.message;
    } finally {
        button.disabled = false;
    }
});

$('#cancelCausalInference').addEventListener('click', () => {
    resetCausalInference();
    $('#causalInference').classList.add('hidden');
});

$('#commitCausalInference').addEventListener('click', () => { commitCausalInference(); });

// Digital-twin parameter tuning: fit a model's own tunable parameters (marked "Tunable" in the
// relationship editor, see normalizedParameterTuning/parameterTuningError above) against measured
// CSV data through the real simulator -- see engine/src/parameterFitting.cpp. Distinct from
// causal inference in one structural way: mapping here is existing-states-only (no "create new
// node" option), since fitting requires a model that already exists.
let parameterTuningState = null;

// Friendly labels only -- NOT the source of truth for which backends exist. That's
// window.engine.capabilities() (engine/src/main.cpp's "capabilities" command reports
// optimizerBackendIds there, the actual set this compiled binary supports), read once and cached
// below, so a build that adds or drops an algorithm doesn't silently drift out of sync with what
// this dropdown offers. An id with no entry here just falls back to showing its raw id.
const PARAMETER_TUNING_BACKEND_LABELS = {
    'nlopt-bobyqa': 'BOBYQA (derivative-free)',
    'nlopt-cobyla': 'COBYLA (derivative-free)',
    'nlopt-neldermead': 'Nelder-Mead (derivative-free)',
    'nlopt-praxis': 'PRAXIS (derivative-free)',
    'nlopt-sbplx': 'Subplex (derivative-free)',
    'nlopt-isres': 'ISRES (derivative-free, global)',
    'nlopt-slsqp': 'SLSQP (gradient-based)',
    'nlopt-mma': 'MMA (gradient-based)',
    'nlopt-ccsaq': 'CCSAQ (gradient-based)'
};

// Caches the in-flight/resolved promise itself (not just its value) so concurrent calls before
// the first capabilities() round-trip finishes all await the same request rather than each
// spawning their own engine process.
let parameterTuningBackendIdsPromise = null;
function loadParameterTuningBackendIds() {
    if (!parameterTuningBackendIdsPromise) {
        parameterTuningBackendIdsPromise = window.engine.capabilities()
            .then((response) => {
                const ids = response?.available ? response.capabilities?.optimizerBackendIds : null;
                return Array.isArray(ids) && ids.length ? ids : Object.keys(PARAMETER_TUNING_BACKEND_LABELS);
            })
            .catch(() => Object.keys(PARAMETER_TUNING_BACKEND_LABELS));
    }
    return parameterTuningBackendIdsPromise;
}

function findTunableParametersInModel() {
    const document = serializeProjectDocument();
    const found = [];
    // A shared parameter is one fitting variable however many parameters link to it.
    for (const shared of document.sharedParameters ?? []) {
        if (shared.tuning) {
            found.push({
                ownerName: 'Shared', parameterId: shared.id,
                name: shared.name, symbol: shared.symbol, value: shared.value, tuning: shared.tuning
            });
        }
    }
    for (const edge of document.edges) {
        for (const parameter of edge.parameters ?? []) {
            if (parameter.tuning) {
                found.push({
                    edgeId: edge.id, edgeName: edge.name, parameterId: parameter.id,
                    name: parameter.name, symbol: parameter.symbol, value: parameter.value, tuning: parameter.tuning
                });
            }
        }
    }
    for (const node of document.nodes) {
        for (const term of node.sourceTerms ?? []) {
            for (const parameter of term.parameters ?? []) {
                if (parameter.tuning) {
                    found.push({
                        nodeId: node.id, sourceTermId: term.id, ownerName: `${node.name} · source term`, parameterId: parameter.id,
                        name: parameter.name, symbol: parameter.symbol, value: parameter.value, tuning: parameter.tuning
                    });
                }
            }
        }
    }
    return found;
}

function resetParameterTuning() {
    parameterTuningState = null;
    $('#parameterTuningFile').value = '';
    $('#parameterTuningStatus').className = 'equationDiagnostics';
    $('#parameterTuningStatus').textContent = '';
    $('#parameterTuningMappingSection').hidden = true;
    $('#parameterTuningMappingRows').replaceChildren();
    $('#parameterTuningParametersSection').hidden = true;
    $('#parameterTuningParameterRows').replaceChildren();
    if (!$('#parameterTuningBackend').options.length) {
        loadParameterTuningBackendIds().then((ids) => {
            if ($('#parameterTuningBackend').options.length) return; // a concurrent call already populated it
            ids.forEach((id) => $('#parameterTuningBackend').append(new Option(PARAMETER_TUNING_BACKEND_LABELS[id] ?? id, id)));
        });
    }
    $('#parameterTuningProgressSection').hidden = true;
    $('#parameterTuningProgress').textContent = '';
    $('#parameterTuningReviewSection').hidden = true;
    $('#parameterTuningReviewRows').replaceChildren();
    $('#parameterTuningReviewStatus').textContent = '';
    $('#parameterTuningComparisonStatus').textContent = '';
    if (!$('#parameterTuningComparisonPlot').hidden) globalThis.Plotly?.purge($('#parameterTuningComparisonPlot'));
    $('#parameterTuningComparisonPlot').hidden = true;
    $('#runParameterTuning').hidden = true;
    $('#runParameterTuning').disabled = true;
    $('#commitParameterTuning').hidden = true;
    $('#commitParameterTuning').disabled = true;
}

function openParameterTuning() {
    if (activeResult) return;
    hideCards($('#parameterTuning'));
    resetParameterTuning();
    $('#parameterTuning').classList.remove('hidden');
}

$('#parameterTuningButton').addEventListener('click', openParameterTuning);

function renderParameterTuningMapping() {
    const container = $('#parameterTuningMappingRows');
    container.replaceChildren();
    parameterTuningState.mapping.forEach((entry) => {
        const modelNode = model.nodes.find((node) => node.id === entry.nodeId);
        const state = modelNode?.states.find((candidate) => candidate.id === entry.stateId);
        const row = document.createElement('div');
        row.className = 'causalInferenceMappingRow';
        const label = document.createElement('span');
        label.textContent = entry.columnName;
        const target = document.createElement('span');
        target.textContent = `→ ${modelNode?.title ?? '?'} · ${state?.label ?? '?'}`;
        row.append(label, target);
        container.append(row);
    });
}

function renderParameterTuningParameters() {
    const container = $('#parameterTuningParameterRows');
    container.replaceChildren();
    parameterTuningState.tunableParameters.forEach((parameter) => {
        const row = document.createElement('div');
        row.className = 'causalInferenceMappingRow';
        const label = document.createElement('span');
        label.textContent = `${parameter.edgeName ?? parameter.ownerName} · ${parameter.symbol}`;
        const range = document.createElement('span');
        range.textContent = `current ${parameter.value}, bounds [${parameter.tuning.minimum}, ${parameter.tuning.maximum}]`;
        row.append(label, range);
        container.append(row);
    });
}

async function loadParameterTuningCsv(content) {
    const status = $('#parameterTuningStatus');
    try {
        const parsed = parseCsv(content);
        const tunableParameters = findTunableParametersInModel();
        if (!tunableParameters.length) {
            status.className = 'equationDiagnostics';
            status.textContent = 'No parameters are marked "Tunable" yet -- mark at least one in a relationship or source-term editor, or in the Parameters table, first.';
            return;
        }
        // Existing-states-only: unlike causal inference, tuning never creates a node -- it fits a
        // model that already exists, so an unmatched CSV column is simply not usable here.
        const mapping = mapColumnsToNodes(parsed.columnNames, existingNodesForMapping()).filter((entry) => !entry.createNew);
        if (!mapping.length) {
            status.className = 'equationDiagnostics';
            status.textContent = 'None of the CSV columns matched an existing state by name.';
            return;
        }
        parameterTuningState = { csvContent: content, mapping, tunableParameters, report: null };
        status.className = 'equationDiagnostics valid';
        status.textContent = `Parsed ${parsed.columnNames.length} column${parsed.columnNames.length === 1 ? '' : 's'}, ${parsed.rows.length} rows. `
            + `Matched ${mapping.length} to existing states.`;
        renderParameterTuningMapping();
        renderParameterTuningParameters();
        $('#parameterTuningMappingSection').hidden = false;
        $('#parameterTuningParametersSection').hidden = false;
        $('#parameterTuningProgressSection').hidden = true;
        $('#parameterTuningReviewSection').hidden = true;
        $('#commitParameterTuning').hidden = true;
        $('#commitParameterTuning').disabled = true;
        $('#runParameterTuning').hidden = false;
        $('#runParameterTuning').disabled = false;
    } catch (error) {
        status.className = 'equationDiagnostics';
        status.textContent = error.message;
    }
}

$('#parameterTuningFile').addEventListener('change', async () => {
    const file = $('#parameterTuningFile').files[0];
    if (!file) return;
    await loadParameterTuningCsv(await file.text());
});

// Same reasoning as window.__debugCausalInference above: a real OS file-picker dialog can't be
// driven by this app's interaction-test harness.
window.__debugParameterTuning = {
    loadCsv: (content) => loadParameterTuningCsv(content),
    report: () => structuredClone(parameterTuningState?.report ?? null)
};

function renderParameterTuningReview() {
    const container = $('#parameterTuningReviewRows');
    container.replaceChildren();
    parameterTuningState.report.finalParameters.forEach((entry) => {
        const parameter = parameterTuningState.tunableParameters.find((candidate) => candidate.parameterId === entry.parameterId);
        if (!parameter) return;
        const row = document.createElement('label');
        row.className = 'causalInferenceCandidateRow';
        // entry.value is JSON `null` (not a number) when the fit diverged to a non-finite value
        // for this specific parameter -- defaulting that row's checkbox to unchecked+disabled
        // stops a divergent result from being applied to the model by default, rather than just
        // fixing how it displays.
        const isFinite_ = entry.value !== null;
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = isFinite_;
        checkbox.disabled = !isFinite_;
        checkbox.dataset.parameterId = String(entry.parameterId);
        const main = document.createElement('span');
        main.className = 'causalInferenceCandidateMain';
        main.textContent = `${parameter.edgeName ?? parameter.ownerName} · ${parameter.symbol}: ${parameter.value} → `
            + (isFinite_ ? Number(entry.value).toPrecision(6) : 'not finite (fit diverged, cannot apply)');
        row.append(checkbox, main);
        container.append(row);
    });
}

// Runs one more simulation with the just-fitted parameter values applied, on the same time grid
// as the measured CSV (matching the fitting loop's own "no interpolation, paired by row index"
// convention -- see engine/src/parameterFitting.cpp), and plots each mapped signal's measured and
// simulated series together with a residual sub-trace. A real extra simulation, not something
// FittingReport already carries: the C++ side only returns the final parameter values and loss,
// not the winning trial's full sample series.
async function renderParameterTuningComparison() {
    const plotElement = $('#parameterTuningComparisonPlot');
    const status = $('#parameterTuningComparisonStatus');
    plotElement.hidden = true;
    status.className = 'equationDiagnostics';
    status.textContent = '';
    if (!parameterTuningState?.report) return;
    try {
        // A non-finite fitted value (JSON `null` -- see parameterFittingReport.cpp) means the fit
        // diverged for at least one parameter; applying it and re-simulating would either poison
        // the whole comparison run or just fail less clearly than saying so up front.
        if (parameterTuningState.report.finalParameters.some((entry) => entry.value === null)) {
            throw new Error('At least one fitted value did not converge to a finite number.');
        }
        status.textContent = 'Running the fitted model to compare against measured data…';
        const parsed = parseCsv(parameterTuningState.csvContent);
        if (parsed.rows.length < 2) throw new Error('Not enough measured rows to compare.');
        const timeStep = parsed.rows[1].time - parsed.rows[0].time;
        const targetTime = timeStep * (parsed.rows.length - 1);

        // serializeProjectDocument()'s edges reference the live model's own parameter objects
        // directly (edge.parameters ?? []) rather than cloning them, so mutating them in place
        // here without cloning first would corrupt the in-editor model.
        const document_ = structuredClone(serializeProjectDocument());
        const fittedById = new Map(parameterTuningState.report.finalParameters.map((entry) => [entry.parameterId, entry.value]));
        document_.edges.forEach((edge) => {
            (edge.parameters ?? []).forEach((parameter) => {
                if (fittedById.has(parameter.id)) parameter.value = fittedById.get(parameter.id);
            });
        });
        document_.nodes.forEach((node) => (node.sourceTerms ?? []).forEach((term) => (term.parameters ?? []).forEach((parameter) => {
            if (fittedById.has(parameter.id)) parameter.value = fittedById.get(parameter.id);
        })));
        // A fitted shared parameter is one variable for everything linked to it, the provider of a node included.
        (document_.sharedParameters ?? []).forEach((parameter) => {
            if (fittedById.has(parameter.id)) parameter.value = fittedById.get(parameter.id);
        });

        const runResult = await window.engine.run(JSON.stringify(document_), { globalTimeStep: timeStep, outputInterval: timeStep, targetTime });
        if (!runResult.available) throw new Error('The native simulation engine is unavailable.');

        const simulatedByState = resultSeriesForStateIds(runResult.result, parameterTuningState.mapping.map((entry) => entry.stateId));
        const times = parsed.rows.map((row) => row.time);
        const entries = parameterTuningState.mapping.map((entry) => {
            const node = model.nodes.find((candidate) => candidate.id === entry.nodeId);
            const state = node?.states.find((candidate) => candidate.id === entry.stateId);
            const columnIndex = parsed.columnNames.indexOf(entry.columnName);
            const simulatedSamples = simulatedByState.get(entry.stateId) ?? [];
            return {
                name: state?.label ?? entry.columnName,
                unit: state?.unit ?? '',
                times,
                measured: parsed.rows.map((row) => row.values[columnIndex]),
                simulated: times.map((_, index) => simulatedSamples[index]?.value ?? NaN)
            };
        }).filter((entry) => entry.simulated.every(Number.isFinite));

        if (!entries.length) throw new Error('Could not align the simulated result with the measured data.');
        // Unhidden *before* rendering, not after: Plotly.newPlot() measures the container's actual
        // clientWidth/clientHeight at render time to size itself, even with responsive: true. A
        // still-hidden ([hidden] { display: none; }) element measures 0x0, so Plotly silently
        // falls back to an internal default width (~700px) instead of the real ~430px panel width
        // -- nothing later tells it to re-measure once revealed, so the oversized plot just
        // overflows the panel horizontally forever. Confirmed via a real screenshot: the whole
        // #parameterTuning panel had a 283px horizontal overflow traced directly to Plotly's own
        // SVG rendering at 675px wide inside a 430px-wide container.
        plotElement.hidden = false;
        await renderMeasuredVsSimulatedComparison(plotElement, entries);
        status.textContent = '';
    } catch (error) {
        status.className = 'equationDiagnostics';
        status.textContent = `Measured-vs-simulated comparison unavailable: ${error.message}`;
    }
}

$('#runParameterTuning').addEventListener('click', async () => {
    if (!parameterTuningState || activeResult) return;
    const button = $('#runParameterTuning');
    const progress = $('#parameterTuningProgress');
    button.disabled = true;
    $('#parameterTuningProgressSection').hidden = false;
    $('#parameterTuningReviewSection').hidden = true;
    $('#commitParameterTuning').hidden = true;
    $('#commitParameterTuning').disabled = true;
    progress.textContent = 'Running…';
    try {
        const content = JSON.stringify(serializeProjectDocument());
        const config = { backend: $('#parameterTuningBackend').value };
        const result = await window.engine.fit(content, parameterTuningState.csvContent, config);
        if (!result.available) throw new Error('The native fitting engine is unavailable.');
        parameterTuningState.report = result.report;
        // finalLoss is JSON `null` (not a number) when the fit diverged to a non-finite value --
        // Number(null) silently coerces to 0, which would misleadingly read as a perfect fit.
        const finalLossText = result.report.finalLoss === null ? 'not finite' : Number(result.report.finalLoss).toPrecision(4);
        progress.textContent = `${result.report.converged ? 'Converged' : 'Did not fully converge'} (${result.report.terminationReason}), `
            + `final loss ${finalLossText}.`;
        renderParameterTuningReview();
        $('#parameterTuningReviewSection').hidden = false;
        $('#commitParameterTuning').hidden = false;
        $('#commitParameterTuning').disabled = false;
        await renderParameterTuningComparison();
    } catch (error) {
        progress.textContent = error.message;
    } finally {
        button.disabled = false;
    }
});

async function commitParameterTuning() {
    if (!parameterTuningState?.report) return;
    const status = $('#parameterTuningReviewStatus');
    const acceptedRows = $$('#parameterTuningReviewRows input[type=checkbox]:checked');
    if (!acceptedRows.length) {
        status.textContent = 'Select at least one fitted value to apply.';
        return;
    }
    const baseDocument = serializeProjectDocument();
    const operations = acceptedRows.map((checkbox) => {
        const parameterId = Number(checkbox.dataset.parameterId);
        const fitted = parameterTuningState.report.finalParameters.find((entry) => entry.parameterId === parameterId);
        return { kind: 'updateParameter', parameterRef: parameterId, value: fitted.value };
    }).filter((operation) => {
        const current = parameterTuningState.tunableParameters.find((parameter) => parameter.parameterId === operation.parameterRef);
        return current && current.value !== operation.value;
    });
    if (!operations.length) {
        status.textContent = 'The selected fitted values already match the model.';
        return;
    }
    let prepared;
    try {
        prepared = buildAssistantProposal(baseDocument, { proposalVersion: 1, operations });
    } catch (error) {
        status.textContent = error.message;
        return;
    }
    const validation = await window.engine.validate(JSON.stringify(prepared.document));
    if (validation.cancelled) return;
    if (!validation.available || !validation.report.valid) {
        status.textContent = validation.available
            ? (validation.report.issues.filter((issue) => issue.severity === 'error').map((issue) => issue.message).join(' ')
                || 'The native validator rejected these fitted values.')
            : 'The native validation engine is unavailable.';
        return;
    }
    const before = baseDocument;
    const after = prepared.document;
    try {
        replaceModelContents(after);
    } catch (error) {
        status.textContent = `Could not apply the fitted parameters: ${error.message}`;
        return;
    }
    recordHistory({ undo: () => replaceModelContents(before), redo: () => replaceModelContents(after) });
    resetParameterTuning();
    $('#parameterTuning').classList.add('hidden');
    $('#statusText').textContent = 'Fitted parameters applied. Use Save As to keep this as a new project -- the original is untouched until you do.';
}

$('#cancelParameterTuning').addEventListener('click', () => {
    resetParameterTuning();
    $('#parameterTuning').classList.add('hidden');
});

$('#commitParameterTuning').addEventListener('click', () => { commitParameterTuning(); });

function assistantModelSummary() {
    const document = serializeProjectDocument();
    return {
        format: document.format,
        version: document.version,
        units: document.metadata.units,
        nodes: document.nodes.map((node) => ({
            id: node.id, name: node.name, type: node.type, enabled: node.enabled !== false,
            states: node.states.map((state) => ({ id: state.id, name: state.name, symbol: state.symbol, initialValue: state.initialValue, unit: state.unit }))
        })),
        edges: document.edges.map((edge) => ({
            id: edge.id, name: edge.name, sourceNodeId: edge.source.nodeId,
            targetNodeId: edge.target.nodeId, directionality: edge.directionality, enabled: edge.enabled !== false
        }))
    };
}

async function refreshAssistantConfigurations() {
    const select = $('#assistantConfiguration');
    try {
        const result = await window.aiProviders.listConfigurations();
        assistantConfigurationCatalog = result;
        const previous = activeAssistantConfigurationUuid || select.value;
        select.replaceChildren(...result.configurations.map((configuration) => {
            const locality = configuration.provider === 'localDemonstration' || configuration.provider === 'ollama' ? 'Local' : 'Online';
            return new Option(`${configuration.name} · ${locality}`, configuration.uuid);
        }));
        activeAssistantConfigurationUuid = result.configurations.some((item) => item.uuid === previous)
            ? previous : result.activeConfigurationUuid;
        select.value = activeAssistantConfigurationUuid;
        select.disabled = false;
    } catch (error) {
        select.replaceChildren(new Option('Configurations unavailable', ''));
        select.disabled = true;
        renderAssistantGenerationError(error.message);
    }
}

function activeConfigurationRecord() {
    return assistantConfigurationCatalog.configurations.find((configuration) => configuration.uuid === $('#assistantConfiguration').value);
}

function selectedProviderDescriptor() {
    return assistantConfigurationCatalog.providers.find((provider) => provider.id === $('#assistantConfigurationProvider').value);
}

function assistantConfigurationDraftSignature() {
    return JSON.stringify({ ...assistantConfigurationFormValue(), credential: $('#assistantConfigurationCredential').value });
}

function assistantConfigurationIsDirty() {
    return assistantConfigurationBaseline && assistantConfigurationDraftSignature() !== assistantConfigurationBaseline;
}

function selectedAssistantModel() {
    return $('#assistantConfigurationModel').value === '__custom__'
        ? $('#assistantCustomModel').value.trim() : $('#assistantConfigurationModel').value;
}

function setAssistantModelChoices(models, selectedModel = '') {
    const discovered = models.some((model) => model.id === selectedModel);
    const options = [new Option(models.length ? 'Select a model' : 'Discover available models', '')];
    options.push(...models.map((model) => new Option(model.name, model.id)));
    if (selectedModel && !discovered) options.push(new Option(selectedModel, selectedModel));
    options.push(new Option('Custom model ID…', '__custom__'));
    $('#assistantConfigurationModel').replaceChildren(...options);
    $('#assistantConfigurationModel').value = selectedModel || '';
    $('#assistantCustomModel').value = '';
    $('#assistantCustomModel').hidden = true;
}

function syncAssistantCustomModel() {
    const custom = $('#assistantConfigurationModel').value === '__custom__';
    $('#assistantCustomModel').hidden = !custom;
    if (custom) $('#assistantCustomModel').focus();
}

function setAssistantConfigurationStatus(message = '', tone = 'neutral') {
    const status = $('#assistantConfigurationStatus');
    status.textContent = message;
    status.className = `assistantConfigurationStatus ${tone}`;
}

function assistantConfigurationErrorMessage(error) {
    const message = error?.message || 'The model provider could not be reached.';
    if ($('#assistantConfigurationProvider').value === 'ollama' &&
        /connect|fetch|network|refused|abort|timed?\s*out/i.test(message)) {
        return 'Ollama is not reachable. Install Ollama if needed, start the Ollama service, then try again.';
    }
    return message;
}

function confirmAssistantConfigurationNavigation() {
    return !assistantConfigurationIsDirty() || window.confirm('Discard unsaved changes to this model configuration?');
}

function renderAssistantConfigurationList() {
    const query = $('#searchAssistantConfigurations').value.trim().toLowerCase();
    const selectedUuid = $('#assistantConfigurationUuid').value;
    const configurations = assistantConfigurationCatalog.configurations.filter((configuration) =>
        `${configuration.name} ${configuration.provider} ${configuration.model}`.toLowerCase().includes(query));
    $('#assistantConfigurationList').replaceChildren(...configurations.map((configuration) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.dataset.configurationUuid = configuration.uuid;
        button.classList.toggle('selected', configuration.uuid === selectedUuid);
        button.setAttribute('role', 'option');
        button.setAttribute('aria-selected', String(configuration.uuid === selectedUuid));
        const provider = assistantConfigurationCatalog.providers.find((item) => item.id === configuration.provider);
        const title = document.createElement('strong');
        title.textContent = configuration.name;
        const details = document.createElement('span');
        details.textContent = configuration.builtIn ? 'Built-in · Local' : `${provider?.name ?? configuration.provider} · ${configuration.model || 'No model selected'}`;
        button.append(title, details);
        if (configuration.uuid === activeAssistantConfigurationUuid) {
            const active = document.createElement('i');
            active.textContent = 'Active';
            button.append(active);
        }
        return button;
    }));
}

function syncAssistantProviderFields({ replaceEndpoint = false } = {}) {
    const provider = selectedProviderDescriptor();
    if (!provider) return;
    if (replaceEndpoint || !$('#assistantConfigurationEndpoint').value) $('#assistantConfigurationEndpoint').value = provider.defaultEndpoint;
    if (replaceEndpoint && !$('#assistantConfigurationUuid').value) {
        $('#assistantConfigurationTimeout').value = provider.defaultTimeoutSeconds ?? 60;
    }
    $('#assistantCredentialField').hidden = !provider.credentialRequired;
    const existing = assistantConfigurationCatalog.configurations.find((item) => item.uuid === $('#assistantConfigurationUuid').value);
    $('#assistantConfigurationCredential').required = provider.credentialRequired && !existing?.credentialConfigured;
}

function populateAssistantConfiguration(configuration = null) {
    assistantDiscoveryRevision += 1;
    const providers = assistantConfigurationCatalog.providers;
    const selectableProviders = providers.filter((provider) => provider.id !== 'localDemonstration');
    const initialProvider = configuration?.provider ?? selectableProviders.find((provider) => provider.id === 'ollama')?.id ?? selectableProviders[0]?.id ?? '';
    $('#assistantConfigurationUuid').value = configuration?.uuid ?? '';
    $('#assistantConfigurationName').value = configuration?.name ?? 'My local model';
    $('#assistantConfigurationProvider').value = initialProvider;
    $('#assistantConfigurationEndpoint').value = configuration?.endpoint ?? '';
    setAssistantModelChoices([], configuration?.model ?? '');
    const initialDescriptor = providers.find((provider) => provider.id === initialProvider);
    $('#assistantConfigurationTimeout').value = configuration?.timeoutSeconds ?? initialDescriptor?.defaultTimeoutSeconds ?? 60;
    $('#assistantConfigurationCredential').value = '';
    $('#assistantConfigurationDialogTitle').textContent = configuration?.name ?? 'New configuration';
    $('#assistantCredentialHint').textContent = configuration?.credentialConfigured ? 'Leave blank to preserve the stored key' : 'Stored only when this configuration is saved';
    $('#assistantConfigurationFields').disabled = Boolean(configuration?.builtIn);
    $('#deleteAssistantConfiguration').hidden = !configuration || configuration.builtIn;
    $('#testAssistantConfiguration').hidden = Boolean(configuration?.builtIn);
    $('#saveAssistantConfiguration').hidden = Boolean(configuration?.builtIn);
    setAssistantConfigurationStatus(
        assistantConfigurationCatalog.credentialStorage?.plainText
            ? 'Secure persistent credentials are unavailable with the current operating-system backend.' : '',
        assistantConfigurationCatalog.credentialStorage?.plainText ? 'error' : 'neutral'
    );
    syncAssistantProviderFields();
    assistantConfigurationBaseline = assistantConfigurationDraftSignature();
    renderAssistantConfigurationList();
    clearTimeout(assistantDiscoveryTimer);
    if (!configuration?.builtIn && initialProvider === 'ollama') {
        assistantDiscoveryTimer = setTimeout(discoverAssistantModels, 350);
    }
}

function openAssistantConfigurationDialog() {
    const providers = assistantConfigurationCatalog.providers;
    $('#assistantConfigurationProvider').replaceChildren(...providers.map((provider) => {
        const option = new Option(provider.name, provider.id);
        option.disabled = provider.id === 'localDemonstration';
        return option;
    }));
    $('#searchAssistantConfigurations').value = '';
    populateAssistantConfiguration(activeConfigurationRecord());
    $('#assistantConfigurationDialog').showModal();
}

function assistantConfigurationFormValue() {
    return {
        uuid: $('#assistantConfigurationUuid').value || undefined,
        name: $('#assistantConfigurationName').value,
        provider: $('#assistantConfigurationProvider').value,
        endpoint: $('#assistantConfigurationEndpoint').value,
        model: selectedAssistantModel(),
        timeoutSeconds: Number($('#assistantConfigurationTimeout').value)
    };
}

async function saveAssistantConfiguration() {
    const credential = $('#assistantConfigurationCredential').value || undefined;
    const saved = await window.aiProviders.saveConfiguration(assistantConfigurationFormValue(), credential);
    activeAssistantConfigurationUuid = saved.uuid;
    await window.aiProviders.setActiveConfiguration(saved.uuid);
    await refreshAssistantConfigurations();
    $('#assistantConfiguration').value = saved.uuid;
    $('#assistantConfigurationCredential').value = '';
    populateAssistantConfiguration(assistantConfigurationCatalog.configurations.find((configuration) => configuration.uuid === saved.uuid));
    setAssistantConfigurationStatus('Configuration saved and selected.');
}

async function discoverAssistantModels() {
    const revision = ++assistantDiscoveryRevision;
    setAssistantConfigurationStatus('Discovering models…');
    try {
        const models = await window.aiProviders.listDraftModels(
            assistantConfigurationFormValue(), $('#assistantConfigurationCredential').value || undefined
        );
        if (revision !== assistantDiscoveryRevision || !$('#assistantConfigurationDialog').open) return;
        const selectedModel = selectedAssistantModel();
        setAssistantModelChoices(models, selectedModel || models[0]?.id || '');
        setAssistantConfigurationStatus(models.length ? '' : 'Connected, but no compatible models were found.', models.length ? 'neutral' : 'warning');
    } catch (error) {
        if (revision !== assistantDiscoveryRevision || !$('#assistantConfigurationDialog').open) return;
        setAssistantConfigurationStatus(assistantConfigurationErrorMessage(error), 'error');
    }
}

function renderAssistantGenerationError(message) {
    pendingAssistantProposal = null;
    updateAssistantTurnOutcome(pendingAssistantTurnRecord, `Error: ${message}`);
    pendingAssistantTurnRecord = null;
    $('#assistantEmpty').hidden = true;
    $('#assistantClarification').hidden = true;
    $('#assistantProposal').hidden = false;
    $('#assistantProposalSummary').textContent = 'No proposal generated';
    $('#assistantProposalStatus').className = '';
    $('#assistantProposalStatus').textContent = 'The request needs attention';
    $('#assistantAssumptionsSection').hidden = true;
    $('#assistantChanges').replaceChildren();
    $('#assistantError').textContent = message;
    $('#assistantError').hidden = false;
    $('#applyAssistantProposal').disabled = true;
    updateAssistantCollapsedStatus('Request needs attention');
}

// What the panel shows while a request is under way: the registry's latest progress snapshot (stage,
// attempt, the model's reasoning and output so far) and a once-a-second elapsed-time tick. Everything
// is set as text, never HTML: it includes what the model wrote.
let assistantProgressRequestUuid = null;
let assistantProgressSnapshot = null;
let assistantProgressStartedAt = 0;
let assistantProgressTimer = null;

function setAssistantProgressText(preId, sectionId, text) {
    const pre = $(preId);
    $(sectionId).hidden = !text;
    if (pre.textContent === text) return;
    pre.textContent = text;
    pre.scrollTop = pre.scrollHeight;
}

function renderAssistantProgress() {
    const panel = $('#assistantProgress');
    panel.hidden = !assistantProgressRequestUuid;
    if (!assistantProgressRequestUuid) return;
    const attemptStartedAt = assistantProgressSnapshot?.attemptStartedAt ?? assistantProgressStartedAt;
    const { headline, notes } = describeAssistantProgress(
        assistantProgressSnapshot, (Date.now() - assistantProgressStartedAt) / 1000, (Date.now() - attemptStartedAt) / 1000);
    $('#assistantProgressHeadline').textContent = headline;
    $('#assistantProgressNote').hidden = notes.length === 0;
    $('#assistantProgressNote').textContent = notes.join(' ');
    const thinking = assistantProgressSnapshot?.thinking ?? '';
    const output = assistantProgressSnapshot?.output ?? '';
    setAssistantProgressText('#assistantProgressThinking', '#assistantProgressThinkingSection', thinking);
    setAssistantProgressText('#assistantProgressOutput', '#assistantProgressOutputSection', output);
    $('#assistantProgressQuiet').hidden = Boolean(thinking || output);
    updateAssistantCollapsedStatus(headline);
}

function startAssistantProgress(requestUuid) {
    clearInterval(assistantProgressTimer);
    assistantProgressRequestUuid = requestUuid;
    assistantProgressSnapshot = null;
    assistantProgressStartedAt = Date.now();
    assistantProgressTimer = setInterval(renderAssistantProgress, 1000);
    renderAssistantProgress();
}

function stopAssistantProgress() {
    clearInterval(assistantProgressTimer);
    assistantProgressTimer = null;
    assistantProgressRequestUuid = null;
    assistantProgressSnapshot = null;
    renderAssistantProgress();
}

window.aiProviders.onProgress((progress) => {
    if (progress.requestUuid !== assistantProgressRequestUuid) return;
    assistantProgressSnapshot = progress;
    renderAssistantProgress();
});

async function requestAssistantProposal() {
    if (activeResult) return { valid: false, error: 'Close simulation results before preparing model changes.' };
    assistantGenerationController?.abort();
    const controller = new AbortController();
    assistantGenerationController = controller;
    const requestUuid = crypto.randomUUID();
    controller.signal.addEventListener('abort', () => {
        window.aiProviders.cancelRequest(requestUuid).catch(() => {});
    }, { once: true });
    const request = $('#assistantPrompt').value.trim();
    const button = $('#generateAssistantProposal');
    button.disabled = true;
    button.textContent = 'Preparing…';
    updateAssistantCollapsedStatus('Preparing proposal…');
    startAssistantProgress(requestUuid);
    $('#assistantEmpty').hidden = false;
    $('#assistantProposal').hidden = true;
    $('#assistantClarification').hidden = true;
    try {
        const response = await window.aiProviders.generateProposal(
            requestUuid, $('#assistantConfiguration').value, request, assistantModelSummary(), assistantTurnHistory
        );
        if (controller.signal.aborted) return { valid: false, cancelled: true };
        // Clear the prompt only once a response has actually arrived, not before sending --
        // losing what was typed to a network hiccup or timeout would be worse than a stale
        // textarea. Still empties for a clarification exactly as it would for a proposal, so a
        // reply is always typed fresh rather than editing the question back down to an answer.
        $('#assistantPrompt').value = '';
        if (response.responseKind === 'clarification') {
            pendingAssistantTurnRecord = pushAssistantTurn(request, `Asked: ${response.question}`);
            renderAssistantClarification(response);
            return { valid: false, clarification: response };
        }
        pendingAssistantTurnRecord = pushAssistantTurn(request, `Proposed: ${response.summary?.trim() || 'model changes'}`);
        return await previewAssistantProposal(response);
    } catch (error) {
        if (controller.signal.aborted || error.name === 'AbortError') {
            if (assistantGenerationController === controller) updateAssistantCollapsedStatus('Request cancelled');
            return { valid: false, cancelled: true };
        }
        renderAssistantGenerationError(error.message);
        return { valid: false, error: error.message };
    } finally {
        if (assistantGenerationController === controller) {
            assistantGenerationController = null;
            stopAssistantProgress();
            button.disabled = false;
            button.textContent = pendingAssistantProposal ? 'Revise proposal'
                : !$('#assistantClarification').hidden ? 'Answer'
                    : 'Generate proposal';
        }
    }
}

$('#cancelAssistantRequest').addEventListener('click', () => assistantGenerationController?.abort());
$('#assistantButton').addEventListener('click', () => {
    if ($('#assistantPanel').hidden) showAssistantPanel();
    else hideAssistantPanel();
});
$('#closeAssistantPanel').addEventListener('click', hideAssistantPanel);
$('#collapseAssistantPanel').addEventListener('click', () => {
    setAssistantCollapsed(!$('#assistantPanel').classList.contains('collapsed'));
});
$('#discardAssistantProposal').addEventListener('click', () => {
    if (pendingAssistantProposal) {
        updateAssistantTurnOutcome(pendingAssistantTurnRecord, `Discarded: ${pendingAssistantProposal.proposal.summary?.trim() || 'a proposed change'}`);
    }
    discardAssistantProposal();
});
$('#applyAssistantProposal').addEventListener('click', commitAssistantProposal);
$('#assistantChanges').addEventListener('click', (event) => {
    const control = event.target.closest('[data-focus-entity]');
    if (control) inspectAssistantEntity(Number(control.dataset.focusEntity));
});
$('#dismissAssistantClarification').addEventListener('click', dismissAssistantClarification);
$('#assistantClarificationOptions').addEventListener('click', (event) => {
    const button = event.target.closest('[data-suggestion]');
    if (!button) return;
    $('#assistantPrompt').value = button.dataset.suggestion;
    $('#assistantPrompt').focus();
});
$('#newAssistantConversation').addEventListener('click', () => {
    const hasSomethingToLose = assistantTurnHistory.length > 0 || Boolean(pendingAssistantProposal) || !$('#assistantClarification').hidden;
    if (hasSomethingToLose && !window.confirm('Start a new conversation? This clears the assistant’s memory of this exchange and cannot be undone.')) return;
    assistantGenerationController?.abort();
    discardAssistantProposal();
    resetAssistantConversation();
});
$('#assistantPromptForm').addEventListener('submit', (event) => {
    event.preventDefault();
    requestAssistantProposal();
});
$('#assistantConfiguration').addEventListener('change', async () => {
    activeAssistantConfigurationUuid = $('#assistantConfiguration').value;
    assistantGenerationController?.abort();
    discardAssistantProposal();
    resetAssistantConversation();
    await window.aiProviders.setActiveConfiguration(activeAssistantConfigurationUuid).catch((error) => renderAssistantGenerationError(error.message));
});
$('#manageAssistantConfigurations').addEventListener('click', openAssistantConfigurationDialog);
$('#assistantConfigurationProvider').addEventListener('change', () => {
    syncAssistantProviderFields({ replaceEndpoint: true });
    setAssistantModelChoices([]);
    clearTimeout(assistantDiscoveryTimer);
    if ($('#assistantConfigurationProvider').value === 'ollama') {
        assistantDiscoveryTimer = setTimeout(discoverAssistantModels, 350);
    }
});
$('#assistantConfigurationModel').addEventListener('change', syncAssistantCustomModel);
$('#cancelAssistantConfiguration').addEventListener('click', () => {
    if (confirmAssistantConfigurationNavigation()) $('#assistantConfigurationDialog').close();
});
$('#assistantConfigurationDialog').addEventListener('cancel', (event) => {
    if (!confirmAssistantConfigurationNavigation()) event.preventDefault();
});
$('#newAssistantConfiguration').addEventListener('click', () => {
    if (!confirmAssistantConfigurationNavigation()) return;
    populateAssistantConfiguration();
});
$('#searchAssistantConfigurations').addEventListener('input', renderAssistantConfigurationList);
$('#assistantConfigurationList').addEventListener('click', (event) => {
    const control = event.target.closest('[data-configuration-uuid]');
    if (!control || !confirmAssistantConfigurationNavigation()) return;
    const configuration = assistantConfigurationCatalog.configurations.find((item) => item.uuid === control.dataset.configurationUuid);
    if (configuration) populateAssistantConfiguration(configuration);
});
$('#assistantConfigurationDialog').addEventListener('submit', async (event) => {
    event.preventDefault();
    setAssistantConfigurationStatus('Saving configuration…');
    try { await saveAssistantConfiguration(); } catch (error) { setAssistantConfigurationStatus(error.message, 'error'); }
});
$('#discoverAssistantModels').addEventListener('click', discoverAssistantModels);
$('#testAssistantConfiguration').addEventListener('click', async () => {
    setAssistantConfigurationStatus('Testing connection…');
    try {
        const result = await window.aiProviders.testDraftConnection(
            assistantConfigurationFormValue(), $('#assistantConfigurationCredential').value || undefined
        );
        setAssistantConfigurationStatus('Connection successful.');
    } catch (error) { setAssistantConfigurationStatus(assistantConfigurationErrorMessage(error), 'error'); }
});
$('#deleteAssistantConfiguration').addEventListener('click', async () => {
    const uuid = $('#assistantConfigurationUuid').value;
    if (!uuid || !window.confirm('Delete this model configuration and its stored credential?')) return;
    const index = assistantConfigurationCatalog.configurations.findIndex((configuration) => configuration.uuid === uuid);
    await window.aiProviders.removeConfiguration(uuid);
    activeAssistantConfigurationUuid = null;
    await refreshAssistantConfigurations();
    const next = assistantConfigurationCatalog.configurations[Math.min(index, assistantConfigurationCatalog.configurations.length - 1)];
    populateAssistantConfiguration(next ?? null);
    setAssistantConfigurationStatus('Configuration deleted.');
});
$('#assistantPrompt').addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        $('#assistantPromptForm').requestSubmit();
    }
});
installAssistantDragging();
window.addEventListener('resize', clampAssistantPanel);

window.konjugateAssistant = Object.freeze({
    getModelSummary: assistantModelSummary,
    requestProposal: requestAssistantProposal,
    previewProposal: previewAssistantProposal,
    applyProposal: commitAssistantProposal,
    discardProposal: discardAssistantProposal,
    dismissClarification: dismissAssistantClarification,
    getTurnHistory: () => structuredClone(assistantTurnHistory),
    resetConversation: resetAssistantConversation
});

function openNodeBuilder(clientX, clientY) {
    const builder = $('#nodeBuilder');
    hideCards(builder);
    $('#newNodeName').value = 'New node';
    $('#newNodeShape').value = 'box';
    $('#newNodeColor').value = '#34727a';
    $('#nodeGeometryFile').value = '';
    $('#geometryImportStatus').classList.remove('loading', 'error');
    $('#geometryImportStatus').textContent = 'No geometry selected';
    pendingImportedGeometry?.dispose();
    pendingImportedGeometry = null;
    pendingGeometryFileName = '';
    $('#stateVariableRows').replaceChildren();
    $('#sourceTermRows').replaceChildren();
    addStateVariableRow();
    $('#addNodeError').textContent = '';
    positionCard(builder, clientX, clientY);
    $('#newNodeName').select();
}

function openEdgeBuilder(clientX, clientY) {
    const builder = $('#edgeBuilder');
    hideCards(builder);
    pendingEdgeTemplate = null;
    $('#newEdgeName').value = 'New relationship';
    $('#newEdgeDirectionality').value = 'directed';
    $('#newEdgeColor').value = '#9c83c4';
    $('#edgeImplementationKind').value = 'equation';
    $('#edgeEquation').value = '';
    $('#edgeMathField').setValue('', { silenceNotifications: true });
    $('#edgeMathField').hidden = false;
    $('#edgeEquation').hidden = true;
    $('#edgeEquationHeading').hidden = false;
    $('#builderEquationDiagnostics').hidden = false;
    $('#edgeReferencePicker').hidden = false;
    $('#edgeProviderSection').hidden = true;
    $('#edgeProviderSource').value = '';
    $('#insertProviderTemplate').hidden = true;
    $('#providerOutputKey').value = '';
    $('#providerBindingRows').replaceChildren();
    $$('[data-builder-equation-mode]').forEach((button) => {
        button.classList.toggle('active', button.dataset.builderEquationMode === 'visual');
    });
    $('#edgeParameterRows').replaceChildren();
    finishEndpointPick();
    $('#edgeSource').replaceChildren();
    $('#edgeTarget').replaceChildren();
    refreshEndpointOptions();
    addEdgeParameterRow({ name: 'Coefficient', symbol: 'k', value: '1' });
    $('#addEdgeError').textContent = '';
    builder.style.removeProperty('left');
    builder.style.removeProperty('top');
    builder.classList.remove('hidden');
}

// Reuses the edge builder's own endpoint-pick flow: pre-fills the source with the node that was
// right-clicked, then immediately starts picking the target on the canvas, same as clicking the
// builder's own "pick target" control would.
function connectFromNode(node) {
    openEdgeBuilder();
    $('#edgeSource').value = String(node.userData.definition.id);
    refreshStateReferences();
    startEndpointPick('target');
}

let nodePointerDown = null;
let relationshipPointerDown = null;
const relationshipHoldDurationMs = 450;
// Distinguishes a genuine "press and hold in place" from a drag that happens to start on an
// edge (e.g. panning) -- cancels the pending hold if the pointer moves before it fires.
const relationshipHoldTravelLimit = 6;
// Staged by the contextmenu handler below and consumed by #edgeContextMenu's/#waypointContextMenu's
// own click handlers -- context-menu opening is itself deferred (see stageContextMenuAction), so
// this can't just be a local passed straight into an inline handler.
let pendingWaypoint = null;
let pendingWaypointRemoval = null;

// The 42 here must match curve.getPoints(42) in createRelationship/updateRelationships -- a
// Line raycast intersection's .index is a segment index into that same sampled geometry, so
// intersection.index / 42 approximates the hit's parameter along the curve. Each existing
// waypoint i sits at exactly t = (i+1)/(waypoints.length+1) on an open CatmullRomCurve3, so the
// insertion index is just how many existing waypoints come before the hit along the curve.
function waypointInsertionIndex(definition, hitSegmentIndex) {
    const waypoints = definition.waypoints ?? [];
    const tHit = hitSegmentIndex / 42;
    return waypoints.filter((_, i) => (i + 1) / (waypoints.length + 1) < tHit).length;
}

function captureAdditiveNodeSelection(event) {
    if (event.button !== 0 || !event.shiftKey || activeEndpointPick || currentTool === 'rectangleSelect') return;
    const label = event.target.closest?.('.node-label-container');
    let node = label ? nodeObjects.get(Number(label.dataset.node)) : null;
    if (!node && event.currentTarget === renderer.domElement) {
        setPointerFromEvent(event);
        node = rootNodeFromIntersection(firstIntersection(nodePickTargets));
    }
    if (!node) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    selectNode(node, { additive: true });
}

renderer.domElement.addEventListener('pointerdown', captureAdditiveNodeSelection, { capture: true });
css2dContainer.addEventListener('pointerdown', captureAdditiveNodeSelection, { capture: true });

let rectangleSelection = null;

function updateSelectionRectangle(clientX, clientY) {
    if (!rectangleSelection) return;
    const canvasBounds = canvas.getBoundingClientRect();
    const left = Math.min(rectangleSelection.startX, clientX);
    const top = Math.min(rectangleSelection.startY, clientY);
    const rectangle = $('#selectionRectangle');
    rectangle.style.left = `${left - canvasBounds.left}px`;
    rectangle.style.top = `${top - canvasBounds.top}px`;
    rectangle.style.width = `${Math.abs(clientX - rectangleSelection.startX)}px`;
    rectangle.style.height = `${Math.abs(clientY - rectangleSelection.startY)}px`;
}

renderer.domElement.addEventListener('pointerdown', (event) => {
    if (currentTool !== 'rectangleSelect' || event.button !== 0 || activeResult) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    rectangleSelection = { startX: event.clientX, startY: event.clientY, additive: event.shiftKey };
    const rectangle = $('#selectionRectangle');
    rectangle.hidden = false;
    updateSelectionRectangle(event.clientX, event.clientY);
}, { capture: true });

window.addEventListener('pointermove', (event) => {
    if (rectangleSelection) updateSelectionRectangle(event.clientX, event.clientY);
});

window.addEventListener('pointerup', (event) => {
    if (!rectangleSelection || event.button !== 0) return;
    const selection = rectangleSelection;
    rectangleSelection = null;
    $('#selectionRectangle').hidden = true;
    const left = Math.min(selection.startX, event.clientX);
    const right = Math.max(selection.startX, event.clientX);
    const top = Math.min(selection.startY, event.clientY);
    const bottom = Math.max(selection.startY, event.clientY);
    const rendererBounds = renderer.domElement.getBoundingClientRect();
    const hits = [...nodeObjects.values()].filter((node) => {
        if (!node.visible) return false;
        const projected = node.position.clone().project(camera);
        const x = rendererBounds.left + (projected.x + 1) * rendererBounds.width / 2;
        const y = rendererBounds.top + (1 - projected.y) * rendererBounds.height / 2;
        return x >= left && x <= right && y >= top && y <= bottom;
    });
    if (!selection.additive) clearSelection();
    hits.forEach((node) => {
        if (!selectedNodeIds.has(node.userData.id)) selectNode(node, { additive: true });
    });
    if (hits.length) $('#statusText').textContent = `${selectedNodeIds.size} node${selectedNodeIds.size === 1 ? '' : 's'} selected`;
});

// OrbitControls' default right-drag pans the camera, and on macOS `contextmenu` fires practically
// on mousedown -- before any drag distance exists to measure and before the eventual `pointerup`
// even happens, let alone reports where it happens. So instead of deciding at `contextmenu` time,
// each handler below only *stages* what it would open; the actual opening is deferred until the
// right button is released, at which point the total pointerdown-to-pointerup travel decides
// whether this was a click (stage the action) or a drag that panned the camera (discard it).
// Listeners live on `window` in the capture phase (rather than on renderer.domElement) so they
// also see drags that start on a CSS2D label/overlay, which stop propagation to the canvas on
// their own pointerdown.
let rightPointerDown = null;
let stagedContextMenuAction = null;
window.addEventListener('pointerdown', (event) => {
    if (event.button === 2) { rightPointerDown = { x: event.clientX, y: event.clientY }; stagedContextMenuAction = null; }
}, { capture: true });
window.addEventListener('pointerup', (event) => {
    if (event.button !== 2 || !rightPointerDown) return;
    const dragged = Math.hypot(event.clientX - rightPointerDown.x, event.clientY - rightPointerDown.y) > 4;
    rightPointerDown = null;
    if (!dragged) stagedContextMenuAction?.();
    stagedContextMenuAction = null;
}, { capture: true });
function stageContextMenuAction(action) {
    stagedContextMenuAction = action;
}

renderer.domElement.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || transformControls.dragging) return;
    setPointerFromEvent(event);
    const subsystemHit = firstIntersection([...subsystemObjects.values()].filter((object) => object.visible));
    if (subsystemHit) {
        nodePointerDown = null;
        enterSubsystem(subsystemHit.object.userData.id);
        return;
    }
    const nodeIntersection = firstIntersection(nodePickTargets);
    const node = rootNodeFromIntersection(nodeIntersection);

    if (node) {
        const wasSelected = selectedNodeIds.has(node.userData.id);
        if (!wasSelected) selectNode(node);
        if (activeEndpointPick) {
            nodePointerDown = null;
            chooseEndpointNode(node.userData.id);
            return;
        }
        nodePointerDown = { id: node.userData.id, x: event.clientX, y: event.clientY, wasSelected };
        if (!activeResult && currentTool in transformPropertyForTool && selectedNodeIds.has(node.userData.id)) transformControls.attach(node);
        return;
    }

    nodePointerDown = null;

    if (activeEndpointPick) return;
    if (event.shiftKey) return;

    // A waypoint handle isn't reachable via rootNodeFromIntersection's node-only walk (by
    // design -- it degrades to null for any non-'node' kind), so it falls through to here just
    // like empty canvas would. Bail out without touching selection and let DragControls' own
    // pointerdown (registered earlier, same element) start the drag -- otherwise clearSelection()
    // below would tear down the very handle the user is about to drag before DragControls sees it.
    if (nodeIntersection?.object.userData.kind === 'waypoint') return;

    const relationshipHit = firstIntersection(relationshipPickTargets);
    if (relationshipHit) {
        // A quick click still opens the editor (via pointerup below, once travel is known) --
        // pressing and holding in place instead enters waypoint routing: the edge gets
        // selected (which is what already makes its waypoint handles visible) without the
        // editor card popping up over it.
        const definition = relationshipHit.object.userData.definition;
        relationshipPointerDown = {
            definition,
            x: event.clientX,
            y: event.clientY,
            holdTriggered: false,
            timer: setTimeout(() => {
                relationshipPointerDown.holdTriggered = true;
                selectRelationship(definition);
                transformControls.detach();
                $('#statusText').textContent = `Editing waypoints · ${definition.title}`;
            }, relationshipHoldDurationMs)
        };
        return;
    }

    clearSelection();
    hideCards();
});

renderer.domElement.addEventListener('pointermove', (event) => {
    if (!relationshipPointerDown || relationshipPointerDown.holdTriggered) return;
    const travel = Math.hypot(event.clientX - relationshipPointerDown.x, event.clientY - relationshipPointerDown.y);
    if (travel > relationshipHoldTravelLimit) {
        clearTimeout(relationshipPointerDown.timer);
        relationshipPointerDown = null;
    }
});

renderer.domElement.addEventListener('pointerup', (event) => {
    if (relationshipPointerDown) {
        clearTimeout(relationshipPointerDown.timer);
        const { definition, x, y, holdTriggered } = relationshipPointerDown;
        relationshipPointerDown = null;
        if (holdTriggered || event.button !== 0) return;
        const pointerTravel = Math.hypot(event.clientX - x, event.clientY - y);
        if (pointerTravel <= 4) {
            selectRelationship(definition);
            transformControls.detach();
            openRelationshipEditor(definition);
        }
        return;
    }

    if (event.button !== 0 || !nodePointerDown || activeEndpointPick) {
        nodePointerDown = null;
        return;
    }
    const pointerTravel = Math.hypot(
        event.clientX - nodePointerDown.x,
        event.clientY - nodePointerDown.y
    );
    const node = nodeObjects.get(nodePointerDown.id);
    const { wasSelected } = nodePointerDown;
    nodePointerDown = null;
    if (pointerTravel <= 4 && node?.visible && !event.shiftKey) {
        if (wasSelected && selectedNodeIds.size > 1) selectNode(node);
        openNodeEditor(node.userData.definition);
    }
});

renderer.domElement.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    setPointerFromEvent(event);
    const nodeIntersection = firstIntersection(nodePickTargets);
    const node = rootNodeFromIntersection(nodeIntersection);

    if (node) {
        stageContextMenuAction(() => {
            if (activeResult) { selectNode(node); return; }
            if (!(selectedNodeIds.size > 1 && selectedNodeIds.has(node.userData.id))) selectNode(node);
            openNodeContextMenu(event.clientX, event.clientY);
        });
        return;
    }

    if (nodeIntersection?.object.userData.kind === 'waypoint') {
        const { relationshipId, index } = nodeIntersection.object.userData;
        stageContextMenuAction(() => {
            if (activeResult) return;
            pendingWaypointRemoval = { relationshipId, index };
            openWaypointContextMenu(event.clientX, event.clientY);
        });
        return;
    }

    const relationshipHit = firstIntersection(relationshipPickTargets);
    if (relationshipHit) {
        stageContextMenuAction(() => {
            const definition = relationshipHit.object.userData.definition;
            selectRelationship(definition);
            if (!activeResult) {
                // relationshipHit.index only exists on a Line-geometry hit (the edge itself, not
                // its direction-marker cone, which reports .faceIndex instead) -- so this is
                // simultaneously "was the line clicked" and the sample index needed below.
                pendingWaypoint = relationshipHit.index === undefined ? null : {
                    relationshipId: definition.id,
                    point: relationshipHit.point.toArray(),
                    insertionIndex: waypointInsertionIndex(definition, relationshipHit.index)
                };
                openEdgeContextMenu(event.clientX, event.clientY);
            }
        });
        return;
    }

    stageContextMenuAction(() => {
        if (!activeResult) openAddPalette(event.clientX, event.clientY);
    });
});

$$('[data-close-card]').forEach((button) => {
    button.addEventListener('click', () => {
        if (button.closest('#edgeEditor')) finishEquationEdit();
        if (button.closest('#edgeGroupEditor')) finishEquationEdit();
        if (button.closest('#edgeBuilder')) finishEndpointPick();
        if (button.closest('#sourceTermEditor')) {
            finishEquationEdit();
            const node = selectedSourceTermNodeId ? nodeObjects.get(selectedSourceTermNodeId) : null;
            selectedSourceTermNodeId = null;
            selectedSourceTermId = null;
            button.closest('.contextCard').classList.add('hidden');
            if (node) openNodeEditor(node.userData.definition);
            return;
        }
        button.closest('.contextCard').classList.add('hidden');
    });
});

$$('[data-node-tab]').forEach((button) => {
    button.addEventListener('click', () => selectNodeEditorTab(button.dataset.nodeTab));
});

$('#editNodeName').addEventListener('change', (event) => {
    if (!selectedNode) return;
    changeNodeModel(selectedNode, (snapshot) => {
        snapshot.title = event.target.value.trim() || 'Untitled node';
    });
});
$('#editNodeType').addEventListener('change', (event) => {
    if (!selectedNode) return;
    changeNodeModel(selectedNode, (snapshot) => {
        snapshot.type = event.target.value.trim() || 'Custom node';
    });
});
$('#editNodeSubsteps').addEventListener('change', (event) => {
    if (!selectedNode) return;
    const substeps = Math.max(1, Math.min(10000, Math.trunc(Number(event.target.value) || 1)));
    changeNodeModel(selectedNode, (snapshot) => { snapshot.substepsPerGlobalStep = substeps; });
});
$('#editNodeProgramKind').addEventListener('change', async (event) => {
    if (!selectedNode) return;
    const node = selectedNode;
    const kind = event.target.value;
    const previous = node.userData.definition.implementation;
    if (kind === 'fmi') {
        const fmus = await refreshInstalledFmus();
        if (fmus.length === 1) { await useFmuForNode(node, fmus[0].packageId, fmus[0].version); return; }
        // Several FMUs (or none): the node is set to take one, and the user chooses which below.
        changeNodeModel(node, (snapshot) => { snapshot.implementation = { kind: 'fmi', fmuId: '', fmuVersion: '', bindings: [], outputs: [] }; });
        return;
    }
    changeNodeModel(node, (snapshot) => {
        if (!kind) { snapshot.implementation = null; return; }
        // The inputs and outputs carry over; the source is kept when the language is, or starts from a template.
        const bindings = structuredClone(previous?.bindings ?? []);
        const outputs = structuredClone(previous?.outputs ?? []);
        const keep = previous?.kind === kind && previous.source;
        snapshot.implementation = {
            kind, providerApiVersion: 1, bindings, outputs,
            source: keep ? previous.source : defaultNodeProviderSource(kind, bindings, outputs, snapshot.title)
        };
    });
});
$('#editNodeProgramFmu').addEventListener('change', (event) => {
    if (!selectedNode || !event.target.value) return;
    const [guid, version] = JSON.parse(event.target.value);
    useFmuForNode(selectedNode, guid, version);
});
$('#editNodeProgramSource').addEventListener('input', (event) => {
    if (activeResult || !selectedNode) return;
    const node = selectedNode;
    const definition = node.userData.definition;
    if (!definition.implementation) return;
    beginEquationEditSession(`nodeProgram:${node.userData.id}`, () => captureNodeModel(node), (snapshot) => applyNodeModel(node, snapshot));
    definition.implementation = { ...definition.implementation, source: event.target.value };
    updateValidationStatus();
});
$('#editNodeProgramSource').addEventListener('change', () => finishEquationEdit());
$('#editNodeProgramTemplate').addEventListener('click', () => {
    if (!selectedNode?.userData.definition.implementation) return;
    const node = selectedNode;
    if ($('#editNodeProgramSource').value.trim() && !window.confirm('Replace the program with a freshly generated template? (Undo brings it back.)')) return;
    changeNodeModel(node, (snapshot) => {
        snapshot.implementation.source = nodeProgramTemplate(snapshot.implementation.kind, snapshot.implementation, snapshot.title);
    });
});
$('#editNodeProgramOpenEditor').addEventListener('click', () => {
    const implementation = selectedNode?.userData.definition.implementation;
    if (!implementation || implementation.kind === 'fmi') return;
    providerEditTarget = { type: 'node', nodeId: selectedNode.userData.id };
    window.providerEditor.openWindow({
        source: $('#editNodeProgramSource').value,
        kind: implementation.kind,
        title: selectedNode.userData.definition.title
    });
});
$('#editAddNodeProgramInput').addEventListener('click', () => {
    if (!selectedNode?.userData.definition.implementation) return;
    const node = selectedNode;
    const { candidates } = nodeProgramContext(node);
    changeNodeModel(node, (snapshot) => {
        const bindings = snapshot.implementation.bindings ??= [];
        bindings.push({ key: freeKey(bindings, 'input'), ...(candidates[0]?.binding ?? { kind: 'state', stateId: null }) });
    });
});
$('#editAddNodeProgramOutput').addEventListener('click', () => {
    if (!selectedNode?.userData.definition.implementation) return;
    const node = selectedNode;
    changeNodeModel(node, (snapshot) => {
        const outputs = snapshot.implementation.outputs ??= [];
        const used = new Set(outputs.map((output) => output.stateId));
        const state = snapshot.states.find((candidate) => !used.has(candidate.id)) ?? snapshot.states[0];
        outputs.push({ key: freeKey(outputs, 'output'), stateId: state?.id ?? null });
    });
});
$('#editNodeIntegration').addEventListener('change', (event) => {
    if (!selectedNode) return;
    const integration = event.target.value === 'semiImplicit' ? 'semiImplicit' : 'explicit';
    changeNodeModel(selectedNode, (snapshot) => { snapshot.integration = integration; });
});
$('#editAddState').addEventListener('click', () => {
    if (!selectedNode) return;
    changeNodeModel(selectedNode, (snapshot) => {
        snapshot.states.push({
            id: allocateModelEntityId(),
            label: 'New state',
            symbol: `x${snapshot.states.length + 1}`,
            initialValue: 0,
            unit: '',
            value: '0',
            className: ''
        });
    });
});
$('#editAddSourceTerm').addEventListener('click', () => {
    if (!selectedNode?.userData.definition.states.length) return;
    changeNodeModel(selectedNode, (snapshot) => {
        snapshot.sourceTerms.push({
            id: allocateModelEntityId(),
            state: snapshot.states[0].symbol,
            expression: '0'
        });
    });
});

$('#editEdgeName').addEventListener('change', (event) => {
    if (!selectedRelationship) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        snapshot.title = event.target.value.trim() || 'Untitled relationship';
    });
});
$('#editEdgeSource').addEventListener('change', (event) => {
    if (!selectedRelationship) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        snapshot.source = event.target.value;
        snapshot.sourceStateId = null;
    });
});
$('#editEdgeTarget').addEventListener('change', (event) => {
    if (!selectedRelationship) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        snapshot.target = event.target.value;
        snapshot.targetStateId = null;
    });
});
$('#editEdgeDirectionality').addEventListener('change', (event) => {
    if (!selectedRelationship || isSeveralEquations(selectedRelationship.equationModel)) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        snapshot.directionality = event.target.value;
    });
});
$('#editEdgeColor').addEventListener('change', (event) => {
    if (!selectedRelationship) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        snapshot.color = Number.parseInt(event.target.value.replace('#', ''), 16);
    });
});

// A single live-edit session mechanism shared by every free-text field (edge equations,
// edge provider source, source-term equations, source-term provider source) so keystrokes
// preview immediately while only one undo/redo entry is recorded per continuous edit.
function beginEquationEditSession(key, capture, apply) {
    if (equationEditSession?.key === key) return;
    finishEquationEdit();
    equationEditSession = { key, before: capture(), capture, apply };
}

function finishEquationEdit() {
    if (!equationEditSession) return;
    const { before, capture, apply } = equationEditSession;
    equationEditSession = null;
    const after = capture();
    if (JSON.stringify(before) === JSON.stringify(after)) return;
    recordHistory({
        undo: () => apply(before),
        redo: () => apply(after)
    });
}

function previewProviderSource(source) {
    if (activeResult || !selectedRelationship) return;
    const definition = selectedRelationship;
    beginEquationEditSession(`edge:${definition.id}`, () => captureEdgeModel(definition), (snapshot) => applyEdgeModel(definition, snapshot));
    definition.implementation = { ...definition.implementation, source };
    $('#editInsertProviderTemplate').hidden = !source.trim();
    updateValidationStatus();
}

function previewEdgeEquation(latex, origin) {
    if (activeResult || !selectedRelationship) return;
    const definition = selectedRelationship;
    beginEquationEditSession(`edge:${definition.id}`, () => captureEdgeModel(definition), (snapshot) => applyEdgeModel(definition, snapshot));
    const equationModel = normalizeEdgeEquationModel(definition, {
        ...definition.equationModel,
        latex
    });
    definition.equationModel = equationModel;
    definition.equation = latex;
    if (origin !== 'visual') $('#editEdgeMathField').setValue(latex, { silenceNotifications: true });
    if (origin !== 'latex') $('#editEdgeEquation').value = latex;
    renderEquationDiagnostics(latex, equationModel.bindings);
    updateRelationships();
    updateValidationStatus();
}

$('#editEdgeMathField').addEventListener('input', (event) => {
    previewEdgeEquation(event.target.value, 'visual');
});
$('#editEdgeMathField').addEventListener('change', (event) => {
    finishEquationEdit();
});
$('#editEdgeEquation').addEventListener('input', (event) => {
    previewEdgeEquation(event.target.value, 'latex');
});
$('#editEdgeEquation').addEventListener('change', (event) => {
    finishEquationEdit();
});
$('#editEquationOutput').addEventListener('change', (event) => {
    if (!selectedRelationship) return;
    const picked = parseEquationOutput(event.target.value);
    if (!picked) return;
    const { role, stateId } = picked;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        if (snapshot.implementation) snapshot.implementation.output = { ...snapshot.implementation.output, role, stateId };
        else snapshot.equationModel.output = { role, stateId };
    });
});
$('#editEdgeImplementationKind').addEventListener('change', (event) => {
    if (!selectedRelationship) return;
    const kind = event.target.value;
    const wasSeveral = isSeveralEquations(selectedRelationship.equationModel);
    if (kind === 'equations') {
        if (wasSeveral) return;
        // The one equation becomes the first of several, now setting its state; the relationship becomes directed.
        changeEdgeModel(selectedRelationship, (snapshot) => {
            const { sourceNode, targetNode, candidates } = severalContext(snapshot);
            const single = snapshot.implementation
                ? { latex: '0', output: { role: snapshot.implementation.output?.role ?? 'target', stateId: snapshot.implementation.output?.stateId } }
                : snapshot.equationModel;
            snapshot.equationModel = severalFromSingle(single, candidates, sourceNode, targetNode);
            snapshot.implementation = null;
            snapshot.directionality = 'directed';
        });
        return;
    }
    if (wasSeveral) {
        const { outputs = [], definitions = [] } = selectedRelationship.equationModel;
        if ((outputs.length > 1 || definitions.length) && !window.confirm(
            `Keep only the first equation${definitions.length ? ', with the intermediate quantities it reads written into it' : ''}? The others are removed (Undo brings them back).`)) {
            event.target.value = 'equations';
            return;
        }
    }
    changeEdgeModel(selectedRelationship, (snapshot) => {
        // From several equations, the first one stays, adding a rate to its state again.
        if (wasSeveral) snapshot.equationModel = singleFromSeveral(snapshot.equationModel);
        if (kind === 'equation') {
            snapshot.implementation = null;
            return;
        }
        const { role, stateId } = parseEquationOutput($('#editEquationOutput').value) ?? { role: 'target', stateId: null };
        const bindings = snapshot.implementation?.bindings ?? [];
        const output = snapshot.implementation?.output ?? { key: 'output', role, stateId };
        snapshot.implementation = pluginOrProgram(kind, snapshot.implementation, bindings, output, snapshot.title);
    });
});
$('#editInsertProviderTemplate').addEventListener('click', () => {
    if (!selectedRelationship?.implementation) return;
    const { kind, bindings, output } = selectedRelationship.implementation;
    if ($('#editEdgeProviderSource').value.trim() &&
        !window.confirm('Replace the current provider source with a freshly generated template?')) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        snapshot.implementation.source = defaultProviderSource(kind, bindings, output?.key, snapshot.title);
    });
});
$('#editOpenProviderEditor').addEventListener('click', () => {
    if (!selectedRelationship?.implementation) return;
    providerEditTarget = { type: 'editor', relationshipId: selectedRelationship.id };
    window.providerEditor.openWindow({
        source: $('#editEdgeProviderSource').value,
        kind: selectedRelationship.implementation.kind,
        title: selectedRelationship.title
    });
});
window.providerEditor.onApplied(({ source }) => {
    const fail = (error) => window.providerEditor.reportApplied({ applied: false, error });
    const succeed = () => window.providerEditor.reportApplied({ applied: true });
    if (!providerEditTarget) return fail('Nothing is being edited anymore.');
    if (providerEditTarget.type === 'editor') {
        if (activeResult) return fail('Results are locked — close them to apply changes.');
        const relationship = model.relationships.find((candidate) => candidate.id === providerEditTarget.relationshipId);
        if (!relationship?.implementation || relationship.deleted) return fail('This relationship no longer exists.');
        changeEdgeModel(relationship, (snapshot) => {
            snapshot.implementation.source = source;
        });
        return succeed();
    }
    if (providerEditTarget.type === 'builder') {
        if ($('#edgeBuilder').classList.contains('hidden')) return fail('The relationship builder was closed.');
        $('#edgeProviderSource').value = source;
        $('#insertProviderTemplate').hidden = !source.trim();
        return succeed();
    }
    if (providerEditTarget.type === 'sourceTerm') {
        if (activeResult) return fail('Results are locked — close them to apply changes.');
        const node = nodeObjects.get(providerEditTarget.nodeId);
        const term = node?.userData.definition.sourceTerms.find((candidate) => candidate.id === providerEditTarget.termId);
        if (!node || node.userData.definition.deleted || !term?.implementation) return fail('This source term no longer exists.');
        changeSourceTermModel(node, providerEditTarget.termId, (snapshotTerm) => {
            snapshotTerm.implementation.source = source;
        });
        return succeed();
    }
    if (providerEditTarget.type === 'builderSourceTerm') {
        if (!document.body.contains(providerEditTarget.sourceElement)) return fail('The source term builder was closed.');
        providerEditTarget.sourceElement.value = source;
        providerEditTarget.sourceElement.dispatchEvent(new Event('input', { bubbles: true }));
        return succeed();
    }
    if (providerEditTarget.type === 'node') {
        if (activeResult) return fail('Results are locked — close them to apply changes.');
        const node = nodeObjects.get(providerEditTarget.nodeId);
        if (!node || node.userData.definition.deleted || !node.userData.definition.implementation) return fail('This node no longer has a program.');
        changeNodeModel(node, (snapshot) => { snapshot.implementation.source = source; });
        return succeed();
    }
    if (providerEditTarget.type === 'group') {
        if (activeResult) return fail('Results are locked — close them to apply changes.');
        const group = model.edgeGroups.find((candidate) => candidate.id === providerEditTarget.groupId && !candidate.deleted);
        if (!group?.definition.implementation) return fail('This edge group no longer exists.');
        changeEdgeGroupModel(group, (snapshot) => { snapshot.definition.implementation.source = source; });
        return succeed();
    }
    return fail('Unknown edit target.');
});
$('#editEdgeProviderSource').addEventListener('input', (event) => {
    previewProviderSource(event.target.value);
});
$('#editEdgeProviderSource').addEventListener('change', () => {
    finishEquationEdit();
});
$('#editProviderOutputKey').addEventListener('change', (event) => {
    if (!selectedRelationship) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        snapshot.implementation.output = { ...snapshot.implementation.output, key: event.target.value.trim() };
    });
});
$('#editAddProviderBinding').addEventListener('click', () => {
    if (!selectedRelationship) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        const candidates = providerReferenceCandidates(snapshot);
        if (!candidates.length) return;
        snapshot.implementation.bindings.push(
            referenceToProviderBinding(`input${snapshot.implementation.bindings.length + 1}`, candidates[0]));
    });
});
$('#termOutputState').addEventListener('change', (event) => {
    if (!selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    const stateId = Number(event.target.value);
    changeSourceTermModel(node, selectedSourceTermId, (term) => {
        if (term.implementation) {
            term.implementation.output = { ...term.implementation.output, stateId };
        } else {
            const state = node.userData.definition.states.find((candidate) => candidate.id === stateId);
            if (state) term.state = state.symbol;
            term.expressionModel = { ...term.expressionModel, output: { stateId } };
        }
    });
});
$('#termAddParameter').addEventListener('click', () => {
    if (!selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    changeSourceTermModel(node, selectedSourceTermId, (term) => {
        term.parameters ??= [];
        const used = new Set(term.parameters.map((parameter) => parameter.symbol));
        let suffix = term.parameters.length + 1;
        while (used.has(`parameter${suffix}`)) suffix += 1;
        term.parameters.push({
            id: allocateModelEntityId(), name: `Parameter ${suffix}`, symbol: `parameter${suffix}`,
            value: 1, unit: '', mode: 'constant'
        });
    });
});
$('#termImplementationKind').addEventListener('change', (event) => {
    if (!selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    const kind = event.target.value;
    changeSourceTermModel(node, selectedSourceTermId, (term) => {
        if (kind === 'equation') {
            term.implementation = null;
            return;
        }
        const stateId = Number($('#termOutputState').value) || node.userData.definition.states[0]?.id || null;
        const bindings = term.implementation?.bindings ?? [];
        const output = term.implementation?.output ?? { key: 'output', stateId };
        term.implementation = pluginOrProgram(kind, term.implementation, bindings, output, node.userData.definition.title);
    });
});
$('#termSetsValue').addEventListener('change', (event) => {
    if (!selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    const setsValue = event.target.value === 'true';
    $('#termSetsValueHint').hidden = !setsValue;
    changeSourceTermModel(node, selectedSourceTermId, (term) => {
        if (setsValue) term.setsValue = true;
        else delete term.setsValue;
    });
});
$('#termInsertProviderTemplate').addEventListener('click', () => {
    if (!selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    const term = node.userData.definition.sourceTerms.find((candidate) => candidate.id === selectedSourceTermId);
    if (!term?.implementation) return;
    if ($('#termProviderSource').value.trim() &&
        !window.confirm('Replace the current provider source with a freshly generated template?')) return;
    changeSourceTermModel(node, selectedSourceTermId, (snapshotTerm) => {
        snapshotTerm.implementation.source = defaultProviderSource(
            snapshotTerm.implementation.kind, snapshotTerm.implementation.bindings,
            snapshotTerm.implementation.output?.key, node.userData.definition.title);
    });
});
$('#termAddProviderBinding').addEventListener('click', () => {
    if (!selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    changeSourceTermModel(node, selectedSourceTermId, (term) => {
        const candidates = sourceTermBindingCandidates(node.userData.definition);
        if (!candidates.length) return;
        term.implementation.bindings.push(
            sourceTermReferenceToBinding(`input${term.implementation.bindings.length + 1}`, candidates[0]));
    });
});
$('#termOpenProviderEditor').addEventListener('click', () => {
    if (!selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    const definition = node.userData.definition;
    const term = definition.sourceTerms.find((candidate) => candidate.id === selectedSourceTermId);
    if (!term?.implementation) return;
    providerEditTarget = { type: 'sourceTerm', nodeId: node.userData.id, termId: term.id };
    window.providerEditor.openWindow({
        source: $('#termProviderSource').value,
        kind: term.implementation.kind,
        title: definition.title
    });
});
$('#termProviderSource').addEventListener('input', (event) => {
    previewSourceTermProviderSource(event.target.value);
});
$('#termProviderSource').addEventListener('change', () => {
    finishEquationEdit();
});
$('#termProviderOutputKey').addEventListener('change', (event) => {
    if (!selectedSourceTermNodeId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    changeSourceTermModel(node, selectedSourceTermId, (term) => {
        term.implementation.output = { ...term.implementation.output, key: event.target.value.trim() };
    });
});
$('#termMathField').addEventListener('input', (event) => {
    previewSourceTermExpression(event.target.value, 'visual');
});
$('#termMathField').addEventListener('change', () => finishEquationEdit());
$('#termEquation').addEventListener('input', (event) => {
    previewSourceTermExpression(event.target.value, 'latex');
});
$('#termEquation').addEventListener('change', () => finishEquationEdit());
$$('[data-term-equation-mode]').forEach((button) => button.addEventListener('click', () => {
    $$('[data-term-equation-mode]').forEach((candidate) => candidate.classList.toggle('active', candidate === button));
    const latexMode = button.dataset.termEquationMode === 'latex';
    $('#termMathField').hidden = latexMode;
    $('#termEquation').hidden = !latexMode;
    (latexMode ? $('#termEquation') : $('#termMathField')).focus();
}));
$('[data-delete-source-term]').addEventListener('click', () => {
    if (!selectedSourceTermNodeId || !selectedSourceTermId) return;
    const node = nodeObjects.get(selectedSourceTermNodeId);
    changeNodeModel(node, (snapshot) => {
        snapshot.sourceTerms = snapshot.sourceTerms.filter((candidate) => candidate.id !== selectedSourceTermId);
    });
    selectedSourceTermNodeId = null;
    selectedSourceTermId = null;
    $('#sourceTermEditor').classList.add('hidden');
    openNodeEditor(node.userData.definition);
});
$$('[data-equation-mode]').forEach((button) => button.addEventListener('click', () => {
    $$('[data-equation-mode]').forEach((candidate) => candidate.classList.toggle('active', candidate === button));
    const latexMode = button.dataset.equationMode === 'latex';
    if (selectedRelationship && isSeveralEquations(selectedRelationship.equationModel)) {
        // Every row of a relationship with several equations switches, and the keyboard stays on the row it was on.
        $$('#editEdgeEquationsList .severalRow').forEach((row) => {
            $('math-field', row).hidden = latexMode;
            $('textarea', row).hidden = !latexMode;
        });
        if (severalFocus) focusSeveralRow(severalFocus.kind, severalFocus.index);
        return;
    }
    $('#editEdgeMathField').hidden = latexMode;
    $('#editEdgeEquation').hidden = !latexMode;
    (latexMode ? $('#editEdgeEquation') : $('#editEdgeMathField')).focus();
}));
$('#editAddEdgeParameter').addEventListener('click', () => {
    if (!selectedRelationship) return;
    changeEdgeModel(selectedRelationship, (snapshot) => {
        snapshot.parameters.push({
            id: allocateModelEntityId(),
            name: 'Parameter',
            symbol: `p${snapshot.parameters.length + 1}`,
            value: 0,
            unit: '',
            mode: 'constant'
        });
    });
});

$('#editNodeShape').addEventListener('change', (event) => {
    if (!selectedNode) return;
    changeNodeAppearance(selectedNode, {
        ...captureNodeAppearance(selectedNode.userData.definition),
        shape: event.target.value,
        importedGeometry: null,
        geometryFileName: null
    });
    $('#editGeometryStatus').textContent = 'Choose a CAD or mesh file';
});

$('#editNodeColor').addEventListener('change', (event) => {
    if (!selectedNode) return;
    changeNodeAppearance(selectedNode, {
        ...captureNodeAppearance(selectedNode.userData.definition),
        color: Number.parseInt(event.target.value.replace('#', ''), 16)
    });
});

$('#editNodeGeometryFile').addEventListener('change', async (event) => {
    const [file] = event.target.files;
    if (!file || !selectedNode) return;
    const node = selectedNode;
    const status = $('#editGeometryStatus');
    status.classList.remove('error');
    status.classList.add('loading');
    status.textContent = `Loading ${file.name}…`;
    try {
        const geometry = await importNodeGeometry(file);
        changeNodeAppearance(node, {
            ...captureNodeAppearance(node.userData.definition),
            shape: 'imported',
            importedGeometry: geometry,
            geometryFileName: file.name
        });
        geometry.dispose();
        $('#editNodeShape').value = '';
        status.textContent = `${file.name} applied`;
        await saveUploadToShapeLibrary(file, status);
    } catch (error) {
        status.classList.add('error');
        status.textContent = error.message;
        $('#editNodeShape').value = node.userData.definition.shape === 'imported'
            ? ''
            : node.userData.definition.shape;
    } finally {
        status.classList.remove('loading');
        event.target.value = '';
    }
});

$('#editBrowseShapeLibrary').addEventListener('click', () => {
    if (!selectedNode) return;
    openShapeLibrary('editor');
});

$$('#editNodeRotationX, #editNodeRotationY, #editNodeRotationZ').forEach((input) => input.addEventListener('change', () => {
    if (!selectedNode) return;
    const degrees = [$('#editNodeRotationX'), $('#editNodeRotationY'), $('#editNodeRotationZ')].map((field) => Number(field.value) || 0);
    changeNodeTransform(selectedNode, 'rotation', degrees.map((value) => THREE.MathUtils.degToRad(value)));
    refreshNodeTransformFields(selectedNode);
}));
$$('#editNodeScaleX, #editNodeScaleY, #editNodeScaleZ').forEach((input) => input.addEventListener('change', () => {
    if (!selectedNode) return;
    const values = [$('#editNodeScaleX'), $('#editNodeScaleY'), $('#editNodeScaleZ')].map((field) => Number(field.value));
    // Zero, negative or unparsable scale would collapse or invert the node's geometry --
    // reject it and snap the fields back to the last valid (live) values instead.
    if (values.some((value) => !(value > 0))) { refreshNodeTransformFields(selectedNode); return; }
    changeNodeTransform(selectedNode, 'scale', values);
    refreshNodeTransformFields(selectedNode);
}));

$('#shapeLibrarySearch').addEventListener('input', renderShapeLibraryResults);
$('#shapeLibraryResults').addEventListener('click', (event) => {
    const button = event.target.closest('[data-shape-id]');
    if (!button) return;
    shapeLibrarySelectedId = button.dataset.shapeId;
    $$('#shapeLibraryResults .shapeLibraryItem').forEach((item) => item.classList.toggle('selected', item === button));
    selectShapeLibraryPreview(shapeLibrarySelectedId);
});
$('#shapeLibraryApply').addEventListener('click', () => {
    if (shapeLibrarySelectedId) applyLibraryShape(shapeLibrarySelectedId);
});
$('#shapeLibraryCancel').addEventListener('click', () => $('#shapeLibraryDialog').close());
$('#shapeLibraryDialog').addEventListener('close', stopShapeLibraryPreview);
// Separate from stopShapeLibraryPreview, which is documented as that subsystem's own single
// cleanup point -- this just stops scheduling further thumbnail work; any generation already
// in flight finishes naturally and gets cached for next time.
$('#shapeLibraryDialog').addEventListener('close', () => {
    shapeLibraryThumbnailQueue.length = 0;
    shapeLibraryThumbnailQueued.clear();
});

$('#addButton').addEventListener('click', (event) => {
    if (activeResult) return;
    const rect = event.currentTarget.getBoundingClientRect();
    openAddPalette(rect.left, rect.bottom + 3);
});

// Shared by openProject() (dialog-driven) and checkPendingProjectOpen() (an OS-initiated
// open this window was created for) -- everything after a file/requiresPassword payload has
// already been obtained, including the password-retry loop.
async function loadOpenedProjectFile(file) {
    let password = null;
    let passwordError = '';
    while (file.requiresPassword) {
        password = await requestProjectPassword({
            error: passwordError,
            title: `Unlock ${file.fileName}`,
            hint: `Enter the password for ${file.fileName}.`
        });
        if (password === null) return;
        try {
            file = await window.projectFiles.unlock(file.path, password);
        } catch {
            passwordError = 'Incorrect password, or this project has been modified.';
        }
    }
    await loadProjectDocument(JSON.parse(file.content), {
        path: file.path,
        fileName: file.fileName,
        password: file.encrypted ? password : null,
        embeddedResult: file.embeddedResult,
        embeddedBranches: file.embeddedBranches
    });
    activeExampleId = null;
    $('#exampleGuideButton').hidden = true;
    $('#statusText').textContent = file.embeddedResult ? 'Project and simulation results loaded' : 'Project loaded';
}

async function openProject() {
    if (simulationRunning) return;
    try {
        if ((documentController.dirty || (activeResult && !activeResultPersistedInProject) || addonDataUnsaved) &&
            !await window.projectFiles.confirmDiscard()) return;
        const file = await window.projectFiles.open();
        if (!file) return;
        await loadOpenedProjectFile(file);
    } catch (error) {
        console.error(error);
        $('#statusText').textContent = `Load failed · ${error.message}`;
    }
}

// Asks main whether this window was created specifically to open an OS-provided file (a
// double-click, a relaunch's argv, or macOS's open-file) -- called once at startup so a fresh
// window can load straight into that file using the exact same UI as a manual Open.
async function checkPendingProjectOpen() {
    const pending = await window.projectFiles.pendingOpen();
    if (!pending) return;
    if (pending.error) {
        $('#statusText').textContent = `Load failed · ${pending.error}`;
        return;
    }
    try {
        await loadOpenedProjectFile(pending);
    } catch (error) {
        console.error(error);
        $('#statusText').textContent = `Load failed · ${error.message}`;
    }
}

function requestSaveContentChoice() {
    const dialog = $('#saveContentDialog');
    const form = $('form', dialog);
    const cancel = $('#saveContentCancel');
    $('input[name="saveContent"][value="modelAndResults"]', form).checked = true;
    return new Promise((resolve) => {
        const finish = (choice) => {
            form.removeEventListener('submit', onSubmit);
            dialog.removeEventListener('cancel', onCancel);
            cancel.removeEventListener('click', onCancelClick);
            dialog.close();
            resolve(choice);
        };
        const onSubmit = (event) => {
            event.preventDefault();
            finish($('input[name="saveContent"]:checked', form).value);
        };
        const onCancel = (event) => { event.preventDefault(); finish(null); };
        const onCancelClick = () => finish(null);
        form.addEventListener('submit', onSubmit);
        dialog.addEventListener('cancel', onCancel);
        cancel.addEventListener('click', onCancelClick);
        dialog.showModal();
    });
}

async function saveProject(saveAs = false, password = currentProjectPassword) {
    try {
        await waitForLauncherProjects();
        const hasEmbeddableResult = Boolean(activeResult && activeEngineJobId && !simulationRunning);
        const contentChoice = hasEmbeddableResult ? await requestSaveContentChoice() : 'model';
        if (!contentChoice) return false;
        const includeResults = contentChoice === 'modelAndResults';
        const content = `${JSON.stringify({ ...serializeProjectDocument(), ...(Object.keys(projectAddonData).length ? { addonData: projectAddonData } : {}) }, null, 4)}\n`;
        // Refresh the active branch's own record before reading it (mirrors activateBranch's own
        // park-on-switch refresh) -- it can otherwise be stale between live updates.
        const activeBranchRecord = branches.get(activeBranchUuid);
        if (activeBranchRecord) activeBranchRecord.jobId = activeEngineJobId;
        // A single branch (no forking this session) sends one entry with no branch metadata at
        // all, so the saved file keeps the exact legacy shape a pre-branching build can still open
        // (see encodeProjectFile's own doc comment) -- only a genuinely forked tree attaches UUIDs.
        const resultBranches = includeResults
            ? [...branches.values()].map((branch) => branches.size > 1
                ? { jobId: branch.jobId, branchUuid: branch.branchUuid, parentBranchUuid: branch.parentBranchUuid, forkTime: branch.forkTime, label: branch.label }
                : { jobId: branch.jobId })
            : null;
        const result = await window.projectFiles.save(
            saveAs ? null : currentProjectPath,
            content,
            currentProjectFilename,
            password,
            resultBranches
        );
        if (!result) return false;
        currentProjectPath = result.path;
        currentProjectFilename = result.fileName;
        currentProjectPassword = result.encrypted ? password : null;
        updateDocumentTitle();
        updateEncryptionControls();
        activeResultPersistedInProject = result.includesResults;
        addonDataUnsaved = false;
        documentController.markSaved();
        $('#statusText').textContent = `${result.encrypted ? 'Encrypted project' : 'Project'} saved${result.includesResults ? ' with simulation results' : ' · model only'}`;
        return true;
    } catch (error) {
        console.error(error);
        $('#statusText').textContent = `Save failed · ${error.message}`;
        return false;
    }
}

async function loadExample(id) {
    if (!id) return;
    try {
        if (simulationRunning) return;
        if ((documentController.dirty || (activeResult && !activeResultPersistedInProject) || addonDataUnsaved) && !await window.projectFiles.confirmDiscard()) return;
        const example = await window.projectFiles.loadExample(id);
        await loadProjectDocument(JSON.parse(example.content), {
            fileName: example.suggestedFilename,
            saved: false,
            embeddedResult: example.embeddedResult,
            embeddedBranches: example.embeddedBranches
        });
        activeExampleId = id;
        $('#exampleGuideButton').hidden = false;
        await window.projectFiles.openExampleGuide(id);
        $('#statusText').textContent = 'Example loaded as an unsaved copy';
    } catch (error) {
        console.error(error);
        $('#statusText').textContent = `Example failed · ${error.message}`;
    } finally {
        // .close() on an already-closed <dialog> is a harmless no-op, so this is safe even if
        // loadExample is ever invoked from somewhere other than the explorer's own Open button.
        $('#examplesExplorerDialog').close();
    }
}

// Projects on their way from a launcher add-on: the host says so before it builds one, and each settles when it has
// loaded here (or its build failed). A save waits for them, so it never writes the project as it was a moment before
// the toolbox's latest change.
let launcherProjectsPending = 0;
let launcherProjectsSettled = null;
let settleLauncherProjects = null;
function launcherProjectExpected() {
    launcherProjectsPending += 1;
    if (!launcherProjectsSettled) launcherProjectsSettled = new Promise((resolve) => { settleLauncherProjects = resolve; });
}
function launcherProjectSettled() {
    launcherProjectsPending = Math.max(0, launcherProjectsPending - 1);
    if (launcherProjectsPending || !settleLauncherProjects) return;
    settleLauncherProjects();
    launcherProjectsSettled = null;
    settleLauncherProjects = null;
}
async function waitForLauncherProjects() {
    if (!launcherProjectsSettled) return;
    $('#statusText').textContent = 'Waiting for the toolbox’s latest changes before saving…';
    // A host that never answers must not block saving for good.
    await Promise.race([launcherProjectsSettled, new Promise((resolve) => setTimeout(resolve, 60000))]);
}
window.launcherHost?.onOpenProjectPending?.(launcherProjectExpected);
window.launcherHost?.onOpenProjectAbandoned?.(launcherProjectSettled);

// A launcher add-on's "open in canvas": load the project it built (with its result branches) as an
// unsaved copy, behind the usual unsaved-work confirmation. Not present in the web edition.
window.launcherHost?.onOpenProject(async (payload) => {
    try {
        if (simulationRunning) return;
        if (!payload.silent && (documentController.dirty || (activeResult && !activeResultPersistedInProject)) && !await window.projectFiles.confirmDiscard()) return;
        await loadProjectDocument(JSON.parse(payload.content), {
            fileName: payload.suggestedFilename,
            saved: false,
            embeddedResult: payload.embeddedResult,
            embeddedBranches: payload.embeddedBranches
        });
        $('#statusText').textContent = payload.silent ? `Live-synced from ${payload.addonName ?? 'the toolbox'}` : 'Opened from the toolbox as an unsaved copy';
    } catch (error) {
        console.error(error);
        $('#statusText').textContent = `Could not open the project · ${error.message}`;
    } finally {
        launcherProjectSettled();
    }
});

// A launcher asks for the data it keeps with this project (its saved session), to restore its window.
window.launcherHost?.onAddonDataRequest?.((addonId) => projectAddonData[addonId] ?? null);

// A launcher keeps its session with this project (work in its window before any model is built), or a result
// visualizer its own data (null removes it): saved with the project, so it counts as unsaved work until then.
window.launcherHost?.onKeepAddonData?.((addonId, entry) => {
    const { [addonId]: _previous, ...others } = projectAddonData;
    projectAddonData = entry === null ? others : { ...others, [addonId]: entry };
    addonDataUnsaved = true;
    updateHistoryControls();
});

$('#exampleGuideButton').addEventListener('click', () => {
    if (activeExampleId) window.projectFiles.openExampleGuide(activeExampleId);
});

function requestProjectPassword({
    confirm = false,
    error = '',
    title = confirm ? 'Save encrypted project' : 'Unlock project',
    hint = confirm
        ? 'Choose a password. It cannot be recovered if you forget it.'
        : 'Enter the password used to protect this project.',
    submitLabel = confirm ? 'Save encrypted' : 'Unlock'
} = {}) {
    const dialog = $('#passwordDialog');
    const form = $('form', dialog);
    const password = $('#projectPassword');
    const confirmation = $('#confirmProjectPassword');
    const submit = $('#passwordSubmit');
    const cancel = $('#passwordCancel');
    $('#passwordDialogTitle').textContent = title;
    $('#passwordDialogHint').textContent = hint;
    submit.textContent = submitLabel;
    $('#confirmPasswordField').hidden = !confirm;
    $('#passwordError').textContent = error;
    password.value = '';
    confirmation.value = '';
    confirmation.required = confirm;

    return new Promise((resolve) => {
        const updateValidation = () => {
            const { valid, message } = validateProjectPassword(
                password.value,
                confirmation.value,
                confirm,
                error
            );
            $('#passwordError').textContent = message;
            confirmation.setAttribute('aria-invalid', String(confirm && Boolean(confirmation.value) && password.value !== confirmation.value));
            submit.disabled = !valid;
        };
        const finish = (value) => {
            form.removeEventListener('submit', onSubmit);
            dialog.removeEventListener('cancel', onCancel);
            password.removeEventListener('input', updateValidation);
            confirmation.removeEventListener('input', updateValidation);
            cancel.removeEventListener('click', onCancelClick);
            password.value = '';
            confirmation.value = '';
            dialog.close();
            resolve(value);
        };
        const onCancel = (event) => {
            event.preventDefault();
            finish(null);
        };
        const onCancelClick = () => finish(null);
        const onSubmit = (event) => {
            event.preventDefault();
            updateValidation();
            if (submit.disabled) return;
            const submittedPassword = password.value;
            finish(submittedPassword);
        };
        form.addEventListener('submit', onSubmit);
        dialog.addEventListener('cancel', onCancel);
        password.addEventListener('input', updateValidation);
        confirmation.addEventListener('input', updateValidation);
        cancel.addEventListener('click', onCancelClick);
        updateValidation();
        dialog.showModal();
        password.focus();
    });
}

let examplesExplorerEntries = null;
let examplesExplorerDomain = 'all';
let examplesExplorerSelectedId = null;

function renderExamplesExplorerResults() {
    const query = $('#examplesExplorerSearch').value.trim().toLowerCase();
    const matches = examplesExplorerEntries.filter((example) => {
        if (examplesExplorerDomain !== 'all' && !example.domains.includes(examplesExplorerDomain)) return false;
        if (!query) return true;
        const haystack = [example.label, example.description, ...example.domains].join(' ').toLowerCase();
        return haystack.includes(query);
    });
    $('#examplesExplorerResults').replaceChildren(...matches.map((example) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'examplesExplorerItem';
        button.dataset.exampleId = example.id;
        button.classList.toggle('selected', example.id === examplesExplorerSelectedId);
        const thumb = example.thumbnailUrl
            ? `<img class="examplesExplorerThumb" src="${escapeHtml(example.thumbnailUrl)}" alt="">`
            : '<span class="examplesExplorerThumbPlaceholder">No preview</span>';
        button.innerHTML = `${thumb}<b>${escapeHtml(example.label)}</b>`;
        return button;
    }));
    $('#examplesExplorerEmpty').hidden = matches.length > 0;
}

function renderExamplesExplorerDetail() {
    const example = examplesExplorerEntries.find((entry) => entry.id === examplesExplorerSelectedId);
    $('#examplesExplorerDetailEmpty').hidden = Boolean(example);
    $('#examplesExplorerDetailContent').hidden = !example;
    if (!example) return;
    const thumbnail = $('#examplesExplorerDetailThumbnail');
    thumbnail.hidden = !example.thumbnailUrl;
    thumbnail.src = example.thumbnailUrl ?? '';
    $('#examplesExplorerDetailTitle').textContent = example.label;
    $('#examplesExplorerDetailDescription').textContent = example.description || 'No description available.';
}

async function openExamplesExplorer() {
    if (!examplesExplorerEntries) {
        try {
            examplesExplorerEntries = await window.projectFiles.listExamples();
        } catch (error) {
            console.error(error);
            $('#exampleButton').disabled = true;
            return;
        }
    }
    examplesExplorerDomain = 'all';
    examplesExplorerSelectedId = null;
    $('#examplesExplorerSearch').value = '';
    const domains = ['all', ...new Set(examplesExplorerEntries.flatMap((example) => example.domains))];
    $('#examplesExplorerDomains').replaceChildren(...domains.map((domain) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = domain === 'all' ? 'All' : domainLabel(domain);
        button.classList.toggle('active', domain === examplesExplorerDomain);
        button.addEventListener('click', () => {
            examplesExplorerDomain = domain;
            $$('#examplesExplorerDomains button').forEach((chip) => chip.classList.toggle('active', chip === button));
            renderExamplesExplorerResults();
        });
        return button;
    }));
    renderExamplesExplorerResults();
    renderExamplesExplorerDetail();
    $('#examplesExplorerDialog').showModal();
    $('#examplesExplorerSearch').focus();
}

let extensionsEntries = null;
let extensionsTab = 'addon';
let extensionsSelectedKey = null;
// Discover mode (see docs/extensionsExplorer.md): browsing what the registry offers, as opposed to
// Installed mode's "what's on disk" above. Kept as separate state/render functions rather than
// folding into the Installed ones, since a registry entry (title/description/license/packages) and
// an installed package (permissions/enabled state) are different shapes of thing.
let extensionsMode = 'installed';
let discoverRegistry = null;
let discoverEntries = [];
let discoverStale = false;
let discoverDomain = 'all';
let discoverSelectedPrefix = null;
// prefix -> { latestVersion, releaseUrl, outdated: [{packageId, installedVersion}] } (see
// docs/extensionsExplorer.md's Update checking note). Populated in the background on dialog open, same
// as discoverEntries above -- a failure here just means no update information this session.
let packageUpdates = new Map();
// True while "Update all" is installing, so a second click, or the detail pane's own Update, cannot start
// another install alongside it.
let updatingAll = false;

function installedOutdated() {
    return outdatedEntries(extensionsEntries ?? [], (packageId) => updateInfoFor(packageId));
}

// The strip, the Updates tab and the per-tab counts: the title bar badge's number made findable. They are
// functions of the same two things as the list (what is installed, and what the update check found), so
// they are redrawn whenever the list is.
function renderExtensionsUpdates() {
    const outdated = installedOutdated();
    // Everything got updated while its tab was open: there is nothing left for that tab to show.
    if (extensionsTab === 'updates' && outdated.length === 0) {
        extensionsTab = 'addon';
        extensionsSelectedKey = null;
    }
    const counts = outdatedCountsByType(outdated);
    $$('#extensionsTabs .extensionsTab').forEach((tab) => {
        const type = tab.dataset.extensionsTab;
        const count = type === 'updates' ? outdated.length : counts[type] ?? 0;
        const badge = tab.querySelector('.extensionsTabCount');
        badge.hidden = count === 0;
        badge.textContent = String(count);
        if (type === 'updates') tab.hidden = outdated.length === 0;
        tab.classList.toggle('active', type === extensionsTab);
    });
    $('#extensionsUpdatesStrip').hidden = extensionsMode !== 'installed' || outdated.length === 0;
    $('#extensionsUpdatesSummary').textContent = describeOutdated(outdated);
    $('#extensionsUpdatesShow').hidden = extensionsTab === 'updates';
    $('#extensionsUpdateAll').disabled = updatingAll;
}

function extensionsPackageKey(entry) {
    return `${entry.packageType}:${entry.packageId}:${entry.version}`;
}

function showExtensionsNotice(message, type = null) {
    const notice = $('#extensionsRestartNotice');
    notice.textContent = message;
    notice.classList.toggle('error', type === 'error');
    notice.classList.toggle('warning', type === 'warning');
    notice.hidden = false;
}

function renderExtensionsResults() {
    renderExtensionsUpdates();
    const matches = extensionsTab === 'updates' ? installedOutdated() : extensionsEntries.filter((entry) => entry.packageType === extensionsTab);
    $('#extensionsResults').replaceChildren(...matches.map((entry) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'examplesExplorerItem extensionsItem';
        button.dataset.packageKey = extensionsPackageKey(entry);
        button.classList.toggle('selected', extensionsPackageKey(entry) === extensionsSelectedKey);
        button.classList.toggle('disabledItem', !entry.enabled);
        const update = updateInfoFor(entry.packageId);
        button.classList.toggle('hasUpdate', Boolean(update) && extensionsTab !== 'updates');
        button.classList.toggle('isIncompatible', Boolean(entry.incompatible));
        const heldBack = entry.incompatible ? null : heldBackInfoFor(entry.packageId);
        const compatibilityMeta = entry.incompatible ? ` · <span class="extensionsItemIncompatible">${escapeHtml(incompatibleText(entry.incompatible))}</span>`
            : heldBack ? ` · <span class="extensionsItemHeldBack">${escapeHtml(heldBackText(heldBack.heldBack))}</span>` : '';
        const meta = extensionsTab === 'updates' && update
            ? `${escapeHtml(installedTypeLabels[entry.packageType] ?? entry.packageType)} · ${escapeHtml(entry.version)} → <span class="extensionsItemUpdate">${escapeHtml(update.latestVersion)}</span>${entry.enabled || entry.incompatible ? '' : ' · Disabled'}`
            : `${escapeHtml(entry.version)} · ${entry.source === 'bundled' ? 'Bundled' : 'Installed'}${entry.enabled || entry.incompatible ? '' : ' · Disabled'}${update ? ` · <span class="extensionsItemUpdate">Update to ${escapeHtml(update.latestVersion)} available</span>` : ''}${compatibilityMeta}`;
        const description = registryDescriptionFor(entry.packageId);
        // FMUs are imported files with no registry entry to borrow an image from, so they keep the
        // plain text-only item rather than a column of identical placeholders.
        const hasThumb = entry.packageType !== 'fmu';
        button.classList.toggle('extensionsItemWithThumb', hasThumb);
        button.innerHTML = (hasThumb ? extensionsThumbHtml(entry.name) : '')
            + (update && extensionsTab !== 'updates' ? '<i class="extensionsUpdatePill">Update available</i>' : '')
            + (entry.incompatible ? '<i class="extensionsIncompatiblePill">Incompatible</i>' : '')
            + `<b>${escapeHtml(entry.name)}</b>`
            + (description ? `<p class="extensionsItemDescription">${escapeHtml(description)}</p>` : '')
            + `<span class="extensionsItemMeta">${meta}</span>`;
        if (hasThumb) attachExtensionsImage(button, registryEntryFor(entry.packageId));
        return button;
    }));
    $('#extensionsEmpty').textContent = extensionsTab === 'addon' ? 'No add-ons are installed.'
        : extensionsTab === 'plugin' ? 'No plugins are installed.'
            : extensionsTab === 'updates' ? 'Everything is up to date.' : 'No FMUs are imported.';
    $('#extensionsEmpty').hidden = matches.length > 0;
}

function renderExtensionsDetail() {
    $('#extensionsDiscoverDetailContent').hidden = true;
    const entry = extensionsEntries.find((candidate) => extensionsPackageKey(candidate) === extensionsSelectedKey);
    $('#extensionsDetailEmpty').hidden = Boolean(entry);
    $('#extensionsDetailContent').hidden = !entry;
    if (!entry) return;
    $('#extensionsDetailBadge').textContent = entry.source === 'bundled' ? 'Bundled' : 'Installed';
    $('#extensionsDetailBadge').classList.toggle('bundled', entry.source === 'bundled');
    $('#extensionsDetailEnabledBadge').hidden = entry.enabled || Boolean(entry.incompatible);   // an incompatible package is not "disabled": the compatibility note explains it
    const selectedKey = extensionsSelectedKey;
    showExtensionsDetailImage($('#extensionsDetailImage'), registryEntryFor(entry.packageId), () => extensionsSelectedKey === selectedKey);
    $('#extensionsDetailTitle').textContent = entry.name;
    $('#extensionsDetailId').textContent = entry.packageId;
    $('#extensionsDetailVersion').textContent = entry.version;
    $('#extensionsDetailPermissions').replaceChildren(...entry.permissions.map((permission) => {
        const item = document.createElement('li');
        item.textContent = permission;
        return item;
    }));
    const bundleEntry = registryBundleFor(entry.packageId);
    $('#extensionsDetailBundleNote').hidden = !bundleEntry;
    if (bundleEntry) {
        const siblingIds = bundleEntry.packages.filter((declared) => declared.packageId !== entry.packageId).map((declared) => declared.packageId).join(', ');
        $('#extensionsDetailBundleNote').textContent = `Part of the ${bundleEntry.title || bundleEntry.prefix} bundle, along with ${siblingIds}.`;
    }
    const update = updateInfoFor(entry.packageId);
    $('#extensionsDetailUpdateNote').hidden = !update;
    $('#extensionsUpdate').hidden = !update;
    // Reset here rather than only in the click handler's error path -- after a successful update
    // this button is hidden with its "Updating…"/disabled state still set, and would otherwise
    // reappear that way for the next outdated package selected.
    $('#extensionsUpdate').disabled = updatingAll;
    $('#extensionsUpdate').textContent = 'Update';
    if (update) $('#extensionsDetailUpdateNote').textContent = `Version ${update.latestVersion} is available (currently ${update.installedVersion}).`;
    // Compatibility (docs/proposals/packageCompatibility.md): an installed package this Konjugate cannot load is explained and can be
    // replaced with a release it can; a newer release that needs a newer Konjugate is mentioned, quietly, and is not an update.
    const heldBack = entry.incompatible ? null : heldBackInfoFor(entry.packageId);
    const compatibilityNote = entry.incompatible
        ? `${incompatibleText(entry.incompatible)} It is not loaded. Installing a compatible version replaces it.`
        : heldBack ? `Version ${heldBackText(heldBack.heldBack)}, so it is not offered as an update. Updating Konjugate makes it available.` : '';
    $('#extensionsDetailCompatibilityNote').hidden = !compatibilityNote;
    $('#extensionsDetailCompatibilityNote').textContent = compatibilityNote;
    const installCompatible = $('#extensionsInstallCompatible');
    installCompatible.hidden = !entry.incompatible;
    installCompatible.disabled = false;
    installCompatible.textContent = 'Install compatible version';
    $('#extensionsToggleEnabled').hidden = Boolean(entry.incompatible);
    $('#extensionsToggleEnabled').textContent = entry.enabled ? 'Disable' : 'Enable';
    $('#extensionsUninstall').hidden = entry.source === 'bundled';
}

function isPackageIdInstalled(packageId) {
    return (extensionsEntries ?? []).some((entry) => entry.packageId === packageId);
}

// The registry entry (if any) that declares packageId as part of a multi-package bundle -- a
// single-package entry isn't a bundle, so it's excluded (nothing for it to cross-reference against).
// Only populated once the registry has actually been fetched (see ensureDiscoverRegistry); returns
// null rather than fetching on demand, since this is used from Installed-mode rendering/handlers
// that shouldn't block on a network round trip just to show a cross-reference note.
function registryBundleFor(packageId) {
    return discoverEntries.find((entry) => entry.packages.length > 1 && entry.packages.some((declared) => declared.packageId === packageId)) ?? null;
}

// Installed packages don't carry their own description (addon.json/plugin.json have no such
// field) -- rather than adding one just for this, an installed item borrows its registry entry's
// description when one is known, the same discoverEntries this dialog already fetches for the
// bundle cross-reference above. Sideloaded/private packages with no registry entry, or a session
// where the registry couldn't be reached, just show nothing extra -- the plain name/version/status
// display this already had.
function registryDescriptionFor(packageId) {
    return discoverEntries.find((entry) => entry.packages.some((declared) => declared.packageId === packageId))?.description ?? null;
}

// { prefix, latestVersion, releaseUrl, installedVersion } for packageId if packageCheckUpdates
// found a newer release, else null. Looked up from packageUpdates (populated in the background on
// dialog open) rather than computed here -- the actual GitHub Releases check happens main-process
// side, once per registry-known installed entry, not per render.
function updateInfoFor(packageId) {
    for (const [prefix, update] of packageUpdates) {
        const outdated = update.outdated.find((item) => item.packageId === packageId);
        if (outdated) return { prefix, latestVersion: update.latestVersion, releaseUrl: update.releaseUrl, installedVersion: outdated.installedVersion };
    }
    return null;
}

// { prefix, heldBack } for packageId if a newer release exists that this Konjugate cannot use (see
// docs/proposals/packageCompatibility.md), else null. A note, never an update: it is not counted in the badge, the Updates tab or Update all.
function heldBackInfoFor(packageId) {
    for (const [prefix, update] of packageUpdates) {
        if (update.heldBack && (update.heldBackPackages ?? []).includes(packageId) && heldBackText(update.heldBack)) return { prefix, heldBack: update.heldBack };
    }
    return null;
}

async function ensurePackageUpdates({ force = false } = {}) {
    packageUpdates = new Map((await window.extensions.checkUpdates({ force })).map((update) => [update.prefix, update]));
    renderPackageUpdatesBadge();
}

// The Explorer entry point's badge (see docs/extensionsExplorer.md's Update checking note): one count
// per outdated installed package, not per registry entry, so a two-package bundle counts as two --
// matching how many rows show "Update available" in Installed mode.
function renderPackageUpdatesBadge() {
    const count = [...packageUpdates.values()].reduce((total, update) => total + update.outdated.length, 0);
    const badge = $('#extensionsUpdateBadge');
    badge.hidden = count === 0;
    badge.textContent = String(count);
    const label = count ? `Manage extensions (${count} update${count === 1 ? '' : 's'} available)` : 'Manage extensions';
    $('#extensionsButton').setAttribute('aria-label', label);
    $('#extensionsButtonLabel').textContent = count ? `Extensions · ${count} update${count === 1 ? '' : 's'} available` : 'Extensions';
}

// A human-readable warning if uninstalling/disabling entry would leave an installed bundle sibling
// without its counterpart (see the Multi-package bundles section of docs/extensionsExplorer.md) -- null
// if entry isn't part of a bundle, or its siblings aren't installed anyway.
function bundleWarningFor(entry, verb) {
    const bundleEntry = registryBundleFor(entry.packageId);
    if (!bundleEntry) return null;
    const installedSiblingIds = bundleEntry.packages
        .filter((declared) => declared.packageId !== entry.packageId && isPackageIdInstalled(declared.packageId))
        .map((declared) => declared.packageId);
    if (!installedSiblingIds.length) return null;
    return `It's part of the ${bundleEntry.title || bundleEntry.prefix} bundle -- ${verb} it will leave ${installedSiblingIds.join(', ')} without its counterpart.`;
}

// prefix -> Promise of a data: URL (or null), fetched once per window through the main
// process (see packageRegistryImage in src/main.mjs) and only for entries that declare an image.
const discoverImages = new Map();
function discoverImageFor(entry) {
    if (!entry.image || !window.extensions.registryImage) return Promise.resolve(null);
    if (!discoverImages.has(entry.prefix)) {
        discoverImages.set(entry.prefix, window.extensions.registryImage(entry.prefix).catch((error) => {
            console.warn(`Could not load the image for ${entry.prefix}:`, error);
            return null;
        }));
    }
    return discoverImages.get(entry.prefix);
}

// The registry entry (if any) that lists packageId -- a single-package entry as well as a bundle,
// unlike registryBundleFor above. Lets an installed package borrow its entry's image.
function registryEntryFor(packageId) {
    return discoverEntries.find((entry) => entry.packages.some((declared) => declared.packageId === packageId)) ?? null;
}

// A list item's thumbnail: the entry's initial straight away, swapped for its image once (and if)
// one arrives, so the list never waits on images and an entry without one still looks deliberate
// rather than broken. Shared by Discover's items and Installed's add-on/plugin items.
function extensionsThumbHtml(title) {
    const initial = (title || '?').replace(/^Konjugate\s+/i, '').trim().charAt(0).toUpperCase() || '?';
    return `<span class="extensionsThumb extensionsThumbPlaceholder" aria-hidden="true">${escapeHtml(initial)}</span>`;
}
function attachExtensionsImage(container, entry) {
    if (!entry) return;
    discoverImageFor(entry).then((imageUrl) => {
        const placeholder = container.querySelector('.extensionsThumbPlaceholder');
        if (!imageUrl || !placeholder) return;
        const image = document.createElement('img');
        image.className = 'extensionsThumb';
        image.alt = '';
        image.addEventListener('load', () => image.classList.add('loaded'), { once: true });
        image.src = imageUrl;
        placeholder.replaceWith(image);
    });
}
// The detail pane's cover image, cleared first so a previous selection's never lingers, and only
// filled in if the same item is still selected once the image arrives.
function showExtensionsDetailImage(image, entry, isStillSelected) {
    image.hidden = true;
    image.classList.remove('loaded');
    image.removeAttribute('src');
    if (!entry) return;
    discoverImageFor(entry).then((imageUrl) => {
        if (!imageUrl || !isStillSelected()) return;
        image.addEventListener('load', () => image.classList.add('loaded'), { once: true });
        image.src = imageUrl;
        image.hidden = false;
    });
}

// prefix#index -> Promise of a data: URL (or null), fetched once per window through the main
// process (see packageRegistryScreenshot in src/main.mjs) the first time an entry's detail pane
// opens, so browsing the list itself never downloads a screenshot.
const discoverScreenshots = new Map();
function discoverScreenshotFor(entry, index) {
    if (!window.extensions.registryScreenshot) return Promise.resolve(null);
    const key = `${entry.prefix}#${index}`;
    if (!discoverScreenshots.has(key)) {
        discoverScreenshots.set(key, window.extensions.registryScreenshot(entry.prefix, index).catch((error) => {
            console.warn(`Could not load screenshot ${index} for ${entry.prefix}:`, error);
            return null;
        }));
    }
    return discoverScreenshots.get(key);
}

// The Discover detail pane's screenshot strip and video links for entry. Screenshots that can't be
// loaded (offline, a failed download) simply don't appear rather than leaving a broken box; a
// video is just a button that asks the main process to open that entry's own link in the browser.
function showDiscoverMedia(entry, isStillSelected) {
    const strip = $('#extensionsDiscoverScreenshots');
    strip.replaceChildren();
    const screenshots = entry.screenshots ?? [];
    strip.hidden = screenshots.length === 0;
    screenshots.forEach((screenshot, index) => {
        const figure = document.createElement('figure');
        figure.className = 'extensionsScreenshot';
        figure.hidden = true;
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'extensionsScreenshotButton';
        button.setAttribute('aria-label', `Enlarge or shrink screenshot: ${screenshot.caption}`);
        const image = document.createElement('img');
        image.alt = screenshot.caption;
        button.append(image);
        button.addEventListener('click', () => figure.classList.toggle('expanded'));
        const caption = document.createElement('figcaption');
        caption.textContent = screenshot.caption;
        figure.append(button, caption);
        strip.append(figure);
        discoverScreenshotFor(entry, index).then((imageUrl) => {
            if (!imageUrl || !isStillSelected()) return;
            image.addEventListener('load', () => image.classList.add('loaded'), { once: true });
            image.src = imageUrl;
            figure.hidden = false;
        });
    });

    const videos = entry.videos ?? [];
    $('#extensionsDiscoverVideos').hidden = videos.length === 0;
    $('#extensionsDiscoverVideoList').replaceChildren(...videos.map((video, index) => {
        const item = document.createElement('li');
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'extensionsVideoLink';
        button.textContent = `\u25B6 ${video.title}`;
        button.title = 'Opens in your browser';
        button.addEventListener('click', () => window.extensions.openRegistryVideo?.(entry.prefix, index));
        item.append(button);
        return item;
    }));
}

function discoverEntryList(registry) {
    // Only entries that actually offer something to install belong in the Explorer -- a
    // reservation-only entry (identity fields but no packages/downloadUrl) is real per the
    // registry's design but has nothing for a user to discover yet.
    return Object.entries(registry?.prefixes ?? {})
        .map(([prefix, entry]) => ({ prefix, ...entry }))
        .filter((entry) => Array.isArray(entry.packages) && entry.packages.length && entry.downloadUrl);
}

function renderDiscoverDomains() {
    const domains = ['all', ...new Set(discoverEntries.map((entry) => entry.domain).filter(Boolean))];
    $('#extensionsDomains').replaceChildren(...domains.map((domain) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = domain === 'all' ? 'All' : domainLabel(domain);
        button.classList.toggle('active', domain === discoverDomain);
        button.addEventListener('click', () => {
            discoverDomain = domain;
            $$('#extensionsDomains button').forEach((chip) => chip.classList.toggle('active', chip === button));
            renderDiscoverResults();
        });
        return button;
    }));
}

function renderDiscoverResults() {
    const matches = discoverEntries.filter((entry) => discoverDomain === 'all' || entry.domain === discoverDomain);
    if (discoverSelectedPrefix && !matches.some((entry) => entry.prefix === discoverSelectedPrefix)) {
        discoverSelectedPrefix = null;
        renderDiscoverDetail();
    }
    $('#extensionsResults').replaceChildren(...matches.map((entry) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'examplesExplorerItem extensionsItem discoverItem';
        button.dataset.discoverPrefix = entry.prefix;
        button.classList.toggle('selected', entry.prefix === discoverSelectedPrefix);
        const installedCount = entry.packages.filter((declared) => isPackageIdInstalled(declared.packageId)).length;
        const allInstalled = installedCount === entry.packages.length;
        const partialInstalled = installedCount > 0 && !allInstalled;
        // A bare package count only says something once there's more than one to count -- the
        // common single-package case gets the domain instead, which actually helps scanning a
        // longer list. Any piece that has nothing to say is left out rather than shown empty.
        const metaParts = [
            entry.domain ? domainLabel(entry.domain) : null,
            entry.packages.length > 1 ? `${entry.packages.length} packages` : null,
            allInstalled ? 'Installed' : partialInstalled ? `${installedCount}/${entry.packages.length} Installed` : null
        ].filter(Boolean);
        // Discover mixes add-ons and plugins with no tab to separate them the way Installed does,
        // so the type is worth a small badge here -- a bundle (Fintech) gets one badge per type it
        // actually contains, not necessarily just one.
        const typeBadges = [...new Set(entry.packages.map((declared) => declared.packageType))].sort()
            .map((type) => `<span class="extensionsBadge">${type}</span>`).join('');
        button.classList.add('extensionsItemWithThumb');
        button.innerHTML = extensionsThumbHtml(entry.title || entry.prefix)
            + `<div class="discoverItemBadges">${typeBadges}</div>`
            + `<b>${escapeHtml(entry.title || entry.prefix)}</b>`
            + (entry.description ? `<p class="extensionsItemDescription">${escapeHtml(entry.description)}</p>` : '')
            + (metaParts.length ? `<span class="extensionsItemMeta">${escapeHtml(metaParts.join(' · '))}</span>` : '');
        attachExtensionsImage(button, entry);
        return button;
    }));
    $('#extensionsEmpty').textContent = 'No add-ons match the registry filters.';
    $('#extensionsEmpty').hidden = matches.length > 0;
}

function renderDiscoverDetail() {
    $('#extensionsDetailContent').hidden = true;
    const entry = discoverEntries.find((candidate) => candidate.prefix === discoverSelectedPrefix);
    $('#extensionsDetailEmpty').hidden = Boolean(entry);
    $('#extensionsDiscoverDetailContent').hidden = !entry;
    if (!entry) return;

    showExtensionsDetailImage($('#extensionsDiscoverDetailImage'), entry, () => discoverSelectedPrefix === entry.prefix);
    showDiscoverMedia(entry, () => discoverSelectedPrefix === entry.prefix);

    const domainBadge = $('#extensionsDiscoverDetailDomain');
    if (entry.domain) {
        domainBadge.hidden = false;
        domainBadge.textContent = domainLabel(entry.domain);
    } else {
        domainBadge.hidden = true;
    }

    $('#extensionsDiscoverDetailTitle').textContent = entry.title || entry.prefix;
    $('#extensionsDiscoverDetailDescription').textContent = entry.description || 'No description available.';
    $('#extensionsDiscoverDetailLicense').textContent = entry.license || 'Not specified';

    const commercialRow = $('#extensionsDiscoverDetailCommercialLicenseRow');
    if (entry.commercialLicenseUrl) {
        commercialRow.hidden = false;
        $('#extensionsDiscoverDetailCommercialLicense').innerHTML = `<a href="#" data-external-url="${escapeHtml(entry.commercialLicenseUrl)}">View license</a>`;
    } else {
        commercialRow.hidden = true;
    }

    $('#extensionsDiscoverDetailOwner').textContent = entry.owner;

    const contactRow = $('#extensionsDiscoverDetailContactRow');
    if (entry.contact) {
        contactRow.hidden = false;
        if (entry.contact.startsWith('http://') || entry.contact.startsWith('https://')) {
            $('#extensionsDiscoverDetailContact').innerHTML = `<a href="#" data-external-url="${escapeHtml(entry.contact)}">${escapeHtml(entry.contact)}</a>`;
        } else {
            $('#extensionsDiscoverDetailContact').textContent = entry.contact;
        }
    } else {
        contactRow.hidden = true;
    }

    const urlRow = $('#extensionsDiscoverDetailUrlRow');
    if (entry.url) {
        urlRow.hidden = false;
        $('#extensionsDiscoverDetailUrl').innerHTML = `<a href="#" data-external-url="${escapeHtml(entry.url)}">${escapeHtml(entry.url)}</a>`;
    } else {
        urlRow.hidden = true;
    }

    $('#extensionsDiscoverDetailPackages').replaceChildren(...entry.packages.map((declared) => {
        const item = document.createElement('li');
        const installed = isPackageIdInstalled(declared.packageId);
        item.textContent = `${declared.packageType} · ${declared.packageId}${installed ? ' (installed)' : ''}`;
        return item;
    }));

    const installedCount = entry.packages.filter((declared) => isPackageIdInstalled(declared.packageId)).length;
    const allInstalled = installedCount === entry.packages.length;
    const partialInstalled = installedCount > 0 && !allInstalled;
    const statusNote = $('#extensionsDiscoverDetailStatus');
    const installBtn = $('#extensionsDiscoverInstall');

    if (allInstalled) {
        statusNote.hidden = false;
        statusNote.textContent = 'All packages in this entry are installed.';
        installBtn.textContent = 'Installed';
        installBtn.disabled = true;
    } else if (partialInstalled) {
        statusNote.hidden = false;
        statusNote.textContent = `Partially installed (${installedCount} of ${entry.packages.length} packages on disk).`;
        installBtn.textContent = 'Trust publisher and install';
        installBtn.disabled = false;
    } else {
        statusNote.hidden = true;
        installBtn.textContent = 'Trust publisher and install';
        installBtn.disabled = false;
    }
}

async function refreshExtensionsList() {
    extensionsEntries = await window.extensions.list();
    renderExtensionsResults();
    renderExtensionsDetail();
}

// Pure data fetch, no DOM -- kept separate from loadDiscoverRegistry (below) so Installed mode can
// populate discoverEntries for bundle cross-referencing (registryBundleFor/bundleWarningFor) without
// touching any Discover-mode-only element. Cached in discoverRegistry/discoverEntries across calls
// within one dialog session; pass force:true to bypass that (used when re-entering Discover mode
// deliberately isn't needed today, but keeps this symmetrical with the old lazy-load behavior).
async function ensureDiscoverRegistry({ force = false } = {}) {
    if (discoverRegistry && !force) return;
    const { registry, stale, staleReason } = await window.extensions.discoverRegistry();
    discoverRegistry = registry;
    discoverEntries = discoverEntryList(registry);
    discoverStale = stale;
    if (stale) console.warn('Showing a cached registry listing:', staleReason);
}

async function loadDiscoverRegistry({ force = false } = {}) {
    try {
        await ensureDiscoverRegistry({ force });
        renderDiscoverDomains();
        renderDiscoverResults();
        renderDiscoverDetail();
        $('#extensionsDiscoverStale').hidden = !discoverStale;
    } catch (error) {
        console.error(error);
        $('#extensionsDomains').replaceChildren();
        $('#extensionsResults').replaceChildren();
        $('#extensionsEmpty').textContent = `Could not reach the registry: ${error.message}`;
        $('#extensionsEmpty').hidden = false;
    }
}

async function openExtensionsDialog() {
    try {
        await refreshExtensionsList();
    } catch (error) {
        console.error(error);
        return;
    }
    extensionsMode = 'installed';
    // The title bar badge says there are updates; opening the dialog from it lands on them, with the first
    // one selected so its detail and Update button are already showing.
    const firstOutdated = installedOutdated()[0];
    extensionsTab = firstOutdated ? 'updates' : 'addon';
    extensionsSelectedKey = firstOutdated ? extensionsPackageKey(firstOutdated) : null;
    discoverSelectedPrefix = null;
    $('#extensionsRestartNotice').hidden = true;
    $('#extensionsDiscoverStale').hidden = true;
    $$('.extensionsModes .extensionsTab').forEach((mode) => mode.classList.toggle('active', mode.dataset.extensionsMode === extensionsMode));
    $('#extensionsTabs').hidden = false;
    $('#extensionsDomains').hidden = true;
    $$('#extensionsTabs .extensionsTab').forEach((tab) => tab.classList.toggle('active', tab.dataset.extensionsTab === extensionsTab));
    renderExtensionsResults();
    renderExtensionsDetail();
    $('#extensionsDialog').showModal();
    // Best-effort and non-blocking: the dialog opens immediately against local data, and the
    // Installed side's bundle cross-reference (registryBundleFor) and borrowed descriptions
    // (registryDescriptionFor) fill in silently once this resolves, rather than making every
    // dialog-open wait on a network round trip it doesn't need to show anything. Failure here just
    // means no registry-sourced info this session -- advisory only, per the design principles in
    // docs/extensionsExplorer.md.
    ensureDiscoverRegistry().then(() => {
        if (extensionsMode === 'installed') {
            renderExtensionsResults();
            renderExtensionsDetail();
        }
    }).catch(() => {});
    // A separate background fetch from the one above -- this is its own round of GitHub Releases
    // API calls (one per installed, registry-known entry), not just the one registry listing fetch,
    // so it's kept independent rather than chained after it.
    ensurePackageUpdates().then(() => {
        if (extensionsMode === 'installed') {
            renderExtensionsResults();
            renderExtensionsDetail();
        }
    }).catch(() => {});
}

$$('.extensionsModes .extensionsTab').forEach((modeButton) => modeButton.addEventListener('click', () => {
    extensionsMode = modeButton.dataset.extensionsMode;
    $$('.extensionsModes .extensionsTab').forEach((candidate) => candidate.classList.toggle('active', candidate === modeButton));
    $('#extensionsTabs').hidden = extensionsMode !== 'installed';
    $('#extensionsDomains').hidden = extensionsMode !== 'discover';
    extensionsSelectedKey = null;
    discoverSelectedPrefix = null;
    if (extensionsMode === 'discover') { renderExtensionsUpdates(); loadDiscoverRegistry(); }
    else { renderExtensionsResults(); renderExtensionsDetail(); }
}));

$('#extensionsUpdatesShow').addEventListener('click', () => {
    extensionsTab = 'updates';
    extensionsSelectedKey = null;
    renderExtensionsResults();
    renderExtensionsDetail();
});

$('#extensionsUpdateAll').addEventListener('click', async () => {
    const plan = updatePlan(packageUpdates);
    if (updatingAll || !plan.length) return;
    updatingAll = true;
    const button = $('#extensionsUpdateAll');
    button.disabled = true;
    $('#extensionsUpdate').disabled = true;
    const outcomes = [];
    try {
        await ensureDiscoverRegistry();
        // One registry entry at a time, each installed whole (a bundle's packages update in lockstep).
        // A failure is recorded and the rest carry on: one broken download must not strand the others.
        for (const [index, step] of plan.entries()) {
            button.textContent = `Updating ${index + 1} of ${plan.length}…`;
            try {
                const registryEntry = discoverEntries.find((candidate) => candidate.prefix === step.prefix);
                if (!registryEntry) throw new Error(`${step.prefix} is no longer listed in the registry.`);
                const results = await window.extensions.installFromRegistry(registryEntry, discoverRegistry);
                outcomes.push({ ...step, results: results.map((result) => ({ packageId: result.packageId, version: result.version })) });
            } catch (error) {
                outcomes.push({ ...step, error: error.message });
            }
        }
    } catch (error) {
        outcomes.push(...plan.slice(outcomes.length).map((step) => ({ ...step, error: error.message })));
    } finally {
        updatingAll = false;
        button.textContent = 'Update all';
        await refreshExtensionsList().catch(() => {});
        if (!extensionsEntries.some((entry) => extensionsPackageKey(entry) === extensionsSelectedKey)) extensionsSelectedKey = null;
        await ensurePackageUpdates().catch(() => {});
        renderExtensionsResults();
        renderExtensionsDetail();
        const summary = summarizeUpdateAll(outcomes);
        if (summary.message) showExtensionsNotice(summary.message, summary.severity);
    }
});

$$('#extensionsTabs .extensionsTab').forEach((tab) => tab.addEventListener('click', () => {
    extensionsTab = tab.dataset.extensionsTab;
    extensionsSelectedKey = null;
    $$('#extensionsTabs .extensionsTab').forEach((candidate) => candidate.classList.toggle('active', candidate === tab));
    renderExtensionsResults();
    renderExtensionsDetail();
}));

$('#extensionsResults').addEventListener('click', (event) => {
    const discoverButton = event.target.closest('[data-discover-prefix]');
    if (discoverButton) {
        discoverSelectedPrefix = discoverButton.dataset.discoverPrefix;
        $$('#extensionsResults .extensionsItem').forEach((item) => item.classList.toggle('selected', item === discoverButton));
        renderDiscoverDetail();
        return;
    }
    const button = event.target.closest('[data-package-key]');
    if (!button) return;
    extensionsSelectedKey = button.dataset.packageKey;
    $$('#extensionsResults .extensionsItem').forEach((item) => item.classList.toggle('selected', item === button));
    renderExtensionsDetail();
});

$('#extensionsInstall').addEventListener('click', async () => {
    try {
        const installed = await window.extensions.install();
        if (!installed) return;
        extensionsMode = 'installed';
        extensionsTab = installed.packageType;
        extensionsSelectedKey = `${installed.packageType}:${installed.packageId}:${installed.version}`;
        await refreshExtensionsList();
        $$('.extensionsModes .extensionsTab').forEach((mode) => mode.classList.toggle('active', mode.dataset.extensionsMode === extensionsMode));
        $('#extensionsTabs').hidden = false;
        $('#extensionsDomains').hidden = true;
        $$('#extensionsTabs .extensionsTab').forEach((tab) => tab.classList.toggle('active', tab.dataset.extensionsTab === extensionsTab));
        renderExtensionsResults();
        renderExtensionsDetail();
        showExtensionsNotice(installed.packageType === 'fmu'
            ? `Installed ${installed.packageId} ${installed.version}. It's ready to reference from a node's implementation immediately -- no restart needed.`
            : `Installed ${installed.packageId} ${installed.version}. Restart Konjugate to activate it.`);
    } catch (error) {
        showExtensionsNotice(`Installation failed: ${error.message}`);
    }
});

$('#extensionsDiscoverInstall').addEventListener('click', async () => {
    const entry = discoverEntries.find((candidate) => candidate.prefix === discoverSelectedPrefix);
    if (!entry) return;
    const installBtn = $('#extensionsDiscoverInstall');
    installBtn.disabled = true;
    installBtn.textContent = 'Installing…';
    const verificationLabel = { verified: 'verified', unsigned: 'unsigned', unclaimed: 'unclaimed publisher', invalid: 'signature invalid -- proceed with caution' };
    try {
        const results = await window.extensions.installFromRegistry(entry, discoverRegistry);
        await refreshExtensionsList();
        renderDiscoverResults();
        renderDiscoverDetail();
        const summary = results.map((result) => `${result.packageId} ${result.version} (${verificationLabel[result.verification.status] ?? result.verification.status})`).join(', ');
        const hasInvalid = results.some((r) => r.verification?.status === 'invalid');
        const heldBack = heldBackSentence(results);
        showExtensionsNotice(
            `Installed ${summary}.${heldBack ? ` ${heldBack}` : ''} Restart Konjugate to activate it.`,
            hasInvalid || heldBack ? 'warning' : null
        );
    } catch (error) {
        showExtensionsNotice(`Installation failed: ${error.message}`, 'error');
        renderDiscoverDetail();
    }
});

$('#extensionsDiscoverDetailContent').addEventListener('click', (event) => {
    const link = event.target.closest('[data-external-url]');
    if (link) {
        event.preventDefault();
        window.extensions?.openRegistryLink?.(link.dataset.externalUrl);
    }
});

$('#extensionsUpdate').addEventListener('click', async () => {
    const entry = extensionsEntries.find((candidate) => extensionsPackageKey(candidate) === extensionsSelectedKey);
    const update = entry && updateInfoFor(entry.packageId);
    if (!update || updatingAll) return;
    const button = $('#extensionsUpdate');
    button.disabled = true;
    button.textContent = 'Updating…';
    try {
        // The update check and the registry fetch run independently on dialog open, so the check can
        // finish (showing this button) before discoverEntries has loaded -- wait for it rather than
        // silently doing nothing.
        await ensureDiscoverRegistry();
        const registryEntry = discoverEntries.find((candidate) => candidate.prefix === update.prefix);
        if (!registryEntry) throw new Error(`${update.prefix} is no longer listed in the registry.`);
        // The whole entry, not just entry.packageId -- a bundle updates in lockstep (see the
        // Multi-package bundles section of docs/extensionsExplorer.md), so updating one half means
        // reinstalling the other too, exactly like a fresh Discover install of the same entry.
        const results = await window.extensions.installFromRegistry(registryEntry, discoverRegistry);
        // Keep the same package selected at its new version, rather than letting the old version's
        // key (no longer on disk if the install replaced it) drop the detail pane back to empty.
        const updated = results.find((result) => result.packageId === entry.packageId);
        if (updated) extensionsSelectedKey = `${updated.packageType}:${updated.packageId}:${updated.version}`;
        await refreshExtensionsList();
        await ensurePackageUpdates().catch(() => {});
        renderExtensionsResults();
        renderExtensionsDetail();
        // The update check reads the release's *tag*, but what gets installed is whatever version the
        // package inside that release declares -- if the publisher bumped the tag without rebuilding
        // the package at the new version, this "update" just reinstalled the same version, and the
        // check will keep offering it. Say so plainly instead of claiming an update happened.
        const stale = results.filter((result) => result.version !== update.latestVersion);
        if (stale.length) {
            const found = stale.map((result) => `${result.packageId} ${result.version}`).join(', ');
            showExtensionsNotice(`The latest release is tagged ${update.latestVersion}, but the package inside it is still ${found} -- nothing was actually updated. The publisher needs to rebuild that release with the package version bumped to match its tag.`, 'warning');
            return;
        }
        const summary = results.map((result) => `${result.packageId} ${result.version}`).join(', ');
        const heldBack = heldBackSentence(results);
        showExtensionsNotice(`Updated ${summary}.${heldBack ? ` ${heldBack}` : ''} Restart Konjugate to activate it.`);
    } catch (error) {
        button.disabled = false;
        button.textContent = 'Update';
        showExtensionsNotice(`Update failed: ${error.message}`, 'error');
    }
});

// "Install compatible version" for an installed package this Konjugate cannot load: the registry install picks the newest release
// this Konjugate can use and replaces the installed version with it (docs/proposals/packageCompatibility.md).
$('#extensionsInstallCompatible').addEventListener('click', async () => {
    const entry = extensionsEntries.find((candidate) => extensionsPackageKey(candidate) === extensionsSelectedKey);
    if (!entry?.incompatible) return;
    const button = $('#extensionsInstallCompatible');
    button.disabled = true;
    button.textContent = 'Installing…';
    try {
        await ensureDiscoverRegistry();
        const registryEntry = registryEntryFor(entry.packageId);
        if (!registryEntry) throw new Error('This package is not in the registry, so there is no other release to install. Install a compatible .kja or .kjp file, or uninstall it.');
        const results = await window.extensions.installFromRegistry(registryEntry, discoverRegistry);
        const replaced = results.find((result) => result.packageId === entry.packageId);
        if (replaced) extensionsSelectedKey = `${replaced.packageType}:${replaced.packageId}:${replaced.version}`;
        await refreshExtensionsList();
        await ensurePackageUpdates().catch(() => {});
        renderExtensionsResults();
        renderExtensionsDetail();
        const summary = results.map((result) => `${result.packageId} ${result.version}`).join(', ');
        const heldBack = heldBackSentence(results);
        showExtensionsNotice(`Installed ${summary}.${heldBack ? ` ${heldBack}` : ''} Restart Konjugate to activate it.`, heldBack ? 'warning' : null);
    } catch (error) {
        button.disabled = false;
        button.textContent = 'Install compatible version';
        showExtensionsNotice(`Could not install a compatible version: ${error.message}`, 'error');
    }
});

$('#extensionsToggleEnabled').addEventListener('click', async () => {
    const entry = extensionsEntries.find((candidate) => extensionsPackageKey(candidate) === extensionsSelectedKey);
    if (!entry) return;
    // Disabling gets the identical warning uninstalling does, not a lighter touch just because it's
    // reversible -- a project needing both bundle halves fails to resolve the same way either way
    // (see the Multi-package bundles section of docs/extensionsExplorer.md). Enabling never needs it.
    if (entry.enabled) {
        const bundleWarning = bundleWarningFor(entry, 'disabling');
        if (bundleWarning && !window.confirm(`Disable ${entry.name} ${entry.version}? ${bundleWarning}`)) return;
    }
    try {
        await window.extensions.setEnabled(entry.packageType, entry.packageId, entry.version, !entry.enabled);
        const verb = entry.enabled ? 'Disabled' : 'Enabled';
        await refreshExtensionsList();
        showExtensionsNotice(`${verb} ${entry.packageId} ${entry.version}. This takes effect immediately -- no restart needed.`);
    } catch (error) {
        showExtensionsNotice(`Could not update: ${error.message}`);
    }
});

$('#extensionsUninstall').addEventListener('click', async () => {
    const entry = extensionsEntries.find((candidate) => extensionsPackageKey(candidate) === extensionsSelectedKey);
    if (!entry) return;
    const bundleWarning = bundleWarningFor(entry, 'uninstalling');
    const question = bundleWarning
        ? `Uninstall ${entry.name} ${entry.version}? ${bundleWarning} This cannot be undone.`
        : `Uninstall ${entry.name} ${entry.version}? This cannot be undone.`;
    if (!window.confirm(question)) return;
    try {
        await window.extensions.uninstall(entry.packageType, entry.packageId, entry.version);
        extensionsSelectedKey = null;
        await refreshExtensionsList();
        // Drop an uninstalled package from the update badge/count right away (the main-process cache
        // was already cleared by the uninstall itself).
        if (updateInfoFor(entry.packageId)) ensurePackageUpdates().then(() => { renderExtensionsResults(); renderExtensionsDetail(); }).catch(() => {});
        showExtensionsNotice(entry.packageType === 'fmu'
            ? `Uninstalled ${entry.packageId} ${entry.version}. Any node still referencing it will fail to run until it is reinstalled or the reference is removed.`
            : `Uninstalled ${entry.packageId} ${entry.version}. Restart Konjugate if it was active.`);
    } catch (error) {
        showExtensionsNotice(`Uninstall failed: ${error.message}`);
    }
});

$('#extensionsClose').addEventListener('click', () => $('#extensionsDialog').close());

$('#newWindowButton').addEventListener('click', () => window.windowControls.newWindow());
$('#loadButton').addEventListener('click', openProject);
$('#extensionsButton').addEventListener('click', openExtensionsDialog);
$('#saveButton').addEventListener('click', () => saveProject());
$('#saveEncryptedButton').addEventListener('click', async (event) => {
    if (!currentProjectPassword) {
        const password = await requestProjectPassword({ confirm: true });
        if (password !== null) await saveProject(true, password);
        return;
    }
    const menu = $('#encryptionMenu');
    const rect = event.currentTarget.getBoundingClientRect();
    menu.style.left = `${Math.max(8, rect.right - 245)}px`;
    menu.style.top = `${rect.bottom + 5}px`;
    menu.classList.toggle('hidden');
});

async function verifyCurrentProjectPassword(actionLabel) {
    let error = '';
    while (true) {
        const password = await requestProjectPassword({
            error,
            title: actionLabel,
            hint: `Enter the current password for ${currentProjectFilename}.`,
            submitLabel: 'Continue'
        });
        if (password === null) return false;
        if (password === currentProjectPassword) return true;
        error = 'The current password is incorrect.';
    }
}

$('#changePasswordButton').addEventListener('click', async () => {
    $('#encryptionMenu').classList.add('hidden');
    if (!await verifyCurrentProjectPassword('Change encryption password')) return;
    const password = await requestProjectPassword({
        confirm: true,
        title: `Change password for ${currentProjectFilename}`,
        hint: 'Choose a new password. It cannot be recovered if you forget it.',
        submitLabel: 'Change password'
    });
    if (password !== null) await saveProject(false, password);
});

$('#removeEncryptionButton').addEventListener('click', async () => {
    $('#encryptionMenu').classList.add('hidden');
    if (!await verifyCurrentProjectPassword('Remove encryption')) return;
    await saveProject(false, null);
});

$('#encryptionMenu').addEventListener('pointerdown', (event) => event.stopPropagation());

$('#diagnosticsButton').addEventListener('click', (event) => {
    event.stopPropagation();
    const panel = $('#diagnosticsPanel');
    const rect = event.currentTarget.getBoundingClientRect();
    panel.style.left = `${Math.max(8, rect.right - 320)}px`;
    panel.style.top = `${rect.bottom + 5}px`;
    const opening = panel.classList.contains('hidden');
    panel.classList.toggle('hidden');
    if (opening) {
        renderDiagnosticsList();
        diagnosticsUnseenCount = 0;
        renderDiagnosticsBadge();
    }
});
$('#diagnosticsPanel').addEventListener('pointerdown', (event) => event.stopPropagation());
$('#diagnosticsClearButton').addEventListener('click', () => {
    diagnosticsEntries.length = 0;
    renderDiagnosticsList();
});
window.addEventListener('pointerdown', (event) => {
    if (!event.target.closest('#diagnosticsButton') && !event.target.closest('#diagnosticsPanel')) {
        $('#diagnosticsPanel').classList.add('hidden');
    }
});
$('#exampleButton').addEventListener('click', openExamplesExplorer);
$('#examplesExplorerSearch').addEventListener('input', renderExamplesExplorerResults);
$('#examplesExplorerResults').addEventListener('click', (event) => {
    const button = event.target.closest('[data-example-id]');
    if (!button) return;
    examplesExplorerSelectedId = button.dataset.exampleId;
    $$('#examplesExplorerResults .examplesExplorerItem').forEach((item) => item.classList.toggle('selected', item === button));
    renderExamplesExplorerDetail();
});
$('#examplesExplorerLoad').addEventListener('click', () => {
    if (examplesExplorerSelectedId) loadExample(examplesExplorerSelectedId);
});
$('#examplesExplorerCancel').addEventListener('click', () => $('#examplesExplorerDialog').close());

$$('[data-add-kind]').forEach((button) => {
    button.addEventListener('click', () => {
        const rect = $('#addPalette').getBoundingClientRect();
        if (button.dataset.addKind === 'node') openNodeBuilder(rect.left, rect.top);
        else openEdgeBuilder(rect.left, rect.top);
    });
});

$('#addStateVariable').addEventListener('click', () => addStateVariableRow());
$('#addSourceTerm').addEventListener('click', addSourceTermRow);
$('#addEdgeParameter').addEventListener('click', () => addEdgeParameterRow());
$('#edgeSource').addEventListener('change', refreshStateReferences);
$('#edgeTarget').addEventListener('change', refreshStateReferences);
$('#edgeMathField').addEventListener('input', (event) => {
    $('#edgeEquation').value = event.target.value;
    renderBuilderEquationDiagnostics();
});
$('#edgeEquation').addEventListener('input', (event) => {
    $('#edgeMathField').setValue(event.target.value, { silenceNotifications: true });
    renderBuilderEquationDiagnostics();
});
$$('[data-builder-equation-mode]').forEach((button) => button.addEventListener('click', () => {
    $$('[data-builder-equation-mode]').forEach((candidate) => candidate.classList.toggle('active', candidate === button));
    const latexMode = button.dataset.builderEquationMode === 'latex';
    $('#edgeMathField').hidden = latexMode;
    $('#edgeEquation').hidden = !latexMode;
    (latexMode ? $('#edgeEquation') : $('#edgeMathField')).focus();
}));
function builderProviderBindingKeys() {
    return $$('#providerBindingRows .providerBindingRow [data-field="key"]').map((input) => ({ key: input.value }));
}

$('#edgeImplementationKind').addEventListener('change', (event) => {
    const kind = event.target.value;
    const isEquation = kind === 'equation';
    $('#edgeEquationHeading').hidden = !isEquation;
    $('#builderEquationDiagnostics').hidden = !isEquation;
    $('#edgeReferencePicker').hidden = !isEquation;
    $('#edgeProviderSection').hidden = isEquation;
    // The math-field/latex-textarea toggle their own `hidden` directly (matching the existing
    // Visual/LaTeX mode toggle) rather than through a hidden ancestor: MathLive's custom element
    // does not reliably accept focus again once an ancestor of it has been display:none'd.
    const latexMode = $('[data-builder-equation-mode="latex"]').classList.contains('active');
    $('#edgeMathField').hidden = !isEquation || latexMode;
    $('#edgeEquation').hidden = !isEquation || !latexMode;
    if (!isEquation && !$('#edgeProviderSource').value.trim()) {
        $('#edgeProviderSource').value = defaultProviderSource(
            kind, builderProviderBindingKeys(), $('#providerOutputKey').value, $('#newEdgeName').value);
    }
    $('#insertProviderTemplate').hidden = !$('#edgeProviderSource').value.trim();
});
$('#insertProviderTemplate').addEventListener('click', () => {
    if ($('#edgeProviderSource').value.trim() &&
        !window.confirm('Replace the current provider source with a freshly generated template?')) return;
    $('#edgeProviderSource').value = defaultProviderSource(
        $('#edgeImplementationKind').value, builderProviderBindingKeys(), $('#providerOutputKey').value, $('#newEdgeName').value);
    $('#insertProviderTemplate').hidden = !$('#edgeProviderSource').value.trim();
});
$('#edgeProviderSource').addEventListener('input', (event) => {
    $('#insertProviderTemplate').hidden = !event.target.value.trim();
});
$('#openProviderEditor').addEventListener('click', () => {
    providerEditTarget = { type: 'builder' };
    window.providerEditor.openWindow({
        source: $('#edgeProviderSource').value,
        kind: $('#edgeImplementationKind').value,
        title: $('#newEdgeName').value
    });
});
$('#addProviderBinding').addEventListener('click', () => addProviderBindingRow());
$('#builderBrowseShapeLibrary').addEventListener('click', () => openShapeLibrary('builder'));
$('#nodeGeometryFile').addEventListener('change', async (event) => {
    const [file] = event.target.files;
    if (!file) return;
    const status = $('#geometryImportStatus');
    status.classList.remove('error');
    status.classList.add('loading');
    status.textContent = `Loading ${file.name}…`;
    $('#createNode').disabled = true;
    try {
        const geometry = await importNodeGeometry(file);
        pendingImportedGeometry?.dispose();
        pendingImportedGeometry = geometry;
        pendingGeometryFileName = file.name;
        $('#newNodeShape').value = 'imported';
        status.textContent = `${file.name} ready`;
        await saveUploadToShapeLibrary(file, status);
    } catch (error) {
        pendingImportedGeometry?.dispose();
        pendingImportedGeometry = null;
        pendingGeometryFileName = '';
        status.classList.add('error');
        status.textContent = error.message;
    } finally {
        status.classList.remove('loading');
        $('#createNode').disabled = false;
    }
});
$$('[data-pick-endpoint]').forEach((button) => {
    button.addEventListener('click', () => startEndpointPick(button.dataset.pickEndpoint));
});
$('#cancelEndpointPick').addEventListener('click', finishEndpointPick);
$('#connectFromNode').addEventListener('click', () => {
    if (!activeResult && selectedNode) connectFromNode(selectedNode);
});

// The position component (x=0, y=1, z=2) every currently visible node happens to share, or null
// if they don't all agree -- used so a freshly created node lands in whatever plane the rest of
// the model is already sitting in, rather than always the same fixed default regardless of what's
// on screen (most relevant while 2D-locked, but not conditional on it: a model that's flat for
// any reason should stay flat for a new node the same way pasting now respects it).
function sharedVisibleNodeAxisValue(axisIndex) {
    // Requires at least 2 nodes to agree, not 1 -- a lone existing node trivially "shares" every
    // axis with itself, which would otherwise drop every subsequent new node exactly on top of it
    // instead of at a predictable default.
    const values = model.nodes
        .filter((node) => !node.deleted && nodeObjects.get(node.id)?.visible !== false)
        .map((node) => nodeObjects.get(node.id).position.getComponent(axisIndex));
    return values.length > 1 && values.every((value) => value === values[0]) ? values[0] : null;
}

$('#createNode').addEventListener('click', () => {
    if (activeResult) return;
    $('#addNodeError').textContent = '';
    const states = stateVariablesFromBuilder();
    if (!states.length) {
        $('#addNodeError').textContent = 'Add at least one state variable before creating the node.';
        $('#stateVariableRows input')?.focus();
        return;
    }
    const invalidSymbol = states.find((state) => !modelSymbolPattern.test(state.symbol));
    if (invalidSymbol) {
        $('#addNodeError').textContent =
            `"${invalidSymbol.symbol}" is not a valid symbol -- symbols must start with a lowercase letter and contain only letters and digits (e.g. "temperature", not "Temperature").`;
        $('.stateVariableRow [data-field="symbol"]')?.focus();
        return;
    }
    if (new Set(states.map((state) => state.symbol)).size !== states.length) {
        $('#addNodeError').textContent = 'Each state variable needs its own unique symbol.';
        $('.stateVariableRow [data-field="symbol"]')?.focus();
        return;
    }
    if ($('#newNodeShape').value === 'imported' && !pendingImportedGeometry) {
        $('#nodeGeometryFile').click();
        return;
    }

    const id = allocateModelEntityId();
    const resolvedStates = states.map((state) => ({
        id: allocateModelEntityId(),
        label: state.name,
        symbol: state.symbol,
        initialValue: Number(state.value) || 0,
        unit: state.unit,
        value: stateValueText(Number(state.value) || 0, state.unit).text, exactValue: stateValueText(Number(state.value) || 0, state.unit).exact
    }));
    const symbolToStateId = new Map(resolvedStates.map((state) => [state.symbol, state.id]));
    const definition = {
        id,
        title: $('#newNodeName').value.trim() || 'Untitled node',
        type: 'Custom node',
        shape: $('#newNodeShape').value,
        importedGeometry: pendingImportedGeometry?.clone() ?? null,
        geometryFileName: pendingGeometryFileName || null,
        position: [
            sharedVisibleNodeAxisValue(0) ?? 0,
            sharedVisibleNodeAxisValue(1) ?? -0.7,
            sharedVisibleNodeAxisValue(2) ?? 0
        ],
        subsystemId: activeSubsystemId,
        deleted: false,
        enabled: true,
        color: Number.parseInt($('#newNodeColor').value.replace('#', ''), 16),
        states: resolvedStates,
        sourceTerms: $$('.sourceTermRow').map((row) => {
            const stateSymbol = $('.sourceState', row).value;
            const kind = $('.sourceTermKind', row)?.value ?? 'equation';
            const termId = allocateModelEntityId();
            if (kind === 'equation') {
                return { id: termId, state: stateSymbol, expression: $('.sourceExpression', row).value.trim(), parameters: [] };
            }
            const bindings = $$('.providerBindingRow', row).map((bindingRow) => ({
                key: $('[data-field="key"]', bindingRow).value.trim(),
                kind: 'state',
                stateId: symbolToStateId.get($('[data-field="reference"]', bindingRow).value.replace('state:', ''))
            })).filter((binding) => binding.stateId);
            return {
                id: termId,
                state: stateSymbol,
                expression: '',
                parameters: [],
                implementation: {
                    kind,
                    providerApiVersion: 1,
                    source: $('.sourceTermProviderSource', row).value,
                    bindings,
                    output: { key: $('.sourceTermProviderOutputKey', row).value.trim(), stateId: symbolToStateId.get(stateSymbol) }
                }
            };
        }).filter((term) => term.state && (term.expression || term.implementation)),
        substepsPerGlobalStep: 1
    };

    hideCards();
    insertNodeDefinition(definition, { attachCurrentTransform: true });
    pendingImportedGeometry?.dispose();
    pendingImportedGeometry = null;
    pendingGeometryFileName = '';
});

$('#createEdge').addEventListener('click', () => {
    if (activeResult) return;
    $('#addEdgeError').textContent = '';
    const source = Number($('#edgeSource').value);
    const target = Number($('#edgeTarget').value);
    if (!source || !target) {
        $('#addEdgeError').textContent = 'Choose both a source and target node.';
        (source ? $('#edgeTarget') : $('#edgeSource')).focus();
        return;
    }
    if (source === target) {
        $('#addEdgeError').textContent = 'An edge must connect two different nodes.';
        $('#edgeTarget').focus();
        return;
    }

    const parameters = $$('.parameterRow').map((row) => ({
        id: allocateModelEntityId(),
        name: $('[data-field="name"]', row).value.trim(),
        symbol: $('[data-field="symbol"]', row).value.trim(),
        value: Number($('[data-field="value"]', row).value) || 0,
        unit: $('[data-field="unit"]', row).value.trim(),
        mode: $('[data-field="mode"]', row).value,
        ...($('[data-field="mode"]', row).value === 'live' ? {
            control: Object.fromEntries($$('[data-control-field]', row)
                .map((input) => [input.dataset.controlField, Number(input.value)]))
        } : {})
    })).filter((parameter) => parameter.name && parameter.symbol);
    const invalidParameter = parameters.find((parameter) => !modelSymbolPattern.test(parameter.symbol));
    if (invalidParameter || new Set(parameters.map((parameter) => parameter.symbol)).size !== parameters.length) {
        $('#addEdgeError').textContent = invalidParameter
            ? `"${invalidParameter.symbol}" is not a valid symbol -- symbols must start with a lowercase letter and contain only letters and digits (e.g. "temperature", not "Temperature").`
            : 'Each parameter needs its own unique symbol.';
        $('.parameterRow [data-field="symbol"]')?.focus();
        return;
    }
    const invalidLiveParameter = parameters.find((parameter) => parameter.mode === 'live' && parameterControlError(parameter.value, parameter.control));
    if (invalidLiveParameter) {
        const row = $$('.parameterRow').find((candidate) => $('[data-field="symbol"]', candidate).value.trim() === invalidLiveParameter.symbol);
        $('.parameterControlError', row).textContent = parameterControlError(invalidLiveParameter.value, invalidLiveParameter.control);
        $('[data-control-field="minimum"]', row).focus();
        return;
    }
    const implementationKind = $('#edgeImplementationKind').value;
    const sourceNode = model.nodes.find((node) => node.id === source);
    const targetNode = model.nodes.find((node) => node.id === target);
    const definition = {
        id: allocateModelEntityId(),
        title: $('#newEdgeName').value.trim() || 'Untitled relationship',
        source,
        target,
        sourceStateId: sourceNode?.states[0]?.id ?? null,
        targetStateId: targetNode?.states[0]?.id ?? null,
        directionality: $('#newEdgeDirectionality').value,
        color: Number.parseInt($('#newEdgeColor').value.replace('#', ''), 16),
        offset: 0,
        enabled: true,
        equation: implementationKind === 'equation' ? $('#edgeEquation').value.trim() : '',
        parameters
    };
    definition.equationModel = normalizeEdgeEquationModel(definition);
    const pickedOutput = parseEquationOutput($('#edgeEquationOutput').value);
    if (pickedOutput) definition.equationModel.output = pickedOutput;
    if (implementationKind === 'equation') {
        if (definition.equation && definition.equationModel.mathJson === null) {
            renderBuilderEquationDiagnostics(definition.equationModel.bindings);
            ($('#edgeMathField').hidden ? $('#edgeEquation') : $('#edgeMathField')).focus();
            return;
        }
    } else {
        const fakeParameterIdToReal = Object.fromEntries(parameters.map((parameter, index) => [`builderParameter${index}`, parameter.id]));
        const bindings = $$('#providerBindingRows .providerBindingRow').map((row) => {
            const key = $('[data-field="key"]', row).value.trim();
            const reference = parseProviderReference($('[data-field="reference"]', row).value);
            if (reference?.kind === 'parameter') return { key, kind: 'parameter', parameterId: fakeParameterIdToReal[reference.parameterId] };
            if (reference) return { key, ...reference };
            // No usable reference selected (e.g. nothing to reference yet): left unresolved for the
            // validation that follows to report, as a missing state was before.
            return { key, kind: 'state', role: undefined, nodeId: null, stateId: null };
        });
        definition.implementation = {
            kind: implementationKind,
            providerApiVersion: 1,
            source: $('#edgeProviderSource').value,
            bindings,
            output: { key: $('#providerOutputKey').value.trim(), role: pickedOutput?.role, stateId: pickedOutput?.stateId }
        };
    }

    if (pendingEdgeTemplate?.bidirectional) {
        const otherRole = pendingEdgeTemplate.output.role === 'source' ? 'target' : 'source';
        const otherNode = model.nodes.find((node) => node.id === definition[otherRole]);
        const otherState = otherNode?.states.find((candidate) => candidate.symbol === pendingEdgeTemplate.output.state);
        if (otherState) definition[otherRole === 'source' ? 'sourceStateId' : 'targetStateId'] = otherState.id;
    }
    pendingEdgeTemplate = null;

    finishEndpointPick();
    $('#edgeBuilder').classList.add('hidden');
    insertRelationshipDefinition(definition);
});

const labelModeOrder = ['compact', 'expanded', 'hidden'];
const labelModeText = { compact: 'compact', expanded: 'expanded', hidden: 'hidden' };
const labelNoun = { nodes: 'Node', edges: 'Relationship' };

// `mode` is 'compact' | 'expanded' | 'hidden'; a boolean still means expanded/compact for older callers.
function setLabelDetail(detail, mode) {
    if (typeof mode === 'boolean') mode = mode ? 'expanded' : 'compact';
    labelModes[detail] = mode;
    const button = $(`[data-detail="${detail}"]`);
    const next = labelModeOrder[(labelModeOrder.indexOf(mode) + 1) % labelModeOrder.length];
    button.dataset.mode = mode;
    button.classList.toggle('active', mode === 'expanded');
    button.setAttribute('aria-label', `${labelNoun[detail]} labels: ${labelModeText[mode]}. Click to make them ${labelModeText[next]}.`);
    button.title = `${labelNoun[detail]} labels: ${labelModeText[mode]} · click for ${labelModeText[next]}`;
    button.dataset.baseTitle = button.title;
    // A label's size changes with its detail: measured again as each is next shown.
    if (detail === 'nodes') nodeLabelSizes.clear();
    const capital = `${detail[0].toUpperCase()}${detail.slice(1)}`;
    canvas.classList.toggle(`show${capital}Details`, mode === 'expanded');
    canvas.classList.toggle(detail === 'nodes' ? 'hideNodeLabels' : 'hideEdgeLabels', mode === 'hidden');
    updateHoverTracking();
    updateLabelPeek();
}

$$('[data-detail]').forEach((button) => {
    const detail = button.dataset.detail;
    setLabelDetail(detail, 'compact');
    button.addEventListener('click', () => {
        if (detail === 'edges') edgeLabelsHiddenByDefault = false;
        setLabelDetail(detail, labelModeOrder[(labelModeOrder.indexOf(labelModes[detail]) + 1) % labelModeOrder.length]);
    });
});

// ---- label peeking ------------------------------------------------------------------------------------

// A model with hundreds of relationships is unreadable, and slow to draw, with a label on every one, so
// opening one starts with relationship labels hidden (the Edges button shows how to bring them back). It
// only ever undoes its own choice: a user's explicit setting is left alone, and opening a small model
// afterwards restores compact labels only if this default is what hid them.
const largeModelRelationshipCount = 150;
let edgeLabelsHiddenByDefault = false;
function applyLargeModelLabelDefault() {
    const large = model.relationships.filter((relationship) => !relationship.deleted).length > largeModelRelationshipCount;
    if (large && labelModes.edges === 'compact') {
        setLabelDetail('edges', 'hidden');
        edgeLabelsHiddenByDefault = true;
    } else if (!large && edgeLabelsHiddenByDefault) {
        if (labelModes.edges === 'hidden') setLabelDetail('edges', 'compact');
        edgeLabelsHiddenByDefault = false;
    }
}

function relationshipBundleKey(relationship) {
    return [relationship.source, relationship.target].sort().join('|');
}

// A hidden group's labels are switched off at the scene level, not just styled invisible: the label
// renderer then skips them entirely, which is what keeps a model with hundreds of relationships
// responsive once its labels are hidden. The exceptions are the labels that must stay.
function bundleLabelAllowed(overlay) {
    return labelModes.edges !== 'hidden' || overlay.element.classList.contains('pinned') || overlay.element.classList.contains('peek');
}
function refreshLabelObjectVisibility() {
    nodeObjects.forEach((object, id) => {
        const label = object.children.find((child) => child.element?.classList.contains('node-label-container'));
        if (!label) return;
        const classes = label.element.classList;
        const mustStay = classes.contains('selected') || classes.contains('peek') || classes.contains('hasStabilityFinding') || Boolean(activeEndpointPick);
        label.visible = mustStay || (labelModes.nodes !== 'hidden' && !declutteredNodeIds.has(id));
    });
    relationshipBundleObjects.forEach((overlay) => { overlay.anchor.visible = (overlay.baseVisible ?? true) && bundleLabelAllowed(overlay); });
}

// Works out again which node labels to leave out, from where they fall on screen now: called a few times a second,
// since the camera moving is what changes it. A model of up to `declutterAbove` nodes keeps every label, as does
// picking an endpoint, where the labels are what is picked.
function refreshLabelDeclutter() {
    // Said on the Nodes control, so shapes without a name are no puzzle.
    const say = () => {
        const button = $('[data-detail="nodes"]');
        const base = button.dataset.baseTitle ?? button.title;
        button.title = declutteredNodeIds.size ? `${base} · ${declutteredNodeIds.size} left out where they would overlap: zoom in, or point at a shape` : base;
        canvas.dataset.labelsLeftOut = String(declutteredNodeIds.size);
    };
    const clear = () => {
        if (!declutteredNodeIds.size) return;
        declutteredNodeIds.clear();
        refreshLabelObjectVisibility();
        updateHoverTracking();
        say();
    };
    if (nodeObjects.size <= declutterAbove || labelModes.nodes === 'hidden' || activeEndpointPick) { clear(); return; }
    const width = labelRenderer.domElement.clientWidth;
    const height = labelRenderer.domElement.clientHeight;
    if (!width || !height) return;
    const degree = new Map();
    model.relationships.forEach((relationship) => {
        for (const end of [relationship.source, relationship.target]) degree.set(end, (degree.get(end) ?? 0) + 1);
    });
    const labels = [];
    nodeObjects.forEach((object, id) => {
        const label = object.children.find((child) => child.element?.classList.contains('node-label-container'));
        if (!label) return;
        const element = label.element;
        // A label left out has no size to measure: its last, or a card's usual.
        if (element.offsetWidth) nodeLabelSizes.set(id, [element.offsetWidth, element.offsetHeight]);
        const [labelWidth, labelHeight] = nodeLabelSizes.get(id) ?? [170, 38];
        label.getWorldPosition(labelProbe).project(camera);
        if (labelProbe.z > 1 || Math.abs(labelProbe.x) > 1.5 || Math.abs(labelProbe.y) > 1.5) return;
        const classes = element.classList;
        labels.push({
            id, left: (labelProbe.x * 0.5 + 0.5) * width, top: (-labelProbe.y * 0.5 + 0.5) * height - labelHeight / 2, width: labelWidth, height: labelHeight,
            priority: degree.get(id) ?? 0, shown: !declutteredNodeIds.has(id),
            keep: classes.contains('selected') || classes.contains('peek') || classes.contains('hasStabilityFinding')
        });
    });
    const hidden = declutterLabels(labels);
    if (hidden.size === declutteredNodeIds.size && [...hidden].every((id) => declutteredNodeIds.has(id))) return;
    declutteredNodeIds.clear();
    hidden.forEach((id) => declutteredNodeIds.add(id));
    refreshLabelObjectVisibility();
    say();
}

// Marks the labels that must stay visible whatever the mode: whatever is hovered, and the label of the
// selected relationship's bundle (a selected node's own label is already marked `selected`).
function updateLabelPeek() {
    if (!labelSystemReady) return;
    $$('.node-label-container').forEach((label) => label.classList.toggle('peek', Number(label.dataset.node) === hoveredNodeId));
    const keys = new Set();
    for (const id of [selectedRelationship?.id, hoveredRelationshipId]) {
        const relationship = id == null ? null : model.relationships.find((candidate) => candidate.id === id);
        if (relationship) keys.add(relationshipBundleKey(relationship));
    }
    relationshipBundleObjects.forEach((overlay, key) => overlay.element.classList.toggle('peek', keys.has(key)));
    refreshLabelObjectVisibility();
}

// While a group is hidden, pointing at a shape (or a relationship) shows its label, since the label is
// the only thing that says what it is. Only tracked while something is hidden, and only when the pointer
// is not dragging.
function hoverTrackingNeeded() {
    return labelModes.nodes === 'hidden' || labelModes.edges === 'hidden' || declutteredNodeIds.size > 0;
}
function updateHoverTracking() {
    if (hoverTrackingNeeded()) return;
    if (hoveredNodeId !== null || hoveredRelationshipId !== null) {
        hoveredNodeId = null;
        hoveredRelationshipId = null;
        updateLabelPeek();
    }
}
renderer.domElement.addEventListener('pointermove', (event) => {
    if (!hoverTrackingNeeded() || event.buttons !== 0 || hoverFrame) return;
    hoverFrame = requestAnimationFrame(() => {
        hoverFrame = null;
        setPointerFromEvent(event);
        const node = labelModes.nodes === 'hidden' || declutteredNodeIds.size ? rootNodeFromIntersection(firstIntersection(nodePickTargets)) : null;
        // A relationship's label sits on top of the line it names, so it is revealed on hover only while
        // that group is hidden; otherwise it would intercept the click the user is about to make.
        const relationship = !node && labelModes.edges === 'hidden' ? firstIntersection(relationshipPickTargets)?.object.userData.definition : null;
        const nextNode = node?.userData.id ?? null;
        const nextRelationship = relationship?.id ?? null;
        if (nextNode === hoveredNodeId && nextRelationship === hoveredRelationshipId) return;
        hoveredNodeId = nextNode;
        hoveredRelationshipId = nextRelationship;
        updateLabelPeek();
    });
});
renderer.domElement.addEventListener('pointerleave', () => {
    if (hoveredNodeId === null && hoveredRelationshipId === null) return;
    hoveredNodeId = null;
    hoveredRelationshipId = null;
    updateLabelPeek();
});

$('#validationSummary').addEventListener('click', () => {
    const panel = $('#validationPanel');
    panel.hidden = !panel.hidden;
    $('#validationSummary').ariaExpanded = String(!panel.hidden);
});
$('#closeValidationPanel').addEventListener('click', () => {
    $('#validationPanel').hidden = true;
    $('#validationSummary').ariaExpanded = 'false';
});

function setTool(tool) {
    if (activeResult && tool !== 'select') return;
    $$('.toolstrip [data-tool]').forEach((button) => button.classList.toggle('active', button.dataset.tool === tool));
    canvas.dataset.tool = tool;
    rectangleSelection = null;
    $('#selectionRectangle').hidden = true;
    currentTool = tool;
    dragControls.enabled = !activeResult && tool === 'select';
    transformControls.enabled = !activeResult && tool in transformPropertyForTool;
    orbitControls.enabled = tool !== 'rectangleSelect';

    if (tool in transformPropertyForTool) transformControls.setMode(tool === 'move' ? 'translate' : tool);
    if (!(tool in transformPropertyForTool)) transformControls.detach();
    if (tool in transformPropertyForTool && selectedNode) transformControls.attach(selectedNode);
}

$$('.toolstrip [data-tool]').forEach((button) => {
    button.addEventListener('click', () => {
        setTool(button.dataset.tool);
    });
});

function animateCameraTo(position, up, animated = true) {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!animated || reduceMotion) {
        camera.position.copy(position);
        camera.up.copy(up);
        camera.lookAt(orbitControls.target);
        orbitControls.update();
        return;
    }
    cameraAnimation = {
        startedAt: performance.now(),
        duration: 650,
        fromPosition: camera.position.clone(),
        toPosition: position.clone(),
        fromUp: camera.up.clone(),
        toUp: up.clone()
    };
    orbitControls.enabled = false;
}

function updateCameraAnimation(time) {
    if (!cameraAnimation) return false;
    const progress = Math.min(1, (time - cameraAnimation.startedAt) / cameraAnimation.duration);
    const eased = 1 - Math.pow(1 - progress, 3);
    camera.position.lerpVectors(cameraAnimation.fromPosition, cameraAnimation.toPosition, eased);
    camera.up.lerpVectors(cameraAnimation.fromUp, cameraAnimation.toUp, eased).normalize();
    camera.lookAt(orbitControls.target);
    if (progress === 1) {
        cameraAnimation = null;
        orbitControls.enabled = true;
        orbitControls.update();
    }
    return true;
}

function setCameraView(view, animated = true) {
    currentView = view;
    const position = new THREE.Vector3();
    const up = new THREE.Vector3(0, 1, 0);
    if (view === 'top') {
        up.set(0, 0, -1);
        position.set(0, 24, 0.001);
    } else if (view === 'bottom') {
        up.set(0, 0, 1);
        position.set(0, -24, 0.001);
    } else if (view === 'front') {
        position.set(0, -0.7, 24);
    } else if (view === 'back') {
        position.set(0, -0.7, -24);
    } else if (view === 'right') {
        position.set(24, -0.7, 0.001);
    } else if (view === 'left') {
        position.set(-24, -0.7, 0.001);
    } else {
        position.set(0, 7.5, 19);
    }
    orbitControls.target.set(0, -0.7, 0);
    animateCameraTo(position, up, animated);
    $$('[data-nav-view]').forEach((button) => {
        button.classList.toggle('active', button.dataset.navView === view);
    });
}

$$('[data-nav-view]').forEach((button) => {
    button.addEventListener('click', () => {
        setCameraView(button.dataset.navView);
    });
});

function nearestOrthogonalView() {
    const cameraDirection = camera.position.clone().sub(orbitControls.target).normalize();
    let bestView = 'front';
    let bestDot = -Infinity;
    for (const [view, direction] of Object.entries(faceDirections)) {
        const dot = cameraDirection.dot(direction);
        if (dot > bestDot) {
            bestDot = dot;
            bestView = view;
        }
    }
    return bestView;
}

// Repurposes OrbitControls' own native mouse-button mapping -- the same mechanism already
// behind today's "Shift-drag pans" behavior -- so a plain left-drag pans instead of rotates
// while locked. Corner/isometric views are inherently non-orthogonal, so they're disabled
// rather than left free to silently break the "always looking straight down one axis" promise.
function set2DLock(locked) {
    is2DLocked = locked;
    orbitControls.enableRotate = !locked;
    orbitControls.mouseButtons.LEFT = locked ? THREE.MOUSE.PAN : THREE.MOUSE.ROTATE;
    const button = $('#lock2DButton');
    button.classList.toggle('active', locked);
    button.ariaPressed = String(locked);
    button.querySelector('img').src = locked ? '../../assets/lock2D.svg' : '../../assets/lock2DOpen.svg';
    $$('.cubeCorner').forEach((corner) => { corner.disabled = locked; });
    if (locked) setCameraView(nearestOrthogonalView(), true);
}

$('#lock2DButton').addEventListener('click', () => set2DLock(!is2DLocked));

function setCameraCorner(direction) {
    const [x, y, z] = direction.split(',').map(Number);
    currentView = `corner:${direction}`;
    orbitControls.target.set(0, -0.7, 0);
    const position = new THREE.Vector3(x, y, z).normalize().multiplyScalar(24);
    position.add(orbitControls.target);
    animateCameraTo(position, new THREE.Vector3(0, 1, 0));
    $$('.cubeFace').forEach((face) => face.classList.remove('active'));
}

function fitCurrentView() {
    // A camera view reset (e.g. the default view a freshly loaded example resets to) animates
    // over 650ms via cameraAnimation/updateCameraAnimation, which keeps overwriting camera.position
    // on every subsequent render frame until it finishes. Fitting the view while that's still
    // in flight -- e.g. clicking Fit right after a model loads -- would have this function's own
    // direct position write immediately clobbered by the still-running animation, landing on
    // the animation's stale destination instead of the freshly computed fit.
    cameraAnimation = null;
    orbitControls.enabled = true;
    const bounds = new THREE.Box3();
    nodeObjects.forEach((object) => {
        if (object.visible) bounds.expandByObject(object);
    });
    if (bounds.isEmpty()) {
        orbitControls.target.set(0, -0.7, 0);
        camera.position.set(0, 7.5, 19);
        camera.lookAt(orbitControls.target);
        orbitControls.update();
        return;
    }
    const center = bounds.getCenter(new THREE.Vector3());
    const sphere = bounds.getBoundingSphere(new THREE.Sphere());
    const direction = camera.position.clone().sub(orbitControls.target).normalize();
    const verticalFov = THREE.MathUtils.degToRad(camera.fov);
    const horizontalFov = 2 * Math.atan(Math.tan(verticalFov / 2) * camera.aspect);
    const limitingFov = Math.min(verticalFov, horizontalFov);
    const distance = Math.max(orbitControls.minDistance, sphere.radius / Math.sin(limitingFov / 2) * 1.15);
    orbitControls.target.copy(center);
    camera.position.copy(direction.multiplyScalar(distance).add(center));
    camera.lookAt(orbitControls.target);
    orbitControls.update();
}

function zoomCamera(direction) {
    if (direction === 'in') orbitControls.dollyIn(0.8);
    else orbitControls.dollyOut(0.8);
}

function panCamera(direction) {
    const step = 36;
    if (direction === 'up') orbitControls.pan(0, step);
    else if (direction === 'down') orbitControls.pan(0, -step);
    else if (direction === 'left') orbitControls.pan(step, 0);
    else orbitControls.pan(-step, 0);
}

$$('[data-nav-corner]').forEach((button) => {
    button.addEventListener('click', () => setCameraCorner(button.dataset.navCorner));
});
$('[data-nav-action="fit"]').addEventListener('click', fitCurrentView);
$('[data-nav-action="zoomIn"]').addEventListener('click', () => zoomCamera('in'));
$('[data-nav-action="zoomOut"]').addEventListener('click', () => zoomCamera('out'));
$$('[data-nav-pan]').forEach((button) => {
    button.addEventListener('click', () => panCamera(button.dataset.navPan));
});

function updateViewCube() {
    $('#viewCube').dataset.cameraDistance = camera.position.distanceTo(orbitControls.target).toFixed(4);
    $('#viewCube').dataset.cameraTarget = orbitControls.target.toArray().map((value) => value.toFixed(4)).join(',');
    const inverseCameraRotation = camera.quaternion.clone().invert();
    const worldRotation = new THREE.Matrix4().makeRotationFromQuaternion(inverseCameraRotation);
    const flipCssY = new THREE.Matrix4().makeScale(1, -1, 1);
    const cssRotation = flipCssY.clone().multiply(worldRotation).multiply(flipCssY);
    $('#viewCubeObject').style.transform = `matrix3d(${cssRotation.elements.join(',')})`;
    const cameraDirection = camera.position.clone().sub(orbitControls.target).normalize();
    $$('.cubeFace').forEach((face) => {
        face.classList.toggle(
            'active',
            cameraDirection.dot(faceDirections[face.dataset.navView]) > 0.985
        );
    });
}

function deleteSelected() {
    if (activeResult) return;
    finishEquationEdit();
    if (selectedNodeIds.size) {
        const nodeIds = new Set(selectedNodeIds);
        const affectedRelationships = [];
        relationshipObjects.forEach((relationship) => {
            const definition = relationship.definition;
            if (nodeIds.has(definition.source) || nodeIds.has(definition.target)) {
                affectedRelationships.push({
                    id: definition.id,
                    visible: !definition.deleted
                });
            }
        });
        const applyDeleted = (deleted) => {
            nodeIds.forEach((id) => setNodeVisibility(id, !deleted));
            affectedRelationships.forEach((relationship) => {
                setRelationshipVisibility(
                    relationship.id,
                    deleted ? false : relationship.visible
                );
            });
        };
        applyDeleted(true);
        recordHistory({ undo: () => applyDeleted(false), redo: () => applyDeleted(true) });
        clearSelection();
        // An editor left open on a deleted node would show stale fields that no longer edit anything.
        ['#nodeEditor', '#sourceTermEditor'].forEach((selector) => $(selector).classList.add('hidden'));
    } else if (selectedRelationship) {
        const id = selectedRelationship.id;
        setRelationshipVisibility(id, false);
        recordHistory({
            undo: () => setRelationshipVisibility(id, true),
            redo: () => setRelationshipVisibility(id, false)
        });
        selectedRelationship = null;
        $('#edgeEditor').classList.add('hidden');
    }
}

function copySelectedGraph() {
    if (activeResult || !selectedNodeIds.size) return false;
    const fragment = createGraphFragment(serializeProjectDocument(), selectedNodeIds);
    if (!fragment) return false;
    window.modelClipboard.write(fragment);
    updateSelectionActionControls();
    $('#statusText').textContent = `${fragment.nodes.length} node${fragment.nodes.length === 1 ? '' : 's'} copied`;
    return true;
}

function hydrateFragmentNode(node) {
    const appearance = node.appearance ?? {};
    const importedGeometry = appearance.type === 'mesh' ? geometryFromDocument(appearance.mesh) : null;
    return {
        id: node.id,
        title: node.name || 'Untitled node',
        type: node.type || 'Custom node',
        shape: importedGeometry ? 'imported' : appearance.shape || 'box',
        position: node.position?.length === 3 ? node.position : [0, 0, 0],
        rotation: node.rotation?.length === 3 ? node.rotation : [0, 0, 0],
        scale: node.scale?.length === 3 ? node.scale : [1, 1, 1],
        color: Number.parseInt(String(appearance.color ?? '#34727a').replace('#', ''), 16),
        importedGeometry,
        geometryFileName: appearance.fileName ?? null,
        badgeClass: '',
        subsystemId: activeSubsystemId,
        deleted: false,
        enabled: node.enabled !== false,
        substepsPerGlobalStep: Math.max(1, Math.min(10000, Number(node.numerics?.substepsPerGlobalStep) || 1)),
            integration: node.numerics?.integration === 'semiImplicit' ? 'semiImplicit' : 'explicit',
        sourceTerms: node.sourceTerms ?? [],
        implementation: node.implementation ? structuredClone(node.implementation) : null,
        appearanceParts: Array.isArray(appearance.parts) ? structuredClone(appearance.parts) : null,
        states: (node.states ?? []).map((state) => ({
            id: state.id,
            label: state.name,
            symbol: state.symbol,
            initialValue: state.initialValue,
            unit: state.unit ?? '',
            value: stateValueText(state.initialValue, state.unit).text, exactValue: stateValueText(state.initialValue, state.unit).exact,
            className: ''
        }))
    };
}

function hydrateFragmentRelationship(edge) {
    return {
        id: edge.id,
        title: edge.name || 'Untitled relationship',
        source: edge.source.nodeId,
        sourceStateId: edge.source.stateId ?? null,
        target: edge.target.nodeId,
        targetStateId: edge.target.stateId ?? null,
        directionality: edge.directionality ?? 'directed',
        equation: edge.equation ?? '',
        equationModel: edge.equationModel,
        parameters: edge.parameters ?? [],
        color: Number.parseInt(String(edge.appearance?.color ?? '#9c83c4').replace('#', ''), 16),
        offset: Number(edge.appearance?.offset) || 0,
        enabled: edge.enabled !== false
    };
}

// The default [1, 0, 1] paste offset shifts a pasted copy along X and Z, leaving Y untouched --
// which only happens to stay in-plane for a Top/Bottom 2D lock. Locked into Front/Back or
// Left/Right instead, that same offset pushes the copy along whatever axis is "depth" for that
// view, out of the plane every other node is visibly sitting in. Zero out that one axis instead
// of leaving it to coincidence.
function pasteOffsetForCurrentView() {
    const offset = [1, 0, 1];
    if (!is2DLocked) return offset;
    const depthAxis = faceDirections[nearestOrthogonalView()].toArray().findIndex((component) => component !== 0);
    offset[depthAxis] = 0;
    return offset;
}

function pasteGraph() {
    if (activeResult) return false;
    const fragment = window.modelClipboard.read();
    if (!validateGraphFragment(fragment)) return false;
    try {
        const remapped = remapGraphFragment(fragment, nextModelEntityId, pasteOffsetForCurrentView());
        nextModelEntityId = remapped.nextId;
        const nodes = remapped.nodes.map(hydrateFragmentNode);
        const relationships = remapped.edges.map(hydrateFragmentRelationship);
        model.nodes.push(...nodes);
        nodes.forEach(createNode);
        model.relationships.push(...relationships);
        relationships.forEach(createRelationship);
        const nodeIds = nodes.map((node) => node.id);
        const relationshipIds = relationships.map((relationship) => relationship.id);
        const applyVisible = (visible) => {
            nodeIds.forEach((id) => setNodeVisibility(id, visible));
            relationshipIds.forEach((id) => setRelationshipVisibility(id, visible));
            updateRelationships();
            updateModelStatus();
        };
        clearSelection();
        nodeIds.forEach((id) => selectNode(nodeObjects.get(id), { additive: selectedNodeIds.size > 0 }));
        if (currentTool in transformPropertyForTool && selectedNode) transformControls.attach(selectedNode);
        recordHistory({ undo: () => applyVisible(false), redo: () => applyVisible(true) });
        updateRelationships();
        updateModelStatus();
        updateValidationStatus();
        $('#statusText').textContent = `${nodes.length} node${nodes.length === 1 ? '' : 's'} pasted`;
        return true;
    } catch (error) {
        console.error('Copied graph could not be pasted.', error);
        $('#statusText').textContent = error.message;
        return false;
    }
}

// Edge groups: one shared relationship definition (docs/edgeGroups.md) expanded into a
// complete mesh -- one directed edge per ordered member pair, both directions independently
// evaluated (docs/edgeDirectionality.md), each an ordinary edge carrying groupId.
// The card at #edgeGroupEditor is a batch/"Save changes" form (like #edgeBuilder), not the
// #edgeEditor's live-per-field-undo pattern -- a group's shared definition has no single concrete
// node pair to bind against while editing, so live diagnostics/candidates are driven off the
// group's first two resolvable members as a representative preview pair.

function memberEdgesForGroup(groupId) {
    return model.relationships.filter((edge) => edge.groupId === groupId && !edge.deleted);
}

function groupPreviewPair(group) {
    const resolvable = group.memberNodeIds
        .map((id) => model.nodes.find((node) => node.id === id))
        .filter((node) => node && !node.deleted);
    return [resolvable[0] ?? null, resolvable[1] ?? null];
}

// Only counts as "the active group" while its editor card is actually visible -- mirrors how
// selectedRelationship/#edgeEditor already interact, so opening any other card implicitly clears
// it without needing a hook into every hideCards() call site.
function currentEdgeGroup() {
    if ($('#edgeGroupEditor').classList.contains('hidden')) return null;
    return model.edgeGroups.find((group) => group.id === activeEdgeGroupId && !group.deleted) ?? null;
}

// Mirrors the single-edge editor's inline .editorParameterRow pattern (renderEdgeEditor): every
// field commits live through changeEdgeGroupModel, matched by the parameter's own stable id
// rather than position -- addGroupParameterRow is only ever called against a parameter that
// already exists in group.definition.parameters (see the "+" button below, which pushes a stub
// parameter through changeEdgeGroupModel first, the same way #editAddEdgeParameter does).
function addGroupParameterRow(container, parameter, group) {
    const control = normalizedParameterControl({ value: Number(parameter.value) || 0, control: parameter.control });
    const row = document.createElement('div');
    row.className = 'builderRow parameterRow';
    row.innerHTML = `
        <label class="parameterField"><span>Name</span><input data-field="name" value="${escapeHtml(parameter.name ?? '')}"></label>
        <label class="parameterField"><span>Symbol</span><input data-field="symbol" value="${escapeHtml(parameter.symbol ?? '')}"></label>
        <label class="parameterField"><span>Initial value</span><input data-field="value" type="number" value="${escapeHtml(parameter.value ?? '')}"></label>
        <label class="parameterField"><span>Unit</span><input data-field="unit" value="${escapeHtml(parameter.unit ?? '')}"></label>
        <label class="parameterField"><span>Mode</span><select data-field="mode"><option value="constant">Constant</option><option value="live">Live</option></select></label>
        <button class="removeBuilderRow" type="button" title="Remove">×</button>
        <div class="parameterControlFields" ${parameter.mode === 'live' ? '' : 'hidden'}>
            <label class="parameterField"><span>Slider minimum</span><input data-control-field="minimum" type="number" value="${control.minimum}"></label>
            <label class="parameterField"><span>Slider maximum</span><input data-control-field="maximum" type="number" value="${control.maximum}"></label>
            <label class="parameterField"><span>Slider step</span><input data-control-field="step" type="number" min="0" value="${control.step}"></label>
            <span class="parameterControlError" role="status"></span>
        </div>
    `;
    $('[data-field="mode"]', row).value = parameter.mode ?? 'constant';
    container.appendChild(row);
    const readControl = () => Object.fromEntries($$('[data-control-field]', row)
        .map((input) => [input.dataset.controlField, Number(input.value)]));
    const showControlError = () => {
        const error = $('[data-field="mode"]', row).value === 'live'
            ? parameterControlError(Number($('[data-field="value"]', row).value), readControl()) : '';
        $('.parameterControlError', row).textContent = error;
        return error;
    };
    $$('[data-control-field], [data-field="value"]', row).forEach((input) => input.addEventListener('input', showControlError));
    $$('[data-field]', row).forEach((input) => input.addEventListener('change', () => {
        if (input.dataset.field === 'mode') $('.parameterControlFields', row).hidden = input.value !== 'live';
        if (showControlError()) return;
        changeEdgeGroupModel(group, (snapshot) => {
            const target = snapshot.definition.parameters.find((candidate) => candidate.id === parameter.id);
            target[input.dataset.field] = input.dataset.field === 'value' ? Number(input.value) || 0 : input.value.trim();
            if (target.mode === 'live') target.control = readControl();
            else delete target.control;
        });
    }));
    $$('[data-control-field]', row).forEach((input) => input.addEventListener('change', () => {
        if (showControlError()) return;
        changeEdgeGroupModel(group, (snapshot) => {
            const target = snapshot.definition.parameters.find((candidate) => candidate.id === parameter.id);
            target.value = Number($('[data-field="value"]', row).value) || 0;
            target.control = readControl();
        });
    }));
    row.querySelector('.removeBuilderRow').addEventListener('click', () => changeEdgeGroupModel(group, (snapshot) => {
        snapshot.definition.parameters = snapshot.definition.parameters.filter((candidate) => candidate.id !== parameter.id);
    }));
}

// Converts one auto-bind candidate (concrete nodeId/stateId, from providerReferenceCandidates)
// into the group's own symbol-keyed provider binding shape -- the inverse of what
// renderGroupProviderBindingRows does to pre-select a row's reference dropdown.
function candidateToGroupBinding(key, candidate, previewSource, previewTarget) {
    if (candidate.kind === 'parameter') return { key, kind: 'parameter', parameterId: candidate.parameterId };
    const node = candidate.role === 'source' ? previewSource : previewTarget;
    return { key, kind: 'state', role: candidate.role, symbol: node?.states.find((state) => state.id === candidate.stateId)?.symbol ?? '' };
}

function renderGroupProviderBindingRows(group, previewSource, previewTarget) {
    const container = $('#groupProviderBindingRows');
    container.replaceChildren();
    const bindings = group.definition.implementation?.bindings ?? [];
    const candidates = providerReferenceCandidates({
        source: previewSource?.id, target: previewTarget?.id, parameters: group.definition.parameters
    });
    if (!bindings.length) container.innerHTML = '<p class="emptyEditorState">No bindings defined</p>';
    bindings.forEach((binding, index) => {
        const row = document.createElement('div');
        row.className = 'builderRow providerBindingRow';
        row.innerHTML = `
            <label class="parameterField"><span>Key</span><input data-field="key" value="${escapeHtml(binding.key ?? '')}"></label>
            <label class="parameterField"><span>Reference</span><select data-field="reference"></select></label>
            <button class="removeBuilderRow" type="button" title="Remove">×</button>
        `;
        const select = $('[data-field="reference"]', row);
        select.replaceChildren(...candidates.map((candidate) => new Option(candidate.label, providerReferenceValue(candidate))));
        if (binding.kind === 'parameter') {
            select.value = `parameter:${binding.parameterId}`;
        } else {
            const node = binding.role === 'source' ? previewSource : previewTarget;
            const state = node?.states.find((candidate) => candidate.symbol === binding.symbol);
            if (state) select.value = providerReferenceValue({ kind: 'state', role: binding.role, nodeId: node.id, stateId: state.id });
        }
        $('[data-field="key"]', row).addEventListener('change', (event) => {
            changeEdgeGroupModel(group, (snapshot) => {
                snapshot.definition.implementation.bindings[index] = { ...snapshot.definition.implementation.bindings[index], key: event.target.value.trim() };
            });
        });
        select.addEventListener('change', (event) => {
            const candidate = candidates.find((option) => providerReferenceValue(option) === event.target.value);
            if (!candidate) return;
            changeEdgeGroupModel(group, (snapshot) => {
                snapshot.definition.implementation.bindings[index] = candidateToGroupBinding($('[data-field="key"]', row).value.trim(), candidate, previewSource, previewTarget);
            });
        });
        row.querySelector('.removeBuilderRow').addEventListener('click', () => changeEdgeGroupModel(group, (snapshot) => {
            snapshot.definition.implementation.bindings = snapshot.definition.implementation.bindings.filter((candidate, i) => i !== index);
        }));
        container.appendChild(row);
    });
}

function renderGroupEquationDiagnostics(group) {
    const [previewSource, previewTarget] = groupPreviewPair(group);
    const bindings = reconcileEquationBindings([], previewSource, previewTarget, group.definition.parameters);
    const latex = ($('#groupMathField').hidden ? $('#groupEquation') : $('#groupMathField')).value;
    const validation = validateEquationLatex(latex, bindings);
    const diagnostics = $('#groupEquationDiagnostics');
    diagnostics.classList.toggle('valid', validation.valid);
    diagnostics.textContent = validation.valid ? 'Valid expression · MathJSON ready' : validation.errors.join(' ');
    return { validation, bindings };
}

function renderEdgeGroupEditor(group) {
    $('#editGroupError').textContent = '';
    $('#editGroupHeading').textContent = group.name;
    $('#groupName').value = group.name;
    $('#groupColor').value = `#${group.color.toString(16).padStart(6, '0')}`;
    const edges = memberEdgesForGroup(group.id);
    $('#toggleEdgeGroupEnabled').textContent = edges.length && edges.every((edge) => edge.enabled === false) ? 'Enable all' : 'Disable all';

    const membersList = $('#groupMembersList');
    membersList.replaceChildren();
    const members = group.memberNodeIds
        .map((id) => model.nodes.find((node) => node.id === id))
        .filter((node) => node && !node.deleted);
    if (!members.length) membersList.innerHTML = '<p class="emptyEditorState">No members</p>';
    members.forEach((node) => {
        const row = document.createElement('div');
        row.className = 'groupMemberRow';
        row.innerHTML = `<span>${escapeHtml(node.title)}</span><button class="removeBuilderRow" type="button" title="Detach">×</button>`;
        row.querySelector('.removeBuilderRow').addEventListener('click', () => detachNodeFromGroup(group, node.id));
        membersList.appendChild(row);
    });
    const soleSelectedId = selectedNodeIds.size === 1 ? [...selectedNodeIds][0] : null;
    $('#groupAddMember').disabled = Boolean(activeResult) || soleSelectedId === null || group.memberNodeIds.includes(soleSelectedId);

    const [previewSource, previewTarget] = groupPreviewPair(group);
    const implementationKind = group.definition.implementation?.kind ?? 'equation';
    const isEquation = implementationKind === 'equation';
    $('#groupImplementationKind').value = implementationKind;
    $('#groupEquationHeading').hidden = !isEquation;
    $('#groupEquationDiagnostics').hidden = !isEquation;
    $('#groupFunctions').hidden = !isEquation;
    $('#groupReferenceHint').hidden = !isEquation;
    $('#groupProviderSection').hidden = isEquation;

    // No source/target role choice here, unlike a hand-authored edge's own "Updates" picker --
    // every generated member edge contributes to its own target by construction (see
    // docs/edgeDirectionality.md), so a group only ever needs to name *which state*, deduplicated
    // across both preview nodes.
    const output = $('#groupEquationOutput');
    output.replaceChildren();
    const outputSymbols = [...new Set([...(previewSource?.states ?? []), ...(previewTarget?.states ?? [])]
        .map((state) => state.symbol))];
    outputSymbols.forEach((symbol) => output.add(new Option(symbol, symbol)));
    output.value = group.definition.output.symbol;

    const parameterContainer = $('#groupParameterRows');
    parameterContainer.replaceChildren();
    if (!group.definition.parameters.length) parameterContainer.innerHTML = '<p class="emptyEditorState">No parameters defined</p>';
    else group.definition.parameters.forEach((parameter) => addGroupParameterRow(parameterContainer, parameter, group));

    const mathField = $('#groupMathField');
    const latexSource = $('#groupEquation');
    if (isEquation) {
        const latexMode = $('[data-group-equation-mode="latex"]').classList.contains('active');
        mathField.hidden = latexMode;
        latexSource.hidden = !latexMode;
        mathField.value = group.definition.equation;
        latexSource.value = group.definition.equation;
        const portList = (role, node) => node?.states.length
            ? node.states.map((state) => `${role}${state.symbol[0].toUpperCase()}${state.symbol.slice(1)}`).join(', ')
            : 'none';
        $('#groupReferenceHint').textContent = previewSource && previewTarget
            ? `Available references (from "${previewSource.title}"/"${previewTarget.title}"): ${portList('source', previewSource)}, ${portList('target', previewTarget)}. Every member must supply the state named in "Updates" below.`
            : 'Add at least two members to see available equation references.';
        renderGroupEquationDiagnostics(group);
    } else {
        mathField.hidden = true;
        latexSource.hidden = true;
        const fromPlugin = group.definition.implementation?.kind === 'plugin';
        $('#groupProviderCode').hidden = fromPlugin;
        $('#groupPluginProviderFields').hidden = !fromPlugin;
        if (fromPlugin) fillPluginProviders($('#groupPluginProvider'), group.definition.implementation);
        $('#groupProviderSource').value = group.definition.implementation?.source ?? '';
        $('#groupInsertProviderTemplate').hidden = !group.definition.implementation?.source?.trim();
        $('#groupProviderOutputKey').value = group.definition.implementation?.output?.key ?? '';
        renderGroupProviderBindingRows(group, previewSource, previewTarget);
    }
}

function captureEdgeGroupModel(group) {
    return { name: group.name, color: group.color, definition: structuredClone(group.definition) };
}

// Pure apply: mutates the group's own record, re-resolves every *existing* member edge's fields
// (never regenerates one that was individually deleted -- see deleteSelected's edge branch), and
// refreshes visuals. Shared by every live field edit below and by every membership action's
// undo/redo. `rerenderEditor: false` skips the full form re-render -- used only while a field is
// actively being typed into (previewGroupEquation/previewGroupProviderSource), so an in-progress
// keystroke's own field doesn't get clobbered/reset mid-edit the way a full re-render would.
function applyEdgeGroupModel(group, snapshot, { rerenderEditor = true } = {}) {
    group.name = snapshot.name;
    group.color = snapshot.color;
    group.definition = structuredClone(snapshot.definition);
    const nodesById = new Map(model.nodes.map((node) => [node.id, node]));
    memberEdgesForGroup(group.id).forEach((edge) => {
        const sourceNode = nodesById.get(edge.source);
        const targetNode = nodesById.get(edge.target);
        if (!sourceNode || !targetNode) return;
        const resolved = resolveGroupEdgeForPair({ group, sourceNode, targetNode, allocateId: () => edge.id });
        edge.title = resolved.title;
        edge.color = resolved.color;
        edge.equation = resolved.equation;
        edge.equationModel = resolved.equationModel;
        edge.implementation = resolved.implementation ?? null;
        edge.parameters = resolved.parameters;
        edge.sourceStateId = resolved.sourceStateId;
        edge.targetStateId = resolved.targetStateId;
        refreshRelationshipVisual(edge);
    });
    updateRelationships();
    updateValidationStatus();
    if (rerenderEditor && currentEdgeGroup()?.id === group.id) renderEdgeGroupEditor(group);
}

// The group editor's equivalent of changeEdgeModel: capture, mutate a clone, validate, apply, and
// record one undo step -- used by every discrete field commit (name, colour, implementation kind,
// parameter/binding rows). Continuously-typed fields (equation text, provider source) go through
// previewGroupEquation/previewGroupProviderSource instead, which batch keystrokes into one
// undo step via beginEquationEditSession/finishEquationEdit, the same session mechanism the
// single-edge editor's own live equation typing already uses -- reused here unchanged.
function changeEdgeGroupModel(group, mutate) {
    if (activeResult) return false;
    finishEquationEdit();
    const before = captureEdgeGroupModel(group);
    const after = structuredClone(before);
    mutate(after);
    const parameterSymbols = after.definition.parameters.map((parameter) => parameter.symbol);
    if (parameterSymbols.some((symbol) => !modelSymbolPattern.test(symbol)) ||
        new Set(parameterSymbols).size !== parameterSymbols.length) {
        const invalidSymbol = after.definition.parameters.find((parameter) => !modelSymbolPattern.test(parameter.symbol));
        renderEdgeGroupEditor(group);
        $('#editGroupError').textContent = invalidSymbol
            ? `"${invalidSymbol.symbol}" is not a valid symbol -- symbols must start with a lowercase letter and contain only letters and digits (e.g. "temperature", not "Temperature").`
            : 'Each parameter needs its own unique symbol.';
        return false;
    }
    applyEdgeGroupModel(group, after);
    recordHistory({
        undo: () => applyEdgeGroupModel(group, before),
        redo: () => applyEdgeGroupModel(group, after)
    });
    return true;
}

function previewGroupEquation(latex, origin) {
    const group = currentEdgeGroup();
    if (activeResult || !group) return;
    beginEquationEditSession(`group:${group.id}`, () => captureEdgeGroupModel(group), (snapshot) => applyEdgeGroupModel(group, snapshot));
    group.definition.equation = latex;
    applyEdgeGroupModel(group, captureEdgeGroupModel(group), { rerenderEditor: false });
    if (origin !== 'visual') $('#groupMathField').setValue(latex, { silenceNotifications: true });
    if (origin !== 'latex') $('#groupEquation').value = latex;
    renderGroupEquationDiagnostics(group);
}

function previewGroupProviderSource(source) {
    const group = currentEdgeGroup();
    if (activeResult || !group?.definition.implementation) return;
    beginEquationEditSession(`group:${group.id}`, () => captureEdgeGroupModel(group), (snapshot) => applyEdgeGroupModel(group, snapshot));
    group.definition.implementation = { ...group.definition.implementation, source };
    applyEdgeGroupModel(group, captureEdgeGroupModel(group), { rerenderEditor: false });
    $('#groupInsertProviderTemplate').hidden = !source.trim();
}

// The one field whose commit isn't a plain changeEdgeGroupModel call: picking a different
// "Updates" state can require adding that state to a member node first, and doing so must land in
// the same undo step as the output-symbol change itself -- a lone state-add with no matching
// definition change would leave the model in a shape that was never actually valid at any point
// in history.
function changeGroupOutputSymbol(group) {
    if (activeResult) return;
    finishEquationEdit();
    const outputSymbol = $('#groupEquationOutput').value;
    if (!outputSymbol || outputSymbol === group.definition.output.symbol) return;
    const before = captureEdgeGroupModel(group);
    const after = structuredClone(before);
    after.definition.output = { symbol: outputSymbol };

    const autoAdd = $('#groupAutoAddStates').checked;
    const affectedNodes = autoAdd
        ? group.memberNodeIds
            .map((id) => model.nodes.find((node) => node.id === id))
            .filter((node) => node && !node.deleted && unresolvedGroupSymbols({ group: { definition: after.definition }, node }).length)
        : [];
    const nodeStatesBefore = new Map(affectedNodes.map((node) => [node.id, structuredClone(node.states)]));
    affectedNodes.forEach((node) => {
        node.states.push({ id: allocateModelEntityId(), label: outputSymbol, symbol: outputSymbol, initialValue: 0, unit: '', value: '0', className: '' });
    });
    const nodeStatesAfter = new Map(affectedNodes.map((node) => [node.id, structuredClone(node.states)]));
    const applyNodeStates = (statesById) => statesById.forEach((states, nodeId) => {
        const node = model.nodes.find((candidate) => candidate.id === nodeId);
        if (node) node.states = structuredClone(states);
    });

    applyEdgeGroupModel(group, after);
    recordHistory({
        undo: () => { applyNodeStates(nodeStatesBefore); applyEdgeGroupModel(group, before); },
        redo: () => { applyNodeStates(nodeStatesAfter); applyEdgeGroupModel(group, after); }
    });
}

function openEdgeGroupEditor(groupId) {
    const group = model.edgeGroups.find((item) => item.id === groupId && !item.deleted);
    if (!group) return;
    activeEdgeGroupId = groupId;
    selectedRelationship = null;
    const editor = $('#edgeGroupEditor');
    hideCards(editor);
    renderEdgeGroupEditor(group);
    editor.style.removeProperty('left');
    editor.style.removeProperty('top');
    editor.classList.remove('hidden');
    applyInspectorReadOnly();
    requestAnimationFrame(avoidAssistantInspectorOverlap);
}

// N member nodes expand to N(N-1) edges -- confirm before it grows large, and refuse outright
// past a point with no engine- or validator-side guard against the blowup (docs/edgeGroups.md).
function confirmEdgeGroupSize(nodeCount) {
    // N(N-1), not C(N,2): one directed edge each way per member pair (docs/edgeDirectionality.md).
    const edgeCount = nodeCount * (nodeCount - 1);
    if (nodeCount > 40) {
        window.alert(`An edge group can have at most 40 member nodes (${40 * 39} edges in the mesh).`);
        return false;
    }
    if (nodeCount > 10) {
        return window.confirm(`This will create ${edgeCount} edges between ${nodeCount} nodes. Continue?`);
    }
    return true;
}

function createEdgeGroupFromSelection() {
    if (activeResult || selectedNodeIds.size < 2) return false;
    const nodeIds = [...selectedNodeIds];
    if (!confirmEdgeGroupSize(nodeIds.length)) return false;
    const id = allocateModelEntityId();
    const group = {
        id,
        name: `Edge group ${model.edgeGroups.filter((item) => !item.deleted).length + 1}`,
        memberNodeIds: nodeIds,
        color: 0x2fb8a4,
        deleted: false,
        definition: { parameters: [], output: { symbol: '' }, equation: '', implementation: null }
    };
    model.edgeGroups.push(group);
    const nodesById = new Map(model.nodes.map((node) => [node.id, node]));
    const edges = expandEdgeGroup({ group, nodesById, allocateId: allocateModelEntityId });
    model.relationships.push(...edges);
    edges.forEach(createRelationship);
    updateRelationships();
    updateModelStatus();
    const edgeIds = edges.map((edge) => edge.id);
    const apply = (created) => {
        group.deleted = !created;
        edgeIds.forEach((edgeId) => setRelationshipVisibility(edgeId, created));
    };
    apply(true);
    recordHistory({ undo: () => apply(false), redo: () => apply(true) });
    openEdgeGroupEditor(id);
    return true;
}

function addNodeToGroup(group, nodeId) {
    if (activeResult || group.memberNodeIds.includes(nodeId)) return false;
    const node = model.nodes.find((candidate) => candidate.id === nodeId && !candidate.deleted);
    if (!node) return false;
    if (!confirmEdgeGroupSize(group.memberNodeIds.length + 1)) return false;
    const autoAdd = $('#groupAutoAddStates').checked;
    const symbol = group.definition.output.symbol;
    const needsState = autoAdd && symbol && unresolvedGroupSymbols({ group, node }).length > 0;
    // Allocated once, up front, and reused verbatim by both directions of the undo step below --
    // never re-allocated inside apply(), or redo would mint a second, different state each time.
    const newState = needsState
        ? { id: allocateModelEntityId(), label: symbol, symbol, initialValue: 0, unit: '', value: '0', className: '' }
        : null;
    const previewNode = newState ? { ...node, states: [...node.states, newState] } : node;
    const nodesById = new Map(model.nodes.map((candidate) => [candidate.id, candidate.id === nodeId ? previewNode : candidate]));
    // One edge in each direction against every existing member -- see memberPairs/expandEdgeGroup
    // and docs/edgeDirectionality.md for why a group's mesh uses directed pairs rather than one
    // bidirectional edge per member.
    const newEdges = group.memberNodeIds.flatMap((existingId) => [
        resolveGroupEdgeForPair({ group, sourceNode: nodesById.get(nodeId), targetNode: nodesById.get(existingId), allocateId: allocateModelEntityId }),
        resolveGroupEdgeForPair({ group, sourceNode: nodesById.get(existingId), targetNode: nodesById.get(nodeId), allocateId: allocateModelEntityId })
    ]);
    const apply = (added) => {
        if (added) {
            group.memberNodeIds.push(nodeId);
            if (newState) node.states.push(newState);
            model.relationships.push(...newEdges);
            newEdges.forEach(createRelationship);
        } else {
            group.memberNodeIds = group.memberNodeIds.filter((id) => id !== nodeId);
            if (newState) node.states = node.states.filter((state) => state.id !== newState.id);
            newEdges.forEach((edge) => setRelationshipVisibility(edge.id, false));
        }
        updateRelationships();
        updateModelStatus();
        if (currentEdgeGroup()?.id === group.id) renderEdgeGroupEditor(group);
    };
    apply(true);
    recordHistory({ undo: () => apply(false), redo: () => apply(true) });
    return true;
}

// Leaves the detached node's own edges to the rest of the group behind as ordinary edges, exactly
// as authored -- only clears groupId, per docs/edgeGroups.md. The rest of the mesh is
// untouched.
function detachNodeFromGroup(group, nodeId) {
    if (activeResult || !group.memberNodeIds.includes(nodeId)) return false;
    const touchedEdges = memberEdgesForGroup(group.id).filter((edge) => edge.source === nodeId || edge.target === nodeId);
    const apply = (detached) => {
        group.memberNodeIds = detached
            ? group.memberNodeIds.filter((id) => id !== nodeId)
            : [...group.memberNodeIds, nodeId];
        touchedEdges.forEach((edge) => { edge.groupId = detached ? null : group.id; });
        updateRelationships();
        updateModelStatus();
        if (currentEdgeGroup()?.id === group.id) renderEdgeGroupEditor(group);
    };
    apply(true);
    recordHistory({ undo: () => apply(false), redo: () => apply(true) });
    return true;
}

function deleteEdgeGroupAction(group) {
    if (activeResult) return false;
    const edgeIds = memberEdgesForGroup(group.id).map((edge) => edge.id);
    const apply = (deleted) => {
        group.deleted = deleted;
        edgeIds.forEach((id) => setRelationshipVisibility(id, !deleted));
        updateModelStatus();
    };
    apply(true);
    $('#edgeGroupEditor').classList.add('hidden');
    recordHistory({ undo: () => apply(false), redo: () => apply(true) });
    return true;
}

function toggleEdgeGroupEnabledAction(group) {
    if (activeResult) return false;
    const edges = memberEdgesForGroup(group.id);
    if (!edges.length) return false;
    const nextEnabled = edges.some((edge) => edge.enabled === false);
    const previous = new Map(edges.map((edge) => [edge.id, edge.enabled !== false]));
    const apply = (enabled) => {
        edges.forEach((edge) => setRelationshipEnabled(edge.id, enabled));
        if (currentEdgeGroup()?.id === group.id) renderEdgeGroupEditor(group);
    };
    apply(nextEnabled);
    recordHistory({
        undo: () => edges.forEach((edge) => setRelationshipEnabled(edge.id, previous.get(edge.id))),
        redo: () => apply(nextEnabled)
    });
    return true;
}

function createSubsystemFromSelection(name) {
    if (activeResult || !selectedNodeIds.size) return false;
    const nodeIds = [...selectedNodeIds];
    const id = allocateModelEntityId();
    const center = nodeIds.reduce((sum, nodeId) => sum.add(nodeObjects.get(nodeId).position), new THREE.Vector3())
        .multiplyScalar(1 / nodeIds.length);
    const serialized = serializeProjectDocument();
    const subsystem = {
        id,
        name: name.trim() || `Subsystem ${model.subsystems.filter((item) => !item.deleted).length + 1}`,
        parentSubsystemId: activeSubsystemId,
        position: center.toArray(),
        ports: deriveSubsystemPorts({ subsystemId: id, nodeIds, edges: serialized.edges, allocateId: allocateModelEntityId }),
        deleted: false
    };
    const previousMembership = new Map(nodeIds.map((nodeId) => [nodeId,
        model.nodes.find((node) => node.id === nodeId).subsystemId]));
    model.subsystems.push(subsystem);
    createSubsystemObject(subsystem);
    const apply = (created) => {
        subsystem.deleted = !created;
        nodeIds.forEach((nodeId) => {
            const node = model.nodes.find((item) => item.id === nodeId);
            node.subsystemId = created ? id : previousMembership.get(nodeId);
        });
        refreshSubsystemView();
    };
    apply(true);
    recordHistory({ undo: () => apply(false), redo: () => apply(true) });
    $('#statusText').textContent = `${subsystem.name} created with ${nodeIds.length} node${nodeIds.length === 1 ? '' : 's'} and ${subsystem.ports.length} boundary ${subsystem.ports.length === 1 ? 'port' : 'ports'}`;
    return true;
}

$('#createSubsystem').addEventListener('click', () => {
    if (activeResult || !selectedNodeIds.size) return;
    $('#subsystemName').value = `Subsystem ${model.subsystems.filter((item) => !item.deleted).length + 1}`;
    $('#subsystemDialog').showModal();
    $('#subsystemName').select();
});
$('#subsystemCancel').addEventListener('click', () => $('#subsystemDialog').close());
$('#subsystemDialog form').addEventListener('submit', (event) => {
    event.preventDefault();
    if (createSubsystemFromSelection($('#subsystemName').value)) $('#subsystemDialog').close();
});

$('#createEdgeGroup').addEventListener('click', () => createEdgeGroupFromSelection());
$('#nodeContextCreateEdgeGroup').addEventListener('click', () => {
    hideCards();
    createEdgeGroupFromSelection();
});
$('#nodeContextAddToGroup').addEventListener('click', () => {
    const group = currentEdgeGroup();
    hideCards($('#edgeGroupEditor'));
    if (group && selectedNode) addNodeToGroup(group, selectedNode.userData.id);
});
$('#nodeContextDetachFromGroup').addEventListener('click', () => {
    const group = currentEdgeGroup();
    hideCards($('#edgeGroupEditor'));
    if (group && selectedNode) detachNodeFromGroup(group, selectedNode.userData.id);
});
$('#edgeContextOpenGroup').addEventListener('click', () => {
    const groupId = selectedRelationship?.groupId;
    hideCards();
    if (groupId != null) openEdgeGroupEditor(groupId);
});

$('#groupAddMember').addEventListener('click', () => {
    const group = currentEdgeGroup();
    if (group && selectedNodeIds.size === 1) addNodeToGroup(group, [...selectedNodeIds][0]);
});
$('#toggleEdgeGroupEnabled').addEventListener('click', () => {
    const group = currentEdgeGroup();
    if (group) toggleEdgeGroupEnabledAction(group);
});
$('[data-delete-edge-group]').addEventListener('click', () => {
    const group = currentEdgeGroup();
    if (group) deleteEdgeGroupAction(group);
});
$('#groupName').addEventListener('change', (event) => {
    const group = currentEdgeGroup();
    if (group) changeEdgeGroupModel(group, (snapshot) => { snapshot.name = event.target.value.trim() || 'Untitled edge group'; });
});
$('#groupColor').addEventListener('change', (event) => {
    const group = currentEdgeGroup();
    if (group) changeEdgeGroupModel(group, (snapshot) => { snapshot.color = Number.parseInt(event.target.value.replace('#', ''), 16); });
});
$('#groupAddParameter').addEventListener('click', () => {
    const group = currentEdgeGroup();
    if (!group) return;
    changeEdgeGroupModel(group, (snapshot) => {
        snapshot.definition.parameters.push({
            id: allocateModelEntityId(), name: 'Parameter', symbol: `p${snapshot.definition.parameters.length + 1}`,
            value: 0, unit: '', mode: 'constant'
        });
    });
});
$('#groupEquationOutput').addEventListener('change', () => {
    const group = currentEdgeGroup();
    if (group) changeGroupOutputSymbol(group);
});
$('#groupImplementationKind').addEventListener('change', (event) => {
    const group = currentEdgeGroup();
    const isEquation = event.target.value === 'equation';
    $('#groupEquationHeading').hidden = !isEquation;
    $('#groupEquationDiagnostics').hidden = !isEquation;
    $('#groupFunctions').hidden = !isEquation;
    $('#groupReferenceHint').hidden = !isEquation;
    $('#groupProviderSection').hidden = isEquation;
    const latexMode = $('[data-group-equation-mode="latex"]').classList.contains('active');
    $('#groupMathField').hidden = !isEquation || latexMode;
    $('#groupEquation').hidden = !isEquation || !latexMode;
    if (!group) return;
    const kind = event.target.value;
    changeEdgeGroupModel(group, (snapshot) => {
        if (kind === 'equation') {
            snapshot.definition.implementation = null;
            return;
        }
        const bindings = snapshot.definition.implementation?.bindings ?? [];
        const output = snapshot.definition.implementation?.output ?? { key: 'output' };
        snapshot.definition.implementation = pluginOrProgram(kind, snapshot.definition.implementation, bindings, output, snapshot.name);
    });
});
$('#groupInsertProviderTemplate').addEventListener('click', () => {
    const group = currentEdgeGroup();
    if (!group?.definition.implementation) return;
    const { kind, bindings, output } = group.definition.implementation;
    if ($('#groupProviderSource').value.trim() &&
        !window.confirm('Replace the current provider source with a freshly generated template?')) return;
    changeEdgeGroupModel(group, (snapshot) => {
        snapshot.definition.implementation.source = defaultProviderSource(kind, bindings, output?.key, snapshot.name);
    });
});
$('#groupProviderSource').addEventListener('input', (event) => {
    previewGroupProviderSource(event.target.value);
});
$('#groupProviderSource').addEventListener('change', () => finishEquationEdit());
$('#groupProviderOutputKey').addEventListener('change', (event) => {
    const group = currentEdgeGroup();
    if (group) changeEdgeGroupModel(group, (snapshot) => {
        if (snapshot.definition.implementation) snapshot.definition.implementation.output = { key: event.target.value.trim() };
    });
});
$('#groupOpenProviderEditor').addEventListener('click', () => {
    const group = currentEdgeGroup();
    if (!group) return;
    providerEditTarget = { type: 'group', groupId: group.id };
    window.providerEditor.openWindow({
        source: $('#groupProviderSource').value,
        kind: $('#groupImplementationKind').value,
        title: group.name
    });
});
$('#groupAddProviderBinding').addEventListener('click', () => {
    const group = currentEdgeGroup();
    if (!group) return;
    const [previewSource, previewTarget] = groupPreviewPair(group);
    changeEdgeGroupModel(group, (snapshot) => {
        const candidates = providerReferenceCandidates({
            source: previewSource?.id, target: previewTarget?.id, parameters: snapshot.definition.parameters
        });
        if (!candidates.length) return;
        snapshot.definition.implementation.bindings.push(
            candidateToGroupBinding(`input${snapshot.definition.implementation.bindings.length + 1}`, candidates[0], previewSource, previewTarget));
    });
});
$('#groupMathField').addEventListener('input', (event) => {
    previewGroupEquation(event.target.value, 'visual');
});
$('#groupMathField').addEventListener('change', () => finishEquationEdit());
$('#groupEquation').addEventListener('input', (event) => {
    previewGroupEquation(event.target.value, 'latex');
});
$('#groupEquation').addEventListener('change', () => finishEquationEdit());
$$('[data-group-equation-mode]').forEach((button) => button.addEventListener('click', () => {
    $$('[data-group-equation-mode]').forEach((candidate) => candidate.classList.toggle('active', candidate === button));
    const latexMode = button.dataset.groupEquationMode === 'latex';
    $('#groupMathField').hidden = latexMode;
    $('#groupEquation').hidden = !latexMode;
    (latexMode ? $('#groupEquation') : $('#groupMathField')).focus();
}));

// Tooltips for the title bar and the toolstrip are drawn here, in one fixed layer of their own, not as a
// ::after of each button. Both bars clip their contents (so a narrow window scrolls or truncates instead of
// overlapping its neighbours), and a tooltip hanging below its button always lay outside that clip.
const barTooltipSelector = '#titleBar [data-tooltip], .toolstrip [data-tooltip]';
const barTooltip = document.createElement('div');
barTooltip.className = 'barTooltip';
barTooltip.setAttribute('role', 'tooltip');
document.body.append(barTooltip);
let barTooltipTarget = null;
let barTooltipTimer = 0;

function hideBarTooltip() {
    clearTimeout(barTooltipTimer);
    barTooltipTarget = null;
    barTooltip.classList.remove('visible');
}

function showBarTooltip(target) {
    const text = target.dataset.tooltip;
    if (!text || !target.isConnected) return;
    barTooltip.textContent = text;
    const anchor = target.getBoundingClientRect();
    const width = barTooltip.offsetWidth;
    const left = Math.min(Math.max(anchor.left + anchor.width / 2 - width / 2, 4), Math.max(4, window.innerWidth - width - 4));
    barTooltip.style.left = `${left}px`;
    barTooltip.style.top = `${anchor.bottom + 7}px`;
    barTooltip.classList.add('visible');
}

function trackBarTooltip(target, delay) {
    if (target === barTooltipTarget) return;
    hideBarTooltip();
    if (!target) return;
    barTooltipTarget = target;
    barTooltipTimer = setTimeout(() => showBarTooltip(target), delay);
}

document.addEventListener('pointerover', (event) => trackBarTooltip(event.target.closest?.(barTooltipSelector) ?? null, 350));
document.addEventListener('pointerdown', hideBarTooltip, true);
document.documentElement.addEventListener('pointerleave', hideBarTooltip);
document.addEventListener('focusin', (event) => {
    const target = event.target.closest?.(barTooltipSelector);
    if (target?.matches(':focus-visible')) trackBarTooltip(target, 0);
});
document.addEventListener('focusout', hideBarTooltip);
window.addEventListener('blur', hideBarTooltip);

$('#copySelection').addEventListener('click', copySelectedGraph);
$('#pasteSelection').addEventListener('click', pasteGraph);
window.addEventListener('focus', updateSelectionActionControls);

$('#newWindowButton').dataset.tooltip = `New window (${isMac ? '⌘N' : 'Ctrl+N'})`;
$('#loadButton').dataset.tooltip = `Open project (${isMac ? '⌘O' : 'Ctrl+O'})`;
$('#saveButton').dataset.tooltip = `Save project (${isMac ? '⌘S' : 'Ctrl+S'})`;
updateEncryptionControls();
$('#undoButton').dataset.tooltip = `Undo (${isMac ? '⌘Z' : 'Ctrl+Z'})`;
$('#redoButton').dataset.tooltip = `Redo (${isMac ? '⇧⌘Z' : 'Ctrl+Y'})`;
$('#copySelection').dataset.tooltip = `Copy selected (${isMac ? '⌘C' : 'Ctrl+C'})`;
$('#pasteSelection').dataset.tooltip = `Paste (${isMac ? '⌘V' : 'Ctrl+V'})`;
$('#selectAllShortcutHint').textContent = isMac ? '⌘A' : 'Ctrl+A';
$('#undoButton').addEventListener('click', undo);
$('#redoButton').addEventListener('click', redo);
updateHistoryControls();

const documentTitle = $('.documentTitle');
const documentTitleInput = $('.documentTitleInput');

function beginFilenameEdit() {
    documentTitleInput.value = filenameStem(currentProjectFilename);
    documentTitle.hidden = true;
    documentTitleInput.hidden = false;
    documentTitleInput.focus();
    documentTitleInput.select();
}

async function commitFilenameEdit() {
    if (documentTitleInput.hidden) return;
    const previousFilename = currentProjectFilename;
    const nextFilename = camelCaseFilename(documentTitleInput.value);
    documentTitleInput.hidden = true;
    documentTitle.hidden = false;
    currentProjectFilename = nextFilename;
    updateDocumentTitle();
    if (currentProjectPath && nextFilename !== previousFilename && !await saveProject(true)) {
        currentProjectFilename = previousFilename;
        updateDocumentTitle();
    }
}

function cancelFilenameEdit() {
    documentTitleInput.hidden = true;
    documentTitle.hidden = false;
}

documentTitle.addEventListener('click', beginFilenameEdit);
documentTitleInput.addEventListener('change', commitFilenameEdit);
documentTitleInput.addEventListener('blur', commitFilenameEdit);
documentTitleInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        event.preventDefault();
        documentTitleInput.blur();
    } else if (event.key === 'Escape') {
        event.preventDefault();
        cancelFilenameEdit();
    }
});

$('[data-action="delete"]').addEventListener('click', deleteSelected);
$('[data-delete-node]').addEventListener('click', () => {
    deleteSelected();
    $('#nodeEditor').classList.add('hidden');
});
$('[data-delete-edge]').addEventListener('click', () => {
    deleteSelected();
    $('#edgeEditor').classList.add('hidden');
});
$('#toggleNodeEnabled').addEventListener('click', toggleSelectedNodeEnabled);
$('#toggleEdgeEnabled').addEventListener('click', toggleSelectedEdgeEnabled);
$('#nodeContextConnect').addEventListener('click', () => {
    hideCards();
    if (!activeResult && selectedNode) connectFromNode(selectedNode);
});
$('#nodeContextToggle').addEventListener('click', () => {
    hideCards();
    toggleSelectedNodeEnabled();
});
$('#nodeContextDisableAll').addEventListener('click', () => {
    hideCards();
    setSelectedNodesEnabled(false);
});
$('#nodeContextEnableAll').addEventListener('click', () => {
    hideCards();
    setSelectedNodesEnabled(true);
});
$('#nodeContextDelete').addEventListener('click', () => {
    hideCards();
    deleteSelected();
});
$('#edgeContextToggle').addEventListener('click', () => {
    hideCards();
    toggleSelectedEdgeEnabled();
});
$('#edgeContextDelete').addEventListener('click', () => {
    hideCards();
    deleteSelected();
});
$('#edgeContextAddWaypoint').addEventListener('click', () => {
    hideCards();
    const staged = pendingWaypoint;
    pendingWaypoint = null;
    if (!staged || selectedRelationship?.id !== staged.relationshipId) return;
    changeEdgeModel(selectedRelationship, (clone) => {
        clone.waypoints.splice(staged.insertionIndex, 0, staged.point);
    });
});
$('#waypointContextRemove').addEventListener('click', () => {
    hideCards();
    const staged = pendingWaypointRemoval;
    pendingWaypointRemoval = null;
    const definition = staged && relationshipObjects.get(staged.relationshipId)?.definition;
    if (!definition) return;
    changeEdgeModel(definition, (clone) => {
        clone.waypoints.splice(staged.index, 1);
    });
});
$('[data-action="select-all"]').addEventListener('click', () => {
    hideCards();
    selectAllNodes();
});
window.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && activeEndpointPick) {
        finishEndpointPick();
        return;
    }
    const isEditing = event.target.matches?.('input, textarea, select, math-field') ||
        event.target.isContentEditable ||
        event.composedPath().some((element) => element?.matches?.('input, textarea, select, math-field') || element?.isContentEditable);
    const commandKey = isMac ? event.metaKey : event.ctrlKey;
    if (commandKey && (event.key === '+' || event.key === '=')) {
        event.preventDefault();
        $('#zoomInButton').click();
        return;
    }
    if (commandKey && event.key === '-') {
        event.preventDefault();
        $('#zoomOutButton').click();
        return;
    }
    if (commandKey && event.key === '0') {
        event.preventDefault();
        window.uiZoom.reset();
        $('#zoomOutButton').disabled = false;
        $('#zoomInButton').disabled = false;
        $('#zoomOutButton').dataset.tooltip = 'Zoom interface out · 100%';
        $('#zoomInButton').dataset.tooltip = 'Zoom interface in · 100%';
        return;
    }
    if (!isEditing && commandKey && event.key.toLowerCase() === 'n') {
        event.preventDefault();
        window.windowControls.newWindow();
        return;
    }
    if (!isEditing && commandKey && event.key.toLowerCase() === 'o') {
        event.preventDefault();
        openProject();
        return;
    }
    if (!isEditing && commandKey && event.key.toLowerCase() === 's') {
        event.preventDefault();
        saveProject(event.shiftKey);
        return;
    }
    if (!isEditing && commandKey && event.key.toLowerCase() === 'c' && selectedNodeIds.size) {
        event.preventDefault();
        copySelectedGraph();
        return;
    }
    if (!isEditing && commandKey && event.key.toLowerCase() === 'v') {
        event.preventDefault();
        pasteGraph();
        return;
    }
    if (!isEditing && commandKey && event.key.toLowerCase() === 'a') {
        event.preventDefault();
        selectAllNodes();
        return;
    }
    if (!isEditing && commandKey && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        if (event.shiftKey) redo();
        else undo();
        return;
    }
    if (!isEditing && !isMac && event.ctrlKey && event.key.toLowerCase() === 'y') {
        event.preventDefault();
        redo();
        return;
    }
    if (
        (event.key === 'Delete' || event.key === 'Backspace') &&
        !isEditing
    ) {
        deleteSelected();
    }
});

function resizeRenderer() {
    const rect = webglContainer.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    camera.aspect = rect.width / rect.height;
    camera.updateProjectionMatrix();
    renderer.setSize(rect.width, rect.height, false);
    labelRenderer.setSize(rect.width, rect.height);
}

new ResizeObserver(resizeRenderer).observe(webglContainer);
resizeRenderer();
setTool('select');
setCameraView('orbit', false);
updateModelStatus();
initializeAddonRailContributions();
checkPendingProjectOpen();

let lastRenderTime = 0;
let lastLabelRefresh = 0;
function render(time) {
    requestAnimationFrame(render);
    if (document.hidden || time - lastRenderTime < 1000 / 30) return;
    lastRenderTime = time;
    if (!updateCameraAnimation(time)) orbitControls.update();
    updateViewCube();
    // A model seen from far back keeps its shapes: the fog thins with the distance, and the far plane keeps up.
    const viewDistance = camera.position.distanceTo(orbitControls.target);
    scene.fog.density = fogDensityFor(viewDistance);
    const farPlane = farPlaneFor(viewDistance);
    if (camera.far !== farPlane) {
        camera.far = farPlane;
        camera.updateProjectionMatrix();
    }

    relationshipObjects.forEach((relationship) => {
        relationship.line.material.opacity = relationship.definition.id === selectedRelationship?.id
            ? 1
            : 0.92;
    });

    if (time - lastLabelRefresh > 250) {
        lastLabelRefresh = time;
        refreshLabelDeclutter();
        if (labelModes.nodes === 'hidden' || labelModes.edges === 'hidden') refreshLabelObjectVisibility();
    }
    renderer.render(scene, camera);
    labelRenderer.render(scene, camera);
}

labelSystemReady = true;
updateLabelPeek();
requestAnimationFrame(render);
