/* Copyright © 2026 Zenin Easa Panthakkalakath */

import { app, BrowserWindow, clipboard, dialog, ipcMain, safeStorage, screen, shell } from 'electron';
import { spawn } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, readdirSync } from 'node:fs';
import { access, mkdir, mkdtemp, readFile, readdir, rename, rm, stat, unlink, writeFile } from 'node:fs/promises';
import { release as osRelease, tmpdir } from 'node:os';
import { basename, dirname, join, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { decodeProjectBundle, encodeProjectFile, inspectProjectFile } from './projectFile.mjs';
import { checkSubstepConvergenceWithEngine, cppProviderSdkPath, fitWithEngine, getEngineCapabilities, inferWithEngine, startEngineRun, validateWithEngine } from './engineAdapter.mjs';
import { generateFmuPackage, mergeFmuPackages } from './fmiExport.mjs';
import { executionProjectDocument } from './subsystems.mjs';
import { stripEdgeGroups } from './edgeGroups.mjs';
import { projectDocumentSignals, resultSignalsToCsv } from './resultExport.mjs';
import { matchRunConfiguration, parseCliFlags } from './cliArgs.mjs';
import {
    buildVisualizerDataEntry,
    createVisualizerSession,
    publicToolstripContributions,
    publicVisualizerContext,
    readSignalSeries,
    validateAddonManifest,
    visualizerDataFromEntry
} from './addonHost.mjs';
import { createAIConfigurationStore, createElectronCredentialVault } from './aiConfigurationStore.mjs';
import { createAIProviderRegistry } from './aiProviderRegistry.mjs';
import { createRemoteAIProviders } from './aiRemoteProviders.mjs';
import { openIndexedResult } from './indexedResultReader.mjs';
import { defaultPlaybackSampleLimit, rendererResultProjection, resultSignalSeries, checkpointIndex } from './resultSession.mjs';
import { createProviderToolchainStore, providerExecutionModes } from './providerToolchainStore.mjs';
import { installSource } from './updateCheck.mjs';
import { createUpdateCoordinator } from './updateCoordinator.mjs';
import { createUpdateSkipStore } from './updateSkipStore.mjs';
import { bugReportUrl } from './bugReport.mjs';
import { createLatestThrottle, createRequestWatchdog, maximumRequestSeconds } from './aiRequestTiming.mjs';
import { fetchWelcomeFeed, parseWelcomeFeed, selectFeatured, welcomeFeedUrl, welcomeImageUrl } from './welcomeFeed.mjs';
import { welcomeLinks, whatsNewFor } from './welcomeModel.mjs';
import { createWelcomeStateStore, withDismissed, withEpisodeOpened, withFeaturedShown, withLastSeenVersion } from './welcomeStateStore.mjs';
import { fetchRecentBlogPosts } from './welcomeContent.mjs';
import { shouldSkipWelcomeTrigger } from './welcomeTrigger.mjs';
import { guideKindSuffix } from './exampleGuide/guideKind.mjs';
import { auxiliaryWindowPresentation, auxiliaryWindowBounds } from './windowLifecycle.mjs';
import { parseKjtPathFromArgv } from './fileAssociation.mjs';
import { listDiagnostics, onDiagnostic, recordDiagnostic } from './diagnosticsLog.mjs';
import { inspectPackageArchive, installPackageArchive, listInstalledPackages, loadNamespaceRegistry, packageCompatibility, packageKey, registryVideoUrlPattern, uninstallPackage } from './packageArchive.mjs';
import { isNewerPackageVersion } from './versionCompare.mjs';
import { checkEntryUpdate, createReleaseFactsCache, fetchRegistryImage, fetchRegistryScreenshot, fetchRemoteRegistry, identifyRegistryImage, installFromRegistryEntry, registryImageUrl, registryScreenshotUrl } from './registryClient.mjs';
import { inspectFmuArchive, installFmuArchive, listInstalledFmus, uninstallFmu } from './fmuPackage.mjs';
import { describeInstalledFmuPorts } from './fmiResolver.mjs';
import { createExtensionStateStore } from './extensionStateStore.mjs';
import { exampleCatalogEntry, exampleIdFromFileName, exampleLabel } from './exampleCatalog.mjs';
import { validateComponentTemplate } from './componentTemplate.mjs';
import { registerLauncherHandlers } from './launcherHost.mjs';
import { addonCacheDirectory } from './addonCache.mjs';
import { createAddonSettingsStore } from './addonSettingsStore.mjs';
import { keepAddonData, requestAddonData } from './projectAddonData.mjs';
import { normalizeShapeLibraryEntry } from './shapeLibraryCatalog.mjs';

if ((process.argv.includes('--interaction-test') || process.argv.includes('--generate-example-thumbnails')) && process.env.KONJUGATE_INTERACTION_USER_DATA) {
    app.setPath('userData', process.env.KONJUGATE_INTERACTION_USER_DATA);
}

// A --cli invocation is a one-shot batch job (run/validate a project, write output, exit), not
// a GUI instance -- it must run and exit on its own even while a real GUI instance is already
// open, so it skips single-instance-lock/open-file entirely below rather than risk being
// silently absorbed into an already-running instance's second-instance handler and never
// actually doing anything.
const isCliMode = process.argv.includes('--cli');

// macOS can fire 'open-file' (double-click on a .kjt) before 'ready' resolves on a cold
// launch -- queued here and drained once app.whenReady() runs, rather than assuming a window
// already exists. openOrFocusProjectFile/parseKjtPathFromArgv are function declarations
// defined further down; referencing them here is safe since neither handler below can run
// before the rest of this module (and their const dependencies) has finished evaluating.
const openFileQueue = [];
if (!isCliMode) {
    app.on('open-file', (event, path) => {
        event.preventDefault();
        if (app.isReady()) openOrFocusProjectFile(path);
        else openFileQueue.push(path);
    });

    // Must run after the userData override above (requestSingleInstanceLock's lock file lives
    // under userData) so interaction-test/thumbnail runs never false-positive collide with a
    // real running instance, or each other in CI, by checking the default profile's lock file
    // instead.
    if (!app.requestSingleInstanceLock()) {
        app.quit();
        process.exit(0);
    }
    app.on('second-instance', (_event, argv) => {
        const path = parseKjtPathFromArgv(argv);
        if (path) {
            openOrFocusProjectFile(path);
            return;
        }
        const [anyProjectWindow] = projectWindows;
        if (anyProjectWindow?.isMinimized()) anyProjectWindow.restore();
        anyProjectWindow?.show();
        anyProjectWindow?.focus();
    });
}

// Backstop for anything logged via console.error/console.warn -- including paths nobody has
// explicitly wired up to a UI element -- so it still reaches the renderer's diagnostics panel
// instead of vanishing into a console nobody watching a packaged app will ever open.
function formatConsoleArgs(args) {
    return args.map((arg) => (
        arg instanceof Error ? (arg.stack || arg.message) : (typeof arg === 'string' ? arg : JSON.stringify(arg))
    )).join(' ');
}
const originalConsoleError = console.error.bind(console);
const originalConsoleWarn = console.warn.bind(console);
console.error = (...args) => {
    originalConsoleError(...args);
    recordDiagnostic({ severity: 'error', message: formatConsoleArgs(args) });
};
console.warn = (...args) => {
    originalConsoleWarn(...args);
    recordDiagnostic({ severity: 'warning', message: formatConsoleArgs(args) });
};
process.on('uncaughtException', (error) => console.error('Uncaught exception:', error));
process.on('unhandledRejection', (reason) => console.error('Unhandled rejection:', reason));

app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');

const currentDir = dirname(fileURLToPath(import.meta.url));
// Konjugate's own icon, used by every window (the project window and each auxiliary and add-on window) so none
// falls back to the default Electron icon in a taskbar or window switcher.
const appIconPath = join(currentDir, '..', 'assets', 'icons', 'app.png');
const pendingEncryptedPaths = new Set();
// Every open project window, plus one state record per window replacing what used to be a
// single set of module-level globals -- each project window gets its own aux windows (example
// guide/about, provider editor, results visualizer) and its own pending-provider-apply state,
// since two project windows can now legitimately have any of these open at once.
const projectWindows = new Set();
const projectWindowState = new WeakMap();
function createProjectWindowState() {
    return {
        exampleGuideWindow: null, exampleGuideBounds: null,
        providerEditorWindow: null, providerEditorBounds: null, providerEditorOwner: null, pendingProviderApply: null,
        analysisWindow: null, analysisAddonId: null, visualizerManifest: null, visualizerSession: null,
        currentProjectPath: null
    };
}
// A window created specifically to open an OS-provided file (double-click, second-instance
// argv, macOS open-file) stores its decode outcome here -- keyed by promise rather than a
// plain value so it's set synchronously at window-creation time (avoiding a race against the
// renderer's own pending-open pull, which can fire before an async readFile/decode settles).
const pendingWindowOpens = new WeakMap();
const addonRegistry = new Map();
const activeEngineJobs = new Map();
const completedEngineResults = new Map();
const activeAIRequests = new Map();
const activeAIOperations = new Set();
const activeValidationOperations = new Set();
const activeInferenceOperations = new Set();
const activeFittingOperations = new Set();
let aiProviderRegistry = null;
let aiConfigurationStore = null;
let providerToolchainStore = null;
let extensionStateStore = null;
// Set once an add-on/plugin is installed or uninstalled (not FMUs, and not enable/disable --
// both already take effect immediately) and never cleared except by an actual restart, since
// that's what makes it true again. Broadcast to every open window, not just the one the install
// happened in, since a restart affects the whole app.
// ---- Package compatibility (docs/proposals/packageCompatibility.md)
//
// An installed package can need a newer Konjugate than the one running (after the app is downgraded, or when a package was put
// in place by hand). Such a package is not loaded: it is left out of discovery like a disabled one, listed as incompatible, and
// offered a compatible release. Returns a Map of packageKey -> { compatible: false, reason, required, running }.
async function incompatiblePackages() {
    const appVersion = app.getVersion();
    const installed = await listInstalledPackages(join(app.getPath('userData'), 'packages'));
    const incompatible = new Map();
    for (const pkg of installed) {
        const verdict = packageCompatibility({ minimumKonjugateVersion: pkg.minimumKonjugateVersion }, appVersion);
        if (!verdict.compatible) incompatible.set(packageKey(pkg.packageType, pkg.packageId, pkg.version), verdict);
    }
    return incompatible;
}
// Disabled and incompatible packages together: the keys discovery and plugin resolution must not load.
async function unavailablePackageKeys() {
    return [...await extensionStateStore.list(), ...(await incompatiblePackages()).keys()];
}

// What is known about each published release of each registry package (its minimum Konjugate version and API versions, never a
// verdict about this app), kept on disk so a release that is too new is not downloaded again at every start. See registryClient.mjs.
let releaseFactsCachePromise = null;
function releaseFactsCache() {
    releaseFactsCachePromise ??= (async () => {
        const file = join(app.getPath('userData'), 'packages', 'releaseFacts.json');
        const initial = await readFile(file, 'utf8').then((text) => JSON.parse(text)).catch(() => ({}));
        return createReleaseFactsCache({
            initial: initial && typeof initial === 'object' && !Array.isArray(initial) ? initial : {},
            onChange: (facts) => { mkdir(dirname(file), { recursive: true }).then(() => writeFile(file, JSON.stringify(facts))).catch(() => {}); }
        });
    })();
    return releaseFactsCachePromise;
}

let packageRestartPending = false;
function markPackageRestartPending() {
    packageRestartPending = true;
    // Whatever's on disk just changed, so a cached update check (see packageCheckUpdates below) may
    // now be reporting a package as outdated that was just updated, or missing one just installed.
    packageUpdatesCache = null;
    for (const window of projectWindows) {
        if (!window.isDestroyed()) window.webContents.send('packageRestartPendingChanged', true);
    }
}
// { checkedAt, promise } for the last packageCheckUpdates run, shared by every window -- each
// window's renderer checks once on startup to badge its Extensions button, and without this a
// handful of open windows would each spend their own round of GitHub API calls (unauthenticated:
// 60/hour/IP) on an identical answer. Cleared by markPackageRestartPending above.
let packageUpdatesCache = null;
const packageUpdatesCacheTtlMs = 60 * 60 * 1000;
let applicationShutdownPromise = null;
let applicationShutdownComplete = false;

function getWindowFromEvent(event) {
    return BrowserWindow.fromWebContents(event.sender);
}

function senderIs(window, event) {
    return Boolean(window && !window.isDestroyed() && event.sender === window.webContents);
}

function isProjectWindow(window) {
    return Boolean(window && !window.isDestroyed() && projectWindows.has(window));
}

function senderIsProjectWindow(event) {
    return isProjectWindow(getWindowFromEvent(event));
}

function requireProjectWindow(event, message = 'Only a project window can do this.') {
    if (!senderIsProjectWindow(event)) throw new Error(message);
}

// Reverse lookup for an auxiliary window's own IPC handlers: given the event from e.g. the
// results-visualizer window itself, find which project window owns it (by comparing against
// that field in every project window's state record) -- the aux window has no identity of its
// own to gate on, only "whichever project window currently has one open under this field."
function projectWindowForAuxSender(event, field) {
    for (const projectWindow of projectWindows) {
        if (senderIs(projectWindowState.get(projectWindow)[field], event)) return projectWindow;
    }
    return null;
}

function installCustomWindowState(window) {
    const sendExpandedState = (expanded) => {
        if (!window.webContents.isDestroyed()) window.webContents.send('windowMaximizedChange', expanded);
    };
    window.on('maximize', () => sendExpandedState(true));
    window.on('unmaximize', () => sendExpandedState(false));
    window.on('enter-full-screen', () => sendExpandedState(true));
    window.on('leave-full-screen', () => sendExpandedState(false));
    window.webContents.on('did-finish-load', () => {
        sendExpandedState(process.platform === 'darwin' ? window.isFullScreen() : window.isMaximized());
    });
}

// pendingFileOpen, when given, is a Promise resolving to the payload the new window's
// renderer will pull via projectPendingOpen once it's ready to load a project.
function createProjectWindow(pendingFileOpen) {
    const window = new BrowserWindow({
        width: 1200,
        height: 760,
        minWidth: 720,
        minHeight: 480,
        frame: false,
        backgroundColor: '#08111f',
        title: 'Konjugate',
        icon: appIconPath,
        webPreferences: {
            preload: join(currentDir, 'preload.mjs'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: false,
            backgroundThrottling: false
        }
    });
    window.maximize();
    projectWindows.add(window);
    projectWindowState.set(window, createProjectWindowState());
    if (pendingFileOpen) pendingWindowOpens.set(window, pendingFileOpen);
    window.on('closed', () => projectWindows.delete(window));

    const owner = window.webContents;
    const ownerUnavailable = () => {
        abortAIOperations(owner);
        shutdownValidationOperations(owner);
        shutdownInferenceOperations(owner);
        shutdownFittingOperations(owner);
        shutdownEngineJobs(owner);
    };
    owner.once('destroyed', ownerUnavailable);
    owner.once('render-process-gone', ownerUnavailable);

    installCustomWindowState(window);

    window.loadFile(join(currentDir, 'renderer', 'index.html'));
    return window;
}

function findProjectWindowByPath(path) {
    for (const projectWindow of projectWindows) {
        if (projectWindowState.get(projectWindow).currentProjectPath === path) return projectWindow;
    }
    return null;
}

// The single entry point for every OS-initiated open (double-click, second-instance argv,
// macOS open-file): reuses an already-open window on this exact file rather than opening a
// confusing duplicate, otherwise opens a new window and lets its renderer pull the decoded
// (or failed) payload once it's ready via projectPendingOpen.
function openOrFocusProjectFile(path) {
    const existing = findProjectWindowByPath(path);
    if (existing) {
        if (existing.isMinimized()) existing.restore();
        existing.show();
        existing.focus();
        return;
    }
    createProjectWindow(readProjectFilePayload(path).catch((error) => ({ error: error.message })));
}

// What the app knows about updates, and when to ask GitHub again -- see src/updateCoordinator.mjs and
// docs/updates.md. There is no dialog: a quiet badge on the title bar's Konjugate button and the
// Updates section of the Welcome window show the result, and the windows are told whenever it changes.
let updateCoordinator = null;

function broadcastUpdateStatus(status) {
    for (const window of BrowserWindow.getAllWindows()) {
        if (!window.isDestroyed()) window.webContents.send('appUpdateStatus', status);
    }
}

async function startUpdateChecks() {
    updateCoordinator = createUpdateCoordinator({
        source: installSource(),
        running: app.getVersion(),
        appImagePath: process.env.APPIMAGE,
        skipStore: createUpdateSkipStore({ directory: app.getPath('userData') }),
        onChange: broadcastUpdateStatus
    });
    await updateCoordinator.init();
    // The launch check. Later ones happen when a window regains focus and the last good answer is a
    // day old (below), which is what covers an app left running for days.
    updateCoordinator.maybeCheck();
}

ipcMain.handle('appUpdateStatus', () => updateCoordinator?.status() ?? null);
ipcMain.handle('appUpdateCheckNow', () => updateCoordinator?.checkNow() ?? null);
ipcMain.handle('appUpdateSkip', (_event, version) => {
    if (typeof version !== 'string' || version === '') return updateCoordinator?.status() ?? null;
    return updateCoordinator.skip(version);
});
// The window never supplies the text: the command comes from the status the main process holds, so a
// page cannot put anything it likes on the clipboard through this.
ipcMain.handle('appUpdateCopyCommand', () => {
    const command = updateCoordinator?.status().command;
    if (!command) return false;
    clipboard.writeText(command);
    return true;
});
app.on('browser-window-focus', () => { updateCoordinator?.maybeCheck(); });

async function openGuideWindow(projectWindow, payload) {
    const state = projectWindowState.get(projectWindow);
    if (!state.exampleGuideWindow || state.exampleGuideWindow.isDestroyed()) {
        const createdWindow = new BrowserWindow({
        icon: appIconPath,
            ...auxiliaryWindowBounds(projectWindow, 720, 760, state.exampleGuideBounds, screen),
            ...auxiliaryWindowPresentation(projectWindow),
            minWidth: 480,
            minHeight: 420,
            frame: false,
            backgroundColor: '#09131b',
            title: `${payload.title} · ${guideKindSuffix(payload.kind)}`,
            webPreferences: {
                preload: join(currentDir, 'exampleGuide', 'preload.cjs'),
                contextIsolation: true,
                nodeIntegration: false,
                sandbox: true
            }
        });
        state.exampleGuideWindow = createdWindow;
        installCustomWindowState(createdWindow);
        createdWindow.on('close', () => { state.exampleGuideBounds = createdWindow.isDestroyed() ? state.exampleGuideBounds : createdWindow.getBounds(); });
        createdWindow.on('closed', () => { if (state.exampleGuideWindow === createdWindow) state.exampleGuideWindow = null; });
        createdWindow.webContents.once('did-finish-load', () => { if (!createdWindow.isDestroyed()) createdWindow.webContents.send('exampleGuideContent', payload); });
        await createdWindow.loadFile(join(currentDir, 'exampleGuide', 'index.html'));
    } else {
        state.exampleGuideWindow.setTitle(`${payload.title} · ${guideKindSuffix(payload.kind)}`);
        state.exampleGuideWindow.webContents.send('exampleGuideContent', payload);
        state.exampleGuideWindow.show();
        state.exampleGuideWindow.focus();
    }
    return true;
}

async function openExampleGuide(projectWindow, id) {
    const pluginExample = (await discoverPluginExamples()).get(id);
    if (pluginExample) {
        // A plugin example's guide is optional: without one there is simply nothing to open.
        if (!pluginExample.guide) return false;
        return openGuideWindow(projectWindow, { id, title: pluginExample.name, markdown: await readFile(pluginExample.guide, 'utf8'), kind: 'example' });
    }
    if (!(await exampleFiles()).includes(id)) throw new Error('That example is not available.');
    const guideName = `${exampleIdFromFileName(id)}.md`;
    const markdown = await readFile(join(examplesDir, guideName), 'utf8');
    return openGuideWindow(projectWindow, {
        id,
        title: exampleLabel(id),
        markdown,
        kind: 'example'
    });
}

// docs/ is excluded wholesale from packaging (see ignoredTopLevelDirectories in
// packageElectron.mjs) -- welcome.md is shipped individually as its own extraResource instead,
// which @electron/packager copies flattened directly into Resources/, not Resources/docs/.
function welcomeMarkdownPath() {
    return app.isPackaged ? join(process.resourcesPath, 'welcome.md') : join(currentDir, '..', 'docs', 'welcome.md');
}

// assets/ is never excluded from packaging (unlike docs/ above), so these need no extraResource
// entry and no app.isPackaged branch -- same as the app icon reference a few lines up.
const welcomeAssetsDir = join(currentDir, '..', 'assets', 'welcome');

// The On-Ramp tutorial series, from the bundled assets/welcome/videos.json: the same episodes, in the
// same order, every time, whatever the network does. Never rotated or replaced (see
// docs/proposals/welcomeWindow.md); only adding an episode to that file changes it.
let welcomeOnRampCache = null;
async function welcomeOnRamp() {
    if (!welcomeOnRampCache) {
        const manifest = JSON.parse(await readFile(join(welcomeAssetsDir, 'videos.json'), 'utf8'));
        // Thumbnails are loaded live from YouTube's own public thumbnail CDN (img-src allows it in
        // exampleGuide/index.html's CSP) rather than a screenshot bundled and committed per video --
        // one less asset to keep in sync by hand every time a new episode is added.
        welcomeOnRampCache = {
            playlistUrl: typeof manifest.playlistUrl === 'string' ? manifest.playlistUrl : null,
            episodes: manifest.videos.map((video) => ({
                videoId: video.videoId,
                title: video.title,
                url: `https://www.youtube.com/watch?v=${video.videoId}`,
                thumbnailUrl: `https://img.youtube.com/vi/${video.videoId}/hqdefault.jpg`
            }))
        };
    }
    return welcomeOnRampCache;
}

// Short highlights for a version's "What's new", authored per release in assets/welcome/whatsNew.json
// ({ "1.2.0": ["...", "..."] }). Optional: without an entry the block is just the release-notes link.
async function welcomeWhatsNewHighlights(version) {
    try {
        const all = JSON.parse(await readFile(join(welcomeAssetsDir, 'whatsNew.json'), 'utf8'));
        return Array.isArray(all?.[version]) ? all[version] : [];
    } catch {
        return [];
    }
}

let welcomeStateStoreInstance = null;
const welcomeState = () => (welcomeStateStoreInstance ??= createWelcomeStateStore({ directory: app.getPath('userData') }));

// A one-time starter-pack offer (see the Recommended add-ons section of docs/extensionsExplorer.md):
// shown once ever, regardless of what the person does with it -- declining is as final as
// accepting, per that section's "must be ... never repeated once declined or accepted". The flag
// is only written at the moment something is actually about to be shown (see openWelcomeWindow
// below), not just because this function ran, so a quiet launch (registry unreachable, or nothing
// left to recommend) doesn't burn the one-time offer on nothing.
const recommendedAddonsOfferedPath = () => join(app.getPath('userData'), 'recommendedAddonsOffered.json');
async function hasOfferedRecommendedAddons() {
    try {
        return JSON.parse(await readFile(recommendedAddonsOfferedPath(), 'utf8')).offered === true;
    } catch {
        return false;
    }
}
async function markRecommendedAddonsOffered() {
    const temporaryPath = `${recommendedAddonsOfferedPath()}.${randomUUID()}.tmp`;
    await writeFile(temporaryPath, JSON.stringify({ offered: true }));
    await rename(temporaryPath, recommendedAddonsOfferedPath());
}

// Entries the live (or cache/bundled-fallback) registry flags recommended:true, minus whatever's
// already installed or bundled -- recomputed fresh each launch rather than cached, since "already
// installed" can change between launches independently of the one-time offered flag.
async function recommendedAddonEntries() {
    let registry;
    try {
        registry = (await discoverableRegistry()).registry;
    } catch {
        return [];
    }
    await discoverAddons();
    const installedIds = new Set([
        ...(await listInstalledPackages(join(app.getPath('userData'), 'packages'))).map((entry) => entry.packageId),
        ...[...addonRegistry.values()].map(({ manifest }) => manifest.addonId)
    ]);
    return Object.entries(registry.prefixes ?? {})
        .filter(([, entry]) => entry.recommended && entry.packages.some((declared) => !installedIds.has(declared.packageId)))
        .map(([prefix, entry]) => ({ prefix, ...entry }));
}

// ---- The Welcome window's content that comes from the network (docs/proposals/welcomeWindow.md)
//
// The Featured slot and "More to watch" come from welcome/featured.json in this repository. The last
// good copy is kept on disk, so a launch with no network still shows it, and with neither there is
// simply nothing featured. Images are fetched by this process and handed over as data: URLs, so the
// page's content-security policy never needs to allow another host.
const welcomeFeedCachePath = () => join(app.getPath('userData'), 'welcomeFeedCache.json');
let currentWelcomeFeed = { featured: [], moreToWatch: [], problems: [] };

async function readCachedWelcomeFeed() {
    try {
        return parseWelcomeFeed(JSON.parse(await readFile(welcomeFeedCachePath(), 'utf8')));
    } catch {
        return parseWelcomeFeed(null);
    }
}

async function refreshWelcomeFeed() {
    const raw = await fetchWelcomeFeed();
    const feed = parseWelcomeFeed(raw);
    // A file that is not the feed format is treated as "nothing new", and the cached copy is kept.
    if (feed.problems.length && !feed.featured.length && !feed.moreToWatch.length && raw?.format !== 'konjugate-welcome-feed') return null;
    for (const problem of feed.problems) console.warn(`Welcome feed: ${problem}`);
    const temporaryPath = `${welcomeFeedCachePath()}.${randomUUID()}.tmp`;
    await writeFile(temporaryPath, JSON.stringify(raw));
    await rename(temporaryPath, welcomeFeedCachePath());
    return feed;
}

async function fetchWelcomeImage(url) {
    const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    return { mimeType: identifyRegistryImage(bytes, url), bytes };
}

// The Featured item as the page needs it: its text, and its image once that has been resolved to a
// data: URL (null until then). The link itself stays here -- the page asks to open an item by id
// (welcomeOpenFeatured).
// A video item that has no image of its own shows its video's thumbnail from YouTube's public thumbnail CDN, loaded by
// the page the way the On-Ramp cards' are (see the CSP in exampleGuide/index.html), so it needs nothing in the repository.
const featuredPayload = (item, imageUrl = null) => (item ? {
    id: item.id, kind: item.kind, title: item.title, text: item.text, imageUrl, playlist: item.playlist,
    thumbnailUrl: item.thumbnailVideoId ? `https://img.youtube.com/vi/${item.thumbnailVideoId}/hqdefault.jpg` : null
} : null);

// The image, from the on-disk cache or the network, or null. Separate from the payload above so it
// never holds the window back: it arrives as a patch.
async function resolveFeaturedImage(item) {
    const url = item?.image ? welcomeImageUrl(item.image, welcomeFeedUrl()) : null;
    if (!url) return null;
    return cachedRegistryImage(`welcome-${createHash('sha256').update(url).digest('hex').slice(0, 16)}`, () => fetchWelcomeImage(url), `Featured image for ${item.id}`);
}

let welcomeGeneration = 0;
let whatsNewForThisRun;

// Opens (or refreshes) the Welcome window at once with everything that is local -- the On-Ramp, the
// footer text, what the person has opened and dismissed, the last good Featured feed -- and then fills
// in the rest as it arrives (blog posts, the add-on offer, a fresh feed) by sending the open window
// patches. Nothing here waits on the network before the window appears, so a slow or absent
// connection can no longer delay it. `automatic` is true for the launch and dock-reactivation opens,
// which are what a Featured item's launch cap counts; clicking the Konjugate button is not a launch.
async function openWelcomeWindow(projectWindow, { automatic = false } = {}) {
    const generation = ++welcomeGeneration;
    const version = app.getVersion();
    const [markdown, onRamp, state, cachedFeed] = await Promise.all([
        readFile(welcomeMarkdownPath(), 'utf8'), welcomeOnRamp(), welcomeState().get(), readCachedWelcomeFeed()
    ]);
    // What's new is worked out once per run: the first time it is needed it also records the version as
    // seen, and later opens in the same run (another window, the Konjugate button) show the same block.
    if (whatsNewForThisRun === undefined) {
        whatsNewForThisRun = whatsNewFor({ running: version, lastSeen: state.lastSeenVersion, highlights: await welcomeWhatsNewHighlights(version) });
        if (state.lastSeenVersion !== version) await welcomeState().update((current) => withLastSeenVersion(current, version));
    }
    currentWelcomeFeed = cachedFeed;

    let countedFeaturedId = null;
    const chooseFeatured = async (feed) => {
        const current = await welcomeState().get();
        const item = selectFeatured({ items: feed.featured, now: Date.now(), dismissed: current.dismissedFeatured, shown: current.featuredShown });
        if (item && automatic && countedFeaturedId !== item.id) {
            countedFeaturedId = item.id;
            await welcomeState().update((latest) => withFeaturedShown(latest, item.id));
        }
        return item;
    };

    const initialFeatured = await chooseFeatured(cachedFeed);
    await openGuideWindow(projectWindow, {
        title: 'Konjugate',
        version,
        markdown,
        kind: 'welcome',
        generation,
        onRamp,
        openedEpisodes: state.openedEpisodes,
        whatsNew: whatsNewForThisRun,
        featured: featuredPayload(initialFeatured),
        moreToWatch: cachedFeed.moreToWatch,
        posts: [],
        recommendedAddons: []
    });
    const guideWindow = projectWindowState.get(projectWindow)?.exampleGuideWindow;
    const patch = (partial) => {
        if (guideWindow && !guideWindow.isDestroyed()) guideWindow.webContents.send('welcomePatch', { generation, ...partial });
    };
    const alive = () => Boolean(guideWindow) && !guideWindow.isDestroyed() && generation === welcomeGeneration;

    // Each of these runs on its own and may fail on its own; none is waited for.
    const sendFeaturedImage = (item) => resolveFeaturedImage(item).then((imageUrl) => {
        if (imageUrl && alive()) patch({ featured: featuredPayload(item, imageUrl) });
    }).catch((error) => console.warn('Welcome featured image:', error.message));
    if (initialFeatured) sendFeaturedImage(initialFeatured);
    fetchRecentBlogPosts().then((posts) => {
        patch({ posts: posts.map((post) => ({ title: post.title, url: post.link, thumbnailUrl: post.thumbnailUrl })) });
    }).catch((error) => console.warn('Welcome blog posts:', error.message));
    (async () => {
        if (await hasOfferedRecommendedAddons()) return;
        const recommendedAddons = await recommendedAddonEntries();
        // The one-time offer is only spent when it is actually put in front of someone.
        if (!recommendedAddons.length || !alive()) return;
        await markRecommendedAddonsOffered();
        patch({ recommendedAddons });
    })().catch((error) => console.warn('Welcome add-on offer:', error.message));
    refreshWelcomeFeed().then(async (feed) => {
        if (!feed || !alive()) return;
        currentWelcomeFeed = feed;
        const featured = await chooseFeatured(feed);
        patch({ featured: featuredPayload(featured), moreToWatch: feed.moreToWatch });
        if (featured) sendFeaturedImage(featured);
    }).catch((error) => console.warn('Welcome feed:', error.message));
    return true;
}

// What the Welcome window can ask of the main process. Each takes only an id or nothing: the page never
// supplies a URL or text, so it cannot make this process open or copy anything of its own choosing.
ipcMain.handle('welcomeEpisodeOpened', async (_event, videoId) => {
    const { episodes } = await welcomeOnRamp();
    if (typeof videoId !== 'string' || !episodes.some((episode) => episode.videoId === videoId)) return false;
    await welcomeState().update((current) => withEpisodeOpened(current, videoId));
    return true;
});
ipcMain.handle('welcomeDismissFeatured', async (_event, id) => {
    if (typeof id !== 'string' || !currentWelcomeFeed.featured.some((item) => item.id === id)) return false;
    await welcomeState().update((current) => withDismissed(current, id));
    return true;
});
ipcMain.handle('welcomeOpenFeatured', (_event, id) => {
    const item = currentWelcomeFeed.featured.find((candidate) => candidate.id === id);
    if (!item) return false;
    shell.openExternal(item.url);
    return true;
});
ipcMain.handle('appOpenBugReport', () => {
    shell.openExternal(bugReportUrl(welcomeLinks.reportProblem, {
        version: app.getVersion(), source: installSource(), platform: process.platform, arch: process.arch,
        osRelease: osRelease(), electron: process.versions.electron, chromium: process.versions.chrome
    }));
    return true;
});

// Same docs/-exclusion-from-packaging reasoning as welcomeMarkdownPath() above -- this doc needs
// its own extraResource entry in packageElectron.mjs for the same reason welcome.md has one.
function causalInferenceInteractionHelpMarkdownPath() {
    return app.isPackaged
        ? join(process.resourcesPath, 'causalInferenceInteractionHelp.md')
        : join(currentDir, '..', 'docs', 'causalInferenceInteractionHelp.md');
}

async function openCausalInferenceInteractionHelp(projectWindow) {
    const markdown = await readFile(causalInferenceInteractionHelpMarkdownPath(), 'utf8');
    return openGuideWindow(projectWindow, {
        title: 'Causal inference',
        markdown,
        kind: 'help'
    });
}

function openProviderEditorWindow(projectWindow, ownerWebContents, payload) {
    const state = projectWindowState.get(projectWindow);
    state.providerEditorOwner = ownerWebContents;
    if (!state.providerEditorWindow || state.providerEditorWindow.isDestroyed()) {
        const createdWindow = new BrowserWindow({
        icon: appIconPath,
            ...auxiliaryWindowBounds(projectWindow, 820, 640, state.providerEditorBounds, screen),
            ...auxiliaryWindowPresentation(projectWindow),
            minWidth: 480,
            minHeight: 360,
            frame: false,
            backgroundColor: '#09131b',
            title: 'Provider source',
            webPreferences: {
                preload: join(currentDir, 'providerEditor', 'preload.cjs'),
                contextIsolation: true,
                nodeIntegration: false,
                sandbox: false
            }
        });
        state.providerEditorWindow = createdWindow;
        installCustomWindowState(createdWindow);
        createdWindow.on('close', () => { state.providerEditorBounds = createdWindow.isDestroyed() ? state.providerEditorBounds : createdWindow.getBounds(); });
        createdWindow.on('closed', () => {
            if (state.providerEditorWindow === createdWindow) { state.providerEditorWindow = null; state.providerEditorOwner = null; }
        });
        createdWindow.webContents.once('did-finish-load', () => { if (!createdWindow.isDestroyed()) createdWindow.webContents.send('providerEditorContent', payload); });
        createdWindow.loadFile(join(currentDir, 'providerEditor', 'index.html'));
    } else {
        state.providerEditorWindow.webContents.send('providerEditorContent', payload);
        state.providerEditorWindow.show();
        state.providerEditorWindow.focus();
    }
}

function aiRequestKey(sender, requestUuid) {
    return `${sender.id}:${requestUuid}`;
}

async function withAIOperation(owner, timeoutSeconds, operation) {
    const controller = new AbortController();
    const active = { owner, controller };
    const timeout = setTimeout(() => controller.abort(), timeoutSeconds * 1000);
    activeAIOperations.add(active);
    try {
        return await operation(controller.signal);
    } finally {
        clearTimeout(timeout);
        activeAIOperations.delete(active);
    }
}

function abortAIOperations(owner = null) {
    for (const [key, active] of activeAIRequests) {
        if (owner && active.owner !== owner) continue;
        active.controller.abort();
        activeAIRequests.delete(key);
    }
    for (const active of activeAIOperations) {
        if (owner && active.owner !== owner) continue;
        active.controller.abort();
        activeAIOperations.delete(active);
    }
}

async function shutdownValidationOperations(owner = null) {
    const operations = [...activeValidationOperations].filter((active) => !owner || active.owner === owner);
    for (const active of operations) active.controller.abort();
    await Promise.allSettled(operations.map((active) => active.completion));
}

async function shutdownInferenceOperations(owner = null) {
    const operations = [...activeInferenceOperations].filter((active) => !owner || active.owner === owner);
    for (const active of operations) active.controller.abort();
    await Promise.allSettled(operations.map((active) => active.completion));
}

async function shutdownFittingOperations(owner = null) {
    const operations = [...activeFittingOperations].filter((active) => !owner || active.owner === owner);
    for (const active of operations) active.controller.abort();
    await Promise.allSettled(operations.map((active) => active.completion));
}

async function shutdownEngineJobs(owner = null) {
    const jobs = [...activeEngineJobs.values()].filter((job) => !owner || job.owner === owner);
    await Promise.allSettled(jobs.map((job) => job.shutdown()));
}

async function closeCompletedEngineResults() {
    const results = [...completedEngineResults.values()];
    completedEngineResults.clear();
    await Promise.allSettled(results.map(async ({ reader, cleanup }) => {
        await reader.close();
        await cleanup();
    }));
}

// Stores the FULL (untrimmed-checkpoints) result server-side, mirroring exactly how a live run's
// completedEngineResults entry is built (result: the raw decoded result, never
// rendererResultProjection-trimmed) -- engineReadCheckpoint reads stored.result.checkpoints
// directly, so an embedded session must keep the same shape a live one does, or forking after
// reopening a saved project would only ever see the last checkpoint instead of every one.
// branchMetadata ({branchUuid, parentBranchUuid, forkTime, label}) is spread onto the returned
// descriptor only when the caller has it (a multi-branch save); a legacy/single-result file has
// none of it, matching bundle.resultBranches' own shape from projectFile.mjs.
async function createEmbeddedResultSession(resultBytes, branchMetadata = {}) {
    if (!resultBytes) return null;
    const directory = await mkdtemp(join(tmpdir(), 'konjugateEmbeddedResult-'));
    const path = join(directory, 'result.bin');
    try {
        await writeFile(path, resultBytes);
        const reader = await openIndexedResult(path);
        const fullResult = {
            ...reader.metadata,
            samples: await reader.readSamples({ maximumSamples: defaultPlaybackSampleLimit })
        };
        const sessionId = randomUUID();
        completedEngineResults.set(sessionId, {
            result: fullResult,
            reader,
            path,
            cleanup: () => rm(directory, { recursive: true, force: true })
        });
        return {
            sessionId,
            result: rendererResultProjection(fullResult),
            checkpointIndex: checkpointIndex(fullResult),
            ...branchMetadata
        };
    } catch (error) {
        await rm(directory, { recursive: true, force: true });
        throw error;
    }
}

// embeddedResult stays the first (in a legacy/single-branch file, the only) branch, so every
// existing renderer code path that only knows about one embedded result keeps working unchanged.
// embeddedBranches carries the rest (or, for a genuinely multi-branch save, all of them again --
// see loadProjectDocument's own dedup-by-sessionId) for the renderer to rebuild its branch tree.
async function decodeProjectForRenderer(bytes, options = {}) {
    const bundle = await decodeProjectBundle(bytes, options);
    JSON.parse(bundle.content);
    const branchSessions = [];
    for (const { buffer, length, ...branchMetadata } of bundle.resultBranches ?? []) {
        branchSessions.push(await createEmbeddedResultSession(buffer, branchMetadata));
    }
    return {
        content: bundle.content,
        embeddedResult: branchSessions[0] ?? null,
        embeddedBranches: branchSessions.length > 1 ? branchSessions : null
    };
}

// Shared by the dialog-driven projectOpen handler and every OS-initiated open (double-click,
// second-instance argv, macOS open-file) -- everything projectOpen does after its own
// dialog.showOpenDialog call, factored out so neither path duplicates the encrypted/decode logic.
async function readProjectFilePayload(path) {
    const bytes = await readFile(path);
    const inspection = inspectProjectFile(bytes);
    if (inspection.encrypted) {
        pendingEncryptedPaths.add(path);
        return { path, fileName: basename(path), encrypted: true, requiresPassword: true };
    }
    return { path, fileName: basename(path), encrypted: false, ...await decodeProjectForRenderer(bytes) };
}

// Shared by projectSave and CLI mode's --output-kjt: write via a temp file + rename so a
// crash or a concurrent read of `path` never observes a partially-written file; falls back to
// a direct overwrite on platforms/situations where the rename itself can't complete in place.
async function atomicWriteFile(path, bytes) {
    const temporaryPath = join(dirname(path), `.${basename(path)}.${randomUUID()}.tmp`);
    try {
        await writeFile(temporaryPath, bytes);
        try {
            await rename(temporaryPath, path);
        } catch (error) {
            if (!['EEXIST', 'EPERM'].includes(error.code)) throw error;
            await writeFile(path, bytes);
            await unlink(temporaryPath);
        }
    } catch (error) {
        await unlink(temporaryPath).catch(() => { });
        throw error;
    }
}

function beginApplicationShutdown() {
    if (applicationShutdownPromise) return applicationShutdownPromise;
    abortAIOperations();
    applicationShutdownPromise = (async () => {
        await Promise.all([shutdownEngineJobs(), shutdownValidationOperations(), shutdownInferenceOperations(), shutdownFittingOperations()]);
        await closeCompletedEngineResults();
    })();
    return applicationShutdownPromise;
}

function visualizerCan(manifest, permission) {
    return manifest?.permissions.includes(permission);
}

async function discoverAddons() {
    addonRegistry.clear();
    const flatAddonRoots = [
        join(currentDir, '..', 'addons'),
        join(app.getPath('userData'), 'addons')
    ];
    for (const addonsDirectory of flatAddonRoots) {
        const entries = await readdir(addonsDirectory, { withFileTypes: true }).catch(() => []);
        for (const entry of entries) {
            if (!entry.isDirectory()) continue;
            const addonDirectory = join(addonsDirectory, entry.name);
            try {
                const manifest = validateAddonManifest(JSON.parse(await readFile(join(addonDirectory, 'addon.json'), 'utf8')));
                if (addonRegistry.has(manifest.addonId)) throw new Error(`Duplicate add-on ID: ${manifest.addonId}.`);
                addonRegistry.set(manifest.addonId, { addonDirectory, manifest });
            } catch (error) {
                console.warn(`Skipping add-on ${entry.name}: ${error.message}`);
            }
        }
    }
    // Installed (packaged) add-ons live one level deeper than the bundled/flat-user roots above
    // -- installPackageArchive() writes userData/packages/addons/<addonId>/<version>/addon.json,
    // matching discoverComponentLibrary()'s equivalent two-level walk for plugins below.
    const packagedAddonRoot = join(app.getPath('userData'), 'packages', 'addons');
    const addonIds = await readdir(packagedAddonRoot, { withFileTypes: true }).catch(() => []);
    const incompatible = await incompatiblePackages();
    for (const idEntry of addonIds) {
        if (!idEntry.isDirectory()) continue;
        const versions = await readdir(join(packagedAddonRoot, idEntry.name), { withFileTypes: true }).catch(() => []);
        for (const versionEntry of versions) {
            if (!versionEntry.isDirectory()) continue;
            const addonDirectory = join(packagedAddonRoot, idEntry.name, versionEntry.name);
            try {
                const manifest = validateAddonManifest(JSON.parse(await readFile(join(addonDirectory, 'addon.json'), 'utf8')));
                // Needs a newer Konjugate than this one: not loaded, but still listed (see packageList) so it can be replaced.
                if (incompatible.has(packageKey('addon', manifest.addonId, manifest.version))) continue;
                if (addonRegistry.has(manifest.addonId)) throw new Error(`Duplicate add-on ID: ${manifest.addonId}.`);
                addonRegistry.set(manifest.addonId, { addonDirectory, manifest });
            } catch (error) {
                console.warn(`Skipping packaged add-on ${idEntry.name}/${versionEntry.name}: ${error.message}`);
            }
        }
    }
}

async function openResultsVisualizer(projectWindow, { addonDirectory, manifest }, payload) {
    const state = projectWindowState.get(projectWindow);
    if (state.analysisWindow && !state.analysisWindow.isDestroyed() && state.analysisAddonId !== manifest.addonId) {
        state.analysisWindow.destroy();
        state.analysisWindow = null;
    }
    state.analysisAddonId = manifest.addonId;
    state.visualizerManifest = manifest;
    const liveResult = activeEngineJobs.get(payload.engineJobId)?.latestResult;
    const completedResult = completedEngineResults.get(payload.engineJobId)?.result;
    state.visualizerSession = createVisualizerSession({ ...payload, result: liveResult ?? completedResult ?? payload.result, sessionId: randomUUID() });
    if (state.analysisWindow && !state.analysisWindow.isDestroyed()) {
        state.analysisWindow.setTitle(`${state.visualizerSession.projectName} — Results`);
        state.analysisWindow.webContents.send('visualizerSessionChange');
        state.analysisWindow.show();
        state.analysisWindow.focus();
        return;
    }
    const createdWindow = new BrowserWindow({
        icon: appIconPath,
        ...auxiliaryWindowBounds(projectWindow, 1080, 720, null, screen),
        minWidth: 720,
        minHeight: 480,
        ...auxiliaryWindowPresentation(projectWindow),
        title: `${state.visualizerSession.projectName} — Results`,
        frame: false,
        backgroundColor: '#081119',
        webPreferences: {
            preload: join(currentDir, 'addonPreload.cjs'),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
            backgroundThrottling: false
        }
    });
    installCustomWindowState(createdWindow);
    state.analysisWindow = createdWindow;
    createdWindow.on('closed', () => {
        if (state.analysisWindow === createdWindow) {
            state.analysisWindow = null;
            state.analysisAddonId = null;
        }
    });
    await state.analysisWindow.loadFile(join(addonDirectory, manifest.entry));
}

ipcMain.handle('addonListToolstripContributions', async (event) => {
    if (!senderIsProjectWindow(event)) return [];
    await discoverAddons();
    const disabledKeys = await extensionStateStore.list();
    return [...addonRegistry.values()]
        .filter(({ manifest }) => !disabledKeys.includes(packageKey('addon', manifest.addonId, manifest.version)))
        .flatMap(({ manifest }) => publicToolstripContributions(manifest));
});

ipcMain.handle('addonInvokeCommand', async (event, { addonId, commandId, contexts = {} }) => {
    if (!senderIsProjectWindow(event)) throw new Error('Only a project window can invoke add-on commands.');
    if (!addonRegistry.size) await discoverAddons();
    const addon = addonRegistry.get(addonId);
    const contribution = addon?.manifest.contributes?.toolstrip?.find((item) => item.commandId === commandId);
    if (!addon || !contribution) throw new Error('That add-on command is unavailable.');
    if ((await extensionStateStore.list()).includes(packageKey('addon', addon.manifest.addonId, addon.manifest.version))) {
        throw new Error('This add-on is disabled.');
    }
    if (!(contribution.contexts ?? []).every((context) => contexts[context])) throw new Error('The add-on command requires unavailable context.');
    if (addon.manifest.kind === 'resultVisualizer') {
        const projectWindow = getWindowFromEvent(event);
        await openResultsVisualizer(projectWindow, addon, contexts.resultSession);
        return { addonId, commandId, sessionId: projectWindowState.get(projectWindow).visualizerSession.sessionId };
    }
    if (addon.manifest.kind === 'launcher') {
        await launcherHost.openLauncher(getWindowFromEvent(event), addon);
        return { addonId, commandId };
    }
    throw new Error(`Unsupported add-on kind: ${addon.manifest.kind}.`);
});

ipcMain.on('visualizerHostTimelineChange', (event, time) => {
    if (!senderIsProjectWindow(event)) return;
    const state = projectWindowState.get(getWindowFromEvent(event));
    if (!state.visualizerSession) return;
    state.visualizerSession.time = Number(time);
    if (visualizerCan(state.visualizerManifest, 'timeline.read') && state.analysisWindow && !state.analysisWindow.isDestroyed()) {
        state.analysisWindow.webContents.send('visualizerTimelineChange', state.visualizerSession.time);
    }
});

ipcMain.on('visualizerHostSelectionChange', (event, nodeId) => {
    if (!senderIsProjectWindow(event)) return;
    const state = projectWindowState.get(getWindowFromEvent(event));
    if (!state.visualizerSession) return;
    state.visualizerSession.selectedNodeId = nodeId ?? null;
    if (visualizerCan(state.visualizerManifest, 'selection.read') && state.analysisWindow && !state.analysisWindow.isDestroyed()) {
        state.analysisWindow.webContents.send('visualizerSelectionChange', nodeId ?? null);
    }
});

function updateVisualizerResult(projectWindow, jobId, result) {
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state || !state.visualizerSession || state.visualizerSession.engineJobId !== jobId) return;
    state.visualizerSession.samples = result.samples;
    state.visualizerSession.run = {
        ...state.visualizerSession.run,
        sampleCount: result.samples.length,
        lifecycle: result.lifecycle,
        simulationTime: Number(result.simulationTime),
        availableResultTime: Number(result.availableResultTime),
        pacing: structuredClone(result.pacing)
    };
    if (!state.analysisWindow || state.analysisWindow.isDestroyed()) return;
    if (visualizerCan(state.visualizerManifest, 'results.live.read')) {
        state.analysisWindow.webContents.send('visualizerSamplesAvailable', {
            sampleCount: state.visualizerSession.run.sampleCount,
            availableResultTime: state.visualizerSession.run.availableResultTime
        });
    }
    if (visualizerCan(state.visualizerManifest, 'simulation.status.read')) {
        state.analysisWindow.webContents.send('visualizerRunStatusChange', structuredClone(state.visualizerSession.run));
    }
    if (visualizerCan(state.visualizerManifest, 'simulation.pacing.read')) {
        state.analysisWindow.webContents.send('visualizerPacingChange', structuredClone(state.visualizerSession.run.pacing));
    }
}

ipcMain.on('visualizerCloseSession', (event) => {
    if (!senderIsProjectWindow(event)) return;
    const state = projectWindowState.get(getWindowFromEvent(event));
    state.visualizerSession = null;
    state.visualizerManifest = null;
    state.analysisAddonId = null;
    state.analysisWindow?.close();
});

ipcMain.handle('visualizerGetContext', (event) => {
    const projectWindow = projectWindowForAuxSender(event, 'analysisWindow');
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state?.visualizerSession || !visualizerCan(state.visualizerManifest, 'results.read')) return null;
    return publicVisualizerContext(state.visualizerSession);
});

ipcMain.handle('visualizerListSignals', (event) => {
    const projectWindow = projectWindowForAuxSender(event, 'analysisWindow');
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state?.visualizerSession || !visualizerCan(state.visualizerManifest, 'results.read')) return [];
    return structuredClone(state.visualizerSession.signals);
});

ipcMain.handle('visualizerReadSeries', (event, { signalIds, options }) => {
    const projectWindow = projectWindowForAuxSender(event, 'analysisWindow');
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state?.visualizerSession || !visualizerCan(state.visualizerManifest, 'results.read')) return [];
    return readSignalSeries(state.visualizerSession, signalIds, options);
});

// The logo shown in the host titlebar of every add-on window. Sent as a data URI because an add-on page's
// own Content Security Policy only allows images from its own package and data: URIs.
let addonTitlebarIconCache = null;
ipcMain.handle('addonTitlebarIcon', async () => {
    addonTitlebarIconCache ??= `data:image/svg+xml;base64,${(await readFile(join(currentDir, '..', 'assets', 'icon.svg'))).toString('base64')}`;
    return addonTitlebarIconCache;
});

ipcMain.handle('visualizerTitlebarStylesheet', (event) => {
    if (!projectWindowForAuxSender(event, 'analysisWindow')) throw new Error('The titlebar stylesheet is available only to the active add-on window.');
    return pathToFileURL(join(currentDir, 'addonTitlebar.css')).href;
});

ipcMain.on('visualizerSeek', (event, time) => {
    const projectWindow = projectWindowForAuxSender(event, 'analysisWindow');
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state?.visualizerSession || !visualizerCan(state.visualizerManifest, 'timeline.seek')) return;
    if (['running', 'paused'].includes(state.visualizerSession.run.lifecycle)) return;
    const boundedTime = Math.max(0, Math.min(Number(time), state.visualizerSession.run.availableResultTime));
    state.visualizerSession.time = boundedTime;
    projectWindow.webContents.send('visualizerSeekRequest', boundedTime);
});

ipcMain.handle('visualizerRequestPacing', async (event, pacing) => {
    const projectWindow = projectWindowForAuxSender(event, 'analysisWindow');
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state?.visualizerSession || !visualizerCan(state.visualizerManifest, 'simulation.pacing.control')) {
        throw new Error('The visualizer does not have permission to control pacing.');
    }
    const job = activeEngineJobs.get(state.visualizerSession.engineJobId);
    if (!job) throw new Error('The simulation is no longer running.');
    return job.setPacing(pacing);
});

ipcMain.handle('visualizerExportCsv', async (event, { suggestedFilename, csv }) => {
    const projectWindow = projectWindowForAuxSender(event, 'analysisWindow');
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state?.visualizerSession || !visualizerCan(state.visualizerManifest, 'results.export')) {
        throw new Error('The visualizer does not have permission to export results.');
    }
    const result = await dialog.showSaveDialog(state.analysisWindow, {
        title: 'Export data as CSV',
        defaultPath: suggestedFilename || 'results.csv',
        filters: [{ name: 'CSV', extensions: ['csv'] }]
    });
    if (result.canceled) return null;
    let path = result.filePath;
    if (!path.toLowerCase().endsWith('.csv')) path += '.csv';
    await writeFile(path, csv, 'utf8');
    return { path, fileName: basename(path) };
});

// A visualizer with project.data keeps its own data with the project (docs/projectSchema.md, `addonData`), held by the
// project window it was opened from, so it is saved and opened with that project.
function visualizerWithPermission(event, permission) {
    const projectWindow = projectWindowForAuxSender(event, 'analysisWindow');
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state?.visualizerSession || !visualizerCan(state.visualizerManifest, permission)) {
        throw new Error(`The visualizer was not granted ${permission}.`);
    }
    return { projectWindow, manifest: state.visualizerManifest };
}

ipcMain.handle('visualizerGetProjectData', async (event) => {
    const { projectWindow, manifest } = visualizerWithPermission(event, 'project.data');
    const entry = await requestAddonData({ ipcMain, projectWindow, addonId: manifest.addonId });
    return visualizerDataFromEntry(entry) ?? { data: null, savedAt: null, addonVersion: null };
});

ipcMain.handle('visualizerSetProjectData', (event, { data }) => {
    const { projectWindow, manifest } = visualizerWithPermission(event, 'project.data');
    keepAddonData(projectWindow, manifest.addonId, data === null || data === undefined ? null : buildVisualizerDataEntry({ addon: manifest, data }));
    return {};
});

// And with settings.store, settings of its own kept for the user, the same in every project.
let addonSettingsInstance = null;
const addonSettings = () => (addonSettingsInstance ??= createAddonSettingsStore({ userData: app.getPath('userData') }));

ipcMain.handle('visualizerGetSettings', (event) => {
    const { manifest } = visualizerWithPermission(event, 'settings.store');
    return addonSettings().get(manifest.addonId);
});

ipcMain.handle('visualizerSetSettings', async (event, { settings }) => {
    const { manifest } = visualizerWithPermission(event, 'settings.store');
    await addonSettings().set(manifest.addonId, settings ?? null);
    return {};
});

ipcMain.on('windowMaximizeToggle', (event) => {
    const targetWindow = getWindowFromEvent(event);
    if (!targetWindow) return;

    if (process.platform === 'darwin') {
        targetWindow.setFullScreen(!targetWindow.isFullScreen());
    } else if (targetWindow.isMaximized()) {
        targetWindow.unmaximize();
    } else {
        targetWindow.maximize();
    }
});

ipcMain.on('windowMinimize', (event) => {
    getWindowFromEvent(event)?.minimize();
});

ipcMain.on('windowClose', (event) => {
    // Just close this window -- 'window-all-closed' below already handles quitting the whole
    // app on non-macOS once truly zero windows remain, which is exactly what's needed now that
    // more than one project window can exist (closing one used to force-quit the entire app).
    getWindowFromEvent(event)?.close();
});

ipcMain.handle('applicationInfo', () => ({ version: app.getVersion() }));
ipcMain.handle('applicationOpenWelcome', (event) => openWelcomeWindow(getWindowFromEvent(event)));
ipcMain.on('newProjectWindow', () => createProjectWindow());
const allowedExternalLinkPrefixes = [
    'https://discord.gg/',
    'https://whatsapp.com/channel/',
    'https://github.com/zenineasa/Konjugate/',
    'https://www.youtube.com/',
    'https://youtu.be/',
    'https://www.konjugate.com/'
];
ipcMain.handle('applicationOpenExternal', (event, url) => {
    if (typeof url !== 'string' || !allowedExternalLinkPrefixes.some((prefix) => url.startsWith(prefix))) return false;
    shell.openExternal(url);
    return true;
});

ipcMain.handle('diagnosticsList', () => listDiagnostics());
onDiagnostic((entry) => {
    for (const window of projectWindows) {
        if (!window.isDestroyed()) window.webContents.send('diagnosticsIssue', entry);
    }
});

const examplesDir = join(currentDir, '..', 'examples');

async function exampleFiles() {
    return (await readdir(examplesDir)).filter((name) => name.endsWith('.kjt'));
}

let examplesManifestCache = null;
async function examplesManifest() {
    if (!examplesManifestCache) {
        const parsed = JSON.parse(await readFile(join(examplesDir, 'manifest.json'), 'utf8'));
        examplesManifestCache = new Map(parsed.examples.map((entry) => [entry.id, entry]));
    }
    return examplesManifestCache;
}

// Example models a plugin contributes ("kind": "example" in its plugin.json), keyed by the same
// "<id>.kjt" file-name id the bundled examples use so the Examples dialog needs no special case.
// Re-scanned on each request, like the component library, and a disabled plugin's are skipped. A
// contribution whose files escape its plugin directory, are missing, or collide with a bundled
// example's id is skipped with a warning rather than failing the whole list.
async function discoverPluginExamples() {
    const found = new Map();
    const bundled = new Set(await exampleFiles());
    const pluginRoot = join(app.getPath('userData'), 'packages', 'plugins');
    const disabledKeys = await unavailablePackageKeys();
    const insidePlugin = (directory, relativePath) => {
        const resolvedPath = resolve(directory, relativePath);
        return resolvedPath.startsWith(`${resolve(directory)}${sep}`) ? resolvedPath : null;
    };
    for (const pluginIdEntry of await readdir(pluginRoot, { withFileTypes: true }).catch(() => [])) {
        if (!pluginIdEntry.isDirectory()) continue;
        for (const versionEntry of await readdir(join(pluginRoot, pluginIdEntry.name), { withFileTypes: true }).catch(() => [])) {
            if (!versionEntry.isDirectory()) continue;
            const pluginDirectory = join(pluginRoot, pluginIdEntry.name, versionEntry.name);
            try {
                const manifest = JSON.parse(await readFile(join(pluginDirectory, 'plugin.json'), 'utf8'));
                if (disabledKeys.includes(packageKey('plugin', manifest.pluginId, manifest.version))) continue;
                for (const contribution of (manifest.contributes ?? []).filter((item) => item.kind === 'example')) {
                    try {
                        const id = `${contribution.exampleId}.kjt`;
                        if (bundled.has(id) || found.has(id)) throw new Error(`Duplicate example ID: ${contribution.exampleId}.`);
                        const entry = insidePlugin(pluginDirectory, contribution.entry);
                        const guide = contribution.guide ? insidePlugin(pluginDirectory, contribution.guide) : null;
                        const thumbnail = contribution.thumbnail ? insidePlugin(pluginDirectory, contribution.thumbnail) : null;
                        if (!entry || !entry.endsWith('.kjt') || (contribution.guide && !guide) || (contribution.thumbnail && !thumbnail)) {
                            throw new Error('An example file lies outside its plugin directory.');
                        }
                        await access(entry);
                        found.set(id, {
                            id, entry, guide, name: contribution.name, domains: contribution.domains ?? [],
                            description: contribution.description ?? '',
                            thumbnailUrl: thumbnail && existsSync(thumbnail) ? pathToFileURL(thumbnail).href : null,
                            source: { pluginId: manifest.pluginId, pluginVersion: manifest.version }
                        });
                    } catch (error) {
                        console.warn(`Skipping example ${contribution.exampleId} from ${pluginIdEntry.name}/${versionEntry.name}: ${error.message}`);
                    }
                }
            } catch (error) {
                console.warn(`Skipping plugin examples from ${pluginIdEntry.name}/${versionEntry.name}: ${error.message}`);
            }
        }
    }
    return found;
}

ipcMain.handle('projectListExamples', async () => {
    const manifest = await examplesManifest();
    const bundledEntries = await Promise.all((await exampleFiles()).map(async (fileName) => {
        const stem = exampleIdFromFileName(fileName);
        const thumbnailPath = join(examplesDir, `${stem}.png`);
        return {
            ...await exampleCatalogEntry(examplesDir, fileName, manifest),
            thumbnailUrl: existsSync(thumbnailPath) ? pathToFileURL(thumbnailPath).href : null
        };
    }));
    const pluginEntries = [...(await discoverPluginExamples()).values()].map((example) => ({
        id: example.id, label: example.name, suggestedFilename: example.id, domains: example.domains,
        description: example.description, thumbnailUrl: example.thumbnailUrl, source: example.source
    }));
    return [...bundledEntries, ...pluginEntries];
});

ipcMain.handle('projectLoadExample', async (_event, id) => {
    const pluginExample = (await discoverPluginExamples()).get(id);
    if (pluginExample) return { ...await decodeProjectForRenderer(await readFile(pluginExample.entry)), suggestedFilename: id };
    if (!(await exampleFiles()).includes(id)) throw new Error('That example is not available.');
    return { ...await decodeProjectForRenderer(await readFile(join(examplesDir, id))), suggestedFilename: id };
});

ipcMain.handle('projectOpenExampleGuide', async (event, id) => {
    requireProjectWindow(event, 'Only a project window can open example guides.');
    return openExampleGuide(getWindowFromEvent(event), id);
});

ipcMain.handle('projectOpenCausalInferenceInteractionHelp', (event) => {
    requireProjectWindow(event, 'Only a project window can open this help window.');
    return openCausalInferenceInteractionHelp(getWindowFromEvent(event));
});

const shapesDir = join(currentDir, '..', 'assets', 'shapes');
const userShapesDir = join(app.getPath('userData'), 'shapes');
const shapeFormatPattern = /\.(stl|step|stp)$/i;

// Mirrors discoverComponentLibrary's bundled-plus-writable-userData split: the bundled manifest
// is hand-curated (name/domain/tags), while every user upload gets a self-describing entry
// synthesized directly from its filename -- there's no separate manifest to keep in sync for
// something that's supposed to "just show up" the moment a file is saved into userShapesDir.
async function shapeLibraryManifest() {
    const bundled = (JSON.parse(await readFile(join(shapesDir, 'manifest.json'), 'utf8')).shapes)
        .map(normalizeShapeLibraryEntry);
    const uploadedEntries = await readdir(userShapesDir, { withFileTypes: true }).catch(() => []);
    const uploaded = uploadedEntries
        .filter((entry) => entry.isFile() && shapeFormatPattern.test(entry.name))
        .map((entry) => {
            const format = entry.name.split('.').pop().toLowerCase();
            return {
                id: `userUploaded/${entry.name}`,
                name: entry.name.slice(0, -(format.length + 1)),
                domains: ['userUploaded'],
                domain: 'userUploaded',
                format,
                file: entry.name,
                tags: [],
                source: 'user'
            };
        });
    return [...bundled, ...uploaded];
}

ipcMain.handle('shapeLibraryList', async () => shapeLibraryManifest());

ipcMain.handle('shapeLibrarySaveUpload', async (_event, { fileName, data }) => {
    const format = fileName.split('.').pop()?.toLowerCase();
    if (!['stl', 'step', 'stp'].includes(format)) {
        throw new Error('Only STL, STEP, or STP files can be saved to the shape library.');
    }
    await mkdir(userShapesDir, { recursive: true });
    const stem = basename(fileName, `.${format}`).replace(/[^a-zA-Z0-9 _-]/g, '').trim() || 'shape';
    let candidateName = `${stem}.${format}`;
    for (let counter = 1; existsSync(join(userShapesDir, candidateName)); counter += 1) {
        candidateName = `${stem} (${counter}).${format}`;
    }
    await writeFile(join(userShapesDir, candidateName), Buffer.from(data));
    return { id: `userUploaded/${candidateName}` };
});

const componentLibraryRegistry = new Map();

async function discoverComponentLibrary() {
    componentLibraryRegistry.clear();
    const componentLibraryRoots = [
        join(currentDir, '..', 'assets', 'componentLibrary'),
        join(app.getPath('userData'), 'componentLibrary')
    ];
    for (const componentLibraryDirectory of componentLibraryRoots) {
        const entries = await readdir(componentLibraryDirectory, { withFileTypes: true }).catch(() => []);
        for (const entry of entries) {
            if (!entry.isFile() || !entry.name.endsWith('.json')) continue;
            try {
                const template = validateComponentTemplate(JSON.parse(await readFile(join(componentLibraryDirectory, entry.name), 'utf8')));
                if (componentLibraryRegistry.has(template.id)) throw new Error(`Duplicate template ID: ${template.id}.`);
                componentLibraryRegistry.set(template.id, template);
            } catch (error) {
                console.warn(`Skipping component template ${entry.name}: ${error.message}`);
            }
        }
    }
    const pluginRoot = join(app.getPath('userData'), 'packages', 'plugins');
    const pluginIds = await readdir(pluginRoot, { withFileTypes: true }).catch(() => []);
    const disabledKeys = await unavailablePackageKeys();
    for (const pluginIdEntry of pluginIds) {
        if (!pluginIdEntry.isDirectory()) continue;
        const pluginVersions = await readdir(join(pluginRoot, pluginIdEntry.name), { withFileTypes: true }).catch(() => []);
        for (const versionEntry of pluginVersions) {
            if (!versionEntry.isDirectory()) continue;
            const pluginDirectory = join(pluginRoot, pluginIdEntry.name, versionEntry.name);
            try {
                const manifest = JSON.parse(await readFile(join(pluginDirectory, 'plugin.json'), 'utf8'));
                // A disabled plugin has no other place to be filtered out (unlike add-ons, which
                // stay in addonRegistry so packageList can still show them with a toggle) --
                // componentLibraryRegistry IS the active-templates list consumed directly by the
                // Component Library panel, so this is where it must be skipped.
                if (disabledKeys.includes(packageKey('plugin', manifest.pluginId, manifest.version))) continue;
                for (const contribution of manifest.contributes ?? []) {
                    if (contribution.kind !== 'component') continue;
                    const template = validateComponentTemplate(JSON.parse(await readFile(join(pluginDirectory, contribution.entry), 'utf8')));
                    if (template.id !== contribution.componentId) throw new Error(`Component ID mismatch: ${contribution.componentId}.`);
                    if (componentLibraryRegistry.has(template.id)) throw new Error(`Duplicate template ID: ${template.id}.`);
                    componentLibraryRegistry.set(template.id, {
                        ...template,
                        source: 'plugin',
                        pluginId: manifest.pluginId,
                        pluginVersion: manifest.version
                    });
                }
            } catch (error) {
                console.warn(`Skipping plugin components from ${pluginIdEntry.name}/${versionEntry.name}: ${error.message}`);
            }
        }
    }
}

ipcMain.handle('componentLibraryList', async () => {
    await discoverComponentLibrary();
    return [...componentLibraryRegistry.values()];
});

ipcMain.handle('shapeLibraryLoad', async (_event, id) => {
    const shape = (await shapeLibraryManifest()).find((candidate) => candidate.id === id);
    if (!shape) throw new Error('That shape is not available.');
    const baseDir = shape.source === 'user' ? userShapesDir : shapesDir;
    return { ...shape, data: await readFile(join(baseDir, shape.file)) };
});

ipcMain.handle('projectOpen', async (event) => {
    const targetWindow = getWindowFromEvent(event);
    const result = await dialog.showOpenDialog(targetWindow, {
        title: 'Open Konjugate project',
        properties: ['openFile'],
        filters: [
            { name: 'Konjugate project', extensions: ['kjt'] }
        ]
    });
    if (result.canceled) return null;
    const [path] = result.filePaths;
    if (!path.toLowerCase().endsWith('.kjt')) throw new Error('Only .kjt project files are supported.');
    return readProjectFilePayload(path);
});

ipcMain.handle('packageInstall', async (event) => {
    const targetWindow = getWindowFromEvent(event);
    const result = await dialog.showOpenDialog(targetWindow, {
        title: 'Install Konjugate package',
        properties: ['openFile'],
        filters: [{ name: 'Konjugate packages and FMUs', extensions: ['kja', 'kjp', 'fmu'] }]
    });
    if (result.canceled) return null;
    const [path] = result.filePaths;
    const lowerPath = path.toLowerCase();

    if (lowerPath.endsWith('.fmu')) {
        const archive = await readFile(path);
        const inspected = inspectFmuArchive(archive);
        const detail = [
            `${inspected.description.modelName} (FMI ${inspected.description.fmiVersion})`,
            `guid: ${inspected.description.guid}`,
            `Platforms in this file: ${inspected.platforms.join(', ')}`
        ].join('\n');
        const confirmation = await dialog.showMessageBox(targetWindow, {
            type: 'question',
            buttons: ['Cancel', 'Install'],
            defaultId: 1,
            cancelId: 0,
            title: 'Review FMU installation',
            message: `Install ${inspected.description.modelName}?`,
            detail
        });
        if (confirmation.response !== 1) return null;
        const installed = await installFmuArchive(archive, {
            directory: join(app.getPath('userData'), 'packages'),
            sourceFileName: basename(path)
        });
        return { packageType: 'fmu', packageId: installed.guid, version: installed.version };
    }

    const extension = lowerPath.endsWith('.kja') ? '.kja' : lowerPath.endsWith('.kjp') ? '.kjp' : null;
    if (!extension) throw new Error('Only .kja add-ons, .kjp plugins and .fmu files can be installed.');
    const archive = await readFile(path);
    // Refused before the review dialog if this Konjugate cannot run it (needs a newer Konjugate, or a newer add-on/plugin API).
    const inspected = inspectPackageArchive(archive, { extension, appVersion: app.getVersion() });
    const permissions = inspected.contributionManifest.permissions ?? [];
    const detail = [
        `${inspected.packageManifest.name} ${inspected.packageManifest.version}`,
        `Publisher package: ${inspected.packageManifest.packageId}`,
        `Type: ${inspected.packageManifest.packageType}`,
        permissions.length ? `Permissions: ${permissions.join(', ')}` : 'Permissions: none'
    ].join('\n');
    const confirmation = await dialog.showMessageBox(targetWindow, {
        type: 'question',
        buttons: ['Cancel', 'Install'],
        defaultId: 1,
        cancelId: 0,
        title: 'Review package installation',
        message: `Install ${inspected.packageManifest.name}?`,
        detail
    });
    if (confirmation.response !== 1) return null;
    const installed = await installPackageArchive(archive, {
        extension,
        directory: join(app.getPath('userData'), 'packages'),
        appVersion: app.getVersion()
    });
    await discoverAddons();
    markPackageRestartPending();
    return {
        packageType: installed.packageManifest.packageType,
        packageId: installed.packageManifest.packageId,
        version: installed.packageManifest.version
    };
});

// An installed FMU's ports, for the node editor to wire it: { name, fmiVersion, inputs, outputs } (see
// describeInstalledFmuPorts), or { error } when it cannot be read.
ipcMain.handle('packageFmuPorts', async (_event, { guid, version }) => {
    try {
        return await describeInstalledFmuPorts(join(app.getPath('userData'), 'packages'), guid, version);
    } catch (error) {
        return { error: error.message };
    }
});

ipcMain.handle('packageList', async () => {
    await discoverAddons();
    const disabledKeys = await extensionStateStore.list();
    const packagedAddonRoot = join(app.getPath('userData'), 'packages', 'addons');
    const bundled = [...addonRegistry.values()]
        .filter(({ addonDirectory }) => !addonDirectory.startsWith(`${packagedAddonRoot}${sep}`))
        .map(({ manifest }) => ({
            packageType: 'addon', packageId: manifest.addonId, name: manifest.name, version: manifest.version,
            source: 'bundled', permissions: manifest.permissions ?? [], manifest, installPath: null,
            enabled: !disabledKeys.includes(packageKey('addon', manifest.addonId, manifest.version))
        }));
    const incompatible = await incompatiblePackages();
    const installed = (await listInstalledPackages(join(app.getPath('userData'), 'packages'))).map((entry) => {
        const key = packageKey(entry.packageType, entry.packageId, entry.version);
        const verdict = incompatible.get(key);
        // An incompatible package is never loaded, so it is never enabled whatever its toggle says.
        return {
            ...entry, enabled: !verdict && !disabledKeys.includes(key),
            ...(verdict ? { incompatible: { required: verdict.required, running: verdict.running } } : {})
        };
    });
    const fmus = (await listInstalledFmus(join(app.getPath('userData'), 'packages'))).map((entry) => ({
        ...entry, enabled: !disabledKeys.includes(packageKey('fmu', entry.packageId, entry.version))
    }));
    return [...bundled, ...installed, ...fmus];
});

ipcMain.handle('packageUninstall', async (_event, { packageType, packageId, version }) => {
    if (packageType === 'fmu') {
        await uninstallFmu({ directory: join(app.getPath('userData'), 'packages'), guid: packageId, version });
        return { packageType, packageId, version };
    }
    await uninstallPackage({ directory: join(app.getPath('userData'), 'packages'), packageType, packageId, version });
    // An add-on's cache goes with its last installed version (a reinstall or an update keeps it).
    if (packageType === 'addon' && !(await listInstalledPackages(join(app.getPath('userData'), 'packages'))).some((entry) => entry.packageType === 'addon' && entry.packageId === packageId)) {
        await rm(addonCacheDirectory(app.getPath('userData'), packageId), { recursive: true, force: true }).catch(() => {});
        await addonSettings().remove(packageId).catch(() => {});
    }
    await discoverAddons();
    await discoverComponentLibrary();
    markPackageRestartPending();
    return { packageType, packageId, version };
});

ipcMain.handle('packageSetEnabled', async (_event, { packageType, packageId, version, enabled }) => {
    await extensionStateStore.setEnabled(packageKey(packageType, packageId, version), enabled);
    await discoverAddons();
    await discoverComponentLibrary();
    return { packageType, packageId, version, enabled };
});

// Pull-based initial state (mirrors diagnosticsList/onIssue's split) for a window opened after the
// flag was already set elsewhere; packageRestartPendingChanged above is the live-update push.
ipcMain.handle('packageRestartPending', () => packageRestartPending);

ipcMain.handle('applicationRestart', () => {
    app.relaunch();
    app.exit(0);
});

// A registry entry's own project/commercial-license/contact links (see docs/extensionsExplorer.md) point
// at whatever a third-party publisher declared -- they will not match allowedExternalLinkPrefixes
// above (that allowlist is for Konjugate's own trusted domains only), and loosening it to cover an
// open, permissionless registry would defeat its purpose. Instead: any https:// URL is allowed, but
// only after the person confirms leaving Konjugate for a destination the registry entry chose, not
// this app -- the same pattern VS Code uses for an extension's own links (see The Extensions Explorer's
// design principles for why that precedent already grounds this feature).
ipcMain.handle('packageOpenRegistryLink', async (event, url) => {
    if (typeof url !== 'string' || !url.startsWith('https://')) return false;
    const confirmation = await dialog.showMessageBox(getWindowFromEvent(event), {
        type: 'question',
        buttons: ['Cancel', 'Open'],
        defaultId: 1,
        cancelId: 0,
        title: 'Open external link',
        message: 'Open this link in your browser?',
        detail: `${url}\n\nThis comes from a third-party registry listing, not from Konjugate itself.`
    });
    if (confirmation.response !== 1) return false;
    shell.openExternal(url);
    return true;
});

// The Explorer's "Discover" side (see docs/extensionsExplorer.md). A local cache means the Explorer
// still shows a (stale-but-present) list offline or if GitHub's API is briefly unreachable, rather
// than an empty/broken screen -- the renderer is told stale:true so it can say so.
const registryCachePath = () => join(app.getPath('userData'), 'registryCache.json');
const bundledRegistryDir = join(currentDir, '..', 'registry');
async function loadBundledRegistry() {
    try {
        return await loadNamespaceRegistry(bundledRegistryDir);
    } catch {
        return { prefixes: {} };
    }
}

// Shared by the packageDiscoverRegistry IPC handler (below) and the Welcome window's recommended-
// add-ons check -- both need "live registry, falling back to the last successful fetch, falling
// back to what's bundled with this install" and shouldn't have two copies of that fallback chain.
async function discoverableRegistry() {
    const bundled = await loadBundledRegistry();
    try {
        const remote = await fetchRemoteRegistry();
        const registry = {
            prefixes: { ...bundled.prefixes, ...(remote.prefixes ?? {}) }
        };
        const temporaryPath = `${registryCachePath()}.${randomUUID()}.tmp`;
        await writeFile(temporaryPath, JSON.stringify(registry));
        await rename(temporaryPath, registryCachePath());
        return { registry, stale: false };
    } catch (error) {
        try {
            const cached = JSON.parse(await readFile(registryCachePath(), 'utf8'));
            const registry = {
                prefixes: { ...bundled.prefixes, ...(cached.prefixes ?? {}) }
            };
            return { registry, stale: true, staleReason: error.message };
        } catch {
            if (Object.keys(bundled.prefixes).length > 0) {
                return { registry: bundled, stale: true, staleReason: error.message };
            }
            throw error;
        }
    }
}

ipcMain.handle('packageDiscoverRegistry', () => discoverableRegistry());

// An entry's optional image (see docs/registry.md), handed to the renderer as a data: URL: its
// Content-Security-Policy only allows img-src 'self' data:, and keeping it that way means no remote
// host can ever be loaded into the project window directly. The renderer passes only a prefix; the
// image path is looked up in this process's own cached/bundled registry, so the renderer can't make
// this read an arbitrary file or URL.
//
// Images ship in registry/images/ alongside the bundled entries, so anything this release knows
// about is read straight from disk -- offline, and with no request at all. Only an entry published
// after this release (or one whose image was renamed since) is downloaded, then kept on disk for a
// day, and past that still used while offline.
const registryImageCacheDirectory = () => join(app.getPath('userData'), 'registryImages');
const registryImageMaxAgeMs = 24 * 60 * 60 * 1000;
const registryImageExtensions = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };
const toImageDataUrl = (mimeType, bytes) => `data:${mimeType};base64,${Buffer.from(bytes).toString('base64')}`;
async function knownRegistryEntry(prefix) {
    try {
        const cached = JSON.parse(await readFile(registryCachePath(), 'utf8'));
        if (Object.hasOwn(cached.prefixes ?? {}, prefix)) return cached.prefixes[prefix];
    } catch {
        // No cache yet -- fall through to the bundled copy.
    }
    const bundled = await loadBundledRegistry();
    return Object.hasOwn(bundled.prefixes, prefix) ? bundled.prefixes[prefix] : null;
}
async function bundledRegistryImage(entry) {
    try {
        const bytes = await readFile(join(bundledRegistryDir, entry.image));
        return toImageDataUrl(identifyRegistryImage(bytes, entry.image), bytes);
    } catch {
        return null;
    }
}
// Reads a registry picture through the on-disk cache: a file younger than a day is used as is, an
// older (or missing) one is downloaded again, and if that fails the stale copy is still better than
// nothing. baseName names the cache file (without its extension); fetchPicture returns
// { mimeType, bytes }, already checked. Shared by entry images and screenshots.
async function cachedRegistryImage(baseName, fetchPicture, description) {
    const directory = registryImageCacheDirectory();
    const cachedName = (await readdir(directory).catch(() => [])).find((name) => name.startsWith(`${baseName}.`));
    const readCached = async () => {
        const bytes = await readFile(join(directory, cachedName));
        return toImageDataUrl(identifyRegistryImage(bytes, cachedName), bytes);
    };
    if (cachedName && Date.now() - (await stat(join(directory, cachedName))).mtimeMs < registryImageMaxAgeMs) return readCached();
    try {
        const { mimeType, bytes } = await fetchPicture();
        await mkdir(directory, { recursive: true });
        const name = `${baseName}.${registryImageExtensions[mimeType]}`;
        const temporaryPath = join(directory, `${name}.${randomUUID()}.tmp`);
        await writeFile(temporaryPath, bytes);
        await rename(temporaryPath, join(directory, name));
        if (cachedName && cachedName !== name) await unlink(join(directory, cachedName)).catch(() => {});
        return toImageDataUrl(mimeType, bytes);
    } catch (error) {
        console.warn(`Could not fetch the registry ${description}:`, error.message);
        return cachedName ? readCached().catch(() => null) : null;
    }
}
const registryImageCacheName = (prefix, url) => `${prefix}-${createHash('sha256').update(url).digest('hex').slice(0, 16)}`;
ipcMain.handle('packageRegistryImage', async (_event, prefix) => {
    if (typeof prefix !== 'string') return null;
    const entry = await knownRegistryEntry(prefix);
    const url = entry && registryImageUrl(entry);
    if (!url) return null;
    const bundled = await bundledRegistryImage(entry);
    if (bundled) return bundled;
    // Named after the URL as well as the prefix, so pointing image at a different file is never
    // answered from the previous file's cache.
    return cachedRegistryImage(registryImageCacheName(prefix, url), () => fetchRegistryImage(entry), `image for ${prefix}`);
});

// An entry's screenshots, unlike its image, are not bundled with the app: they only matter next to
// an Install button, which needs the network anyway, so they are downloaded when the detail pane is
// opened and cached the same way. The renderer only ever names an entry and a position -- the URL
// comes from the entry the main process itself already knows.
ipcMain.handle('packageRegistryScreenshot', async (_event, request) => {
    const prefix = request?.prefix;
    const index = request?.index;
    if (typeof prefix !== 'string' || !Number.isInteger(index)) return null;
    const entry = await knownRegistryEntry(prefix);
    const url = entry && registryScreenshotUrl(entry, index);
    if (!url) return null;
    return cachedRegistryImage(`${registryImageCacheName(prefix, url)}-s${index}`, () => fetchRegistryScreenshot(entry, index), `screenshot ${index} for ${prefix}`);
});

// A registry entry's video is only a link, opened in the person's own browser -- nothing is
// fetched or embedded by the app. Re-checked here against the entry the main process knows (the
// renderer sends only a position), and against the same YouTube-only pattern the registry's own
// validation applies, in case the cached copy of the registry predates a rule or was edited.
ipcMain.handle('packageOpenRegistryVideo', async (_event, request) => {
    const prefix = request?.prefix;
    const index = request?.index;
    if (typeof prefix !== 'string' || !Number.isInteger(index)) return false;
    const url = (await knownRegistryEntry(prefix))?.videos?.[index]?.url;
    if (typeof url !== 'string' || !registryVideoUrlPattern.test(url)) return false;
    shell.openExternal(url);
    return true;
});

// entry comes from whatever packageDiscoverRegistry last returned to this renderer -- not
// re-fetched here, so what gets installed is exactly what the user saw when they clicked Install,
// and installing doesn't cost a second round trip to GitHub for data already in hand. One click
// installs every package a bundle entry lists (see the Multi-package bundles section of
// docs/extensionsExplorer.md); nothing here shows a confirmation dialog first the way manual
// packageInstall does -- the Explorer's own detail pane, showing what it does before the click, is
// that review, matching how a marketplace install normally works.
//
// namespaces for verifyPackageArchive, though, is NOT taken from the renderer -- verification only
// means something if the public keys it checks against come from a source the renderer can't
// control, so this always re-derives them from the main process's own bundled/cached registry
// copies, spread last so they win over anything the renderer passed. The renderer's namespaces is
// kept only as a last-resort fallback for a prefix neither trusted source knows about yet (e.g. a
// registry that was never successfully fetched even once) -- rare enough that just-fetched-and-not-
// yet-cached is not worth special-casing, since packageDiscoverRegistry writes its cache immediately
// after every successful fetch, before the renderer could have shown an Install button at all.
// Shared with welcomeInstallRecommendedAddons below, which needs the identical trust derivation.
async function trustedRegistryNamespaces(rendererNamespaces) {
    try {
        const cached = JSON.parse(await readFile(registryCachePath(), 'utf8'));
        const bundled = await loadBundledRegistry();
        return { prefixes: { ...(rendererNamespaces?.prefixes ?? {}), ...bundled.prefixes, ...(cached.prefixes ?? {}) } };
    } catch {
        return rendererNamespaces;
    }
}

// `release` (optional) names one release tag to install instead of the newest compatible one, for rolling back.
ipcMain.handle('packageInstallFromRegistry', async (_event, { entry, namespaces, release = null }) => {
    const results = await installFromRegistryEntry(entry, {
        namespaces: await trustedRegistryNamespaces(namespaces),
        directory: join(app.getPath('userData'), 'packages'),
        overwrite: true,
        appVersion: app.getVersion(),
        factsCache: await releaseFactsCache(),
        release
    });
    await discoverAddons();
    await discoverComponentLibrary();
    markPackageRestartPending();
    return results;
});

// The Welcome window's one-time starter-pack action (see recommendedAddonEntries/openWelcomeWindow
// above) -- entries are exactly what that window was shown, not re-fetched, matching
// packageInstallFromRegistry's "install what you saw" reasoning above. Installs every entry's
// packages in sequence rather than one at a time from the renderer, since this is a single "Install
// recommended" click covering however many entries are currently recommended, not a per-entry pick.
ipcMain.handle('welcomeInstallRecommendedAddons', async (_event, entries) => {
    const namespaces = await trustedRegistryNamespaces(null);
    const results = [];
    for (const entry of entries) {
        results.push(...await installFromRegistryEntry(entry, {
            namespaces, directory: join(app.getPath('userData'), 'packages'), overwrite: true,
            appVersion: app.getVersion(), factsCache: await releaseFactsCache()
        }));
    }
    await discoverAddons();
    await discoverComponentLibrary();
    markPackageRestartPending();
    return results;
});

// One GitHub Releases API call per installed entry that has a matching registry entry -- not a
// download, so this is cheap enough to run every time the Extensions dialog opens (see
// docs/extensionsExplorer.md's Update checking note). Only entries that are actually installed are
// checked, keeping the request count proportional to what's on disk, not the whole registry.
async function checkPackageUpdates() {
    let registry;
    try {
        registry = (await discoverableRegistry()).registry;
    } catch {
        return [];
    }
    const installed = await listInstalledPackages(join(app.getPath('userData'), 'packages'));
    const updates = [];
    for (const [prefix, entry] of Object.entries(registry.prefixes ?? {})) {
        if (!entry.downloadUrl || !Array.isArray(entry.packages)) continue;
        const installedMatches = entry.packages
            .map((declared) => installed.find((pkg) => pkg.packageId === declared.packageId))
            .filter(Boolean);
        if (!installedMatches.length) continue;
        const check = await checkEntryUpdate(entry, installedMatches.map((pkg) => pkg.version), {
            appVersion: app.getVersion(), factsCache: await releaseFactsCache()
        });
        if (check.status === 'unknown' || check.status === 'current') continue;
        // `outdated` lists the installed packages a compatible newer release would update, and is empty for an entry that is only
        // held back (a newer release exists but needs a newer Konjugate): that is a note, not an update, so it never reaches the
        // badge, Update all or the Updates tab, all of which count `outdated`.
        const outdated = check.status === 'update' ? installedMatches.filter((pkg) => isNewerPackageVersion(check.latest.version, pkg.version)) : [];
        updates.push({
            prefix, latestVersion: check.latest?.version ?? null, releaseUrl: check.latest?.url ?? null,
            outdated: outdated.map((pkg) => ({ packageId: pkg.packageId, installedVersion: pkg.version })),
            ...(check.heldBack ? { heldBack: check.heldBack } : {}),
            heldBackPackages: check.heldBack ? installedMatches.map((pkg) => pkg.packageId) : []
        });
    }
    return updates;
}

ipcMain.handle('packageCheckUpdates', async (_event, { force = false } = {}) => {
    const fresh = packageUpdatesCache && Date.now() - packageUpdatesCache.checkedAt < packageUpdatesCacheTtlMs;
    if (fresh && !force) return packageUpdatesCache.promise;
    const promise = checkPackageUpdates();
    packageUpdatesCache = { checkedAt: Date.now(), promise };
    // A failed check shouldn't be cached for an hour -- let the next caller retry.
    promise.catch(() => { if (packageUpdatesCache?.promise === promise) packageUpdatesCache = null; });
    return promise;
});

ipcMain.handle('projectUnlock', async (_event, { path, password }) => {
    if (!pendingEncryptedPaths.has(path)) throw new Error('Select the encrypted project again.');
    const project = await decodeProjectForRenderer(await readFile(path), { password });
    pendingEncryptedPaths.delete(path);
    return { path, fileName: basename(path), encrypted: true, ...project };
});

// Pull-based rather than pushed against a fresh window's did-finish-load: lets the renderer
// ask "was I opened with a file?" once on its own startup and reuse its existing open/unlock
// UI verbatim, rather than timing a webContents.send() against a load that can itself fail.
ipcMain.handle('projectPendingOpen', (event) => {
    const window = getWindowFromEvent(event);
    const pending = pendingWindowOpens.get(window);
    if (pending) pendingWindowOpens.delete(window);
    return pending ?? null;
});

// Lets openOrFocusProjectFile find an already-open window on the same file instead of opening
// a confusing duplicate -- main has no other visibility into which window has which file open.
ipcMain.on('projectPathChanged', (event, path) => {
    if (!senderIsProjectWindow(event)) return;
    const state = projectWindowState.get(getWindowFromEvent(event));
    if (state) state.currentProjectPath = path || null;
});

// resultBranches: [{jobId, branchUuid?, parentBranchUuid?, forkTime?, label?}, ...] -- a plain
// single-branch save (today's common case, no forking) sends one entry with no branch metadata at
// all, which encodeProjectFile writes in the exact legacy shape a build predating branching
// already understands (see projectFile.mjs's own doc comment on why that distinction matters).
ipcMain.handle('projectSave', async (event, { path: existingPath, content, suggestedFilename, password, resultBranches }) => {
    const targetWindow = getWindowFromEvent(event);
    let path = existingPath;
    if (!path) {
        const defaultName = suggestedFilename || 'untitled.kjt';
        const result = await dialog.showSaveDialog(targetWindow, {
            title: 'Save Konjugate project',
            defaultPath: defaultName,
            filters: [{ name: password ? 'Encrypted Konjugate project' : 'Konjugate project', extensions: ['kjt'] }]
        });
        if (result.canceled) return null;
        path = result.filePath;
    }
    if (!path.toLowerCase().endsWith('.kjt')) path += '.kjt';
    const resolvedBranches = [];
    for (const { jobId, ...branchMetadata } of resultBranches ?? []) {
        const stored = jobId ? completedEngineResults.get(jobId) : null;
        if (jobId && !stored?.path) throw new Error('The simulation results are no longer available.');
        if (!stored) continue;
        resolvedBranches.push({ buffer: await readFile(stored.path), ...branchMetadata });
    }
    const bytes = await encodeProjectFile(content, { password, resultBranches: resolvedBranches.length ? resolvedBranches : null });
    const verification = await decodeProjectBundle(bytes, { password });
    if (verification.content !== content || Boolean(verification.result) !== Boolean(resolvedBranches.length)) {
        throw new Error('The saved project could not be verified.');
    }
    await atomicWriteFile(path, bytes);
    return { path, fileName: basename(path), encrypted: Boolean(password), includesResults: Boolean(resolvedBranches.length) };
});

ipcMain.handle('projectExportResultsCsv', async (event, { suggestedFilename, csv }) => {
    const targetWindow = getWindowFromEvent(event);
    const result = await dialog.showSaveDialog(targetWindow, {
        title: 'Export results as CSV',
        defaultPath: suggestedFilename || 'results.csv',
        filters: [{ name: 'CSV', extensions: ['csv'] }]
    });
    if (result.canceled) return null;
    let path = result.filePath;
    if (!path.toLowerCase().endsWith('.csv')) path += '.csv';
    await writeFile(path, csv, 'utf8');
    return { path, fileName: basename(path) };
});

ipcMain.handle('projectExportGeneratedProgram', async (event, { suggestedFilename, source, kind }) => {
    const targetWindow = getWindowFromEvent(event);
    const extension = kind === 'cpp' ? 'cpp' : 'py';
    const result = await dialog.showSaveDialog(targetWindow, {
        title: kind === 'cpp' ? 'Export as C++ program' : 'Export as Python program',
        defaultPath: suggestedFilename || `results.${extension}`,
        filters: [{ name: kind === 'cpp' ? 'C++' : 'Python', extensions: [extension] }]
    });
    if (result.canceled) return null;
    let path = result.filePath;
    if (!path.toLowerCase().endsWith(`.${extension}`)) path += `.${extension}`;
    await writeFile(path, source, 'utf8');
    return { path, fileName: basename(path) };
});

ipcMain.handle('projectExportFmu', async (event, { suggestedFilename, document, modelName }) => {
    const targetWindow = getWindowFromEvent(event);
    const buffer = await generateFmuPackage(document, {
        modelName,
        engineOptions: { applicationPath: app.getAppPath(), resourcesPath: process.resourcesPath, packaged: app.isPackaged }
    });
    const result = await dialog.showSaveDialog(targetWindow, {
        title: 'Export as FMU',
        defaultPath: suggestedFilename || 'model.fmu',
        filters: [{ name: 'FMU', extensions: ['fmu'] }]
    });
    if (result.canceled) return null;
    let path = result.filePath;
    if (!path.toLowerCase().endsWith('.fmu')) path += '.fmu';
    await writeFile(path, buffer);
    return { path, fileName: basename(path) };
});

ipcMain.handle('projectMergeFmus', async (event) => {
    const targetWindow = getWindowFromEvent(event);
    const picked = await dialog.showOpenDialog(targetWindow, {
        title: 'Select FMUs to merge (one export per target platform)',
        filters: [{ name: 'FMU', extensions: ['fmu'] }],
        properties: ['openFile', 'multiSelections']
    });
    if (picked.canceled || picked.filePaths.length < 2) return null;

    const files = await Promise.all(picked.filePaths.map(async (path) => ({ name: basename(path), data: await readFile(path) })));
    const buffer = mergeFmuPackages(files);

    const saved = await dialog.showSaveDialog(targetWindow, {
        title: 'Save merged FMU',
        defaultPath: 'model.fmu',
        filters: [{ name: 'FMU', extensions: ['fmu'] }]
    });
    if (saved.canceled) return null;
    let path = saved.filePath;
    if (!path.toLowerCase().endsWith('.fmu')) path += '.fmu';
    await writeFile(path, buffer);
    return { path, fileName: basename(path), mergedCount: files.length };
});

ipcMain.handle('projectConfirmDiscard', async (event) => {
    const result = await dialog.showMessageBox(getWindowFromEvent(event), {
        type: 'warning',
        title: 'Unsaved changes',
        message: 'Discard unsaved changes?',
        detail: 'Unsaved model changes or simulation results cannot be recovered after closing or opening another project.',
        buttons: ['Cancel', 'Discard changes'],
        defaultId: 0,
        cancelId: 0
    });
    return result.response === 1;
});

function runProcess(command, args, { input } = {}) {
    return new Promise((resolve) => {
        let child;
        try {
            child = spawn(command, args);
        } catch (error) {
            resolve({ code: -1, stdout: '', stderr: error.message });
            return;
        }
        let stdout = '';
        let stderr = '';
        child.stdout.on('data', (chunk) => { stdout += chunk; });
        child.stderr.on('data', (chunk) => { stderr += chunk; });
        child.on('error', (error) => resolve({ code: -1, stdout: '', stderr: error.message }));
        child.on('close', (code) => resolve({ code, stdout, stderr }));
        if (input !== undefined) child.stdin.write(input);
        child.stdin.end();
    });
}

// Returns what auto-detection alone would choose, ignoring any stored override — used both
// as resolveCppCompiler()'s fallback and to show the user what "auto-detect" currently means.
async function autoDetectCppCompiler() {
    if (process.platform === 'darwin') {
        const result = await runProcess('xcrun', ['-find', 'clang++']);
        if (result.code === 0 && result.stdout.trim()) return { compiler: result.stdout.trim(), flavor: 'clang' };
    }
    if (process.platform === 'win32') {
        const msvcBin = 'C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64';
        if (existsSync(msvcBin) && !process.env.PATH.includes(msvcBin)) {
            process.env.PATH = msvcBin + ';' + process.env.PATH;
        }
        const candidateCls = [
            'cl.exe',
            'C:\\Program Files\\Microsoft Visual Studio\\18\\Community\\VC\\Tools\\MSVC\\14.51.36231\\bin\\Hostx64\\x64\\cl.exe',
            'C:\\Program Files (x86)\\Microsoft Visual Studio\\2022\\BuildTools\\VC\\Tools\\MSVC\\14.40.33807\\bin\\Hostx64\\x64\\cl.exe'
        ];
        for (const candidate of candidateCls) {
            const clResult = await runProcess(candidate, ['/?']);
            if (clResult.code === 0 || clResult.stderr.includes('Microsoft') || clResult.stdout.includes('Microsoft')) {
                return { compiler: candidate, flavor: 'msvc' };
            }
        }
        for (const candidate of ['clang++', 'g++', 'c++']) {
            const result = await runProcess(candidate, ['--version']);
            if (result.code === 0) return { compiler: candidate, flavor: 'clang' };
        }
    }
    return { compiler: 'c++', flavor: 'clang' };
}

// A GUI-launched app doesn't inherit the shell PATH additions a compiler manager (Homebrew,
// asdf, a non-default MSVC install, ...) may rely on, so auto-detection can genuinely miss a
// toolchain that is present on the machine. A stored override takes precedence when set.
async function resolveCppCompiler() {
    const overridePath = (await providerToolchainStore.get()).cpp.compilerPath;
    if (overridePath) {
        return { compiler: overridePath, flavor: /(^|[\\/])cl(\.exe)?$/i.test(overridePath) ? 'msvc' : 'clang' };
    }
    return autoDetectCppCompiler();
}

async function autoDetectPythonInterpreter() {
    for (const candidate of ['python3', 'python']) {
        if ((await runProcess(candidate, ['--version'])).code === 0) return candidate;
    }
    return null;
}

async function resolvePythonInterpreter() {
    const overridePath = (await providerToolchainStore.get()).python.interpreterPath;
    if (overridePath) return overridePath;
    return (await autoDetectPythonInterpreter()) ?? 'python3';
}

// Runs a candidate compiler/interpreter path with a harmless version-reporting flag to confirm
// it is actually runnable, before it is saved as an override or used to explain a failure.
async function testToolchainPath(kind, path) {
    const trimmed = (path ?? '').trim();
    if (!trimmed) return { valid: false, message: 'Enter a path first.' };
    if (kind === 'python') {
        const result = await runProcess(trimmed, ['--version']);
        if (result.code === 0) return { valid: true, message: (result.stdout || result.stderr).trim() || 'Python found.' };
        return { valid: false, message: result.stderr.trim() || result.stdout.trim() || 'That path could not be run.' };
    }
    const versionResult = await runProcess(trimmed, ['--version']);
    if (versionResult.code === 0) return { valid: true, message: versionResult.stdout.trim().split('\n')[0] || 'Compiler found.' };
    const helpResult = await runProcess(trimmed, ['/?']);
    if (helpResult.code === 0 || helpResult.stdout.includes('Microsoft') || helpResult.stderr.includes('Microsoft')) {
        return { valid: true, message: 'MSVC compiler found.' };
    }
    return { valid: false, message: versionResult.stderr.trim() || versionResult.stdout.trim() || 'That path could not be run.' };
}

async function resolveAppleSdkSysroot() {
    const result = await runProcess('xcrun', ['--show-sdk-path']);
    return result.code === 0 ? result.stdout.trim() : '';
}

function parseCompilerDiagnostics(output, filePath) {
    const clangPattern = /^(.*):(\d+):(\d+):\s+(error|warning|note):\s+(.*)$/;
    const msvcPattern = /^(.*)\((\d+)(?:,(\d+))?\):\s+(error|warning)\s+([A-Z0-9]+):\s+(.*)$/;
    const severityByLevel = { error: 'error', warning: 'warning', note: 'info' };
    const diagnostics = [];
    for (const rawLine of output.split('\n')) {
        const trimmed = rawLine.trim();
        const clangMatch = trimmed.match(clangPattern);
        if (clangMatch && (clangMatch[1] === filePath || clangMatch[1].endsWith('relationship.cpp'))) {
            diagnostics.push({
                line: Number(clangMatch[2]),
                column: Number(clangMatch[3]),
                severity: severityByLevel[clangMatch[4]] ?? 'error',
                message: clangMatch[5]
            });
            continue;
        }
        const msvcMatch = trimmed.match(msvcPattern);
        if (msvcMatch && (msvcMatch[1] === filePath || msvcMatch[1].endsWith('relationship.cpp'))) {
            diagnostics.push({
                line: Number(msvcMatch[2]),
                column: Number(msvcMatch[3] ?? 1),
                severity: severityByLevel[msvcMatch[4]] ?? 'error',
                message: `${msvcMatch[5]}: ${msvcMatch[6]}`
            });
        }
    }
    return diagnostics;
}

function findMsvcIncludeDirs() {
    const includeDirs = [];
    const vsBases = [
        'C:\\Program Files\\Microsoft Visual Studio',
        'C:\\Program Files (x86)\\Microsoft Visual Studio'
    ];
    for (const vsBase of vsBases) {
        if (!existsSync(vsBase)) continue;
        try {
            for (const year of readdirSync(vsBase)) {
                const yearPath = join(vsBase, year);
                for (const edition of readdirSync(yearPath)) {
                    const msvcPath = join(yearPath, edition, 'VC', 'Tools', 'MSVC');
                    if (existsSync(msvcPath)) {
                        for (const version of readdirSync(msvcPath)) {
                            const inc = join(msvcPath, version, 'include');
                            if (existsSync(inc)) {
                                includeDirs.push(inc);
                                break;
                            }
                        }
                    }
                    if (includeDirs.length) break;
                }
                if (includeDirs.length) break;
            }
        } catch {}
        if (includeDirs.length) break;
    }
    const winKitsBases = [
        'C:\\Program Files (x86)\\Windows Kits\\10\\Include',
        'C:\\Program Files\\Windows Kits\\10\\Include'
    ];
    for (const winKitBase of winKitsBases) {
        if (!existsSync(winKitBase)) continue;
        try {
            const sdks = readdirSync(winKitBase);
            if (sdks.length) {
                const latestSdk = join(winKitBase, sdks[sdks.length - 1]);
                for (const sub of ['ucrt', 'um', 'shared']) {
                    const inc = join(latestSdk, sub);
                    if (existsSync(inc)) includeDirs.push(inc);
                }
                break;
            }
        } catch {}
    }
    return includeDirs;
}

// Runs syntax checking (-fsyntax-only on Clang/GCC, /zs on MSVC), a parse/type-check pass that never produces or runs a binary.
async function validateCppSource(source) {
    const directory = await mkdtemp(join(tmpdir(), 'konjugateProviderCheck-'));
    try {
        const filePath = join(directory, 'relationship.cpp');
        await writeFile(filePath, source ?? '', 'utf8');
        const { compiler, flavor } = await resolveCppCompiler();
        const includePath = join(cppProviderSdkPath({
            applicationPath: app.getAppPath(), resourcesPath: process.resourcesPath, packaged: app.isPackaged
        }), 'include');
        let args;
        if (flavor === 'msvc') {
            const msvcIncs = findMsvcIncludeDirs();
            if (!process.env.INCLUDE && msvcIncs.length) {
                process.env.INCLUDE = msvcIncs.join(';');
            }
            args = ['/std:c++20', '/EHsc', '/Zs', '/nologo', '/I' + includePath];
            for (const dir of msvcIncs) {
                args.push('/I' + dir);
            }
            args.push(filePath);
        } else {
            args = ['-std=c++20', '-fsyntax-only', '-I' + includePath];
            if (process.platform === 'darwin') {
                const sysroot = await resolveAppleSdkSysroot();
                if (sysroot) args.push('-isysroot', sysroot);
            }
            args.push(filePath);
        }
        const result = await runProcess(compiler, args);
        const output = (result.stderr + '\n' + result.stdout).trim();
        const diagnostics = parseCompilerDiagnostics(output, filePath);
        if (result.code !== 0 && diagnostics.length === 0) {
            diagnostics.push({
                line: 1,
                column: 1,
                severity: 'error',
                message: output || `The C++ compiler ("${compiler}") exited with code ${result.code}.`
            });
        }
        return { valid: result.code === 0, diagnostics };
    } finally {
        await rm(directory, { recursive: true, force: true });
    }
}

// Pure ast.parse — a syntax check only. It never imports or executes the source, which
// matters because this runs automatically as the user types.
const PYTHON_SYNTAX_CHECK_SCRIPT = 'import ast, sys\n'
    + 'try:\n'
    + '    ast.parse(sys.stdin.read())\n'
    + 'except SyntaxError as error:\n'
    + '    print(f"{error.lineno or 1}:{error.offset or 1}: {error.msg}", file=sys.stderr)\n'
    + '    sys.exit(1)\n';

async function validatePythonSource(source) {
    const interpreter = await resolvePythonInterpreter();
    const result = await runProcess(interpreter, ['-c', PYTHON_SYNTAX_CHECK_SCRIPT], { input: source ?? '' });
    if (result.code === 0) return { valid: true, diagnostics: [] };
    const match = result.stderr.trim().match(/^(\d+):(\d+):\s*(.*)$/);
    if (!match) {
        return { valid: false, diagnostics: [{ line: 1, column: 1, severity: 'error', message: result.stderr.trim() || 'Python syntax check failed.' }] };
    }
    return { valid: false, diagnostics: [{ line: Number(match[1]), column: Number(match[2]), severity: 'error', message: match[3] }] };
}

ipcMain.handle('providerEditorOpenWindow', (event, payload) => {
    openProviderEditorWindow(getWindowFromEvent(event), event.sender, payload);
});

ipcMain.handle('providerEditorValidate', async (_event, { source, kind }) => (
    kind === 'python' ? validatePythonSource(source) : validateCppSource(source)
));

ipcMain.handle('providerEditorApply', (event, { source }) => {
    // This call comes from the provider-editor window itself, not a project window -- find
    // which project window owns it (each can have its own provider editor open now).
    const projectWindow = projectWindowForAuxSender(event, 'providerEditorWindow');
    const state = projectWindow && projectWindowState.get(projectWindow);
    if (!state?.providerEditorOwner || state.providerEditorOwner.isDestroyed()) {
        return { applied: false, error: 'The originating window is no longer available.' };
    }
    // The project window computes success/failure (e.g. its edge or source term may have been
    // deleted while this editor was open) and reports back over providerEditorApplyResult,
    // since webContents.send() has no built-in reply channel of its own.
    state.pendingProviderApply?.({ applied: false, error: 'Superseded by a newer apply.' });
    return new Promise((resolve) => {
        state.pendingProviderApply = resolve;
        state.providerEditorOwner.send('providerEditorApplied', { source });
    });
});

ipcMain.on('providerEditorApplyResult', (event, result) => {
    if (!senderIsProjectWindow(event)) return;
    const state = projectWindowState.get(getWindowFromEvent(event));
    state.pendingProviderApply?.(result);
    state.pendingProviderApply = null;
});

ipcMain.on('clipboardReadBuffer', (event, format) => {
    event.returnValue = clipboard.readBuffer(format);
});

ipcMain.on('clipboardWriteBuffer', (event, { format, buffer }) => {
    clipboard.writeBuffer(format, Buffer.from(buffer));
    event.returnValue = true;
});

const requireToolchainWindow = (event) => requireProjectWindow(event, 'Only a project window can access toolchain settings.');

ipcMain.handle('providerToolchainGet', async (event, kind) => {
    requireToolchainWindow(event);
    const settings = await providerToolchainStore.get();
    const overridePath = kind === 'python' ? settings.python.interpreterPath : settings.cpp.compilerPath;
    const guess = kind === 'python' ? await autoDetectPythonInterpreter() : (await autoDetectCppCompiler()).compiler;
    const detectedPath = guess && (await testToolchainPath(kind, guess)).valid ? guess : null;
    return { overridePath, detectedPath };
});

ipcMain.handle('providerToolchainSet', async (event, { kind, path }) => {
    requireToolchainWindow(event);
    const trimmed = (path ?? '').trim();
    if (trimmed) {
        const test = await testToolchainPath(kind, trimmed);
        if (!test.valid) throw new Error(test.message || 'That path could not be verified.');
    }
    const settings = await providerToolchainStore.set(kind, trimmed);
    return kind === 'python' ? settings.python : settings.cpp;
});

ipcMain.handle('providerToolchainTest', async (event, { kind, path }) => {
    requireToolchainWindow(event);
    return testToolchainPath(kind, path);
});

ipcMain.handle('providerToolchainBrowse', async (event, kind) => {
    requireToolchainWindow(event);
    const result = await dialog.showOpenDialog(getWindowFromEvent(event), {
        title: kind === 'python' ? 'Select a Python interpreter' : 'Select a C++ compiler',
        properties: ['openFile'],
        ...(process.platform === 'win32' ? { filters: [{ name: 'Executable', extensions: ['exe'] }] } : {})
    });
    if (result.canceled || !result.filePaths.length) return null;
    return result.filePaths[0];
});

// Advanced/expert setting: how C++ relationship providers run relative to the engine process.
// See ProviderExecutionMode in the engine for what each option actually does; '' ("Automatic")
// leaves it to the engine's own default rather than persisting a specific choice, so a future
// change to that default reaches users who never touched this setting.
ipcMain.handle('providerExecutionModeGet', async (event) => {
    requireToolchainWindow(event);
    const settings = await providerToolchainStore.get();
    return { executionMode: settings.executionMode, options: providerExecutionModes };
});

ipcMain.handle('providerExecutionModeSet', async (event, executionMode) => {
    requireToolchainWindow(event);
    const settings = await providerToolchainStore.set('executionMode', executionMode);
    return { executionMode: settings.executionMode };
});

ipcMain.handle('aiListConfigurations', async (event) => {
    requireProjectWindow(event);
    const result = await aiConfigurationStore.list();
    return { ...result, providers: aiProviderRegistry.descriptors() };
});

ipcMain.handle('aiListModels', async (event, configurationUuid) => {
    requireProjectWindow(event);
    const resolved = await aiConfigurationStore.resolve(configurationUuid);
    return withAIOperation(event.sender, resolved.configuration.timeoutSeconds,
        (signal) => aiProviderRegistry.listModels({ ...resolved, signal }));
});

ipcMain.handle('aiListDraftModels', async (event, configuration, credential) => {
    requireProjectWindow(event);
    const resolved = await aiConfigurationStore.resolveDraft(configuration, credential);
    return withAIOperation(event.sender, resolved.configuration.timeoutSeconds,
        (signal) => aiProviderRegistry.listModels({ ...resolved, signal }));
});

ipcMain.handle('aiSaveConfiguration', async (event, configuration, credential) => {
    requireProjectWindow(event);
    return aiConfigurationStore.save(configuration, credential);
});

ipcMain.handle('aiRemoveConfiguration', async (event, configurationUuid) => {
    requireProjectWindow(event);
    return aiConfigurationStore.remove(configurationUuid);
});

ipcMain.handle('aiSetActiveConfiguration', async (event, configurationUuid) => {
    requireProjectWindow(event);
    return aiConfigurationStore.setActive(configurationUuid);
});

ipcMain.handle('aiTestConnection', async (event, configurationUuid) => {
    requireProjectWindow(event);
    const resolved = await aiConfigurationStore.resolve(configurationUuid);
    return withAIOperation(event.sender, resolved.configuration.timeoutSeconds,
        (signal) => aiProviderRegistry.testConnection({ ...resolved, signal }));
});

ipcMain.handle('aiTestDraftConnection', async (event, configuration, credential) => {
    requireProjectWindow(event);
    const resolved = await aiConfigurationStore.resolveDraft(configuration, credential);
    return withAIOperation(event.sender, resolved.configuration.timeoutSeconds,
        (signal) => aiProviderRegistry.testConnection({ ...resolved, signal }));
});

ipcMain.handle('aiGenerateProposal', async (event, { requestUuid, configurationUuid, request, context, history }) => {
    requireProjectWindow(event);
    if (typeof requestUuid !== 'string' || requestUuid.length > 100) throw new Error('A valid AI request identifier is required.');
    if (typeof request !== 'string' || !request.trim() || request.length > 8000) throw new Error('The AI request must contain between 1 and 8,000 characters.');
    if (!context || typeof context !== 'object' || JSON.stringify(context).length > 1_000_000) throw new Error('The model context is invalid or too large.');
    if (history !== undefined) {
        const validHistory = Array.isArray(history) && history.length <= 5 &&
            history.every((turn) => turn && typeof turn.request === 'string' && typeof turn.outcome === 'string');
        if (!validHistory || JSON.stringify(history).length > 20_000) throw new Error('The conversation history is invalid or too large.');
    }
    const key = aiRequestKey(event.sender, requestUuid);
    activeAIRequests.get(key)?.controller.abort();
    const resolved = await aiConfigurationStore.resolve(configurationUuid);
    const controller = new AbortController();
    let expiredBecause = null;
    // The configuration's timeout is how long the model may stay silent, not how long the whole request
    // may take: every sign of life (see the registry's progress) restarts it, and each repair attempt
    // starts a fresh one. A hard maximum still ends a request that never finishes.
    const watchdog = createRequestWatchdog({
        idleSeconds: resolved.configuration.timeoutSeconds,
        onExpire: (reason) => {
            expiredBecause = reason;
            controller.abort();
        }
    });
    const progressToPanel = createLatestThrottle((progress) => {
        if (!event.sender.isDestroyed()) event.sender.send('aiProgress', { requestUuid, ...progress });
    }, 120);
    activeAIRequests.set(key, { owner: event.sender, controller });
    try {
        const proposal = await aiProviderRegistry.generate({
            ...resolved, context, request: request.trim(), history, signal: controller.signal,
            onProgress: (progress) => {
                watchdog.touch();
                progressToPanel.push(progress);
            }
        });
        return { ok: true, proposal };
    } catch (error) {
        const message = expiredBecause === 'idle'
            ? `The model sent nothing for ${resolved.configuration.timeoutSeconds} seconds. This timeout counts silence, not total time: increase it in this model configuration, or choose a faster model.`
            : expiredBecause === 'maximum'
                ? `The request was stopped after ${maximumRequestSeconds / 60} minutes in total.`
                : error.name === 'AbortError' ? 'Proposal generation was cancelled.' : error.message;
        const code = expiredBecause ? 'requestTimedOut' : error.name === 'AbortError' ? 'requestCancelled' : error.code ?? 'providerError';
        return { ok: false, error: { message, code } };
    } finally {
        watchdog.stop();
        progressToPanel.stop();
        if (activeAIRequests.get(key)?.controller === controller) activeAIRequests.delete(key);
    }
});

ipcMain.handle('aiCancelRequest', async (event, requestUuid) => {
    requireProjectWindow(event);
    const key = aiRequestKey(event.sender, requestUuid);
    const active = activeAIRequests.get(key);
    if (!active || active.owner !== event.sender) return false;
    active.controller.abort();
    activeAIRequests.delete(key);
    return true;
});

const engineOptions = async () => {
    const resolvedCpp = await resolveCppCompiler();
    const resolvedPython = await resolvePythonInterpreter();
    const { executionMode } = await providerToolchainStore.get();
    const packagesDirectory = join(app.getPath('userData'), 'packages');
    const disabledExtensionKeys = await extensionStateStore.list();
    // A plugin that needs a newer Konjugate is never run: a model that references it gets the reason, not a missing-file error.
    const incompatiblePluginKeys = Object.fromEntries([...(await incompatiblePackages())]
        .filter(([key]) => key.startsWith('plugin:'))
        .map(([key, verdict]) => [key, `needs Konjugate ${verdict.required} or later; this is Konjugate ${verdict.running}.`]));
    return {
        applicationPath: app.getAppPath(),
        resourcesPath: process.resourcesPath,
        packaged: app.isPackaged,
        pluginDirectory: packagesDirectory,
        disabledPluginKeys: disabledExtensionKeys,
        incompatiblePluginKeys,
        // Same root and the same disabled-key list as plugins above -- packageKey()'s type
        // prefix ("fmu:"/"plugin:"/...) is what keeps one shared disabled-extension list
        // unambiguous across every installed package kind.
        fmuDirectory: packagesDirectory,
        disabledFmuKeys: disabledExtensionKeys,
        providerToolchains: {
            cpp: { compilerPath: resolvedCpp?.compiler ?? '' },
            python: { interpreterPath: resolvedPython ?? '', chosen: Boolean((await providerToolchainStore.get()).python.interpreterPath) },
            executionMode
        }
    };
};

const launcherHost = registerLauncherHandlers({
    ipcMain, dialog, BrowserWindow, app, screen, currentDir, iconPath: appIconPath, projectWindows, projectWindowState, installCustomWindowState,
    auxiliaryWindowBounds, auxiliaryWindowPresentation, engineOptions, decodeProjectForRenderer, addonRegistry, inferWithEngine, shell
});

const cliUsage = 'Usage: konjugate --cli run <project.kjt> --target-time <seconds> '
    + '[--configuration <name-or-id>] [--output-kjt <path>] [--output-csv <path>]\n'
    + '       konjugate --cli validate <project.kjt>';

// Runs entirely inside app.whenReady() (see the branch there) -- never creates a BrowserWindow,
// and always ends in app.exit(code) rather than leaving the process running or calling the
// graceful app.quit(), since a CLI invocation is a one-shot batch job, not a long-lived instance.
async function runCliMode() {
    const cliArgs = process.argv.slice(process.argv.indexOf('--cli') + 1);
    const [subcommand, inputPath, ...rest] = cliArgs;
    if (!subcommand || !inputPath || !['run', 'validate'].includes(subcommand)) {
        console.error(cliUsage);
        app.exit(2);
        return;
    }
    const flags = parseCliFlags(rest);

    providerToolchainStore = createProviderToolchainStore({ directory: join(app.getPath('userData'), 'providers') });
    extensionStateStore = createExtensionStateStore({ directory: join(app.getPath('userData'), 'packages') });

    let bundle;
    try {
        // KONJUGATE_PASSWORD, not a --password flag, matching the engine's own CLI convention
        // for the same input -- a password never belongs in shell history or a process list.
        bundle = await decodeProjectBundle(await readFile(inputPath), { password: process.env.KONJUGATE_PASSWORD });
    } catch (error) {
        console.error(`Could not read or decode "${inputPath}": ${error.message}`);
        app.exit(1);
        return;
    }
    const options = await engineOptions();

    if (subcommand === 'validate') {
        const outcome = await validateWithEngine(bundle.content, options);
        if (!outcome.available) {
            console.error('The simulation engine is unavailable.');
            app.exit(1);
            return;
        }
        console.log(JSON.stringify(outcome.report, null, 2));
        app.exit(outcome.report.valid ? 0 : 2);
        return;
    }

    const targetTime = Number(flags['target-time']);
    if (!Number.isFinite(targetTime) || targetTime <= 0) {
        console.error('--target-time <seconds> (a positive number) is required for --cli run.');
        app.exit(2);
        return;
    }
    const document = JSON.parse(bundle.content);
    const runConfigurations = document.runConfigurations ?? [];
    const runConfiguration = matchRunConfiguration(runConfigurations, document.activeRunConfigurationId, flags.configuration);
    if (flags.configuration && !runConfiguration) {
        console.error(`No run configuration named or numbered "${flags.configuration}".`);
        app.exit(2);
        return;
    }
    if (!runConfiguration) {
        console.error('The project has no run configurations.');
        app.exit(2);
        return;
    }

    const configuration = { ...runConfiguration, targetTime, pacing: { mode: 'fastest' } };
    console.log(`Running "${inputPath}" with configuration "${runConfiguration.name}" for ${targetTime}s of simulated time...`);
    let execution;
    try {
        execution = await startEngineRun(
            JSON.stringify(stripEdgeGroups(executionProjectDocument(document))), configuration, options, { retainResult: true }
        );
    } catch (error) {
        console.error(`The simulation failed: ${error.message}`);
        app.exit(1);
        return;
    }
    if (!execution.available) {
        console.error('The simulation engine is unavailable.');
        app.exit(1);
        return;
    }

    let result;
    try {
        result = await execution.completion;
    } catch (error) {
        console.error(`The simulation failed: ${error.message}`);
        await execution.cleanup();
        app.exit(1);
        return;
    }

    try {
        if (flags['output-kjt']) {
            const resultBytes = await readFile(execution.resultPath);
            await atomicWriteFile(flags['output-kjt'], await encodeProjectFile(bundle.content, { result: resultBytes }));
            console.log(`Wrote ${flags['output-kjt']}`);
        }
        if (flags['output-csv']) {
            const csv = resultSignalsToCsv(result, projectDocumentSignals(document));
            await writeFile(flags['output-csv'], csv, 'utf8');
            console.log(`Wrote ${flags['output-csv']}`);
        }
        if (!flags['output-kjt'] && !flags['output-csv']) {
            console.log('Simulation completed. Pass --output-kjt and/or --output-csv to save the result.');
        }
    } catch (error) {
        console.error(`Could not write output: ${error.message}`);
        await execution.cleanup();
        app.exit(1);
        return;
    }
    await execution.cleanup();
    app.exit(0);
}

ipcMain.handle('engineCapabilities', async () => getEngineCapabilities(await engineOptions()));

// `supersede` names a stream of validations of the same thing (the canvas passes 'model'): a new
// request cancels that window's previous one still in flight, whose result would only be thrown
// away. A validation cancelled that way, or because its window closed, resolves to
// { cancelled: true } -- a cancellation is an outcome, not an engine failure. Real failures still
// reject.
ipcMain.handle('engineValidate', async (event, content, { supersede = null } = {}) => {
    if (supersede) {
        for (const previous of activeValidationOperations) {
            if (previous.owner === event.sender && previous.supersede === supersede) previous.controller.abort();
        }
    }
    const active = { owner: event.sender, supersede, controller: new AbortController(), completion: null };
    activeValidationOperations.add(active);
    try {
        active.completion = validateWithEngine(content, { ...await engineOptions(), signal: active.controller.signal });
        return await active.completion;
    } catch (error) {
        if (active.controller.signal.aborted) return { cancelled: true };
        throw error;
    } finally {
        activeValidationOperations.delete(active);
    }
});

// Post-run phase's "Check convergence" action (docs/proposals/numericalStabilityDiagnostics.md)
// -- unlike validate/infer/fit above, this isn't tracked in an active-operations set with its own
// AbortController: checkSubstepConvergence() has no cancellation support internally (each of its
// sequential engine re-runs completes before the next starts), so there is nothing a signal could
// actually interrupt yet. Accepted for now as a real, not faked, limitation of this first version.
ipcMain.handle('engineCheckSubstepConvergence', async (_event, content, runConfiguration, nodeIds) =>
    checkSubstepConvergenceWithEngine(content, runConfiguration, nodeIds, await engineOptions()));

ipcMain.handle('engineInfer', async (event, csvContent, config) => {
    const active = { owner: event.sender, controller: new AbortController(), completion: null };
    activeInferenceOperations.add(active);
    try {
        active.completion = inferWithEngine(csvContent, config, { ...await engineOptions(), signal: active.controller.signal });
        return await active.completion;
    } finally {
        activeInferenceOperations.delete(active);
    }
});

ipcMain.handle('engineFit', async (event, content, csvContent, config) => {
    const active = { owner: event.sender, controller: new AbortController(), completion: null };
    activeFittingOperations.add(active);
    try {
        active.completion = fitWithEngine(content, csvContent, config, { ...await engineOptions(), signal: active.controller.signal });
        return await active.completion;
    } finally {
        activeFittingOperations.delete(active);
    }
});

ipcMain.handle('engineRun', async (event, content, configuration) => {
    const execution = await startEngineRun(content, configuration, await engineOptions());
    if (!execution.available) return execution;
    activeEngineJobs.set(execution.jobId, { owner: event.sender, latestResult: null, ...execution });
    try {
        return { available: true, result: await execution.completion };
    } finally {
        activeEngineJobs.delete(execution.jobId);
    }
});

ipcMain.handle('engineStart', async (event, content, configuration) => {
    const owner = event.sender;
    const projectWindow = getWindowFromEvent(event);
    let execution;
    let latestUpdate = null;
    let updateTimer = null;
    const flushUpdate = () => {
        updateTimer = null;
        if (latestUpdate && !owner.isDestroyed()) owner.send('engineRunUpdate', latestUpdate);
        latestUpdate = null;
    };
    const projectLiveResult = (result) => ({
        ...result,
        samples: result.samples?.length ? [result.samples.at(-1)] : [],
        checkpoints: []
    });
    execution = await startEngineRun(content, configuration, await engineOptions(), {
        retainResult: true,
        onUpdate: (result) => {
            const job = activeEngineJobs.get(execution.jobId);
            if (job) job.latestResult = result;
            updateVisualizerResult(projectWindow, execution.jobId, result);
            latestUpdate = { jobId: execution.jobId, result: projectLiveResult(result) };
            updateTimer ??= setTimeout(flushUpdate, 100);
        }
    });
    if (!execution.available) return { available: false };
    activeEngineJobs.set(execution.jobId, { owner, latestResult: null, ...execution });
    execution.completion.then(async (result) => {
        if (updateTimer) clearTimeout(updateTimer);
        updateTimer = null;
        latestUpdate = null;
        const reader = await openIndexedResult(execution.resultPath);
        completedEngineResults.set(execution.jobId, { result, reader, cleanup: execution.cleanup, path: execution.resultPath });
        updateVisualizerResult(projectWindow, execution.jobId, result);
        if (!owner.isDestroyed()) owner.send('engineRunComplete', {
            jobId: execution.jobId,
            result: rendererResultProjection(result),
            checkpointIndex: checkpointIndex(result)
        });
    }).catch((error) => {
        if (updateTimer) clearTimeout(updateTimer);
        console.error(`[Engine Error] Simulation job ${execution.jobId} failed:`, error.message || error);
        execution.cleanup().catch(() => { });
        if (!owner.isDestroyed()) owner.send('engineRunError', { jobId: execution.jobId, message: error.message });
    }).finally(() => activeEngineJobs.delete(execution.jobId));
    return { available: true, jobId: execution.jobId };
});

ipcMain.handle('engineSetPacing', async (event, jobId, pacing) => {
    const job = activeEngineJobs.get(jobId);
    if (!job || job.owner !== event.sender) throw new Error('That simulation job is not active.');
    return job.setPacing(pacing);
});

ipcMain.handle('engineSetExecutionState', async (event, jobId, executionState) => {
    const job = activeEngineJobs.get(jobId);
    if (!job || job.owner !== event.sender) throw new Error('That simulation job is not active.');
    return job.setExecutionState(executionState);
});

ipcMain.handle('engineSetParameterValue', async (event, jobId, parameterId, value) => {
    const job = activeEngineJobs.get(jobId);
    if (!job || job.owner !== event.sender) throw new Error('That simulation job is not active.');
    return job.setParameterValue(parameterId, value);
});

ipcMain.handle('engineScheduleParameterValue', async (event, jobId, parameterId, schedule) => {
    const job = activeEngineJobs.get(jobId);
    if (!job || job.owner !== event.sender) throw new Error('That simulation job is not active.');
    return job.scheduleParameterValue(parameterId, schedule);
});

ipcMain.handle('engineCancel', async (event, jobId) => {
    const job = activeEngineJobs.get(jobId);
    if (!job || job.owner !== event.sender) return false;
    await job.cancel();
    return true;
});

ipcMain.handle('engineReadResultSeries', async (event, jobId, signalIds, options) => {
    if (!senderIsProjectWindow(event)) return [];
    const stored = completedEngineResults.get(jobId);
    if (!stored) return [];
    const result = {
        ...stored.reader.metadata,
        samples: await stored.reader.readSamples({
            startTime: options?.startTime,
            endTime: options?.endTime,
            maximumSamples: options?.maxPoints
        })
    };
    return resultSignalSeries(result, signalIds, options);
});

ipcMain.handle('engineReadResultSample', async (event, jobId, time) => {
    if (!senderIsProjectWindow(event)) return null;
    const stored = completedEngineResults.get(jobId);
    if (!stored) return null;
    return structuredClone(await stored.reader.readNearestSample(Number(time)));
});

// Reads from the in-memory `stored.result.checkpoints` (decoded once, in full, by
// decodeResultFile -- see engineProtocol.mjs) rather than `stored.reader`, whose
// indexedResultReader.mjs never copies a checkpoint's providerStates when building its
// on-disk index. Fetching through the reader would silently drop provider state and make
// any fork of a provider-bearing model fail to restore.
ipcMain.handle('engineReadCheckpoint', async (event, jobId, time) => {
    if (!senderIsProjectWindow(event)) return null;
    const stored = completedEngineResults.get(jobId);
    const checkpoints = stored?.result.checkpoints ?? [];
    if (!checkpoints.length) return null;
    const target = Number(time);
    const nearest = checkpoints.reduce((closest, candidate) =>
        Math.abs(Number(candidate.time) - target) < Math.abs(Number(closest.time) - target) ? candidate : closest);
    return structuredClone(nearest);
});

ipcMain.handle('engineReleaseResult', async (event, jobId) => {
    if (!senderIsProjectWindow(event)) return false;
    const stored = completedEngineResults.get(jobId);
    if (!stored) return false;
    completedEngineResults.delete(jobId);
    await stored.reader.close();
    await stored.cleanup();
    return true;
});

app.whenReady().then(async () => {
    if (isCliMode) {
        await runCliMode();
        return;
    }
    const operationSchema = JSON.parse(await readFile(join(currentDir, '..', 'schemas', 'assistantOperations.schema.json'), 'utf8'));
    aiProviderRegistry = createAIProviderRegistry(createRemoteAIProviders({ operationSchema }));
    aiConfigurationStore = createAIConfigurationStore({
        directory: join(app.getPath('userData'), 'ai'),
        credentialVault: createElectronCredentialVault(safeStorage)
    });
    providerToolchainStore = createProviderToolchainStore({
        directory: join(app.getPath('userData'), 'providers')
    });
    extensionStateStore = createExtensionStateStore({ directory: join(app.getPath('userData'), 'packages') });

    // A file passed on the initial launch (Windows/Linux double-click, or a path Electron
    // handed us via process.argv) opens directly into the first window rather than opening
    // blank and then a second one; any additional macOS open-file paths queued before ready
    // get their own window each via the normal open-or-focus routing.
    const initialPath = parseKjtPathFromArgv(process.argv) ?? openFileQueue.shift() ?? null;
    const firstWindow = initialPath
        ? createProjectWindow(readProjectFilePayload(initialPath).catch((error) => ({ error: error.message })))
        : createProjectWindow();
    for (const queuedPath of openFileQueue.splice(0)) openOrFocusProjectFile(queuedPath);

    // These CLI-driven harness hooks are wired only for this one, first-created window --
    // never inside createProjectWindow() itself, since that factory is also used for every
    // window a user opens via "New Window" (and every window the interaction-test suite itself
    // opens to exercise multi-window behavior), which must never recursively re-run the suite.
    if (process.argv.includes('--interaction-test')) {
        firstWindow.webContents.once('did-finish-load', async () => {
            try {
                const { runInteractionTests } = await import('../tests/interactionRunner.mjs');
                const { createElectronDriver } = await import('../tests/drivers/electronWindowDriver.mjs');
                await runInteractionTests(createElectronDriver(firstWindow));
                app.exit(0);
            } catch (error) {
                console.error(error);
                app.exit(1);
            }
        });
    } else {
        startUpdateChecks().catch((error) => console.warn('Update checks could not start:', error.message));
    }
    if (process.argv.includes('--generate-example-thumbnails')) {
        firstWindow.webContents.once('did-finish-load', async () => {
            try {
                const { generateExampleThumbnails } = await import('../tests/generateExampleThumbnails.mjs');
                await generateExampleThumbnails(firstWindow);
                app.exit(0);
            } catch (error) {
                console.error(error);
                app.exit(1);
            }
        });
    }
    if (!shouldSkipWelcomeTrigger()) openWelcomeWindow(firstWindow, { automatic: true });

    app.on('activate', () => {
        if (projectWindows.size === 0) {
            const window = createProjectWindow();
            if (!shouldSkipWelcomeTrigger()) openWelcomeWindow(window, { automatic: true });
        }
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('before-quit', (event) => {
    if (applicationShutdownComplete) return;
    event.preventDefault();
    beginApplicationShutdown().finally(() => {
        applicationShutdownComplete = true;
        app.quit();
    });
});
