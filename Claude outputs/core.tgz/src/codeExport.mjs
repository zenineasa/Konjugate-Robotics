/* Copyright © 2026 Zenin Easa Panthakkalakath */

// Generates a standalone, single-file C++ or Python program that reproduces one full simulation
// run of the given (already flattened, subsystem/edgeGroup-stripped) project document -- with no
// runtime dependency on the Konjugate engine binary or GUI. See docs/codeExport.md for the
// supported subset and docs/projectSchema.md for the document shape this reads.
//
// Fidelity contract, confirmed against engine/src/executionPlan.cpp and
// engine/src/simulationRunner.cpp (the only integrator that exists is fixed-step, multi-rate
// Explicit Euler -- there is no RK4/implicit solver to consider):
//   - each global step takes one frozen copy of the whole state vector ("snapshot"); a node's own
//     states evolve through a local, substep-updated working copy SEEDED FROM that snapshot, while
//     a binding into another node's state always reads the frozen snapshot value, for every
//     substep of every node, the whole step through. A node's freshly computed states are only
//     committed back into the global vector after every node has finished the step.
//   - contributions targeting the same state are summed in a fixed order: a node's own source
//     terms in their JSON order, then edges that touch this node in document order (a
//     bidirectional edge's negated "other side" contribution is generated independently from the
//     same expression/bindings, re-evaluated for that side, not reused as a cached number).
//   - a contribution's finalized value (post negation) must be finite or the run aborts, exactly
//     like the engine's per-task check -- sub-expression NaN/Infinity is not itself an error.

import { resolveSharedParameters } from './sharedParameters.mjs';

const numericLiteralPattern = /^-?\d+(\.\d+)?([eE]-?\d+)?$/;

const minimumArgumentCounts = {
    Negate: 1, Divide: 2, Power: 2, Sqrt: 1, Abs: 1, Exp: 1, Ln: 1, Log: 1, Sin: 1, Cos: 1, Tan: 1, Arcsin: 1, Arccos: 1, Arctan: 1, Arctan2: 2, Tanh: 1, Min: 2, Max: 2,
    Which: 2, Less: 2, LessEqual: 2, Greater: 2, GreaterEqual: 2, Equal: 2, NotEqual: 2, And: 2, Or: 2, Not: 1
};

// Chained comparisons (0 < x < 1) hold only when every adjacent pair does, matching the engine.
function chainedComparison(symbol, joiner) {
    return (args) => `(${args.slice(1).map((right, index) => `(${args[index]} ${symbol} ${right})`).join(` ${joiner} `)})`;
}

// "Which" is (condition, value) pairs; the last condition is always true once validated, so it
// becomes the final else. Anything else falls through to NaN, which fails the run the same way the
// engine's "no branch matched" error does.
function whichEmitter(conditional, fallback) {
    return (args, nodes) => {
        const lastIsOtherwise = nodes.length >= 2 && nodes[nodes.length - 2].boolean === true;
        const pairs = lastIsOtherwise ? args.length - 2 : args.length;
        let result = lastIsOtherwise ? args[args.length - 1] : fallback;
        for (let index = pairs - 2; index >= 0; index -= 2) result = conditional(args[index], args[index + 1], result);
        return result;
    };
}

export const cppOperators = {
    Add: (args) => (args.length ? `(${args.join(' + ')})` : '0.0'),
    Multiply: (args) => (args.length ? `(${args.join(' * ')})` : '1.0'),
    Negate: (args) => `(-${args[0]})`,
    Divide: (args) => `(${args[0]} / ${args[1]})`,
    Power: (args) => `std::pow(${args[0]}, ${args[1]})`,
    Sqrt: (args) => `std::sqrt(${args[0]})`,
    Abs: (args) => `std::abs(${args[0]})`,
    Exp: (args) => `std::exp(${args[0]})`,
    Ln: (args) => `std::log(${args[0]})`,
    Log: (args) => `std::log(${args[0]})`,
    Sin: (args) => `std::sin(${args[0]})`,
    Cos: (args) => `std::cos(${args[0]})`,
    Tan: (args) => `std::tan(${args[0]})`,
    Arcsin: (args) => `std::asin(${args[0]})`,
    Arccos: (args) => `std::acos(${args[0]})`,
    Arctan: (args) => `std::atan(${args[0]})`,
    Arctan2: (args) => `std::atan2(${args[0]}, ${args[1]})`,
    Tanh: (args) => `std::tanh(${args[0]})`,
    Min: (args) => `std::min(${args[0]}, ${args[1]})`,
    Max: (args) => `std::max(${args[0]}, ${args[1]})`,
    Which: whichEmitter((condition, value, otherwise) => `(${condition} ? ${value} : ${otherwise})`, 'std::nan("")'),
    Less: chainedComparison('<', '&&'),
    LessEqual: chainedComparison('<=', '&&'),
    Greater: chainedComparison('>', '&&'),
    GreaterEqual: chainedComparison('>=', '&&'),
    Equal: chainedComparison('==', '&&'),
    NotEqual: (args) => `(${args[0]} != ${args[1]})`,
    And: (args) => `(${args.join(' && ')})`,
    Or: (args) => `(${args.join(' || ')})`,
    Not: (args) => `(!${args[0]})`,
    True: 'true',
    False: 'false'
};

// math.pow/math.sqrt/math.log raise ValueError on inputs where std::pow/std::sqrt/std::log would
// return NaN (e.g. sqrt of a negative number) instead of propagating a non-finite value the same
// way -- an acceptable, documented divergence (docs/codeExport.md) rather than a wrong-physics
// bug, since both forms fail loudly rather than silently continuing with bad data.
const pythonOperators = {
    Add: (args) => (args.length ? `(${args.join(' + ')})` : '0.0'),
    Multiply: (args) => (args.length ? `(${args.join(' * ')})` : '1.0'),
    Negate: (args) => `(-${args[0]})`,
    Divide: (args) => `(${args[0]} / ${args[1]})`,
    Power: (args) => `math.pow(${args[0]}, ${args[1]})`,
    Sqrt: (args) => `math.sqrt(${args[0]})`,
    Abs: (args) => `abs(${args[0]})`,
    Exp: (args) => `math.exp(${args[0]})`,
    Ln: (args) => `math.log(${args[0]})`,
    Log: (args) => `math.log(${args[0]})`,
    Sin: (args) => `math.sin(${args[0]})`,
    Cos: (args) => `math.cos(${args[0]})`,
    Tan: (args) => `math.tan(${args[0]})`,
    Arcsin: (args) => `math.asin(${args[0]})`,
    Arccos: (args) => `math.acos(${args[0]})`,
    Arctan: (args) => `math.atan(${args[0]})`,
    Arctan2: (args) => `math.atan2(${args[0]}, ${args[1]})`,
    Tanh: (args) => `math.tanh(${args[0]})`,
    Min: (args) => `min(${args[0]}, ${args[1]})`,
    Max: (args) => `max(${args[0]}, ${args[1]})`,
    Which: whichEmitter((condition, value, otherwise) => `(${value} if ${condition} else ${otherwise})`, "float('nan')"),
    Less: chainedComparison('<', 'and'),
    LessEqual: chainedComparison('<=', 'and'),
    Greater: chainedComparison('>', 'and'),
    GreaterEqual: chainedComparison('>=', 'and'),
    Equal: chainedComparison('==', 'and'),
    NotEqual: (args) => `(${args[0]} != ${args[1]})`,
    And: (args) => `(${args.join(' and ')})`,
    Or: (args) => `(${args.join(' or ')})`,
    Not: (args) => `(not ${args[0]})`,
    True: 'True',
    False: 'False'
};

// Always a floating-point literal, in C++ as in Python: "75" would be an int in C++, where 1 / 2 is 0 and std::min(75,
// x) with x a double does not compile. String() already writes a large or small value with an exponent (1e+21), which
// is a double.
export function doubleLiteral(value) {
    if (!Number.isFinite(value)) throw new Error(`Cannot embed a non-finite constant (${value}) in generated code.`);
    if (Object.is(value, -0)) return '-0.0';
    const text = String(value);
    return /[.e]/.test(text) ? text : `${text}.0`;
}

function csvField(value) {
    return /[",\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
}

export function compileExpressionNode(node) {
    if (Array.isArray(node)) {
        const [operator, ...args] = node;
        return { op: operator, args: args.map(compileExpressionNode) };
    }
    const text = String(node);
    if (text === 'True' || text === 'False') return { boolean: text === 'True' };
    return numericLiteralPattern.test(text) ? { literal: Number(text) } : { symbol: text };
}

// A contribution reads the substep's start time; an algebraic term reads the instant of the states it
// is computed from, which the emitted code holds in algebraicTime (see cppAlgebraicLines).
const timeTexts = {
    cpp: { start: 'stepTime', algebraic: 'algebraicTime' },
    python: { start: 'step_time', algebraic: 'algebraic_time' }
};

// A parameter that follows a stored schedule reads it at the instant the engine resolves it: the
// substep's start for a derivative, the algebraic instant for an algebraic term.
const scheduleCalls = {
    cpp: (index, time) => `scheduleValue(${index}, ${timeTexts.cpp[time]})`,
    python: (index, time) => `schedule_value(${index}, ${timeTexts.python[time]})`
};

// The text a symbol entry reads as in `language`: a time, a scheduled parameter's lookup, or its
// fixed text (a literal, a state slot, or an FMU member).
export function symbolText(value, language) {
    if (value.time) return timeTexts[language][value.time];
    if (value.schedule !== undefined) return scheduleCalls[language](value.schedule, value.scheduleTime);
    return value.text;
}

export function symbolTexts(symbols, language) {
    return new Map(Array.from(symbols, ([key, value]) => [key, symbolText(value, language)]));
}

export function emitExpression(node, symbols, operators) {
    if ('literal' in node) return doubleLiteral(node.literal);
    if ('boolean' in node) return operators[node.boolean ? 'True' : 'False'];
    if ('symbol' in node) {
        const resolved = symbols.get(node.symbol);
        if (!resolved) throw new Error(`Unknown executable symbol: ${node.symbol}.`);
        return resolved;
    }
    const emitter = operators[node.op];
    if (!emitter) throw new Error(`Unsupported executable operation: ${node.op}.`);
    const minimum = minimumArgumentCounts[node.op] ?? 0;
    if (node.args.length < minimum) throw new Error(`An expression is missing an argument for ${node.op}.`);
    return emitter(node.args.map((argument) => emitExpression(argument, symbols, operators)), node.args);
}

// ---- graph build: mirrors engine/src/executionPlan.cpp's compileExecutionPlan exactly enough to
// reproduce its numerics, without needing any of its parallel-execution/checkpoint machinery. ----

export function buildModel(sourceDocument) {
    // Standalone programs have no runtime notion of sharing: bake each link to its shared value.
    const document = resolveSharedParameters(sourceDocument);
    const enabledNodes = (document.nodes ?? []).filter((node) => node.enabled !== false);
    const disabledNodeIds = new Set((document.nodes ?? []).filter((node) => node.enabled === false).map((node) => node.id));
    const stateOwnerNodeId = new Map();
    const stateRecord = new Map();
    let globalIndex = 0;
    for (const node of enabledNodes) {
        node.states.forEach((state, localIndex) => {
            stateOwnerNodeId.set(state.id, node.id);
            stateRecord.set(state.id, { node, state, globalIndex, localIndex });
            globalIndex += 1;
        });
    }
    const nodeById = new Map(enabledNodes.map((node) => [node.id, node]));
    const nodePlans = enabledNodes.map((node) => ({
        node,
        localIndexByStateId: new Map(node.states.map((state, index) => [state.id, index])),
        substeps: node.numerics?.substepsPerGlobalStep ?? 1,
        contributions: [],
        // setsValue source terms: recomputed and written directly at the start of every substep,
        // never integrated (see applyAlgebraicTasks in engine/src/executionPlan.cpp).
        algebraic: [],
        nodeProvider: null
    }));
    const nodePlanById = new Map(nodePlans.map((plan) => [plan.node.id, plan]));
    // Stored parameter schedules, one table per shared parameter however many parameters link to it.
    const schedules = { list: [], byKey: new Map() };

    for (const plan of nodePlans) {
        for (const term of plan.node.sourceTerms ?? []) {
            const programmable = term.implementation != null;
            (term.setsValue === true ? plan.algebraic : plan.contributions).push(buildContribution({
                entityLabel: `source term on node "${plan.node.name}"`, ownerPlan: plan, alwaysLocal: true,
                algebraic: term.setsValue === true,
                bindings: programmable ? term.implementation.bindings : term.expressionModel.bindings,
                outputStateId: programmable ? term.implementation.output.stateId : term.expressionModel.output.stateId,
                mathJson: programmable ? null : term.expressionModel.mathJson,
                implementation: term.implementation ?? null,
                negate: false,
                parameters: term.parameters ?? [],
                identifierField: programmable ? 'key' : 'symbol'
            }, stateRecord, schedules));
        }
        plan.algebraic = orderAlgebraicTasks(plan);
        if (plan.node.implementation) plan.nodeProvider = buildNodeProvider(plan, stateRecord, schedules);
    }

    for (const node of enabledNodes) {
        if (node.numerics?.integration === 'semiImplicit') {
            throw new Error(`Node "${node.name}" is integrated semi-implicitly, which code export cannot write yet.`);
        }
    }
    for (const edge of document.edges ?? []) {
        if (edge.enabled === false) continue;
        if (Array.isArray(edge.equationModel?.outputs)) {
            throw new Error(`Relationship "${edge.name}" sets several states with its equations, which code export cannot write yet.`);
        }
        if (disabledNodeIds.has(edge.source.nodeId) || disabledNodeIds.has(edge.target.nodeId)) continue;
        const programmable = edge.implementation != null;
        const outputRole = programmable ? edge.implementation.output.role : edge.equationModel.output.role;
        const outputStateId = programmable ? edge.implementation.output.stateId : edge.equationModel.output.stateId;
        const outputPlan = nodePlanById.get(stateOwnerNodeId.get(outputStateId));
        const bindings = programmable ? edge.implementation.bindings : edge.equationModel.bindings;
        const mathJson = programmable ? null : edge.equationModel.mathJson;
        const identifierField = programmable ? 'key' : 'symbol';
        if (outputPlan) {
            outputPlan.contributions.push(buildContribution({
                entityLabel: `relationship "${edge.name}"`, ownerPlan: outputPlan, alwaysLocal: false,
                bindings, outputStateId, mathJson, implementation: edge.implementation ?? null, negate: false,
                parameters: edge.parameters ?? [], identifierField
            }, stateRecord, schedules));
        }
        if (edge.directionality === 'bidirectional') {
            const otherNodeId = outputRole === 'target' ? edge.source.nodeId : edge.target.nodeId;
            const otherNode = nodeById.get(otherNodeId);
            const otherPlan = nodePlanById.get(otherNodeId);
            if (otherNode && otherPlan) {
                const otherEndpoint = outputRole === 'target' ? edge.source : edge.target;
                let otherStateId = otherEndpoint?.stateId;
                if (otherStateId == null || !otherNode.states.some((state) => state.id === otherStateId)) {
                    otherStateId = otherNode.states[0]?.id;
                }
                if (otherStateId == null) throw new Error(`Bidirectional relationship "${edge.name}" has an endpoint with no states.`);
                otherPlan.contributions.push(buildContribution({
                    entityLabel: `relationship "${edge.name}"`, ownerPlan: otherPlan, alwaysLocal: false,
                    bindings, outputStateId: otherStateId, mathJson, implementation: edge.implementation ?? null, negate: true,
                    parameters: edge.parameters ?? [], identifierField
                }, stateRecord, schedules));
            }
        }
    }

    return { nodePlans, globalStateCount: globalIndex, stateRecord, schedules: schedules.list };
}

// Same order as the engine: an algebraic state bound by another algebraic term is computed first.
function mathJsonSymbols(expression, symbols = new Set()) {
    if (Array.isArray(expression)) expression.slice(1).forEach((argument) => mathJsonSymbols(argument, symbols));
    else if (typeof expression === 'string' && !['True', 'False'].includes(expression) && !Number.isFinite(Number(expression))) symbols.add(expression);
    return symbols;
}

function orderAlgebraicTasks(plan) {
    const byOutput = new Map(plan.algebraic.map((task) => [task.outputStateId, task]));
    const ordered = [];
    const visiting = new Set();
    const done = new Set();
    const visit = (task) => {
        if (done.has(task)) return;
        if (visiting.has(task)) throw new Error(`Algebraic (setsValue) source terms on node "${plan.node.name}" depend on each other in a cycle.`);
        visiting.add(task);
        for (const stateId of task.boundStateIds) {
            const dependency = byOutput.get(stateId);
            if (dependency && dependency !== task) visit(dependency);
        }
        visiting.delete(task);
        done.add(task);
        ordered.push(task);
    };
    plan.algebraic.forEach(visit);
    return ordered;
}

// A parameter's stored schedule as a table: { hold, times, values }, checked as the engine checks it.
function compileStoredSchedule(parameter) {
    const { interpolation = 'linear', samples } = parameter.schedule;
    if (interpolation !== 'linear' && interpolation !== 'hold') throw new Error(`Parameter "${parameter.name ?? parameter.symbol}" has a schedule whose interpolation is neither linear nor hold.`);
    if (!Array.isArray(samples) || !samples.length) throw new Error(`Parameter "${parameter.name ?? parameter.symbol}" has a schedule with no samples.`);
    const times = [];
    const values = [];
    for (const sample of samples) {
        if (!Array.isArray(sample) || sample.length !== 2 || !sample.every(Number.isFinite) || (times.length && !(sample[0] > times.at(-1)))) {
            throw new Error(`Parameter "${parameter.name ?? parameter.symbol}" has a schedule whose samples are not finite [time, value] pairs in increasing time.`);
        }
        times.push(sample[0]);
        values.push(sample[1]);
    }
    return { hold: interpolation === 'hold', times, values, label: parameter.symbol };
}

// The lookup the engine's evaluateParameterSchedule() performs (executionPlan.cpp): edge-held
// outside the samples, then held or linearly interpolated, found by binary search.
export function cppScheduleLines(model) {
    if (!model.schedules.length) return '';
    const tables = model.schedules.map((schedule, index) => [
        `// ${schedule.label}: ${schedule.times.length} samples, ${schedule.hold ? 'held' : 'linear'}`,
        `const double scheduleTimes${index}[] = { ${schedule.times.map(doubleLiteral).join(', ')} };`,
        `const double scheduleValues${index}[] = { ${schedule.values.map(doubleLiteral).join(', ')} };`
    ].join('\n'));
    return [
        '// Stored parameter schedules (sharedParameters[].schedule): the parameter follows these samples over time.',
        'struct ParameterScheduleTable { const double* times; const double* values; std::size_t count; bool hold; };',
        ...tables,
        `const ParameterScheduleTable parameterSchedules[] = { ${model.schedules.map((schedule, index) => `{ scheduleTimes${index}, scheduleValues${index}, ${schedule.times.length}, ${schedule.hold} }`).join(', ')} };`,
        'inline double scheduleValue(std::size_t index, double time) {',
        '    const ParameterScheduleTable& schedule = parameterSchedules[index];',
        '    if (time <= schedule.times[0]) return schedule.values[0];',
        '    if (time >= schedule.times[schedule.count - 1]) return schedule.values[schedule.count - 1];',
        '    const std::size_t upper = static_cast<std::size_t>(std::upper_bound(schedule.times, schedule.times + schedule.count, time) - schedule.times);',
        '    if (schedule.hold) return schedule.values[upper - 1];',
        '    const double fraction = (time - schedule.times[upper - 1]) / (schedule.times[upper] - schedule.times[upper - 1]);',
        '    return schedule.values[upper - 1] + fraction * (schedule.values[upper] - schedule.values[upper - 1]);',
        '}',
        ''
    ].join('\n');
}

function pythonScheduleLines(model) {
    if (!model.schedules.length) return '';
    const literal = (value) => (Number.isInteger(value) ? `${value}.0` : doubleLiteral(value));
    return [
        '# Stored parameter schedules (sharedParameters[].schedule): the parameter follows these samples over time.',
        'PARAMETER_SCHEDULES = [',
        ...model.schedules.map((schedule) => `    (${schedule.hold ? 'True' : 'False'}, [${schedule.times.map(literal).join(', ')}], [${schedule.values.map(literal).join(', ')}]),  # ${schedule.label}`),
        ']',
        '',
        '',
        'def schedule_value(index, time):',
        '    hold, times, values = PARAMETER_SCHEDULES[index]',
        '    if time <= times[0]:',
        '        return values[0]',
        '    if time >= times[-1]:',
        '        return values[-1]',
        '    upper = bisect.bisect_right(times, time)',
        '    if hold:',
        '        return values[upper - 1]',
        '    fraction = (time - times[upper - 1]) / (times[upper] - times[upper - 1])',
        '    return values[upper - 1] + fraction * (values[upper] - values[upper - 1])',
        '',
        ''
    ].join('\n');
}

// A parameter's symbol entry: its value, or, when it follows a stored schedule, a lookup of that schedule at `time`
// ('start' of the substep, or 'algebraic' for a setsValue term's instant). `parameter` is also exposed on the entry
// (beyond text/comment) so a caller that cares about liveness -- fmiCodeGen.mjs, which exposes a live parameter as a
// real FMI input rather than baking it, unlike this module's own C++/Python export -- can tell without re-deriving
// the binding. Existing callers only read text/comment.
function parameterSymbol(parameter, time, schedules) {
    if (parameter.schedule) {
        const scheduleKey = parameter.scheduleKey ?? `parameter:${parameter.id}`;
        if (!schedules.byKey.has(scheduleKey)) {
            schedules.byKey.set(scheduleKey, schedules.list.length);
            schedules.list.push(compileStoredSchedule(parameter));
        }
        const schedule = schedules.byKey.get(scheduleKey);
        // `text` is the C++ form, read directly by provider input lists; symbolText() gives either language.
        return { schedule, scheduleTime: time, text: scheduleCalls.cpp(schedule, time), comment: `${parameter.symbol} (follows a schedule)`, parameter };
    }
    return { text: doubleLiteral(parameter.value), comment: parameter.symbol, parameter };
}

function buildContribution(spec, stateRecord, schedules) {
    const { entityLabel, ownerPlan, alwaysLocal, algebraic = false, bindings, outputStateId, mathJson, implementation, negate, parameters, identifierField } = spec;
    const outputLocalIndex = ownerPlan.localIndexByStateId.get(outputStateId);
    if (outputLocalIndex === undefined) throw new Error(`The ${entityLabel} targets a state that is not on its own node.`);
    const symbols = new Map();
    for (const binding of bindings ?? []) {
        const key = binding[identifierField];
        if (binding.kind === 'time') {
            // Language-specific, resolved by symbolTexts(): substep start for a derivative, end
            // for an algebraic term -- the same instants the engine uses.
            symbols.set(key, { time: algebraic ? 'algebraic' : 'start', comment: 'simulation time' });
            continue;
        }
        if (binding.kind === 'parameter') {
            const parameter = (parameters ?? []).find((item) => item.id === binding.parameterId);
            if (!parameter) throw new Error(`The ${entityLabel} has an unresolved parameter binding.`);
            symbols.set(key, parameterSymbol(parameter, algebraic ? 'algebraic' : 'start', schedules));
        } else {
            const record = stateRecord.get(binding.stateId);
            if (!record) throw new Error(`The ${entityLabel} references a disabled or missing state.`);
            const isLocal = alwaysLocal || binding.nodeId === ownerPlan.node.id;
            symbols.set(key, isLocal
                ? { text: `state[${ownerPlan.localIndexByStateId.get(binding.stateId)}]`, comment: `${ownerPlan.node.name}.${record.state.name}` }
                : { text: `snapshot[${record.globalIndex}]`, comment: `${record.node.name}.${record.state.name}` });
        }
    }
    // A provider may read any state it binds; an equation only the ones it uses (the node editor
    // binds all of a node's states to each source term).
    const used = implementation ? null : mathJsonSymbols(mathJson);
    const boundStateIds = (bindings ?? [])
        .filter((binding) => (binding.kind === 'state' || binding.kind === undefined) && (!used || used.has(binding[identifierField])))
        .map((binding) => binding.stateId);
    return { entityLabel, outputStateId, outputLocalIndex, negate, symbols, mathJson, implementation, boundStateIds };
}

function buildNodeProvider(plan, stateRecord, schedules) {
    const implementation = plan.node.implementation;
    const symbols = new Map();
    for (const binding of implementation.bindings ?? []) {
        // A shared parameter, baked into the binding by resolveSharedParameters, read at the substep's start.
        if (binding.kind === 'parameter') {
            if (!binding.parameter) throw new Error(`The computational-node provider on node "${plan.node.name}" binds a parameter that is not a shared one.`);
            symbols.set(binding.key, parameterSymbol(binding.parameter, 'start', schedules));
            continue;
        }
        const record = stateRecord.get(binding.stateId);
        if (!record) throw new Error(`The computational-node provider on node "${plan.node.name}" references a disabled or missing state.`);
        // Its own node's state as the node advances, another node's from the step's snapshot, as the engine reads them.
        const localIndex = plan.localIndexByStateId.get(binding.stateId);
        symbols.set(binding.key, localIndex !== undefined
            ? { text: `state[${localIndex}]`, comment: `${plan.node.name}.${record.state.name}` }
            : { text: `snapshot[${record.globalIndex}]`, comment: `${record.node.name}.${record.state.name}` });
    }
    const outputs = (implementation.outputs ?? []).map((output) => {
        const localIndex = plan.localIndexByStateId.get(output.stateId);
        if (localIndex === undefined) throw new Error(`A computational-node provider output on node "${plan.node.name}" targets a state not on this node.`);
        return { key: output.key, localIndex, setsValue: output.setsValue === true };
    });
    return { entityLabel: `computational-node provider on node "${plan.node.name}"`, implementation, symbols, outputs };
}

// ---- provider blocking + registry: validates every provider-bearing entity up front (no partial
// output is ever emitted) and assigns each a stable, collision-free instance name. ----

export function collectProviders(model, kind) {
    const providers = [];
    const visit = (owner) => {
        if (!owner.implementation) return;
        const providerKind = owner.implementation.kind;
        if (providerKind === 'plugin') {
            throw new Error(`The ${owner.entityLabel} references an installed plugin provider, which has no embeddable source -- export cannot include it.`);
        }
        if (providerKind !== 'cpp' && providerKind !== 'python') {
            throw new Error(`The ${owner.entityLabel} has an unrecognized provider kind "${providerKind}".`);
        }
        if (providerKind !== kind) {
            throw new Error(`The ${owner.entityLabel} is implemented in ${providerKind === 'cpp' ? 'C++' : 'Python'}, but export to ${kind === 'cpp' ? 'C++' : 'Python'} was requested -- export blocked. Provider source is never auto-translated between languages.`);
        }
        providers.push(owner);
    };
    for (const plan of model.nodePlans) {
        for (const contribution of [...plan.algebraic, ...plan.contributions]) visit(contribution);
        if (plan.nodeProvider) {
            if (kind === 'cpp') throw new Error(`The computational-node provider on node "${plan.node.name}" has no C++ equivalent in the engine -- export to C++ is blocked for this model.`);
            visit(plan.nodeProvider);
        }
    }
    return providers;
}

export function stripLeadingCppInclude(source) {
    return source.replace(/^#include\s*<konjugate\/relationshipProvider\.hpp>\s*\n/, '');
}

function pythonProviderClassName(source, entityLabel) {
    const match = source.match(/^class\s+(\w+)\s*\(\s*(RelationshipProvider|NodeProvider)\s*\)\s*:/m);
    if (!match) throw new Error(`Could not find a class implementing RelationshipProvider or NodeProvider in the provider source for the ${entityLabel}.`);
    return { className: match[1], baseClassName: match[2], pattern: new RegExp(`\\bclass\\s+${match[1]}\\s*\\(`) };
}

const parallelismModes = ['serial', 'openmp', 'stdThread', 'mpi'];

export function generateStandaloneProgram(document, kind, options = {}) {
    if (kind !== 'cpp' && kind !== 'python') throw new Error(`Unknown export kind "${kind}" -- expected "cpp" or "python".`);
    const parallelism = options.parallelism ?? 'serial';
    if (!parallelismModes.includes(parallelism)) {
        throw new Error(`Unknown parallelism option "${parallelism}" -- expected one of ${parallelismModes.join(', ')}.`);
    }
    if (kind === 'python' && parallelism !== 'serial' && parallelism !== 'mpi') {
        throw new Error(`"${parallelism}" has no meaningful Python equivalent -- Python threads are GIL-bound and would not actually run this CPU-bound loop in parallel. Only "serial" and "mpi" are available for a Python export.`);
    }
    const model = buildModel(document);
    const providers = collectProviders(model, kind);
    const runConfiguration = (document.runConfigurations ?? []).find((item) => item.id === document.activeRunConfigurationId) ?? document.runConfigurations?.[0];
    const globalTimeStep = runConfiguration?.globalTimeStep ?? 0.01;
    const outputInterval = runConfiguration?.outputInterval ?? globalTimeStep;
    const meta = { globalTimeStep, outputInterval, defaultTargetTime: document.exportDefaultTargetTime ?? 1, parallelism };
    return kind === 'cpp' ? generateCpp(model, providers, meta, document) : generatePython(model, providers, meta, document);
}

// A Python string literal's contents for `text`, in ASCII alone: every other character as a \u or \U escape, which
// Python reads back as the character itself, so what the program writes is unchanged. The header names every state on
// one line, and Python 3.9 (still the system Python on macOS) refuses a source line of several thousand bytes with a
// non-ASCII character in it ("Non-UTF-8 code"), which every header has: the dash between a node's name and a state's.
function pythonStringContents(text) {
    return [...text.replace(/\\/g, '\\\\').replace(/"/g, '\\"')].map((character) => {
        const code = character.codePointAt(0);
        if (code < 0x80) return character;
        return code > 0xffff ? `\\U${code.toString(16).padStart(8, '0')}` : `\\u${code.toString(16).padStart(4, '0')}`;
    }).join('');
}

function csvHeader(model) {
    const columns = ['time (s)'];
    for (const plan of model.nodePlans) {
        for (const state of plan.node.states) columns.push(`${plan.node.name} — ${state.name}${state.unit ? ` (${state.unit})` : ''}`);
    }
    return columns.map(csvField).join(',');
}

function stateIndexComment(model, commentPrefix) {
    const lines = [];
    let index = 0;
    for (const plan of model.nodePlans) {
        for (const state of plan.node.states) {
            lines.push(`${commentPrefix} snapshot[${index}] / globalState[${index}] = ${plan.node.name}.${state.name}${state.unit ? ` (${state.unit})` : ''}`);
            index += 1;
        }
    }
    return lines.join('\n');
}

function cppRunInstructionLines(parallelism, marker) {
    if (parallelism === 'openmp') {
        return [
            `${marker}How to run this program (OpenMP -- parallel across nodes on one machine):`,
            `${marker}  1. Compile it:`,
            `${marker}       Linux:   c++ -std=c++20 -O2 -fopenmp <this file> -o simulation`,
            `${marker}       macOS:   Xcode's clang++ has no bundled OpenMP -- run "brew install libomp"`,
            `${marker}                once, then (libomp is keg-only, so -I/-L must point at it explicitly):`,
            `${marker}                c++ -std=c++20 -O2 -Xpreprocessor -fopenmp \\`,
            `${marker}                    -I"$(brew --prefix libomp)/include" -L"$(brew --prefix libomp)/lib" -lomp \\`,
            `${marker}                    <this file> -o simulation`,
            `${marker}       Windows: cl /std:c++20 /O2 /openmp <this file>`,
            `${marker}  2. Run it (OMP_NUM_THREADS controls the worker count, e.g. OMP_NUM_THREADS=4):`,
            `${marker}       macOS/Linux: ./simulation`,
            `${marker}       Windows:     simulation.exe`
        ];
    }
    if (parallelism === 'stdThread') {
        return [
            `${marker}How to run this program (std::thread -- parallel across nodes on one machine):`,
            `${marker}  1. Compile it:`,
            `${marker}       macOS/Linux: c++ -std=c++20 -O2 -pthread <this file> -o simulation`,
            `${marker}       Windows (Developer Command Prompt for VS): cl /std:c++20 /O2 <this file>`,
            `${marker}  2. Run it:`,
            `${marker}       macOS/Linux: ./simulation`,
            `${marker}       Windows:     simulation.exe`
        ];
    }
    if (parallelism === 'mpi') {
        return [
            `${marker}How to run this program (MPI -- distributed across ranks/machines):`,
            `${marker}  Needs an MPI implementation installed (e.g. OpenMPI or MPICH).`,
            `${marker}  1. Compile it:  mpic++ -std=c++20 -O2 <this file> -o simulation`,
            `${marker}  2. Run it with the desired number of ranks: mpirun -n 4 ./simulation`,
            `${marker}  Nodes are split into contiguous blocks across ranks by node count, not by`,
            `${marker}  estimated work -- a simple partition, unlike the engine's own METIS/`,
            `${marker}  communication-aware partitioner. Only rank 0 writes the output file.`
        ];
    }
    return [
        `${marker}How to run this program:`,
        `${marker}  1. Compile it:`,
        `${marker}       macOS/Linux (clang or gcc): c++ -std=c++20 -O2 <this file> -o simulation`,
        `${marker}       Windows (Developer Command Prompt for VS): cl /std:c++20 /O2 <this file>`,
        `${marker}  2. Run it:`,
        `${marker}       macOS/Linux: ./simulation`,
        `${marker}       Windows:     simulation.exe`
    ];
}

function pythonRunInstructionLines(parallelism, marker) {
    if (parallelism === 'mpi') {
        return [
            `${marker}How to run this program (MPI -- distributed across ranks/machines):`,
            `${marker}  Needs mpi4py ("pip install mpi4py") and a system MPI implementation (e.g.`,
            `${marker}  OpenMPI or MPICH) -- mpi4py links against whichever MPI your "mpirun" points to.`,
            `${marker}  Run it with the desired number of ranks: mpirun -n 4 python3 <this file>`,
            `${marker}  Nodes are split into contiguous blocks across ranks by node count, not by`,
            `${marker}  estimated work -- a simple partition, unlike the engine's own METIS/`,
            `${marker}  communication-aware partitioner. Only rank 0 writes the output file.`
        ];
    }
    return [
        `${marker}How to run this program:`,
        `${marker}  macOS/Linux: python3 <this file>`,
        `${marker}  Windows:     python <this file>`
    ];
}

function runInstructions(kind, meta, marker) {
    const lines = kind === 'cpp' ? cppRunInstructionLines(meta.parallelism ?? 'serial', marker) : pythonRunInstructionLines(meta.parallelism ?? 'serial', marker);
    lines.push(
        `${marker}Optional flags on either platform: --target-time <seconds> (default ${doubleLiteral(meta.defaultTargetTime)}), --output <path> (default results.csv)`
    );
    return lines.join('\n');
}

function initialStateLiterals(model) {
    return Array.from(model.stateRecord.values()).map((record) => doubleLiteral(record.state.initialValue ?? 0)).join(', ');
}

// Prefix sums of per-node state counts, e.g. node state counts [1, 2, 1] -> [0, 1, 3, 4]: node i
// owns global state indices [offsets[i], offsets[i + 1]). Only used by MPI's dispatch, where it is
// what makes a single contiguous-block partition (by node order) correspond to a contiguous
// global-state-index range per rank, which is what lets one MPI_Allgatherv reconcile the whole
// state vector each step instead of needing an indexed/scattered exchange.
function nodeStateOffsetLiterals(model) {
    const offsets = [0];
    let running = 0;
    for (const plan of model.nodePlans) {
        running += plan.node.states.length;
        offsets.push(running);
    }
    return offsets.join(', ');
}

function commentLines(symbols, prefix, marker) {
    return Array.from(symbols, ([key, value]) => `${prefix}${marker} ${key} <- ${value.comment}`);
}

// ---- C++ ----

export function emitCppRegularContribution(contribution) {
    const expression = emitExpression(compileExpressionNode(contribution.mathJson), symbolTexts(contribution.symbols, 'cpp'), cppOperators);
    return [
        '        {',
        ...commentLines(contribution.symbols, '            ', '//'),
        `            double contributionValue = ${expression};`,
        contribution.negate ? '            contributionValue = -contributionValue;' : '',
        '            if (!std::isfinite(contributionValue)) throw std::runtime_error("A contribution produced a non-finite derivative.");',
        `            derivative[${contribution.outputLocalIndex}] += contributionValue;`,
        '        }'
    ].filter(Boolean).join('\n');
}

// An algebraic state is a plain replacement: g(x, t) from the node's states at one instant.
export function emitCppAlgebraicTask(task, info) {
    const lines = ['        {', ...commentLines(task.symbols, '            ', '//')];
    if (task.implementation) {
        const keys = Array.from(task.symbols.keys());
        const values = keys.map((key) => task.symbols.get(key).text).join(', ') || '0.0';
        const keyLiterals = keys.map((key) => `std::string_view("${key}")`).join(', ') || 'std::string_view("")';
        lines.push(
            `            const double inputValues[] = { ${values} };`,
            `            const std::string_view inputKeys[] = { ${keyLiterals} };`,
            '            konjugate::sdk::v1::OutputCollector outputCollector;',
            `            ${info.instanceVariable}->evaluate({algebraicTime, nodeTimeStep, konjugate::sdk::v1::InputView(inputValues, inputKeys)}, outputCollector);`,
            '            const double algebraicValue = outputCollector.gradient();'
        );
    } else {
        lines.push(`            const double algebraicValue = ${emitExpression(compileExpressionNode(task.mathJson), symbolTexts(task.symbols, 'cpp'), cppOperators)};`);
    }
    lines.push(
        '            if (!std::isfinite(algebraicValue)) throw std::runtime_error("An algebraic source term produced a non-finite value.");',
        `            state[${task.outputLocalIndex}] = algebraicValue;`,
        '        }'
    );
    return lines.join('\n');
}

// The engine computes a node's algebraic states twice: at the start of every substep, before its
// derivatives, and once more after the last update, so what the node hands back (and other nodes
// read next step) agrees with its states. `where` picks which; both set algebraicTime to the instant
// the states represent.
export function cppAlgebraicLines(plan, providerInfo, where = 'substep') {
    if (!plan.algebraic.length) return '';
    const tasks = plan.algebraic.map((task) => emitCppAlgebraicTask(task, providerInfo.get(task))).join('\n');
    if (where === 'substep') return ['        {', '            const double algebraicTime = stepTime;', tasks, '        }'].join('\n');
    return ['        {', '            // After the last update: the value handed back with the states.', '            const double algebraicTime = currentTime + globalTimeStep;', tasks, '        }'].join('\n');
}

// Before the first step the engine computes every algebraic state once from the initial states, so
// the first row (and what other nodes read in step 0) agrees with the other initial values, even
// when a parameter it uses was edited after the stored initial value was written.
function cppSettleLines(model, providerInfo) {
    const blocks = model.nodePlans.filter((plan) => plan.algebraic.length).map((plan) => {
        const seed = plan.node.states.map((state) => `globalState[${model.stateRecord.get(state.id).globalIndex}]`).join(', ');
        const commitLines = plan.node.states.map((state, index) => (
            `        globalState[${model.stateRecord.get(state.id).globalIndex}] = state[${index}];`
        )).join('\n');
        return [
            `    // Settle algebraic states: ${plan.node.name}`,
            '    {',
            '        const std::vector<double>& snapshot = globalState;',
            `        double state[${plan.node.states.length}] = { ${seed} };`,
            `        const double nodeTimeStep = globalTimeStep / ${plan.substeps}.0;`,
            '        const double algebraicTime = 0.0;',
            plan.algebraic.map((task) => emitCppAlgebraicTask(task, providerInfo.get(task))).join('\n'),
            commitLines,
            '    }'
        ].join('\n');
    });
    return blocks.length ? blocks.join('\n') : null;
}

export function emitCppProviderContribution(contribution, info) {
    const keys = Array.from(contribution.symbols.keys());
    const values = keys.map((key) => contribution.symbols.get(key).text).join(', ') || '0.0';
    const keyLiterals = keys.map((key) => `std::string_view("${key}")`).join(', ') || 'std::string_view("")';
    return [
        '        {',
        ...commentLines(contribution.symbols, '            ', '//'),
        `            const double inputValues[] = { ${values} };`,
        `            const std::string_view inputKeys[] = { ${keyLiterals} };`,
        '            konjugate::sdk::v1::OutputCollector outputCollector;',
        `            ${info.instanceVariable}->evaluate({stepTime, nodeTimeStep, konjugate::sdk::v1::InputView(inputValues, inputKeys)}, outputCollector);`,
        '            double contributionValue = outputCollector.gradient();',
        contribution.negate ? '            contributionValue = -contributionValue;' : '',
        '            if (!std::isfinite(contributionValue)) throw std::runtime_error("A contribution produced a non-finite derivative.");',
        `            derivative[${contribution.outputLocalIndex}] += contributionValue;`,
        '        }'
    ].filter(Boolean).join('\n');
}

// Every parallelism mode calls the same per-node lambda body -- only how (and which subset of)
// nodes get called differs. Correctness relies on each lambda touching disjoint globalState
// indices (confirmed: a node's commit lines only ever write its own states' global indices), so
// running them concurrently (openmp/stdThread) or on separate processes (mpi) needs no locking.
function cppNodeIntegratorLambdas(model, providerInfo) {
    return model.nodePlans.map((plan, nodeIndex) => {
        const stateCount = plan.node.states.length;
        const seed = plan.node.states.map((state) => `snapshot[${model.stateRecord.get(state.id).globalIndex}]`).join(', ');
        const contributionLines = plan.contributions.map((contribution) => (
            contribution.implementation
                ? emitCppProviderContribution(contribution, providerInfo.get(contribution))
                : emitCppRegularContribution(contribution)
        )).join('\n');
        const commitLines = plan.node.states.map((state, index) => (
            `        globalState[${model.stateRecord.get(state.id).globalIndex}] = state[${index}];`
        )).join('\n');
        return [
            `    // Node: ${plan.node.name}`,
            `    const auto integrateNode${nodeIndex} = [&]() {`,
            `        double state[${stateCount}] = { ${seed} };`,
            `        const double nodeTimeStep = globalTimeStep / ${plan.substeps}.0;`,
            `        for (int substep = 0; substep < ${plan.substeps}; ++substep) {`,
            '            const double stepTime = currentTime + substep * nodeTimeStep;',
            cppAlgebraicLines(plan, providerInfo),
            `            double derivative[${stateCount}] = {};`,
            contributionLines,
            `            for (int index = 0; index < ${stateCount}; ++index) state[index] += nodeTimeStep * derivative[index];`,
            '        }',
            cppAlgebraicLines(plan, providerInfo, 'end'),
            commitLines,
            '    };'
        ].join('\n');
    }).join('\n');
}

function cppDispatchLines(parallelism) {
    if (parallelism === 'openmp') {
        return [
            '        #pragma omp parallel for',
            '        for (int nodeIndex = 0; nodeIndex < nodeCount; ++nodeIndex) nodeIntegrators[static_cast<std::size_t>(nodeIndex)]();'
        ];
    }
    if (parallelism === 'stdThread') {
        return [
            '        // Spawns and joins a thread per node every step -- the simplest correct approach.',
            '        // A persistent worker pool would avoid the repeated spawn cost; left as a possible',
            '        // follow-up rather than obscuring the reference logic here.',
            '        std::vector<std::thread> workers;',
            '        workers.reserve(nodeIntegrators.size());',
            '        for (const auto& integrate : nodeIntegrators) workers.emplace_back(integrate);',
            '        for (auto& worker : workers) worker.join();'
        ];
    }
    if (parallelism === 'mpi') {
        return [
            '        for (int nodeIndex = myNodeStart; nodeIndex < myNodeEnd; ++nodeIndex) nodeIntegrators[static_cast<std::size_t>(nodeIndex)]();',
            '        MPI_Allgatherv(MPI_IN_PLACE, 0, MPI_DATATYPE_NULL, globalState.data(), recvCounts.data(), displacements.data(), MPI_DOUBLE, MPI_COMM_WORLD);'
        ];
    }
    return ['        for (const auto& integrate : nodeIntegrators) integrate();'];
}

// Splits nodes into contiguous, evenly-sized-by-node-count blocks across MPI ranks, computed at
// runtime since the rank count is an `mpirun -n` choice, not known at generation time. Contiguous
// blocks mean each rank's owned states are also one contiguous global-index range (global indices
// are assigned in node order), which is what lets one MPI_Allgatherv reconcile the full state
// vector -- every rank derives the same recvCounts/displacements independently, no extra
// coordination message needed.
function mpiSetupLines(model) {
    return [
        '    int worldRank = 0;',
        '    int worldSize = 1;',
        '    MPI_Comm_rank(MPI_COMM_WORLD, &worldRank);',
        '    MPI_Comm_size(MPI_COMM_WORLD, &worldSize);',
        `    constexpr std::size_t nodeStateOffsets[] = { ${nodeStateOffsetLiterals(model)} };`,
        '    const int nodesPerRank = (nodeCount + worldSize - 1) / worldSize;',
        '    const int myNodeStart = std::min(worldRank * nodesPerRank, nodeCount);',
        '    const int myNodeEnd = std::min(myNodeStart + nodesPerRank, nodeCount);',
        '    std::vector<int> recvCounts(static_cast<std::size_t>(worldSize));',
        '    std::vector<int> displacements(static_cast<std::size_t>(worldSize));',
        '    for (int rank = 0; rank < worldSize; ++rank) {',
        '        const int rankNodeStart = std::min(rank * nodesPerRank, nodeCount);',
        '        const int rankNodeEnd = std::min(rankNodeStart + nodesPerRank, nodeCount);',
        '        displacements[static_cast<std::size_t>(rank)] = static_cast<int>(nodeStateOffsets[static_cast<std::size_t>(rankNodeStart)]);',
        '        recvCounts[static_cast<std::size_t>(rank)] = static_cast<int>(nodeStateOffsets[static_cast<std::size_t>(rankNodeEnd)] - nodeStateOffsets[static_cast<std::size_t>(rankNodeStart)]);',
        '    }'
    ].join('\n');
}

function generateCpp(model, providers, meta, document) {
    // collectProviders already rejects any node-level computational provider before this function
    // is ever reached (there is no C++ equivalent in the engine), so every entry here is an
    // ordinary single-output relationship/source-term provider.
    let providerIndex = 0;
    const providerInfo = new Map();
    const providerBlocks = providers.map((provider) => {
        const namespaceName = `provider${providerIndex}`;
        providerIndex += 1;
        providerInfo.set(provider, { namespaceName, instanceVariable: `${namespaceName}Instance` });
        return `namespace ${namespaceName} {\n${stripLeadingCppInclude(provider.implementation.source)}\n}\n`;
    });

    const isMpi = meta.parallelism === 'mpi';
    const nodeCount = model.nodePlans.length;
    const nodeLambdas = cppNodeIntegratorLambdas(model, providerInfo);
    const nodeIntegratorList = model.nodePlans.map((_plan, nodeIndex) => `integrateNode${nodeIndex}`).join(', ');
    const dispatchLines = cppDispatchLines(meta.parallelism);

    const providerDeclarations = providers.map((provider) => {
        const info = providerInfo.get(provider);
        return `    auto ${info.instanceVariable} = ${info.namespaceName}::createRelationshipProvider();\n    ${info.instanceVariable}->initialize({});`;
    }).join('\n');

    const includes = [
        '#include <algorithm>',
        '#include <cmath>',
        '#include <cstddef>',
        '#include <fstream>',
        '#include <functional>',
        '#include <iomanip>',
        '#include <iostream>',
        meta.parallelism === 'mpi' ? '#include <mpi.h>' : '',
        '#include <memory>',
        providers.length ? '#include <span>' : '',
        '#include <stdexcept>',
        '#include <string>',
        '#include <string_view>',
        meta.parallelism === 'stdThread' ? '#include <thread>' : '',
        '#include <vector>'
    ].filter(Boolean).join('\n');

    const header = `// Generated by Konjugate's "Export simulation code" feature from "${document.metadata?.projectName ?? 'this project'}".\n`
        + `// Reproduces one Explicit Euler run of the model as it was when exported. See docs/codeExport.md\n`
        + `// for exactly what is (and is not) reproduced.\n//\n`
        + `${runInstructions('cpp', meta, '// ')}\n//\n${stateIndexComment(model, '// ')}\n`;

    const escapedHeader = csvHeader(model).replace(/\\/g, '\\\\').replace(/"/g, '\\"');

    const outputSetupLines = isMpi ? [
        '    std::ofstream output;',
        '    if (worldRank == 0) {',
        '        output.open(outputPath);',
        '        output << std::setprecision(15);',
        `        output << "${escapedHeader}\\n";`,
        '    }',
        '    const auto writeRow = [&](double time) {',
        '        if (worldRank != 0) return;',
        '        output << time;',
        '        for (double value : globalState) output << \',\' << value;',
        '        output << \'\\n\';',
        '    };'
    ] : [
        '    std::ofstream output(outputPath);',
        '    output << std::setprecision(15);',
        `    output << "${escapedHeader}\\n";`,
        '    const auto writeRow = [&](double time) {',
        '        output << time;',
        '        for (double value : globalState) output << \',\' << value;',
        '        output << \'\\n\';',
        '    };'
    ];

    return [
        header,
        includes,
        '',
        providers.length ? `${cppSdkNamespace}\n` : '',
        providerBlocks.join('\n'),
        cppScheduleLines(model),
        'int main(int argc, char** argv) {',
        isMpi ? '    MPI_Init(&argc, &argv);' : null,
        `    double targetTime = ${doubleLiteral(meta.defaultTargetTime)};`,
        '    std::string outputPath = "results.csv";',
        '    for (int index = 1; index < argc; ++index) {',
        '        const std::string argument = argv[index];',
        '        if (argument == "--target-time" && index + 1 < argc) targetTime = std::stod(argv[++index]);',
        '        else if (argument == "--output" && index + 1 < argc) outputPath = argv[++index];',
        '    }',
        `    constexpr double globalTimeStep = ${doubleLiteral(meta.globalTimeStep)};`,
        `    constexpr double outputInterval = ${doubleLiteral(meta.outputInterval)};`,
        '    const std::size_t outputEveryStep = static_cast<std::size_t>(outputInterval / globalTimeStep + 0.5);',
        `    constexpr int nodeCount = ${nodeCount};`,
        isMpi ? mpiSetupLines(model) : null,
        providerDeclarations,
        `    std::vector<double> globalState = { ${initialStateLiterals(model)} };`,
        cppSettleLines(model, providerInfo),
        outputSetupLines.join('\n'),
        '    writeRow(0);',
        '    const auto steps = static_cast<std::size_t>(std::ceil(targetTime / globalTimeStep - 1e-9));',
        '    for (std::size_t step = 0; step < steps; ++step) {',
        '        const std::vector<double> snapshot = globalState;',
        '        const double currentTime = step * globalTimeStep;',
        nodeLambdas.split('\n').map((line) => `    ${line}`).join('\n'),
        `        std::vector<std::function<void()>> nodeIntegrators = { ${nodeIntegratorList} };`,
        dispatchLines.join('\n'),
        '        if ((step + 1) % outputEveryStep == 0) writeRow((step + 1) * globalTimeStep);',
        '    }',
        isMpi ? '    if (worldRank == 0) std::cerr << "Wrote " << outputPath << "\\n";' : '    std::cerr << "Wrote " << outputPath << "\\n";',
        isMpi ? '    MPI_Finalize();' : null,
        '    return 0;',
        '}',
        ''
    ].filter((line) => line !== null).join('\n');
}

export const cppSdkNamespace = `namespace konjugate::sdk::v1 {

struct ScalarPort { std::string key; std::string name; std::string unit; };
struct RelationshipDescription { std::string providerId; std::string name; std::vector<ScalarPort> inputs; ScalarPort output; };
struct InitializationContext { std::uint64_t instanceId = 0; };

class InputView {
public:
    InputView(std::span<const double> values, std::span<const std::string_view> keys) noexcept : values_(values), keys_(keys) {}
    [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
    [[nodiscard]] double at(std::size_t index) const {
        if (index >= values_.size()) throw std::out_of_range("Relationship-provider input index is out of range.");
        return values_[index];
    }
    [[nodiscard]] double at(std::string_view key) const {
        for (std::size_t index = 0; index < keys_.size(); ++index) if (keys_[index] == key) return values_[index];
        throw std::out_of_range("Unknown relationship-provider input key.");
    }
private:
    std::span<const double> values_;
    std::span<const std::string_view> keys_;
};

struct EvaluationContext { double simulationTime = 0; double stepSize = 0; InputView inputs; };

class OutputCollector {
public:
    void addGradient(double value) noexcept { gradient_ += value; }
    [[nodiscard]] double gradient() const noexcept { return gradient_; }
private:
    double gradient_ = 0;
};

class RelationshipProvider {
public:
    virtual ~RelationshipProvider() = default;
    [[nodiscard]] virtual RelationshipDescription describe() const = 0;
    virtual void initialize(const InitializationContext&) {}
    virtual void evaluate(const EvaluationContext&, OutputCollector&) = 0;
    virtual void shutdown() noexcept {}
};

} // namespace konjugate::sdk::v1

std::unique_ptr<konjugate::sdk::v1::RelationshipProvider> createRelationshipProvider();
`;

// ---- Python ----

function pythonSymbolsDict(symbols) {
    return `{${Array.from(symbols, ([key, value]) => `"${key}": ${symbolText(value, 'python')}`).join(', ')}}`;
}

function emitPythonRegularContribution(contribution) {
    const expression = emitExpression(compileExpressionNode(contribution.mathJson), symbolTexts(contribution.symbols, 'python'), pythonOperators);
    return [
        ...commentLines(contribution.symbols, '        ', '#'),
        `        contribution_value = ${expression}`,
        contribution.negate ? '        contribution_value = -contribution_value' : '',
        '        if not math.isfinite(contribution_value): raise RuntimeError("A contribution produced a non-finite derivative.")',
        `        derivative[${contribution.outputLocalIndex}] += contribution_value`
    ].filter(Boolean).join('\n');
}

function emitPythonProviderContribution(contribution, info) {
    return [
        ...commentLines(contribution.symbols, '        ', '#'),
        '        outputs = OutputCollector()',
        `        ${info.instanceVariable}.evaluate(EvaluationContext(step_time, node_time_step), InputView(${pythonSymbolsDict(contribution.symbols)}), outputs)`,
        '        contribution_value = outputs.gradient',
        contribution.negate ? '        contribution_value = -contribution_value' : '',
        '        if not math.isfinite(contribution_value): raise RuntimeError("A contribution produced a non-finite derivative.")',
        `        derivative[${contribution.outputLocalIndex}] += contribution_value`
    ].filter(Boolean).join('\n');
}

function emitPythonAlgebraicTask(task, info) {
    const lines = [...commentLines(task.symbols, '        ', '#')];
    if (task.implementation) {
        lines.push(
            '        outputs = OutputCollector()',
            `        ${info.instanceVariable}.evaluate(EvaluationContext(algebraic_time, node_time_step), InputView(${pythonSymbolsDict(task.symbols)}), outputs)`,
            '        algebraic_value = outputs.gradient'
        );
    } else {
        lines.push(`        algebraic_value = ${emitExpression(compileExpressionNode(task.mathJson), symbolTexts(task.symbols, 'python'), pythonOperators)}`);
    }
    lines.push(
        '        if not math.isfinite(algebraic_value): raise RuntimeError("An algebraic source term produced a non-finite value.")',
        `        state[${task.outputLocalIndex}] = algebraic_value`
    );
    return lines.join('\n');
}

// Mirrors cppSettleLines: algebraic states computed once from the initial states before step 0.
function pythonSettleLines(model, providerInfo) {
    const blocks = model.nodePlans.filter((plan) => plan.algebraic.length).map((plan) => {
        const seed = plan.node.states.map((state) => `global_state[${model.stateRecord.get(state.id).globalIndex}]`).join(', ');
        const commitLines = plan.node.states.map((state, index) => (
            `    global_state[${model.stateRecord.get(state.id).globalIndex}] = state[${index}]`
        )).join('\n');
        const tasks = plan.algebraic.map((task) => emitPythonAlgebraicTask(task, providerInfo.get(task)))
            .join('\n').split('\n').map((line) => line.replace(/^    /, '')).join('\n');
        return [
            `    # Settle algebraic states: ${plan.node.name}`,
            '    snapshot = global_state',
            `    state = [${seed}]`,
            `    node_time_step = global_time_step / ${plan.substeps}`,
            '    algebraic_time = 0.0',
            tasks,
            commitLines
        ].join('\n');
    });
    return blocks.join('\n');
}

function emitPythonNodeProvider(nodeProvider, info) {
    // setsValue outputs are written after every contribution has been evaluated, as the engine
    // does, so no contribution in this substep sees them early.
    const outputLines = nodeProvider.outputs.map((output) => (output.setsValue
        ? `        pending_algebraic.append((${output.localIndex}, node_outputs.gradients.get("${output.key}", 0.0)))`
        : `        derivative[${output.localIndex}] += node_outputs.gradients.get("${output.key}", 0.0)`
    ));
    return [
        ...commentLines(nodeProvider.symbols, '        ', '#'),
        '        node_outputs = NodeOutputCollector()',
        `        ${info.instanceVariable}.evaluate(EvaluationContext(step_time, node_time_step), InputView(${pythonSymbolsDict(nodeProvider.symbols)}), node_outputs)`,
        ...outputLines
    ].join('\n');
}

// Only used for parallelism 'mpi': wraps a node's block in a guard so each rank executes only the
// nodes in its own contiguous block (see mpiSetupLines's C++ counterpart / nodeStateOffsetLiterals
// for why a contiguous-by-node-order partition is what makes the later single comm.allgather()
// sufficient to reconcile the full state list).
function pythonNodeBlockLines(model, providerInfo, isMpi) {
    return model.nodePlans.map((plan, nodeIndex) => {
        const stateCount = plan.node.states.length;
        const seed = plan.node.states.map((state) => `snapshot[${model.stateRecord.get(state.id).globalIndex}]`).join(', ');
        const contributionLines = plan.contributions.map((contribution) => (
            contribution.implementation
                ? emitPythonProviderContribution(contribution, providerInfo.get(contribution))
                : emitPythonRegularContribution(contribution)
        )).join('\n');
        const nodeProviderLines = plan.nodeProvider ? emitPythonNodeProvider(plan.nodeProvider, providerInfo.get(plan.nodeProvider)) : '';
        // Twice, as the engine does: before each substep's derivatives, and after the last update
        // (see cppAlgebraicLines).
        const algebraicLines = plan.algebraic.map((task) => emitPythonAlgebraicTask(task, providerInfo.get(task))).join('\n');
        const algebraicAtStart = algebraicLines && ['        algebraic_time = step_time', algebraicLines].join('\n');
        const algebraicAtEnd = algebraicLines && ['    algebraic_time = current_time + global_time_step', algebraicLines.split('\n').map((line) => line.replace(/^    /, '')).join('\n')].join('\n');
        const hasPendingAlgebraic = plan.nodeProvider?.outputs.some((output) => output.setsValue);
        const commitLines = plan.node.states.map((state, index) => (
            `    global_state[${model.stateRecord.get(state.id).globalIndex}] = state[${index}]`
        )).join('\n');
        const body = [
            `    # Node: ${plan.node.name}`,
            `    state = [${seed}]`,
            `    node_time_step = global_time_step / ${plan.substeps}`,
            `    for substep in range(${plan.substeps}):`,
            '        step_time = current_time + substep * node_time_step',
            algebraicAtStart,
            `        derivative = [0.0] * ${stateCount}`,
            hasPendingAlgebraic ? '        pending_algebraic = []' : '',
            contributionLines,
            nodeProviderLines,
            hasPendingAlgebraic ? '        for index, value in pending_algebraic:\n            if not math.isfinite(value): raise RuntimeError("An algebraic output produced a non-finite value.")\n            state[index] = value' : '',
            `        for index in range(${stateCount}):`,
            '            state[index] += node_time_step * derivative[index]',
            algebraicAtEnd,
            commitLines
        ].filter(Boolean).join('\n');
        if (!isMpi) return body;
        return [`    if my_node_start <= ${nodeIndex} < my_node_end:`, body.split('\n').map((line) => `    ${line}`).join('\n')].join('\n');
    }).join('\n');
}

// See generateCpp's mpiSetupLines for the identical partition scheme (contiguous node blocks by
// node count, computed at runtime from the rank count). mpi4py initializes/finalizes MPI on
// import/interpreter-exit automatically, so unlike C++ there is no explicit Init/Finalize here.
function pythonMpiSetupLines(model) {
    return [
        '    comm = MPI.COMM_WORLD',
        '    world_rank = comm.Get_rank()',
        '    world_size = comm.Get_size()',
        `    node_state_offsets = [${nodeStateOffsetLiterals(model)}]`,
        '    nodes_per_rank = -(-node_count // world_size)  # ceiling division',
        '    my_node_start = min(world_rank * nodes_per_rank, node_count)',
        '    my_node_end = min(my_node_start + nodes_per_rank, node_count)',
        '    my_state_start = node_state_offsets[my_node_start]',
        '    my_state_end = node_state_offsets[my_node_end]'
    ].join('\n');
}

function generatePython(model, providers, meta, document) {
    let providerIndex = 0;
    const providerInfo = new Map();
    const providerBlocks = providers.map((provider) => {
        const { className, pattern } = pythonProviderClassName(provider.implementation.source, provider.entityLabel);
        const uniqueName = `${className}Provider${providerIndex}`;
        providerIndex += 1;
        providerInfo.set(provider, { className: uniqueName, instanceVariable: `${uniqueName.charAt(0).toLowerCase()}${uniqueName.slice(1)}` });
        const withoutImport = provider.implementation.source.replace(/^from konjugate import\s*(\([^)]*\)|[^\n]*)\n?/m, '');
        return withoutImport.replace(pattern, `class ${uniqueName}(`);
    });

    const isMpi = meta.parallelism === 'mpi';
    const nodeCount = model.nodePlans.length;
    const nodeBlocks = pythonNodeBlockLines(model, providerInfo, isMpi);

    const providerInstances = providers.map((provider) => {
        const info = providerInfo.get(provider);
        return [
            `    ${info.instanceVariable} = ${info.className}()`,
            `    ${info.instanceVariable}.initialize(InitializationContext(0))`
        ].join('\n');
    }).join('\n');

    const header = `# Generated by Konjugate's "Export simulation code" feature from "${document.metadata?.projectName ?? 'this project'}".\n`
        + `# Reproduces one Explicit Euler run of the model as it was when exported. See docs/codeExport.md\n`
        + `# for exactly what is (and is not) reproduced.\n#\n`
        + `${runInstructions('python', meta, '# ')}\n#\n${stateIndexComment(model, '# ')}\n`;

    const escapedHeader = pythonStringContents(csvHeader(model));

    const outputSetupLines = isMpi ? [
        "    output = open(output_path, 'w') if world_rank == 0 else None",
        '    if output:',
        `        output.write("${escapedHeader}\\n")`,
        '    def write_row(time):',
        '        if output is None:',
        '            return',
        '        output.write(",".join(f"{value:.10g}" for value in [time, *global_state]) + "\\n")'
    ] : [
        "    output = open(output_path, 'w')",
        `    output.write("${escapedHeader}\\n")`,
        '    def write_row(time):',
        '        output.write(",".join(f"{value:.10g}" for value in [time, *global_state]) + "\\n")'
    ];

    const gatherLines = isMpi ? [
        '        gathered_chunks = comm.allgather(global_state[my_state_start:my_state_end])',
        '        global_state = [value for chunk in gathered_chunks for value in chunk]'
    ] : [];

    return [
        header,
        'import argparse',
        model.schedules.length ? 'import bisect' : '',
        'import math',
        isMpi ? 'from mpi4py import MPI' : '',
        '',
        providers.length ? `${pythonSdkModule}\n` : '',
        providerBlocks.join('\n\n\n'),
        '',
        pythonScheduleLines(model),
        'def run(target_time, output_path):',
        `    global_time_step = ${doubleLiteral(meta.globalTimeStep)}`,
        `    output_interval = ${doubleLiteral(meta.outputInterval)}`,
        '    output_every_step = round(output_interval / global_time_step)',
        `    node_count = ${nodeCount}`,
        isMpi ? pythonMpiSetupLines(model) : '',
        providerInstances,
        `    global_state = [${initialStateLiterals(model)}]`,
        pythonSettleLines(model, providerInfo),
        outputSetupLines.join('\n'),
        '    write_row(0)',
        '    steps = math.ceil(target_time / global_time_step - 1e-9)',
        '    for step in range(steps):',
        '        snapshot = list(global_state)',
        '        current_time = step * global_time_step',
        nodeBlocks.split('\n').map((line) => `    ${line}`).join('\n'),
        ...gatherLines,
        '        if (step + 1) % output_every_step == 0:',
        '            write_row((step + 1) * global_time_step)',
        '    if output:',
        '        output.close()',
        '        print(f"Wrote {output_path}")',
        '',
        '',
        'if __name__ == "__main__":',
        '    parser = argparse.ArgumentParser()',
        `    parser.add_argument("--target-time", type=float, default=${doubleLiteral(meta.defaultTargetTime)})`,
        '    parser.add_argument("--output", type=str, default="results.csv")',
        '    arguments = parser.parse_args()',
        '    run(arguments.target_time, arguments.output)',
        ''
    ].join('\n');
}

const pythonSdkModule = `# --- vendored from engine/sdk/python/konjugate (author-facing provider SDK types) ---
from abc import ABC, abstractmethod
from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping, Sequence


@dataclass(frozen=True)
class ScalarPort:
    key: str
    name: str
    unit: str = ""


@dataclass(frozen=True)
class RelationshipDescription:
    provider_id: str
    name: str
    inputs: Sequence[ScalarPort]
    output: ScalarPort


@dataclass(frozen=True)
class InitializationContext:
    instance_id: int


@dataclass(frozen=True)
class EvaluationContext:
    simulation_time: float
    step_size: float


class InputView:
    def __init__(self, values: Mapping[str, float]):
        self._values = MappingProxyType(dict(values))

    def __getitem__(self, key: str) -> float:
        return self._values[key]

    def __len__(self) -> int:
        return len(self._values)


class OutputCollector:
    def __init__(self):
        self._gradient = 0.0

    def add_gradient(self, value: float) -> None:
        self._gradient += float(value)

    @property
    def gradient(self) -> float:
        return self._gradient


class RelationshipProvider(ABC):
    @abstractmethod
    def describe(self) -> RelationshipDescription:
        raise NotImplementedError

    def initialize(self, context: InitializationContext) -> None:
        del context

    @abstractmethod
    def evaluate(self, context: EvaluationContext, inputs: InputView, outputs: OutputCollector) -> None:
        raise NotImplementedError

    def shutdown(self) -> None:
        pass


@dataclass(frozen=True)
class NodeProviderDescription:
    provider_id: str
    name: str
    inputs: Sequence[ScalarPort]
    outputs: Sequence[ScalarPort]


class NodeOutputCollector:
    def __init__(self):
        self._gradients = {}

    def add_gradient(self, key: str, value: float) -> None:
        self._gradients[key] = self._gradients.get(key, 0.0) + float(value)

    @property
    def gradients(self) -> Mapping[str, float]:
        return MappingProxyType(dict(self._gradients))


class NodeProvider(ABC):
    @abstractmethod
    def describe(self) -> NodeProviderDescription:
        raise NotImplementedError

    def initialize(self, context: InitializationContext) -> None:
        del context

    @abstractmethod
    def evaluate(self, context: EvaluationContext, inputs: InputView, outputs: NodeOutputCollector) -> None:
        raise NotImplementedError

    def shutdown(self) -> None:
        pass
# --- end vendored SDK types ---`;
