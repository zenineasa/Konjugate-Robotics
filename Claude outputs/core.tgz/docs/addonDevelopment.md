---
type: Guide
title: Add-on development
description: Guide for building launcher and visualizer add-ons (.kja) with the visualizer bridge, window state, and IPC permissions.
tags: [addons, visualizer, extensions, ipc]
status: stable
---

<!-- Copyright © 2026 Zenin Easa Panthakkalakath -->

# Add-on development

## Status

Konjugate add-on API version 1 is experimental. It currently supports one add-on kind: a read-only result visualizer launched from a button in the left rail that the manifest contributes. The API will evolve from experience gained with the bundled Results Analysis add-on.

An add-on is self-contained. Konjugate discovers its manifest, creates its rail button, opens its entry page in a separate sandboxed window, and supplies a permission-controlled bridge. Adding another compatible visualizer does not require modifying Konjugate's main process, preload, renderer, or HTML files.

## Add-ons vs. plugins

Konjugate uses two deliberately separate extension concepts. Confusing them is the most common mistake when reasoning about what an extension can do — this document is only about the first one.

| | Add-on (this document) | Plugin |
| --- | --- | --- |
| Layer | Electron application and presentation | Native engine and numerical execution |
| Status | Implemented (API version 1, `resultVisualizer` kind only) | Implemented first slice: packaged C++/Python relationship providers |
| Examples | Result visualizer, dashboard, modelling interface | Relationship provider, computational node, external-system adapter |
| Runs where | A separate sandboxed Electron window, host-supplied bridge | Resolved and supervised by the native engine |
| Model access | None — "no ability to edit the active model through API version 1" | Declared inputs/outputs only, no ambient authority |
| Consequence of failure | The optional interface closes or becomes unavailable | A dependent model cannot run, or the active run fails |

The two systems intentionally retain separate manifests, registries, permission models, API versions and runtime hosts, and installing or trusting one must never grant authority to the other. See [Interaction providers](interactionProviders.md#add-ons-and-plugins) for the plugin side — including the long-term contribution kinds it's expected to support (`relationshipProvider`, `nodeProvider`, `connector`, `validator`) and the "inline code → reusable plugin" promotion path. What this document describes is the C++/Python inline `relationshipProvider` execution engine plus this add-on system. A plugin packaging/registry layer also now ships alongside it — `src/packageArchive.mjs` (install/enable/disable/uninstall), `src/pluginResolver.mjs` (version-pinned resolution, project-reference and incompatibility checks) and `src/extensionStateStore.mjs` — see [Plugin development](pluginDevelopment.md). What remains future work is the deeper *trust* layer specifically: publisher signatures, artifact-hash verification, and platform-specific package selection.

## Installation and discovery

An add-on is a directory containing `addon.json` and every file it needs at runtime:

```text
myResultViewer/
├── addon.json
├── index.html
├── viewer.mjs
├── styles.css
└── vendor/
```

Konjugate scans two locations when its main renderer starts:

- the application's bundled `addons` directory;
- `addons` inside Electron's user-data directory for Konjugate.

The user-data location follows the operating system. It is normally beneath `~/Library/Application Support` on macOS, `%APPDATA%` on Windows, and `$XDG_CONFIG_HOME` or `~/.config` on Linux. The final application-directory name is determined by the installed Konjugate build. Restart Konjugate after adding or removing an add-on; version 1 does not hot-reload manifests.

During source development, placing the directory under the repository's `addons/` directory installs it as a bundled add-on.

A minimal working example lives in its own repository, walked through in [Hello World add-on](helloWorldAddon.md). Start there before building a larger visualizer or dashboard.

For end users, package the add-on as a `.kja` file and use the application's installer. See [Konjugate packages](packageDevelopment.md) for the portable package layout and safety checks.

Invalid manifests are skipped. A diagnostic is written to the main-process console. Add-on IDs must be globally unique across bundled and user-installed add-ons; a duplicate is skipped.

## Manifest

`addon.json` must be valid JSON. Version 1 result visualizers declare exactly one toolstrip command:

```json
{
    "addonId": "example.vehicleTrajectoryViewer",
    "name": "Vehicle Trajectory Viewer",
    "version": "0.1.0",
    "apiVersion": 1,
    "kind": "resultVisualizer",
    "entry": "index.html",
    "copyright": "Copyright © 2026 Example Author",
    "permissions": [
        "results.read",
        "results.live.read",
        "timeline.read",
        "timeline.seek",
        "selection.read",
        "simulation.status.read",
        "simulation.pacing.read",
        "simulation.pacing.control"
    ],
    "contributes": {
        "toolstrip": [{
            "commandId": "openViewer",
            "label": "Trajectory",
            "tooltip": "Open vehicle trajectory viewer",
            "symbol": "◇",
            "when": "resultsActive",
            "contexts": ["resultSession"]
        }]
    }
}
```

### Identity and entry fields

- `addonId` is a dotted, globally unique identifier. Each segment begins with a lower-case letter and continues in lower camel case, for example `example.vehicleTrajectoryViewer`.
- `name` is the user-facing add-on name.
- `version` is the add-on's own version string.
- `apiVersion` must currently be `1`.
- `kind` must currently be `resultVisualizer`.
- `entry` is an HTML file inside the add-on directory. Absolute paths and `..` traversal are rejected.
- `copyright` records attribution. It is recommended for every manifest.

### Toolstrip contribution

The host creates the button; add-on code does not manipulate the main application's DOM. The manifest key is called `toolstrip` for historical reasons, but the buttons it contributes are not in the toolstrip along the top of the window: the host shows them in a rail along the left edge, as the contribution's `symbol` alone until the pointer or keyboard focus reaches that one button, which then widens over the canvas to show its `label` as well. The Extensions button sits at the top of the same rail.

- `commandId` is a lower-camel-case identifier unique within the add-on.
- `label` appears beside the button symbol.
- `tooltip` becomes both hover text and the accessible label.
- `symbol` is a short textual glyph. Version 1 does not accept executable markup or an external icon path.
- `when` must be `resultsActive`.
- `contexts` must contain `resultSession`.

The button and its add-on separator appear only while results are active. Invoking it opens or focuses the add-on's modeless window. Version 1 supports one active result-visualizer window at a time.

Konjugate supplies the add-on window's titlebar, branding and operating-system-aware minimize, maximize or full-screen and close controls. Add-ons should not create their own window chrome or reserve space for it; the host inserts the titlebar and adjusts the document automatically.

## Permissions

Permissions are declared explicitly. Unknown permissions cause the manifest to be rejected.

| Permission | Capability |
| --- | --- |
| `results.read` | Read run context, discover signals, and request signal samples. |
| `timeline.read` | Receive timeline-position changes from the main result player. |
| `timeline.seek` | Request that the main result player seek to a time. |
| `selection.read` | Receive selected-node changes from the main canvas. |
| `results.live.read` | Receive notifications when additional live samples are available. |
| `simulation.status.read` | Receive live run lifecycle and progress metadata. |
| `simulation.pacing.read` | Receive the active simulation pacing mode and ratio. |
| `simulation.pacing.control` | Request a pacing change for the active engine job. |
| `results.export` | Save signal samples to a CSV file the user chooses. |
| `project.data` | Keep data with the open project: for a result visualizer, `getProjectData()` and `setProjectData(data)` (below); for a launcher, its session. |
| `settings.store` | Result visualizer only. Keep settings for the user, the same in every project, with `getSettings()` and `setSettings(settings)` (below). |
| `network.fetch` | Launcher only. Fetch a file from the internet into an importer file role (or a page of text, up to 1 MB, for the window to show, such as a symbol search), only over https, only from the exact host names listed in the manifest's `network.hosts`, with a size and time limit. The address and time of each fetch are recorded in the run manifest. |
| `links.open` | Launcher only. Open a page in the user's browser with `openLink(url)`, only over https and only on the exact host names listed in the manifest's `links.hosts` (with `requires: ["openLink"]`): directions between two places on a map, say, for the user to read. Nothing comes back to the window. |
| `files.store` | Launcher only. Keep large files for the user in Konjugate's own data folder (with `requires: ["storedFiles"]`): `storedFiles()` lists them (each `{ id, name, bytes, storedAt, origin, details }`, `origin` saying whether it was downloaded, from which server and address, or brought in by the user, and under what name), `storeFiles(details, { accept, title })` brings files in from disk as copies (`accept` the endings it keeps, such as `['osm.pbf']`: the dialog offers only those, by their last extension, and a file of another ending is refused before anything is copied; no `accept`, any file), `downloadFile(url, { name, server, checksumUrl, details, downloadId })` downloads one from a host in `network.hosts` (with `network.fetch`), streamed to disk, its progress heard by `onProgress` as `{ stage: 'download', downloadId, done, total }`, cancelled with `cancelDownload(downloadId)`, its size asked beforehand with `fileSize(url)` (bytes, or null when the server does not say), and kept only when whole and matching a published MD5 when one is named; `describeStoredFile(id, details)` adds the add-on's details (16 KB at most), `removeStoredFile(id)` removes one, and `useStoredFiles(importerId, role, ids)` gives stored files to a binary role as if chosen. A window never sees a stored file's path, and nothing is removed but by the user. |
| `analysis.infer` | Launcher only. Run causal inference on a table of time series the launcher supplies and get the inferred edges back. |

Only request capabilities the visualizer uses. The bundled preload may expose a method whose corresponding permission was not granted, but the host will not provide the protected data or event.

## Runtime environment

The entry page runs in a separate Electron renderer with:

- Chromium's renderer sandbox enabled;
- context isolation enabled;
- Node.js integration disabled;
- no direct access to Konjugate's main renderer or model objects;
- no ability to edit the active model through API version 1.

`window.require`, Node.js built-ins, Electron APIs, and the main application's DOM are unavailable. Package browser-ready dependencies inside the add-on. Do not depend on Konjugate's internal `node_modules` layout; the bundled viewer does this only because it ships with the application.

The add-on controls its own Content Security Policy. A conservative starting point is:

```html
<meta http-equiv="Content-Security-Policy"
      content="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:">
```

Konjugate injects one frozen bridge into the isolated page:

```js
window.konjugateVisualizer
```

## Visualizer API version 1

### `getContext()`

Returns a promise for the active result context:

```js
const context = await window.konjugateVisualizer.getContext();
```

```text
context
├── apiVersion
├── sessionId
├── projectName
├── selectedNodeId
├── time
└── run
    ├── name
    ├── targetTime
    ├── outputInterval
    ├── sampleCount
    ├── lifecycle              `running`, `paused`, `stopped`, or `completed`
    ├── simulationTime
    ├── availableResultTime
    └── pacing
        ├── mode               `fastest`, `realTime`, or `limitedRatio`
        └── simulationSecondsPerWallSecond
```

The context contains metadata, not the full model or result sample storage. It returns `null` after the result session is no longer available.

It also carries the model's `nodes` and `edges` as they appear: each node's `id`, `title`, `shape`, `color`, `rotation`, `scale`, its imported `mesh` (`{ position, normal, index }`) when it has one, and its `parts` when its appearance has them (see [Project schema](projectSchema.md)): the meshes of bodies the node reports the pose of, such as a robot's links, each named by the `prefix` of its pose states.

### `listSignals()`

Returns a promise for the signal catalogue. It requires `results.read`.

```js
const signals = await window.konjugateVisualizer.listSignals();
```

Each signal contains:

```text
signal
├── signalId       numeric state ID used for API references
├── entityId       numeric owning-node ID
├── entityName     current display name of the node
├── name           display name of the state
├── symbol         model symbol of the state
└── unit           unit string, possibly empty
```

Names and symbols are presentation metadata. Store and request signals by `signalId`.

### `readSeries(signalIds, options)`

Returns samples for the requested signals. It requires `results.read`.

```js
const series = await window.konjugateVisualizer.readSeries(
    selectedSignalIds,
    {
        startTime: 0,
        endTime: context.run.targetTime,
        maxPoints: 5000
    }
);
```

All options are optional. The defaults are the entire run and at most 4,000 requested points. The host may downsample before crossing the process boundary. The first and last retained samples in the requested range are preserved when possible.

Each returned series repeats its signal metadata and adds:

```text
samples: [{ time: Number, value: Number }, ...]
```

An add-on should request only the signals and resolution it can display. Do not assume all runs fit comfortably in renderer memory.

During a live run, `readSeries()` returns the complete samples currently published by the engine. Re-request only the visible series after `onSamplesAvailable`; the event intentionally does not push the potentially large sample payload across the bridge.

### `seek(time)`

Requests a new time from the main result player. It requires `timeline.seek`.

```js
window.konjugateVisualizer.seek(4.2);
```

The host clamps the request to the latest available result time. The main player selects its nearest available output sample and subsequently publishes the accepted time through `onTimelineChange` when `timeline.read` is granted.

### `onTimelineChange(callback)`

Subscribes to accepted timeline changes. It requires `timeline.read`.

```js
window.konjugateVisualizer.onTimelineChange((time) => {
    movePlotCursor(time);
});
```

The callback may run frequently during playback. Update cursors or layout incrementally instead of rebuilding complete plots.

### `onSelectionChange(callback)`

Subscribes to selected-node ID changes. It requires `selection.read`. The value is `null` when no node is selected or when another entity type is selected.

```js
window.konjugateVisualizer.onSelectionChange((nodeId) => {
    highlightEntity(nodeId);
});
```

Selection notification does not require the add-on to replace its chosen signals.

### `onSessionChange(callback)`

Notifies an already-open visualizer that its result session was replaced by a new command invocation. Re-read the context, catalogue, and required series inside the callback.

```js
window.konjugateVisualizer.onSessionChange(async () => {
    await loadActiveSession();
});
```

When the user explicitly closes results in Konjugate, the visualizer window is closed and its session is invalidated.

### Live run events and pacing

`onSamplesAvailable(callback)` requires `results.live.read` and reports `{ sampleCount, availableResultTime }` whenever a new atomic result snapshot is available. `onRunStatusChange(callback)` requires `simulation.status.read` and publishes the current `run` metadata. `onPacingChange(callback)` requires `simulation.pacing.read`.

```js
window.konjugateVisualizer.onSamplesAvailable(async () => {
    const series = await window.konjugateVisualizer.readSeries(selectedSignalIds);
    updatePlot(series);
});
window.konjugateVisualizer.onRunStatusChange((run) => updateStatus(run.lifecycle));
```

An add-on with `simulation.pacing.control` may request a live pacing change:

```js
await window.konjugateVisualizer.requestPacing({
    mode: 'limitedRatio',
    simulationSecondsPerWallSecond: 2
});
```

`realTime` always means one simulation second per wall second. `fastest` removes the wall-clock limit. A limited ratio is a cap, not a guarantee: computationally expensive models may advance more slowly. Simulation pacing controls engine execution; it is separate from the completed-result playback rate and must not be presented as playback speed.

### `exportCsv(suggestedFilename, csv)`

Requires `results.export`. Opens a native save dialog pre-filled with `suggestedFilename`, then writes the given CSV text to the path the user chooses:

```js
await window.konjugateVisualizer.exportCsv('trajectory.csv', csv);
```

Returns a promise for `{ path, fileName }`, or `null` if the user cancels the dialog. The add-on builds the CSV text itself, client-side, from data already returned by `readSeries`; the host only handles the file-system write.

## Minimal visualizer

`index.html`:

```html
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Security-Policy"
          content="default-src 'self'; script-src 'self'; style-src 'self'">
    <title>My result viewer</title>
    <script type="module" src="viewer.mjs"></script>
</head>
<body>
    <select id="signals" multiple></select>
    <pre id="output"></pre>
</body>
</html>
```

`viewer.mjs`:

```js
const signalSelect = document.querySelector('#signals');
const output = document.querySelector('#output');

async function loadSession() {
    const context = await window.konjugateVisualizer.getContext();
    const signals = await window.konjugateVisualizer.listSignals();

    signalSelect.replaceChildren(...signals.map((signal) => {
        const option = document.createElement('option');
        option.value = signal.signalId;
        option.textContent = `${signal.entityName} · ${signal.name} (${signal.unit || 'unitless'})`;
        return option;
    }));

    output.textContent = `${context.projectName} · ${context.run.name}`;
}

signalSelect.addEventListener('change', async () => {
    const signalIds = [...signalSelect.selectedOptions].map((option) => Number(option.value));
    const series = await window.konjugateVisualizer.readSeries(signalIds, { maxPoints: 1000 });
    output.textContent = JSON.stringify(series, null, 2);
});

window.konjugateVisualizer.onSessionChange(loadSession);
loadSession();
```

This example intentionally uses no framework. Canvas, WebGL, SVG, and locally packaged plotting libraries are all possible inside the add-on window.

### Keeping data: `getProjectData()`, `setProjectData(data)`, `getSettings()`, `setSettings(settings)`

A visualizer can keep what the user set up in it, in two places:

- With `project.data` (and `requires: ["projectData"]`), with the project. `setProjectData(data)` gives the project any JSON (up to 1 MB) under the visualizer's id in its `addonData` ([Project schema](projectSchema.md)); the project counts as unsaved until the user saves it, and `null` removes it. `getProjectData()` answers `{ data, savedAt, addonVersion }`, with `data: null` when the project keeps none. Use it for what belongs to one model: which signals play which role, say. Refer to nodes and states by their numeric ids, which last as long as the project does.
- With `settings.store` (and `requires: ["addonSettings"]`), for the user. `setSettings(settings)` keeps any JSON (up to 256 KB) in Konjugate's own data folder, one file per add-on, and `getSettings()` answers it, or `null`. Use it for preferences that hold in every project. Settings are kept across reinstalls and updates, and removed with the add-on's last installed version.

```js
const { data } = await window.konjugateVisualizer.getProjectData();
await window.konjugateVisualizer.setProjectData({ ...data, roles: chosenRoles });
```

A version of Konjugate that does not know these permissions refuses the visualizer; one that knows the permissions but not a feature named in `requires` says which feature is missing.

## Domain-specific visualizers

The version 1 catalogue supplies state identity, name, symbol, unit, and owning node. It does not yet prescribe semantic roles such as longitude, X position, heading, quaternion component, or coordinate frame.

A domain-specific add-on should therefore let the user map signals to its required roles. For example, a vehicle viewer might request mappings for X, Y, Z, and heading, and keep that mapping with the project by signal id (`setProjectData`, above). Do not infer durable meaning solely from a mutable display name.

Semantic quantity and coordinate-frame metadata are candidates for a later API version. They should remain domain-agnostic and optional.

## Launcher add-ons (experimental)

A second add-on kind, `"kind": "launcher"`, opens a guided starting window instead of visualizing results, for a package that wants to give a first-time user a simple path: bring your data, choose a scenario, read a comparison. Its rail button is always visible (`"when": "always"`, no contexts), and its page is an ordinary sandboxed add-on page with the host titlebar. It gets a different bridge, `window.konjugateLauncher`, whose every call names something the manifest declared and never takes a path or URL of its own.

The manifest declares `contributes.importers` (a module that turns chosen files into a model, run by the host in a worker, plus the file roles it reads and optional sample files), `contributes.scenarios` (named sets of parameter changes with a fork time, run time, optional entity choice and effect sentences), and `contributes.pages` (bundled help pages). Permissions are `data.import`, `scenario.run`, `model.open`, `results.export`, `pages.open`, `analysis.infer`, `network.fetch`, `project.data` and `links.open`. An importer file role may accept several files (`multiple`) and list several samples, and an importer may receive options from the window and return only data, as a first step before the window asks it to build the model. A scenario may also take data from the window: an intervention with the target `supplied` names either a fixed value or (with `samples: true`) a path of time and value pairs for each entity the window names, followed as a piecewise schedule; a supplied value outside the parameter's slider is held to it, and that change in the run's `interventions` carries `clamped: { count, of, minimum, maximum }` so the window can say so (with `requires: ["suppliedPerParameter"]`, the window may give this per parameter, `supplied.byParameter[parameterKey] = { entities, samples }`, so one scenario changes several parameters, each for its own entities along its own paths), and the window may set how far ahead to run, and (with `requires: ["scenarioForkTime"]`) when the scenario starts (`forkAt`, from the run's start up to its end; the fork lands on the nearest output time, and a supplied path is counted from it): any time after the scenario's fork, up to 500,000 of the model's own global steps (a limit in steps, not time, since models count time in their own units). A launcher may list `requires` (features it depends on, currently `scenarioOverrides`, `runRecord`, `projectSession`, `parameterSchedules` for an importer that writes stored parameter schedules, `scenarioForkTime` for a window that chooses when its scenario starts, `suppliedPerParameter` for data supplied per parameter, `fetchCache` for fetches kept in a cache, `keepSession` for a session kept before any model is built, `openLink` for pages opened in the browser `scenarioEveryBackend` for a scenario whose changes apply whichever execution backend the engine chooses, where up to 1.1.10 the partitioned backend ignored them, `binaryInputs` for a binary file role and derived files, below, `nodeProviderInputs` for a model whose computational-node providers read other nodes' states and shared parameters, which the canvas keeps through saving and running, `pythonCheck` for `checkPython(modules)`, below, and `algebraicRelationships` for a model whose relationships set several states at each instant (`equationModel.outputs`, see [Project schema](projectSchema.md)), which an earlier engine would refuse); a version of Konjugate that does not know one refuses the launcher. When it runs a scenario, the window may pass `overrides`, `{ parameterKey: { entityName or '*' for the global entry: { value, at, duration } or null } }`, which adjust the scenario's declared interventions for parameters the importer declared live (null removes one), and `retain: false`, which releases the run's result files once summarized. The run manifest then records the importer options and the overrides, and records nothing extra when there are none. Runs that ask for a baseline of the same length at the same time share one. The host runs the importer, runs each scenario headless as a baseline and a fork of it, opens the result in the canvas as a baseline and a forked branch, and exports a folder with the results, the project and a provenance manifest. A launcher package is rejected at install if it declares a file the archive does not contain. A launcher with `project.data` (and `requires: ["projectSession"]`) can keep its session with the project: `openInCanvas(scenarioId, { session })` writes the window's `session` (any JSON, up to 2 MB) and the input files the model was built from into the project's `addonData` under the launcher's id, kept when the user saves (the project window is told a project is on its way before the host builds it, and a save there waits until it has loaded, so it never writes the project as it was a moment before); `restoreSession()`, called when its window opens, asks the project window for that entry, makes its input files the pending files again, and answers `{ session, savedAt, addonVersion, inputs }` (or `{ session: null }` when the project holds none), so the window can carry on where it was, offline. Inputs are kept up to 64 MB; a project file is compressed. With `keepSession`, `keepSession(session)` keeps the session with the project without opening a model, so work done in the window before a build is saved with the project too (the project counts as unsaved until it is). With `fetchCache`, `fetchFile(importerId, role, url, name, { cache, maximumAgeDays })` may be answered from a cache of what the add-on fetched before, on disk in the user's data, one folder per add-on, never seen by the window: `cache: 'use'` reads an answer from the same address fetched within `maximumAgeDays` (30 by default) and keeps a fresh one, `'refresh'` always fetches and keeps the answer, and `'off'` (the default) neither reads nor keeps; the answer says whether it came from the cache, and the file's `retrievedAt` is when it was really fetched. The address is checked against the listed hosts either way. `cacheInfo()` answers `{ entries, bytes, oldest, newest }` and `clearCache()` empties it. The cache holds up to 512 MB per add-on, dropping what was used longest ago first; it is kept when the add-on is reinstalled or updated, and removed with its last installed version. With `pythonCheck`, `checkPython(modules)` (up to 8 import names) says whether the Python that runs inline providers, the one set under Provider toolchains or else the one found on the PATH, imports each: `{ found, interpreter, chosen, version, modules: { name: { found, version } or { found: false, error } }, message }`, each module imported for real in the temporary directory, so a window can say what is missing before a run fails on it. See [Project schema](projectSchema.md). The design, the trust model and what is not yet built are in [Launcher add-ons](proposals/launcherAddons.md).

An importer's file role may be `binary: true` (with `requires: ["binaryInputs"]`): an optional file, with no sample, of up to 1 GB (several with `multiple: true` and `requires: ["multipleBinaryInputs"]`, up to 2 GB together, as for a city on a border whose map comes in one extract for each country), for data too large or not textual, such as a map extract. The host notes the file when it is chosen and reads it from disk when the importer runs; the importer gets it as `{ role, name, data }` with `data` a `Uint8Array`, and more time and memory by the file's size. A binary file is never kept in memory between runs or with a session. So that its content is, an importer may return `derived: [{ role, name, text, source }]` beside `data`: text files of its other roles (each within the 10 MB a chosen file may be, 64 at most), which take the place of the files of those roles, as if they had been chosen. The binary files stay chosen, as paths, and are given to the importer only for a run whose options ask for them (`useBinaryFiles: true`): a step that does not read them is not made to wait for a gigabyte, and the same files can be read again for another area. They are kept with the session like any input, each with the `source` it was read from, which `restoreSession` gives back as `derivedFrom`. An importer that takes long may say how far it has got with `helpers.progress({ done, total, message })` (with `requires: ["importProgress"]`): the host passes it on, a few times a second at most, to the window's `onProgress` as `{ stage: 'import', importerId, done, total, message }`. The Logistics Toolbox reads a region's roads out of an OpenStreetMap extract this way: the extract is read once, and what it keeps is the roads of the area as text.

## Versioning and forward compatibility

- Reject an unavailable `apiVersion`; do not guess compatible behavior.
- Treat unknown fields returned by the host as additive and ignore them safely.
- Use numeric ID fields for identity and display fields only for presentation.
- Expect result datasets to become larger than can be copied into one renderer.
- Keep add-on state out of the Konjugate model: keep it with the project through `project.data`, or for the user through `settings.store`.
- Avoid depending on the bundled Results Analysis add-on or other Konjugate implementation files.

Future API versions may add richer semantic metadata, streaming and live-run subscriptions, additional contribution points, and installation or trust management. None of those capabilities are part of version 1.
