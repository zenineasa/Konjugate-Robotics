/* Copyright © 2026 Zenin Easa Panthakkalakath */

const identifierPattern = /^[a-z][A-Za-z0-9]*$/;

function sanitizedKeys(bindings) {
    return bindings
        .map((binding) => binding.key?.trim())
        .filter((key) => key && identifierPattern.test(key));
}

function providerIdentity(title) {
    const words = (title ?? '').trim().split(/[^A-Za-z0-9]+|(?=[A-Z])/).filter(Boolean);
    if (!words.length) return { id: 'relationship', name: 'Relationship', className: 'Relationship' };
    const id = words.map((word, index) => {
        const lower = word.toLowerCase();
        return index ? `${lower.charAt(0).toUpperCase()}${lower.slice(1)}` : lower;
    }).join('');
    const name = words.map((word) => `${word.charAt(0).toUpperCase()}${word.slice(1)}`).join(' ');
    // A C++/Python class name must start with a letter, so a title beginning with a digit
    // (e.g. "3-way valve") falls back to a prefixed, still-distinct identifier.
    const candidateClassName = name.replace(/\s+/g, '');
    const className = /^[A-Za-z]/.test(candidateClassName) ? candidateClassName : `Relationship${candidateClassName}`;
    return { id, name, className };
}

function cppTemplate(inputKeys, outputKey, title) {
    const { id, name, className } = providerIdentity(title);
    const inputPorts = inputKeys.length
        ? inputKeys.map((key) => `                konjugate::sdk::v1::ScalarPort{"${key}", "${key}", ""}`).join(',\n')
        : '                // No bindings declared yet — add one below, then insert this template again.';
    const readLines = (inputKeys.length ? inputKeys : ['key']).map((key) => `        //   const double ${key} = context.inputs.at("${key}");`).join('\n');
    return `#include <konjugate/relationshipProvider.hpp>

#include <memory>

namespace {

class ${className} final : public konjugate::sdk::v1::RelationshipProvider {
public:
    konjugate::sdk::v1::RelationshipDescription describe() const override {
        return {
            "${id}",
            "${name}",
            {
${inputPorts}
            },
            konjugate::sdk::v1::ScalarPort{"${outputKey || 'output'}", "${outputKey || 'output'}", ""}
        };
    }

    void evaluate(const konjugate::sdk::v1::EvaluationContext& context,
                  konjugate::sdk::v1::OutputCollector& output) override {
        // Read each bound input by its declared key:
${readLines}
        // Add your computed contribution to the declared output:
        //   output.addGradient(value);
        output.addGradient(0);
    }
};

}

std::unique_ptr<konjugate::sdk::v1::RelationshipProvider> createRelationshipProvider() {
    return std::make_unique<${className}>();
}
`;
}

function pythonTemplate(inputKeys, outputKey, title) {
    const { id, name, className } = providerIdentity(title);
    const inputPorts = inputKeys.length
        ? inputKeys.map((key) => `                ScalarPort("${key}", "${key}", ""),`).join('\n')
        : '                # No bindings declared yet — add one below, then insert this template again.';
    const readLines = (inputKeys.length ? inputKeys : ['key']).map((key) => `        #   ${key} = inputs["${key}"]`).join('\n');
    return `from konjugate import (
    EvaluationContext,
    InputView,
    OutputCollector,
    RelationshipDescription,
    RelationshipProvider,
    ScalarPort,
)


class ${className}(RelationshipProvider):
    def describe(self):
        return RelationshipDescription(
            "${id}",
            "${name}",
            [
${inputPorts}
            ],
            ScalarPort("${outputKey || 'output'}", "${outputKey || 'output'}", ""),
        )

    def evaluate(self, context, inputs, outputs):
        # Read each bound input by its declared key:
${readLines}
        # Add your computed contribution to the declared output:
        #   outputs.add_gradient(value)
        outputs.add_gradient(0)
`;
}

/**
 * Generates a starter provider implementation from the relationship's currently declared
 * bindings and output key, so authoring a C++/Python relationship begins from a compiling
 * skeleton that already names every value the provider can read from and write to.
 */
export function defaultProviderSource(kind, bindings = [], outputKey = '', title = '') {
    const inputKeys = sanitizedKeys(bindings);
    const trimmedOutputKey = outputKey?.trim() ?? '';
    return kind === 'python'
        ? pythonTemplate(inputKeys, trimmedOutputKey, title)
        : cppTemplate(inputKeys, trimmedOutputKey, title);
}

// A C++ literal for a finite double -- pairs' time/value entries are already validated finite by
// the engine's own parseInferenceCsv() (this function's caller only ever feeds it data that
// already passed causal inference), but toString() on a bare double can still produce forms
// (e.g. "1e-7") that read fine here since C++ accepts the same scientific-notation syntax as JS.
function cppDoubleLiteral(value) {
    return Object.is(value, -0) ? '-0.0' : String(value);
}

/**
 * Generates a no-bindings, `setsValue` C++ source term that replays one CSV column's own recorded
 * (time, value) samples exactly, rather than fitting a model to it -- for a column causal
 * inference found nothing predicting (see docs/proposals/causalInferenceInputReplay.md). Each
 * evaluate() call emits the linearly-interpolated value between the two recorded samples
 * straddling the current simulation time; the caller marks the owning source term `setsValue:
 * true` (docs/projectSchema.md), so the engine writes that value directly into the state every
 * substep instead of integrating it as a derivative. This is exact at any substep count and,
 * unlike an earlier version of this generator that emitted the interval's local slope for the
 * engine to Euler-integrate, has no dependency on the state's starting value ever being exactly
 * right -- there is nothing to integrate from, so a wrong initial value can never leave a
 * permanent offset the way it could under the derivative-based approach. Past the last recorded
 * sample (and before the first), the value holds at its last/first known point rather than
 * extrapolating.
 *
 * pairs: [{ time, value }, ...] in chronological row order, already regularly spaced (the same
 * guarantee parseInferenceCsv enforces on its input). Requires at least 2 samples -- interpolation
 * needs two points, and a `double[]` embedded with zero entries is a compiler extension, not
 * standard C++ (confirmed: clang accepts it but flags it under -Wpedantic, which this project's
 * engine build enables) -- rejected outright rather than silently emitting that.
 */
export function replayProviderSource(columnName, pairs, title) {
    if (!Array.isArray(pairs) || pairs.length < 2) {
        throw new Error(`replayProviderSource needs at least 2 recorded samples for "${columnName}", got ${pairs?.length ?? 0}.`);
    }
    const { id, name, className } = providerIdentity(title || columnName);
    const times = pairs.map((pair) => cppDoubleLiteral(pair.time)).join(', ');
    const values = pairs.map((pair) => cppDoubleLiteral(pair.value)).join(', ');
    return `#include <konjugate/relationshipProvider.hpp>

#include <cstddef>
#include <memory>

namespace {

// Recorded "${columnName}" samples from the imported CSV, chronological and regularly spaced.
constexpr double kTimes[] = { ${times} };
constexpr double kValues[] = { ${values} };
constexpr std::size_t kSampleCount = sizeof(kTimes) / sizeof(kTimes[0]);

class ${className} final : public konjugate::sdk::v1::RelationshipProvider {
public:
    konjugate::sdk::v1::RelationshipDescription describe() const override {
        return {
            "${id}",
            "${name}",
            {},
            konjugate::sdk::v1::ScalarPort{"output", "output", ""}
        };
    }

    void evaluate(const konjugate::sdk::v1::EvaluationContext& context,
                  konjugate::sdk::v1::OutputCollector& output) override {
        if (kSampleCount < 2) { output.addGradient(kValues[0]); return; }
        const double rowTimeStep = kTimes[1] - kTimes[0];
        // position is dimensionless (row-index units), so a fixed small nudge here is safe
        // regardless of the CSV's own absolute time scale or sampling interval. Needed because
        // the caller's own accumulated simulationTime can drift a hair off an exact recorded
        // sample time (e.g. summing 0.2 five times does not land on exactly 1.0 in double
        // precision) -- both range boundaries below and the interior interval lookup all derive
        // from this one nudged value, so "just before the end" and "just past an interior
        // boundary" get the same tolerant treatment rather than two independently-tuned checks
        // drifting out of sync with each other. See docs/proposals/causalInferenceInputReplay.md.
        const double position = (context.simulationTime - kTimes[0]) / rowTimeStep + 1e-6;
        // Before the first recorded sample, or past the last one (any run longer than the CSV's
        // own recorded span will reach this): hold at the nearest known point rather than
        // extrapolating.
        if (position < 0) { output.addGradient(kValues[0]); return; }
        if (position >= kSampleCount - 1) { output.addGradient(kValues[kSampleCount - 1]); return; }
        std::size_t index = static_cast<std::size_t>(position);
        if (index >= kSampleCount - 1) index = kSampleCount - 2;
        const double fraction = position - static_cast<double>(index);
        output.addGradient(kValues[index] + fraction * (kValues[index + 1] - kValues[index]));
    }
};

}

std::unique_ptr<konjugate::sdk::v1::RelationshipProvider> createRelationshipProvider() {
    return std::make_unique<${className}>();
}
`;
}

/**
 * A starter computational-node provider (a node's own program): it reads every declared input by its key and adds
 * to every declared output, and keeps no state of its own, so checkpoint() is empty. A program that keeps state (a
 * controller's integral, say) saves it in checkpoint() and reads it back in restore(), so forks and resumed runs
 * carry on exactly.
 */
export function defaultNodeProviderSource(kind, inputs = [], outputs = [], title = '') {
    const inputKeys = sanitizedKeys(inputs);
    const outputKeys = sanitizedKeys(outputs);
    const { id, name, className } = providerIdentity(title || 'Node');
    if (kind === 'python') {
        const ports = (keys) => keys.map((key) => `                ScalarPort("${key}", "${key}", ""),`).join('\n') || '                # None declared yet.';
        return `from konjugate import NodeProvider, NodeProviderDescription, ScalarPort


class ${className}(NodeProvider):
    def describe(self):
        return NodeProviderDescription(
            "${id}",
            "${name}",
            [
${ports(inputKeys)}
            ],
            [
${ports(outputKeys)}
            ],
        )

    def evaluate(self, context, inputs, outputs):
        # Each input by its key (context.simulation_time and context.step_size are there too):
${(inputKeys.length ? inputKeys : ['key']).map((key) => `        #   ${key} = inputs["${key}"]`).join('\n')}
        # Each output: a rate added to its state, or the state's value when the output sets the value.
${outputKeys.length ? outputKeys.map((key) => `        outputs.add_gradient("${key}", 0.0)`).join('\n') : '        pass'}

    def checkpoint(self):
        return b""

    def restore(self, payload):
        pass
`;
    }
    const ports = (keys) => keys.map((key) => `                konjugate::sdk::v1::ScalarPort{"${key}", "${key}", ""}`).join(',\n') || '                // None declared yet.';
    return `#include <konjugate/relationshipProvider.hpp>

#include <memory>

namespace {

class ${className} final : public konjugate::sdk::v1::NodeProvider {
public:
    konjugate::sdk::v1::NodeProviderDescription describe() const override {
        return {
            "${id}",
            "${name}",
            {
${ports(inputKeys)}
            },
            {
${ports(outputKeys)}
            }
        };
    }

    void evaluate(const konjugate::sdk::v1::EvaluationContext& context,
                  konjugate::sdk::v1::NodeOutputCollector& outputs) override {
        // Each input by its key (context.simulationTime and context.stepSize are there too):
${(inputKeys.length ? inputKeys : ['key']).map((key) => `        //   const double ${key} = context.inputs.at("${key}");`).join('\n')}
        // Each output: a rate added to its state, or the state's value when the output sets the value.
${outputKeys.map((key) => `        outputs.addGradient("${key}", 0.0);`).join('\n') || '        (void)context;'}
        (void)outputs;
    }

    std::vector<std::byte> checkpoint() const override { return {}; }
    void restore(std::span<const std::byte>) override {}
};

}

std::unique_ptr<konjugate::sdk::v1::NodeProvider> createNodeProvider() {
    return std::make_unique<${className}>();
}
`;
}
