/* Copyright © 2026 Zenin Easa Panthakkalakath */

#include "simulationRunner.hpp"
#include "engineProtocol.pb.h"
#include "dependencyGraph.hpp"
#include "duringRunStabilityMonitor.hpp"
#include "executionBackend.hpp"
#include "executionPlan.hpp"
#include "partitionPlan.hpp"
#include "partitionRuntime.hpp"
#include "providerRuntime.hpp"
#include "taskExecutor.hpp"
#include <algorithm>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <future>
#include <memory>
#include <mutex>
#include <numeric>
#include <openssl/evp.h>
#include <random>
#include <set>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

namespace konjugate {
namespace {
void writeFramedEvent(std::ostream& output, const protocol::EngineEvent& event) {
    const auto size = event.ByteSizeLong();
    if (size > 0xffffffffu) throw std::runtime_error("The protocol event is too large.");
    const unsigned char header[4] = {
        static_cast<unsigned char>((size >> 24) & 0xff), static_cast<unsigned char>((size >> 16) & 0xff),
        static_cast<unsigned char>((size >> 8) & 0xff), static_cast<unsigned char>(size & 0xff)
    };
    output.write(reinterpret_cast<const char*>(header), sizeof(header));
    if (!event.SerializeToOstream(&output)) throw std::runtime_error("Could not serialize the protocol event.");
    output.flush();
}
using Values = StateValues;
struct Sample { double time; Values states; };
// Each entry pairs a computational-node-provider-owning node's id with that provider instance's
// opaque checkpoint() payload. Empty for a plan with no computational-node providers.
using ProviderCheckpointStates = std::vector<std::pair<EntityId, std::vector<std::byte>>>;
struct Checkpoint { std::string uuid; double time; Values states; ProviderCheckpointStates providerStates; };
enum class PacingMode { fastest, realTime, limitedRatio };
enum class RunState { running, paused, stopped };
struct Pacing { PacingMode mode = PacingMode::fastest; double ratio = 1; };
struct RunControl {
    Pacing pacing;
    RunState executionState = RunState::running;
    EntityValues parameterValues;
    // Appended to, never overwritten -- see ParameterSchedule's own doc comment for why more than
    // one schedule per parameter is expected (a later intervention layered onto an earlier one).
    std::vector<ParameterSchedule> activeSchedules;
};
struct ControlInbox {
    std::mutex mutex;
    std::vector<protocol::EngineCommand> commands;
    std::string error;
};
struct ExecutionSettings {
    ExecutionBackend requestedBackend = ExecutionBackend::automatic;
    ExecutionBackend backend = ExecutionBackend::serial;
    std::size_t workerThreads = 1;
    std::size_t estimatedOperationsPerSynchronization = 0;
    std::size_t automaticParallelThreshold = 128;
};
struct NodeRuntimeMetrics {
    std::uint64_t invocations = 0;
    std::uint64_t executedSubsteps = 0;
    std::uint64_t evaluatedContributions = 0;
    std::uint64_t computeNanoseconds = 0;
};

EntityId entityIdValue(const boost::property_tree::ptree& tree, const std::string& key) {
    const auto text = tree.get<std::string>(key, "");
    std::size_t consumed = 0;
    const auto result = std::stoull(text, &consumed);
    if (!result || result > 9007199254740991ULL || consumed != text.size()) {
        throw std::runtime_error("Model ids must be positive safe integers.");
    }
    return result;
}

// A restart checkpoint is plain JSON, which has no native bytes type, so a computational-node
// provider's opaque checkpoint payload travels as base64 text -- same convention already used for
// the encrypted-project container header in projectContainer.cpp, though that helper is
// fixed-size-only and local to a different translation unit, hence this small counterpart.
std::vector<std::byte> decodeBase64Bytes(const std::string& encoded) {
    if (encoded.empty()) return {};
    if (encoded.size() % 4) {
        throw std::runtime_error("A computational-node provider checkpoint payload is not valid base64.");
    }
    std::vector<unsigned char> decoded(encoded.size() / 4 * 3);
    const auto size = EVP_DecodeBlock(decoded.data(), reinterpret_cast<const unsigned char*>(encoded.data()),
        static_cast<int>(encoded.size()));
    if (size < 0) throw std::runtime_error("A computational-node provider checkpoint payload is not valid base64.");
    std::size_t actual = static_cast<std::size_t>(size);
    if (encoded.ends_with("==")) actual -= 2;
    else if (encoded.ends_with("=")) actual -= 1;
    decoded.resize(actual);
    std::vector<std::byte> bytes(decoded.size());
    std::transform(decoded.begin(), decoded.end(), bytes.begin(),
        [](unsigned char byte) { return static_cast<std::byte>(byte); });
    return bytes;
}

PacingMode pacingModeFromString(const std::string& value) {
    if (value == "fastest") return PacingMode::fastest;
    if (value == "realTime") return PacingMode::realTime;
    if (value == "limitedRatio") return PacingMode::limitedRatio;
    throw std::runtime_error("Pacing mode must be fastest, realTime, or limitedRatio.");
}

std::string_view pacingModeName(PacingMode value) noexcept {
    switch (value) {
        case PacingMode::fastest: return "fastest";
        case PacingMode::realTime: return "realTime";
        case PacingMode::limitedRatio: return "limitedRatio";
    }
    return "fastest";
}

std::string createUuid() {
    static thread_local std::mt19937_64 generator(std::random_device{}());
    std::uniform_int_distribution<unsigned int> octet(0, 255);
    unsigned int bytes[16];
    for (auto& byte : bytes) byte = octet(generator);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    std::ostringstream value;
    value << std::hex << std::setfill('0');
    for (std::size_t index = 0; index < 16; ++index) {
        if (index == 4 || index == 6 || index == 8 || index == 10) value << '-';
        value << std::setw(2) << bytes[index];
    }
    return value.str();
}

std::string escape(const std::string& input) {
    std::string output;
    for (const char character : input) {
        if (character == '\\' || character == '"') output += '\\';
        output += character;
    }
    return output;
}

void atomicWrite(const std::filesystem::path& path, const std::string& content) {
    const auto temporary = path.string() + ".tmp";
    std::ofstream stream(temporary, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("The simulation result could not be created.");
    stream << content;
    stream.close();
    std::error_code error;
    std::filesystem::rename(temporary, path, error);
    if (error) {
        std::filesystem::remove(path, error);
        std::filesystem::rename(temporary, path);
    }
}

Pacing pacingFromTree(const boost::property_tree::ptree& tree, const Pacing& fallback = {}) {
    Pacing pacing;
    pacing.mode = pacingModeFromString(tree.get<std::string>(
        "pacing.mode", tree.get<std::string>("mode", std::string(pacingModeName(fallback.mode)))));
    pacing.ratio = tree.get<double>("pacing.simulationSecondsPerWallSecond",
        tree.get<double>("simulationSecondsPerWallSecond", fallback.ratio));
    if (pacing.mode == PacingMode::realTime) pacing.ratio = 1;
    if (pacing.mode == PacingMode::limitedRatio && (!(pacing.ratio > 0) || !std::isfinite(pacing.ratio))) {
        throw std::runtime_error("Limited pacing requires a finite positive simulationSecondsPerWallSecond value.");
    }
    return pacing;
}

// A pacing wait, used below both for the paused-state poll and the real-time/limited-ratio
// per-step throttle. On every platform except the web build this is a plain
// std::this_thread::sleep_for(), a real, ordinary blocking call. Under Emscripten's pthread
// support specifically, that call was confirmed (directly, via a real live run in a real browser)
// to hang indefinitely for any non-negligible duration: the thread that instantiates a
// MODULARIZE'd module -- a dedicated Worker for every caller in this codebase (src/
// webEngineLiveRunWorker.mjs et al.), never the page's own thread -- is still treated by
// Emscripten's pthread support as ITS OWN distinct "main runtime thread", a role that does not
// support genuine blocking the way an ordinary pthread worker does. -sPROXY_TO_PTHREAD=1 is
// Emscripten's textbook fix for exactly this class of problem (it moves callMain() itself onto a
// real, dedicated proxy pthread where blocking works normally) -- also confirmed directly, and
// also confirmed to regress ordinary Module.FS-based batch runs/validate (they started failing
// with ErrnoError: No such file or directory) at the same time, an unacceptable tradeoff for a
// real-time-pacing-only problem, so it is not used. A plain busy-wait against a monotonic clock
// sidesteps the whole question: it needs no blocking primitive at all, so it behaves identically
// regardless of which thread runs it, at the cost of spinning one core for the wait's duration:
// each individual call is capped at a few tens of milliseconds, which is the whole cost for the
// real-time/limited-ratio per-step throttle (bounded by the run's own length), but the
// paused-state poll calls this repeatedly for as long as a web-edition run stays paused, meaning
// this Worker's core stays pegged at 100% for the entire pause, not just each 40ms slice of it --
// a real, known, accepted cost on the web build specifically, not a correctness problem (nothing
// elsewhere on the page is affected; pausing a run natively is unaffected, since this branch never
// compiles in there).
void pacingWait(std::chrono::milliseconds duration) {
#ifdef __EMSCRIPTEN__
    const auto deadline = std::chrono::steady_clock::now() + duration;
    while (std::chrono::steady_clock::now() < deadline) {}
#else
    std::this_thread::sleep_for(duration);
#endif
}

// Validates and pushes one already-length-delimited command frame's payload into inbox, tracking
// previousSequence the same way across calls a caller must maintain -- shared by both the
// native-shaped, thread-plus-blocking-stream reader below and the web build's own polling reader
// (see pollEmscriptenControlBytes()), which differ only in how the raw framed bytes arrive, not in
// how a frame's payload is validated or queued.
void handleControlCommandPayload(const char* payload, std::size_t size, ControlInbox& inbox, std::uint64_t& previousSequence) {
    protocol::EngineCommand command;
    if (!command.ParseFromArray(payload, static_cast<int>(size)) ||
        command.protocol_version() != 1 || !command.sequence() || command.sequence() <= previousSequence ||
        command.payload_case() == protocol::EngineCommand::PAYLOAD_NOT_SET) {
        std::lock_guard lock(inbox.mutex);
        inbox.error = "The engine received an invalid, unsupported or out-of-order command.";
        return;
    }
    previousSequence = command.sequence();
    std::lock_guard lock(inbox.mutex);
    inbox.commands.push_back(std::move(command));
}

#ifdef __EMSCRIPTEN__
extern "C" {
// Synchronously drains and returns whatever command bytes are currently queued (possibly zero) in
// the live-run job's SharedArrayBuffer-backed ring buffer -- see src/webEngineStdinBuffer.mjs's
// drainStdinBytes() and src/webEngineLiveRunWorker.mjs, which writes this Worker's stdinRing
// reference into Module.controlStreamRing before callMain() runs. Never blocks: unlike the
// native pipe transport's dedicated reader thread, this is called from
// pollEmscriptenControlBytes() below, itself called from the SAME thread running the whole
// simulation loop (see that function's own header comment for why), so it must return
// immediately with whatever is available, exactly like every other per-step check in that loop.
EM_JS(unsigned char*, wasmDrainControlBytes, (int* outLen), {
    if (typeof Module.drainControlStreamBytes !== 'function') {
        HEAP32[outLen >> 2] = 0;
        return 0;
    }
    const bytes = Module.drainControlStreamBytes();
    if (!bytes || bytes.length === 0) {
        HEAP32[outLen >> 2] = 0;
        return 0;
    }
    const buffer = _malloc(bytes.length);
    HEAPU8.set(bytes, buffer);
    HEAP32[outLen >> 2] = bytes.length;
    return buffer;
});
}

// The web build's control-stream reader: docs/proposals/webEdition.md's live-run design initially
// reused the native pipe transport's own std::cin/startControlReader() thread unchanged (matching
// this file's own "no engine changes needed" original plan), on the theory that a real std::thread
// under Emscripten's pthread support becomes a genuine separate Worker whose blocking stdin read
// would work exactly like a native blocking pipe read. Confirmed FALSE by direct testing in a real
// browser: Module.stdin was never invoked at all, and pause/setPacing/setParameterValue commands
// were silently dropped (no error -- the reader thread's own read() call is itself proxied back to
// whichever thread owns Emscripten's FS/TTY state, normally the thread that instantiated the
// module -- but that thread is THIS thread, permanently busy running the very simulation loop the
// proxied call would need to interrupt to be serviced, so it can never actually complete).
// -sPROXY_TO_PTHREAD=1 (Emscripten's textbook fix for "my code needs to block on what would
// otherwise be the main thread") was also tried and also confirmed broken, differently: it made
// ordinary Module.FS-based batch runs/validate fail outright. A synchronous EM_JS poll sidesteps
// the whole question the same way emitEngineEvent (engine/src/main.cpp) already does for the
// output direction: no blocking primitive, no separate thread, no thread-ownership question --
// just a plain, non-blocking, same-thread call, made from inside the main loop's own existing
// per-step refreshRunControl() poll (already gated on the same ~10ms cadence a real read would
// have imposed a syscall's worth of overhead for anyway).
struct EmscriptenControlBuffer {
    std::string pending;
    std::uint64_t previousSequence = 0;
};

void pollEmscriptenControlBytes(ControlInbox& inbox, EmscriptenControlBuffer& buffer) {
    int length = 0;
    unsigned char* bytes = wasmDrainControlBytes(&length);
    if (bytes && length > 0) {
        buffer.pending.append(reinterpret_cast<const char*>(bytes), static_cast<std::size_t>(length));
        std::free(bytes);
    }
    while (buffer.pending.size() >= 4) {
        const auto& header = buffer.pending;
        const auto size = (static_cast<std::uint32_t>(static_cast<unsigned char>(header[0])) << 24) |
            (static_cast<std::uint32_t>(static_cast<unsigned char>(header[1])) << 16) |
            (static_cast<std::uint32_t>(static_cast<unsigned char>(header[2])) << 8) |
             static_cast<std::uint32_t>(static_cast<unsigned char>(header[3]));
        if (!size || size > 1024 * 1024) {
            std::lock_guard lock(inbox.mutex);
            inbox.error = "The engine command frame has an invalid size.";
            return;
        }
        if (buffer.pending.size() < 4 + static_cast<std::size_t>(size)) return; // wait for the rest of this frame
        handleControlCommandPayload(buffer.pending.data() + 4, size, inbox, buffer.previousSequence);
        buffer.pending.erase(0, 4 + size);
    }
}
#endif

// stream must outlive the whole process -- see runSimulation()'s doc comment in
// simulationRunner.hpp. The thread below is deliberately detached rather than joined: joining it
// would mean blocking runSimulation()'s return on stream->read() reaching EOF or an error, which
// for the real caller (stdin, piped from a parent process) may never happen on a clean, one-shot
// successful run if the parent never closes its write end -- exactly the deadlock main.cpp's own
// std::_Exit() comment works around on the shutdown side. Detaching is the reason stream's
// lifetime requirement is "the whole process" rather than "until runSimulation() returns". Never
// actually used on the web build (see pollEmscriptenControlBytes() above for why), so it is
// excluded there entirely rather than left as unreachable dead code.
#ifndef __EMSCRIPTEN__
std::shared_ptr<ControlInbox> startControlReader(std::istream* stream) {
    auto inbox = std::make_shared<ControlInbox>();
    if (!stream) return inbox;
    std::thread([stream, inbox] {
        std::uint64_t previousSequence = 0;
        while (true) {
            unsigned char header[4];
            stream->read(reinterpret_cast<char*>(header), sizeof(header));
            const auto headerBytes = stream->gcount();
            if (!headerBytes && stream->eof()) return;
            if (headerBytes != static_cast<std::streamsize>(sizeof(header))) {
                std::lock_guard lock(inbox->mutex);
                inbox->error = "The engine command stream ended inside a frame header.";
                return;
            }
            const auto size = (static_cast<std::uint32_t>(header[0]) << 24) |
                (static_cast<std::uint32_t>(header[1]) << 16) |
                (static_cast<std::uint32_t>(header[2]) << 8) | static_cast<std::uint32_t>(header[3]);
            if (!size || size > 1024 * 1024) {
                std::lock_guard lock(inbox->mutex);
                inbox->error = "The engine command frame has an invalid size.";
                return;
            }
            std::vector<char> payload(size);
            stream->read(payload.data(), static_cast<std::streamsize>(payload.size()));
            if (stream->gcount() != static_cast<std::streamsize>(payload.size())) {
                std::lock_guard lock(inbox->mutex);
                inbox->error = "The engine command stream ended inside a frame payload.";
                return;
            }
            handleControlCommandPayload(payload.data(), payload.size(), *inbox, previousSequence);
        }
    }).detach();
    return inbox;
}
#endif

RunControl drainRunControl(const std::shared_ptr<ControlInbox>& inbox, RunControl current) {
    std::vector<protocol::EngineCommand> commands;
    {
        std::lock_guard lock(inbox->mutex);
        if (!inbox->error.empty()) throw std::runtime_error(inbox->error);
        commands.swap(inbox->commands);
    }
    for (const auto& command : commands) {
        if (command.has_set_pacing()) {
            const auto& update = command.set_pacing();
            if (update.mode() == protocol::PACING_MODE_FASTEST) current.pacing.mode = PacingMode::fastest;
            else if (update.mode() == protocol::PACING_MODE_REAL_TIME) current.pacing.mode = PacingMode::realTime;
            else if (update.mode() == protocol::PACING_MODE_LIMITED_RATIO) current.pacing.mode = PacingMode::limitedRatio;
            else throw std::runtime_error("The engine received an unsupported pacing mode.");
            current.pacing.ratio = current.pacing.mode == PacingMode::realTime ? 1 : update.simulation_seconds_per_wall_second();
            if (!(current.pacing.ratio > 0) || !std::isfinite(current.pacing.ratio)) {
                throw std::runtime_error("The engine received an invalid pacing ratio.");
            }
        } else if (command.has_set_run_state()) {
            const auto state = command.set_run_state().state();
            if (state == protocol::RUN_STATE_RUNNING) current.executionState = RunState::running;
            else if (state == protocol::RUN_STATE_PAUSED) current.executionState = RunState::paused;
            else if (state == protocol::RUN_STATE_STOPPED) current.executionState = RunState::stopped;
            else throw std::runtime_error("The engine received an unsupported run state.");
        } else if (command.has_set_parameter_value()) {
            const auto& update = command.set_parameter_value();
            if (!update.parameter_id() || update.parameter_id() > 9007199254740991ULL || !std::isfinite(update.value())) {
                throw std::runtime_error("The engine received an invalid live parameter value.");
            }
            current.parameterValues[update.parameter_id()] = update.value();
        } else if (command.has_schedule_parameter_value()) {
            const auto& update = command.schedule_parameter_value();
            if (!update.parameter_id() || update.parameter_id() > 9007199254740991ULL) {
                throw std::runtime_error("The engine received an invalid parameter schedule identifier.");
            }
            if (!std::isfinite(update.start_time()) || !std::isfinite(update.duration()) ||
                !std::isfinite(update.target_value()) || !std::isfinite(update.base_value())) {
                throw std::runtime_error("The engine received a non-finite parameter schedule value.");
            }
            ParameterSchedule schedule;
            schedule.parameterId = update.parameter_id();
            schedule.startTime = update.start_time();
            schedule.duration = update.duration();
            schedule.targetValue = update.target_value();
            schedule.baseValue = update.base_value();
            switch (update.mode()) {
            case protocol::PARAMETER_SCHEDULE_MODE_STEP: schedule.mode = ParameterSchedule::Mode::step; break;
            case protocol::PARAMETER_SCHEDULE_MODE_RAMP: schedule.mode = ParameterSchedule::Mode::ramp; break;
            case protocol::PARAMETER_SCHEDULE_MODE_PULSE: schedule.mode = ParameterSchedule::Mode::pulse; break;
            case protocol::PARAMETER_SCHEDULE_MODE_PIECEWISE:
                schedule.mode = ParameterSchedule::Mode::piecewise;
                schedule.samples.reserve(update.samples_size());
                for (const auto& sample : update.samples()) {
                    if (!std::isfinite(sample.time()) || !std::isfinite(sample.value())) {
                        throw std::runtime_error("The engine received a non-finite piecewise parameter schedule sample.");
                    }
                    schedule.samples.emplace_back(sample.time(), sample.value());
                }
                std::sort(schedule.samples.begin(), schedule.samples.end());
                break;
            default:
                throw std::runtime_error("The engine received an unsupported parameter schedule mode.");
            }
            current.activeSchedules.push_back(std::move(schedule));
        }
    }
    return current;
}

ExecutionSettings executionSettingsFromTree(const boost::property_tree::ptree& tree, const ExecutionPlan& plan) {
    ExecutionSettings settings;
    settings.requestedBackend = executionBackendFromString(tree.get<std::string>("execution.backend", "automatic"));
    settings.automaticParallelThreshold = tree.get<std::size_t>("execution.automaticParallelThreshold", 128);
    if (!settings.automaticParallelThreshold || settings.automaticParallelThreshold > 1000000) {
        throw std::runtime_error("execution.automaticParallelThreshold must be an integer from 1 through 1000000.");
    }
    for (const auto& node : plan.nodes) {
        settings.estimatedOperationsPerSynchronization += node.estimatedOperationsPerSubstep * node.substeps;
    }
    const auto hardwareThreads = std::max(1u, std::thread::hardware_concurrency());
    const auto requestedThreads = tree.get<std::size_t>("execution.workerThreads", hardwareThreads);
    if (!requestedThreads || requestedThreads > 256) {
        throw std::runtime_error("execution.workerThreads must be an integer from 1 through 256.");
    }
    settings.backend = settings.requestedBackend;
    settings.workerThreads = settings.requestedBackend == ExecutionBackend::serial
        ? 1 : std::min(requestedThreads, std::max<std::size_t>(1, plan.nodes.size()));
    return settings;
}

}

void runSimulation(const boost::property_tree::ptree& document,
                   const boost::property_tree::ptree& configuration,
                   const std::filesystem::path& outputPath,
                   std::istream* controlStream,
                   std::ostream* eventStream) {
    const auto targetTime = configuration.get<double>("targetTime");
    const auto globalTimeStep = configuration.get<double>("globalTimeStep", configuration.get<double>("timeStep", 0.01));
    const auto outputInterval = configuration.get<double>("outputInterval", globalTimeStep);
    const auto outputRatio = outputInterval / globalTimeStep;
    auto pacing = pacingFromTree(configuration);
    RunControl runControl{pacing, RunState::running, {}};
#ifdef __EMSCRIPTEN__
    // See pollEmscriptenControlBytes()'s own header comment for why the web build never spawns
    // startControlReader()'s thread at all here (not just why it wouldn't work): a thread that can
    // never make progress would otherwise permanently occupy one of a finite number of pthread
    // pool slots for the rest of the run, competing with slots parallel execution may need.
    static_cast<void>(controlStream); // never read on the web build -- see pollEmscriptenControlBytes() above
    const auto controlInbox = std::make_shared<ControlInbox>();
    EmscriptenControlBuffer emscriptenControlBuffer;
#else
    const auto controlInbox = startControlReader(controlStream);
#endif
    if (!(targetTime > 0) || !(globalTimeStep > 0) || globalTimeStep > targetTime || !(outputInterval > 0) ||
        !std::isfinite(targetTime) || !std::isfinite(globalTimeStep) || !std::isfinite(outputInterval)) {
        throw std::runtime_error("A run requires a finite positive targetTime and numerical timestep values.");
    }
    if (outputInterval < globalTimeStep || std::abs(outputRatio - std::round(outputRatio)) > 1e-9) {
        throw std::runtime_error("outputInterval must be an integer multiple of globalTimeStep.");
    }

    const auto planningStartedAt = std::chrono::steady_clock::now();
    const auto executionPlan = compileExecutionPlan(document);
    ProviderConfiguration providerConfig;
    if (const auto providers = configuration.get_child_optional("providers")) {
        providerConfig.cppCompiler = providers->get<std::string>("cpp.compiler", "");
        providerConfig.cppSdkPath = providers->get<std::string>("cpp.sdkPath", "");
        providerConfig.pythonInterpreter = providers->get<std::string>("python.interpreter", "");
        providerConfig.pythonSdkPath = providers->get<std::string>("python.sdkPath", "");
        providerConfig.buildDirectory = providers->get<std::string>("buildDirectory", "");
        // See ProviderExecutionMode. Absent or unrecognized always defaults to the
        // always-available pipe transport.
        const auto executionModeText = providers->get<std::string>("executionMode", "");
        providerConfig.executionMode = executionModeText == "inProcess" ? ProviderExecutionMode::inProcess
            : executionModeText == "sharedMemoryWorker" ? ProviderExecutionMode::sharedMemoryWorker
            : ProviderExecutionMode::pipeWorker;
    }
    std::unique_ptr<ProviderRuntime> providerRuntime;
    if (planRequiresProviders(executionPlan)) {
        providerRuntime = std::make_unique<ProviderRuntime>(providerConfig);
        providerRuntime->initialize(executionPlan);
    }
    const auto dependencyGraph = buildDependencyGraph(executionPlan);
    auto executionSettings = executionSettingsFromTree(configuration, executionPlan);
    const auto requestedPartitions = configuration.get<std::size_t>("execution.partitionCount", executionSettings.workerThreads);
    if (!requestedPartitions || requestedPartitions > 256) {
        throw std::runtime_error("Partition count must be an integer from 1 through 256.");
    }
    const auto executablePartitions = executionSettings.requestedBackend == ExecutionBackend::partitioned ||
        executionSettings.requestedBackend == ExecutionBackend::automatic
        ? std::min(requestedPartitions, executionSettings.workerThreads) : requestedPartitions;
    const auto communicationBias = configuration.get<double>("execution.partitionCommunicationBias", 4);
    const auto partitionAlgorithm = configuration.get<std::string>("execution.partitionAlgorithm", "automatic");
    auto partitionPlan = createPartitionPlan(dependencyGraph, executablePartitions, communicationBias, partitionAlgorithm);
    partitionPlan.requestedPartitions = requestedPartitions;
    const auto totalCommunicationWeight = std::accumulate(
        dependencyGraph.dependencies.begin(), dependencyGraph.dependencies.end(), std::size_t{0},
        [](std::size_t total, const auto& dependency) { return total + dependency.communicationWeight; });
    const auto maximumPartitionCutFraction = configuration.get<double>("execution.automaticMaximumPartitionCutFraction", 0.25);
    const auto backendDecision = selectExecutionBackend(
        executionSettings.requestedBackend, executionPlan.nodes.size(),
        executionSettings.estimatedOperationsPerSynchronization, executionSettings.automaticParallelThreshold,
        partitionPlan.selected.communicationCutWeight, totalCommunicationWeight, maximumPartitionCutFraction);
    executionSettings.backend = backendDecision.backend;
#if defined(__EMSCRIPTEN__) && !defined(__EMSCRIPTEN_PTHREADS__)
    // The default web build (docs/proposals/webEdition.md's "web" preset) has no pthread
    // support at all -- TaskExecutor/PartitionRuntime constructing real std::threads there
    // aborts the whole WASM instance rather than throwing a catchable C++ exception. Only the
    // separate "web-threads" preset (-pthread, a different vcpkg triplet) defines
    // __EMSCRIPTEN_PTHREADS__. Same fail-loud-on-explicit/quietly-downgrade-on-automatic
    // convention as the node-provider/partitioned case just below.
    if (executionSettings.backend == ExecutionBackend::threadPool || executionSettings.backend == ExecutionBackend::partitioned) {
        if (executionSettings.requestedBackend != ExecutionBackend::automatic) {
            throw std::runtime_error("The threadPool and partitioned execution backends require the pthread-enabled web build "
                "(see docs/proposals/webEdition.md's \"web-threads\" preset); this build has no thread support.");
        }
        executionSettings.backend = ExecutionBackend::serial;
    }
#endif
    // Computational-node providers work through the partitioned backend "for free" -- it calls
    // the same evaluateContributionTasks() as serial/threadPool -- but are untested there this
    // release (see docs/pluginDevelopment.md). An explicit request fails loudly; an automatic
    // choice quietly downgrades to threadPool, which is fully supported.
    if (executionSettings.backend == ExecutionBackend::partitioned &&
        std::any_of(executionPlan.nodes.begin(), executionPlan.nodes.end(),
            [](const auto& node) { return node.nodeProvider.has_value(); })) {
        if (executionSettings.requestedBackend == ExecutionBackend::partitioned) {
            throw std::runtime_error("Computational-node providers are not yet supported by the partitioned execution backend.");
        }
        executionSettings.backend = ExecutionBackend::threadPool;
    }
    if (executionSettings.backend == ExecutionBackend::serial) executionSettings.workerThreads = 1;
    const auto planningNanoseconds = static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now() - planningStartedAt).count());
    std::unique_ptr<TaskExecutor> taskExecutor;
    if (executionSettings.backend == ExecutionBackend::threadPool) taskExecutor = std::make_unique<TaskExecutor>(executionSettings.workerThreads);
    std::vector<std::vector<std::size_t>> partitionNodeIndexes;
    std::vector<std::vector<EntityId>> partitionSnapshotStateIds;
    std::vector<std::unique_ptr<PartitionRuntime>> partitionRuntimes;
    std::unique_ptr<InMemoryPartitionTransport> partitionTransport;
    const auto partitionReceiveTimeoutMilliseconds = configuration.get<std::size_t>(
        "execution.partitionReceiveTimeoutMilliseconds", 5000);
    if (!partitionReceiveTimeoutMilliseconds || partitionReceiveTimeoutMilliseconds > 60000) {
        throw std::runtime_error("execution.partitionReceiveTimeoutMilliseconds must be an integer from 1 through 60000.");
    }
    if (executionSettings.backend == ExecutionBackend::partitioned) {
        partitionRuntimes.reserve(partitionPlan.effectivePartitions);
        partitionNodeIndexes.resize(partitionPlan.effectivePartitions);
        partitionSnapshotStateIds.resize(partitionPlan.effectivePartitions);
        std::unordered_map<EntityId, std::size_t> executionNodeIndexes;
        std::unordered_map<EntityId, std::size_t> nodePartitions;
        for (std::size_t index = 0; index < executionPlan.nodes.size(); ++index) {
            executionNodeIndexes[executionPlan.nodes[index].nodeId] = index;
        }
        for (const auto& assignment : partitionPlan.assignments) {
            nodePartitions[assignment.nodeId] = assignment.partition;
            partitionNodeIndexes[assignment.partition].push_back(executionNodeIndexes.at(assignment.nodeId));
        }
        for (std::size_t partition = 0; partition < partitionNodeIndexes.size(); ++partition) {
            std::set<EntityId> snapshotStateIds;
            for (const auto nodeIndex : partitionNodeIndexes[partition]) {
                snapshotStateIds.insert(executionPlan.nodes[nodeIndex].stateIds.begin(), executionPlan.nodes[nodeIndex].stateIds.end());
            }
            for (const auto& dependency : dependencyGraph.dependencies) {
                if (nodePartitions.at(dependency.targetNodeId) == partition) {
                    snapshotStateIds.insert(dependency.remoteStateIds.begin(), dependency.remoteStateIds.end());
                }
            }
            partitionSnapshotStateIds[partition].assign(snapshotStateIds.begin(), snapshotStateIds.end());
        }
        for (std::size_t partition = 0; partition < partitionPlan.effectivePartitions; ++partition) {
            partitionRuntimes.push_back(std::make_unique<PartitionRuntime>(
                partition, executionPlan, partitionNodeIndexes[partition]));
        }
        partitionTransport = std::make_unique<InMemoryPartitionTransport>();
    }
    const auto activeWorkerThreads = executionSettings.backend == ExecutionBackend::partitioned
        ? partitionPlan.effectivePartitions : executionSettings.workerThreads;
    Values states = executionPlan.initialStates;
    const auto& stateNodes = executionPlan.stateNodes;
    std::unordered_map<EntityId, std::size_t> nodeSubsteps;
    for (const auto& node : executionPlan.nodes) {
        nodeSubsteps[node.nodeId] = node.substeps;
    }

    double startTime = 0;
    if (const auto checkpoint = configuration.get_child_optional("startCheckpoint")) {
        startTime = checkpoint->get<double>("time");
        std::set<EntityId> restored;
        for (const auto& stateItem : checkpoint->get_child("states")) {
            const auto stateId = entityIdValue(stateItem.second, "stateId");
            const auto stateIndex = executionPlan.stateIndexes.find(stateId);
            if (stateIndex == executionPlan.stateIndexes.end() || !restored.insert(stateId).second) {
                throw std::runtime_error("The restart checkpoint does not match the model state vector.");
            }
            states[stateIndex->second] = stateItem.second.get<double>("value");
        }
        if (restored.size() != states.size()) throw std::runtime_error("The restart checkpoint is missing model states.");

        // Opaque provider-owned state (e.g. a controller's integral term) has no analog in the
        // ordinary numeric state vector restored above, so it must be restored explicitly and
        // exhaustively: a missing entry fails loudly here rather than silently resetting a
        // provider instance to its initialize()-time default.
        const auto providerNodeCount = std::count_if(executionPlan.nodes.begin(), executionPlan.nodes.end(),
            [](const auto& node) { return node.nodeProvider.has_value(); });
        if (providerNodeCount) {
            const auto providerStatesNode = checkpoint->get_child_optional("providerStates");
            if (!providerStatesNode) {
                throw std::runtime_error("The restart checkpoint is missing computational-node provider state.");
            }
            std::set<EntityId> restoredNodes;
            for (const auto& entry : *providerStatesNode) {
                const auto nodeId = entityIdValue(entry.second, "nodeId");
                const auto nodeIt = std::find_if(executionPlan.nodes.begin(), executionPlan.nodes.end(),
                    [&](const auto& node) { return node.nodeId == nodeId; });
                if (nodeIt == executionPlan.nodes.end() || !nodeIt->nodeProvider || !restoredNodes.insert(nodeId).second) {
                    throw std::runtime_error("The restart checkpoint references an unknown computational-node provider.");
                }
                providerRuntime->requestNodeRestore(*nodeIt->nodeProvider,
                    decodeBase64Bytes(entry.second.get<std::string>("payload", "")));
            }
            if (static_cast<std::size_t>(providerNodeCount) != restoredNodes.size()) {
                throw std::runtime_error("The restart checkpoint is missing computational-node provider state.");
            }
        }
    }
    if (!(startTime >= 0) || !(targetTime > startTime)) throw std::runtime_error("targetTime must be later than the restart checkpoint.");

    const auto& stateIds = executionPlan.stateIds;
    std::vector<EntityId> nodeIds;
    for (const auto& item : nodeSubsteps) nodeIds.push_back(item.first);
    std::sort(nodeIds.begin(), nodeIds.end());

    // A run (or the rest of one, from a checkpoint) that is a whole number of steps, give or take rounding in
    // targetTime - startTime, takes exactly that many full steps: a resumed run then steps exactly as the run it
    // came from, rather than ending on a step a few ulps short.
    const auto stepsExactly = (targetTime - startTime) / globalTimeStep;
    const auto wholeSteps = std::abs(stepsExactly - std::round(stepsExactly)) <= 1e-9 * std::max(1.0, stepsExactly);
    const auto steps = static_cast<std::size_t>(wholeSteps ? std::round(stepsExactly) : std::ceil(stepsExactly));
    std::vector<NodeRuntimeMetrics> nodeMetrics(executionPlan.nodes.size());
    std::uint64_t synchronizationComputeNanoseconds = 0;
    std::uint64_t partitionBoundaryMessages = 0;
    std::uint64_t partitionBoundaryPayloadBytes = 0;
    std::uint64_t partitionMessagePreparationNanoseconds = 0;
    std::uint64_t partitionTransportPublishNanoseconds = 0;
    std::uint64_t partitionBoundaryWaitNanoseconds = 0;
    const auto captureProviderStates = [&]() {
        ProviderCheckpointStates result;
        if (!providerRuntime) return result;
        for (const auto& node : executionPlan.nodes) {
            if (node.nodeProvider) result.emplace_back(node.nodeId, providerRuntime->requestNodeCheckpoint(*node.nodeProvider));
        }
        return result;
    };
    // Algebraic states are set from their expressions before anything is recorded or read, so the
    // first sample, the first checkpoint and every node's first step all see consistent values --
    // after a restart too, where a fork may have changed the parameters they depend on.
    settleAlgebraicStates(executionPlan, states, runControl.parameterValues, startTime, globalTimeStep, providerRuntime.get(), runControl.activeSchedules);
    // And the states algebraic relationships set, across nodes, in dependency order.
    evaluateAlgebraicRelationships(executionPlan, states, runControl.parameterValues, runControl.activeSchedules, startTime);
    std::vector<Sample> samples = {{startTime, states}};
    std::vector<Checkpoint> checkpoints = {{createUuid(), startTime, states, captureProviderStates()}};
    std::vector<Sample> pendingEventSamples;
    // During-run phase of docs/proposals/numericalStabilityDiagnostics.md -- entirely opt-in
    // (empty monitoredNodeIds, the default, makes observeGlobalStep() a no-op below) via the run
    // configuration's own stabilityMonitoring.nodeIds, not a project/schema concept: this is about
    // how THIS run is executed, not what the model is, matching pacing/providers' own placement.
    std::unordered_set<EntityId> stabilityMonitoredNodeIds;
    if (const auto stabilityMonitoring = configuration.get_child_optional("stabilityMonitoring.nodeIds")) {
        for (const auto& entry : *stabilityMonitoring) stabilityMonitoredNodeIds.insert(entry.second.get_value<EntityId>());
    }
    DuringRunStabilityMonitor stabilityMonitor(executionPlan, stabilityMonitoredNodeIds, globalTimeStep);
    std::vector<DuringRunStabilityFinding> stabilityFindings;
    if (eventStream) {
        protocol::EngineEvent event;
        event.set_protocol_version(1);
        auto* table = event.mutable_state_table();
        for (const auto stateId : stateIds) table->add_states()->set_state_id(stateId);
        writeFramedEvent(*eventStream, event);
    }
    const auto flushSampleEvents = [&]() {
        if (!eventStream || pendingEventSamples.empty()) return;
        protocol::EngineEvent event;
        event.set_protocol_version(1);
        auto* batch = event.mutable_sample_batch();
        batch->set_state_count(static_cast<std::uint32_t>(stateIds.size()));
        constexpr std::size_t maximumLiveBatchSamples = 256;
        const auto transmittedSamples = std::min(pendingEventSamples.size(), maximumLiveBatchSamples);
        for (std::size_t outputIndex = 0; outputIndex < transmittedSamples; ++outputIndex) {
            const auto sampleIndex = transmittedSamples == 1 ? std::size_t{0} : static_cast<std::size_t>(std::llround(
                static_cast<double>(outputIndex) * static_cast<double>(pendingEventSamples.size() - 1) /
                static_cast<double>(transmittedSamples - 1)));
            const auto& sample = pendingEventSamples[sampleIndex];
            batch->add_times(sample.time);
            for (const auto stateId : stateIds) {
                batch->add_values(sample.states.at(executionPlan.stateIndexes.at(stateId)));
            }
        }
        writeFramedEvent(*eventStream, event);
        pendingEventSamples.clear();
    };
    const auto appendStreamRecord = [&](const std::string& type, double time, const Values& recordStates, const std::string& uuid = {}) {
        if (eventStream && type == "sample") {
            pendingEventSamples.push_back({time, recordStates});
        }
        static_cast<void>(uuid);
    };
    appendStreamRecord("sample", startTime, states);
    appendStreamRecord("checkpoint", startTime, states, checkpoints.front().uuid);
    double currentTime = startTime;
    const auto captureBoundary = [&]() {
        if (currentTime > samples.back().time + 1e-12) {
            samples.push_back({currentTime, states});
            appendStreamRecord("sample", currentTime, states);
        }
        if (currentTime > checkpoints.back().time + 1e-12) {
            checkpoints.push_back({createUuid(), currentTime, states, captureProviderStates()});
            appendStreamRecord("checkpoint", currentTime, states, checkpoints.back().uuid);
        }
    };
    const auto writeResult = [&](const std::string& lifecycle, double simulationTime, bool completeSnapshot = false) {
        flushSampleEvents();
        std::ostringstream json;
        json << std::setprecision(17) << "{\"resultVersion\":2,\"engineVersion\":\"0.2.0\",\"configurationName\":\""
             << escape(configuration.get<std::string>("name", "Untitled")) << "\",\"snapshotMode\":\"" << (completeSnapshot ? "full" : "live")
             << "\",\"lifecycle\":\"" << lifecycle
             << "\",\"simulationTime\":" << simulationTime << ",\"availableResultTime\":" << samples.back().time
             << ",\"pacing\":{\"mode\":\"" << pacingModeName(pacing.mode) << "\",\"simulationSecondsPerWallSecond\":" << pacing.ratio << "}"
             << ",\"targetTime\":" << targetTime << ",\"globalTimeStep\":" << globalTimeStep << ",\"outputInterval\":" << outputInterval
             << ",\"execution\":{\"planVersion\":1,\"requestedBackend\":\"" << executionBackendName(executionSettings.requestedBackend)
             << "\",\"backend\":\"" << executionBackendName(executionSettings.backend)
             << "\",\"workerThreads\":" << activeWorkerThreads << ",\"planningNanoseconds\":" << planningNanoseconds
             << ",\"estimatedOperationsPerSynchronization\":" << executionSettings.estimatedOperationsPerSynchronization
             << ",\"automaticParallelThreshold\":" << executionSettings.automaticParallelThreshold
             << ",\"selectionReason\":\"" << backendSelectionReasonName(backendDecision.reason) << "\",\"communicationCutFraction\":"
             << backendDecision.communicationCutFraction << ",\"automaticMaximumPartitionCutFraction\":"
             << maximumPartitionCutFraction
             << ",\"schedulingPolicy\":\"" << (executionSettings.backend == ExecutionBackend::partitioned
                 ? "partitionAffinity" : "largestEstimatedWorkFirst")
             << "\",\"synchronizationComputeNanoseconds\":"
             << synchronizationComputeNanoseconds << ",\"partitionCommunication\":{\"messageVersion\":1,\"transport\":\"inMemory\""
             << ",\"boundaryMessages\":" << partitionBoundaryMessages << ",\"boundaryPayloadBytes\":"
             << partitionBoundaryPayloadBytes << ",\"messagePreparationNanoseconds\":"
             << partitionMessagePreparationNanoseconds << ",\"serializationNanoseconds\":0,\"transportPublishNanoseconds\":"
             << partitionTransportPublishNanoseconds << ",\"boundaryWaitNanoseconds\":"
             << partitionBoundaryWaitNanoseconds << "},\"nodeMetrics\":[";
        for (std::size_t index = 0; index < executionPlan.nodes.size(); ++index) {
            if (index) json << ',';
            const auto& node = executionPlan.nodes[index];
            const auto& metrics = nodeMetrics[index];
            json << "{\"nodeId\":" << node.nodeId << ",\"estimatedOperationsPerSubstep\":"
                 << node.estimatedOperationsPerSubstep << ",\"invocations\":" << metrics.invocations
                 << ",\"executedSubsteps\":" << metrics.executedSubsteps << ",\"evaluatedContributions\":"
                 << metrics.evaluatedContributions << ",\"computeNanoseconds\":" << metrics.computeNanoseconds << '}';
        }
        json << "]},\"dependencyGraph\":{\"version\":" << dependencyGraph.version << ",\"componentCount\":"
             << dependencyGraph.componentCount << ",\"nodes\":[";
        for (std::size_t index = 0; index < dependencyGraph.nodes.size(); ++index) {
            if (index) json << ',';
            const auto& node = dependencyGraph.nodes[index];
            json << "{\"nodeId\":" << node.nodeId << ",\"stateCount\":" << node.stateCount
                 << ",\"substeps\":" << node.substeps << ",\"estimatedOperationsPerSynchronization\":"
                 << node.estimatedOperationsPerSynchronization << ",\"component\":" << node.component << '}';
        }
        json << "],\"dependencies\":[";
        for (std::size_t index = 0; index < dependencyGraph.dependencies.size(); ++index) {
            if (index) json << ',';
            const auto& dependency = dependencyGraph.dependencies[index];
            json << "{\"sourceNodeId\":" << dependency.sourceNodeId << ",\"targetNodeId\":"
                 << dependency.targetNodeId << ",\"remoteStateIds\":[";
            for (std::size_t stateIndex = 0; stateIndex < dependency.remoteStateIds.size(); ++stateIndex) {
                if (stateIndex) json << ',';
                json << dependency.remoteStateIds[stateIndex];
            }
            json << "],\"contributionTaskCount\":" << dependency.contributionTaskCount << ",\"remoteBindingsPerSubstep\":"
                 << dependency.remoteBindingsPerSubstep << ",\"estimatedDependentOperationsPerSynchronization\":"
                 << dependency.estimatedDependentOperationsPerSynchronization << ",\"communicationWeight\":"
                 << dependency.communicationWeight << '}';
        }
        json << "]},\"partitionPlan\":{\"version\":" << partitionPlan.version << ",\"algorithm\":\""
             << partitionPlan.algorithm << "\",\"algorithmVersion\":\"" << partitionPlan.algorithmVersion
             << "\",\"requestedAlgorithm\":\"" << partitionPlan.requestedAlgorithm
             << "\",\"fallbackReason\":\"" << escape(partitionPlan.fallbackReason)
             << "\",\"metisAvailable\":" << (metisPartitionerAvailable() ? "true" : "false")
             << ",\"requestedPartitions\":" << partitionPlan.requestedPartitions
             << ",\"effectivePartitions\":" << partitionPlan.effectivePartitions << ",\"communicationBias\":"
             << partitionPlan.communicationBias << ",\"assignments\":[";
        for (std::size_t index = 0; index < partitionPlan.assignments.size(); ++index) {
            if (index) json << ',';
            json << "{\"nodeId\":" << partitionPlan.assignments[index].nodeId << ",\"partition\":"
                 << partitionPlan.assignments[index].partition << '}';
        }
        json << "],\"partitions\":[";
        for (std::size_t index = 0; index < partitionPlan.partitions.size(); ++index) {
            if (index) json << ',';
            const auto& partition = partitionPlan.partitions[index];
            json << "{\"partition\":" << partition.partition << ",\"nodeCount\":" << partition.nodeCount
                 << ",\"computeWeight\":" << partition.computeWeight << ",\"localStateCount\":"
                 << partition.localStateCount << ",\"boundaryStateCount\":" << partition.boundaryStateCount << '}';
        }
        const auto appendComparison = [&json](const PartitionComparison& comparison) {
            json << "{\"communicationCutWeight\":" << comparison.communicationCutWeight
                 << ",\"cutDependencyCount\":" << comparison.cutDependencyCount
                 << ",\"computeImbalance\":" << comparison.computeImbalance << '}';
        };
        json << "],\"selected\":";
        appendComparison(partitionPlan.selected);
        json << ",\"greedy\":";
        appendComparison(partitionPlan.greedy);
        json << ",\"roundRobin\":";
        appendComparison(partitionPlan.roundRobin);
        json << '}'
             << ",\"globalSteps\":" << steps << ",\"nodeTimesteps\":[";
        for (std::size_t index = 0; index < nodeIds.size(); ++index) {
            if (index) json << ',';
            const auto& nodeId = nodeIds[index];
            json << "{\"nodeId\":" << nodeId << ",\"substepsPerGlobalStep\":" << nodeSubsteps.at(nodeId)
                 << ",\"effectiveTimeStep\":" << globalTimeStep / static_cast<double>(nodeSubsteps.at(nodeId)) << '}';
        }
        json << "],\"states\":[";
        for (std::size_t index = 0; index < stateIds.size(); ++index) {
            if (index) json << ',';
            const auto& stateId = stateIds[index];
            json << "{\"nodeId\":" << stateNodes.at(stateId) << ",\"stateId\":" << stateId
                 << ",\"value\":" << states.at(executionPlan.stateIndexes.at(stateId)) << '}';
        }
        json << "]}";
        protocol::ResultFile result;
        result.set_result_version(2);
        result.set_metadata_json(json.str());
        for (const auto stateId : stateIds) result.mutable_state_table()->add_states()->set_state_id(stateId);
        // During-run phase of docs/proposals/numericalStabilityDiagnostics.md -- a real protobuf
        // field on ResultFile, not a JSON string: doubles (globalTime, and any future numeric
        // finding data) natively represent Infinity/NaN in protobuf, the same reason the one-shot
        // report messages moved off hand-written JSON (see engineProtocol.proto's own comment on
        // ValidationIssueReport and friends) -- a diverging amplification factor should never be
        // able to produce output a JSON parser rejects outright.
        for (const auto& finding : stabilityFindings) {
            auto* report = result.add_stability_findings();
            report->set_node_id(finding.nodeId);
            report->set_state_id(finding.stateId);
            report->set_code(finding.code);
            report->set_message(finding.message);
            report->set_global_time(finding.globalTime);
        }
        if (completeSnapshot) {
            for (const auto& checkpoint : checkpoints) {
                auto* encoded = result.add_checkpoints();
                encoded->set_uuid(checkpoint.uuid);
                encoded->set_time(checkpoint.time);
                encoded->set_solver_kind("explicitEuler");
                encoded->set_solver_version(1);
                for (const auto stateId : stateIds) {
                    encoded->add_values(checkpoint.states.at(executionPlan.stateIndexes.at(stateId)));
                }
                for (const auto& [nodeId, payload] : checkpoint.providerStates) {
                    auto* providerState = encoded->add_provider_states();
                    providerState->set_node_id(nodeId);
                    providerState->set_payload(std::string(reinterpret_cast<const char*>(payload.data()), payload.size()));
                }
            }
        }
        const auto appendLength = [](std::string& target, std::size_t size) {
            if (size > 0xffffffffu) throw std::runtime_error("A binary result section is too large to serialize.");
            const auto length = static_cast<std::uint32_t>(size);
            target.push_back(static_cast<char>((length >> 24) & 0xff));
            target.push_back(static_cast<char>((length >> 16) & 0xff));
            target.push_back(static_cast<char>((length >> 8) & 0xff));
            target.push_back(static_cast<char>(length & 0xff));
        };
        std::string header;
        if (!result.SerializeToString(&header)) throw std::runtime_error("The binary result header could not be serialized.");
        std::string container("KJR\x02", 4);
        appendLength(container, header.size());
        container += header;
        protocol::ResultIndex index;
        index.set_result_version(2);
        index.set_sample_count(completeSnapshot ? samples.size() : 0);
        constexpr std::size_t samplesPerResultBatch = 4096;
        if (completeSnapshot) {
            for (std::size_t start = 0; start < samples.size(); start += samplesPerResultBatch) {
                const auto end = std::min(samples.size(), start + samplesPerResultBatch);
                protocol::SampleBatch batch;
                batch.set_state_count(static_cast<std::uint32_t>(stateIds.size()));
                for (std::size_t sampleIndex = start; sampleIndex < end; ++sampleIndex) {
                    const auto& sample = samples[sampleIndex];
                    batch.add_times(sample.time);
                    for (const auto stateId : stateIds) {
                        batch.add_values(sample.states.at(executionPlan.stateIndexes.at(stateId)));
                    }
                }
                std::string payload;
                if (!batch.SerializeToString(&payload)) throw std::runtime_error("A result sample batch could not be serialized.");
                auto* entry = index.add_batches();
                entry->set_start_time(samples[start].time);
                entry->set_end_time(samples[end - 1].time);
                entry->set_offset(container.size());
                entry->set_length(static_cast<std::uint32_t>(payload.size()));
                entry->set_sample_count(static_cast<std::uint32_t>(end - start));
                appendLength(container, payload.size());
                container += payload;
            }
        }
        std::string indexPayload;
        if (!index.SerializeToString(&indexPayload)) throw std::runtime_error("The binary result index could not be serialized.");
        container += indexPayload;
        appendLength(container, indexPayload.size());
        container += "KJIX";
        atomicWrite(outputPath, container);
    };
    writeResult("running", startTime);
    auto lastPublishedAt = std::chrono::steady_clock::now();
    auto lastControlReadAt = std::chrono::steady_clock::now() - std::chrono::seconds(1);
    const auto refreshRunControl = [&](bool force = false) {
        const auto now = std::chrono::steady_clock::now();
        if (force || now - lastControlReadAt >= std::chrono::milliseconds(10)) {
#ifdef __EMSCRIPTEN__
            pollEmscriptenControlBytes(*controlInbox, emscriptenControlBuffer);
#endif
            runControl = drainRunControl(controlInbox, std::move(runControl));
            lastControlReadAt = now;
        }
    };
    auto nextOutputTime = startTime + outputInterval;
    for (std::size_t step = 0; step < steps; ++step) {
        refreshRunControl();
        pacing = runControl.pacing;
        if (runControl.executionState == RunState::paused) {
            captureBoundary();
            writeResult("paused", currentTime);
            while (runControl.executionState == RunState::paused) {
                pacingWait(std::chrono::milliseconds(40));
                refreshRunControl(true);
            }
            pacing = runControl.pacing;
            if (runControl.executionState == RunState::stopped) {
                writeResult("stopped", currentTime, true);
                return;
            }
            writeResult("running", currentTime);
        } else if (runControl.executionState == RunState::stopped) {
            captureBoundary();
            writeResult("stopped", currentTime, true);
            return;
        }
        const auto wallStepStarted = std::chrono::steady_clock::now();
        const auto synchronizationStep = wholeSteps || step + 1 < steps
            ? globalTimeStep : std::min(globalTimeStep, targetTime - startTime - static_cast<double>(step) * globalTimeStep);
        const auto synchronizationStartedAt = std::chrono::steady_clock::now();
        const auto snapshot = states;
        auto synchronizedStates = snapshot;
        std::vector<NodeIntegrationResult> nodeResults(executionPlan.nodes.size());
        if (taskExecutor) {
            const auto parameterValues = runControl.parameterValues;
            const auto activeSchedules = runControl.activeSchedules;
            std::vector<std::future<NodeIntegrationResult>> futures;
            futures.reserve(executionPlan.nodes.size());
            futures.resize(executionPlan.nodes.size());
            for (const auto index : executionPlan.taskSubmissionOrder) {
                const auto* nodePlan = &executionPlan.nodes[index];
                futures[index] = taskExecutor->submit([nodePlan, &snapshot, &parameterValues, &activeSchedules, currentTime, synchronizationStep, evaluatorPtr = providerRuntime.get()] {
                    return integrateNode(*nodePlan, snapshot, parameterValues, currentTime, synchronizationStep, evaluatorPtr, activeSchedules);
                });
            }
            for (std::size_t index = 0; index < futures.size(); ++index) nodeResults[index] = futures[index].get();
        } else if (!partitionRuntimes.empty()) {
            // Each partition worker gets the run's active schedules with the live values, so a
            // scheduled parameter intervention (a scenario fork's changes) applies under this
            // backend as it does under serial and thread-pool execution.
            const auto parameterValues = runControl.parameterValues;
            const auto activeSchedules = runControl.activeSchedules;
            for (std::size_t partition = 0; partition < partitionRuntimes.size(); ++partition) {
                const auto preparationStartedAt = std::chrono::steady_clock::now();
                PartitionBoundaryMessage message;
                message.synchronizationIndex = step;
                message.targetPartition = partition;
                message.states.reserve(partitionSnapshotStateIds[partition].size());
                for (const auto& stateId : partitionSnapshotStateIds[partition]) {
                    message.states[stateId] = snapshot.at(executionPlan.stateIndexes.at(stateId));
                }
                partitionMessagePreparationNanoseconds += static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::steady_clock::now() - preparationStartedAt).count());
                partitionBoundaryPayloadBytes += partitionMessagePayloadBytes(message);
                ++partitionBoundaryMessages;
                const auto publishStartedAt = std::chrono::steady_clock::now();
                partitionTransport->publish(std::move(message));
                partitionTransportPublishNanoseconds += static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::steady_clock::now() - publishStartedAt).count());
            }
            std::vector<std::future<PartitionResultMessage>> futures;
            futures.reserve(partitionRuntimes.size());
            for (auto& runtime : partitionRuntimes) {
                futures.push_back(runtime->submit(
                    *partitionTransport, step, parameterValues, synchronizationStep, currentTime,
                    std::chrono::milliseconds(partitionReceiveTimeoutMilliseconds), providerRuntime.get(), activeSchedules));
            }
            for (std::size_t partition = 0; partition < futures.size(); ++partition) {
                const auto result = futures[partition].get();
                if (result.version != 1 || result.synchronizationIndex != step || result.sourcePartition != partition) {
                    throw std::runtime_error("A partition returned an incompatible result message.");
                }
                partitionBoundaryWaitNanoseconds += result.boundaryWaitNanoseconds;
                for (const auto& nodeResult : result.nodes) {
                    nodeResults[nodeResult.nodeIndex] = {nodeResult.states, nodeResult.computeNanoseconds};
                }
            }
        } else {
            for (std::size_t index = 0; index < executionPlan.nodes.size(); ++index) {
                nodeResults[index] = integrateNode(executionPlan.nodes[index], snapshot, runControl.parameterValues, currentTime, synchronizationStep, providerRuntime.get(), runControl.activeSchedules);
            }
        }
        for (std::size_t index = 0; index < executionPlan.nodes.size(); ++index) {
            const auto& node = executionPlan.nodes[index];
            const auto& result = nodeResults[index];
            for (std::size_t stateIndex = 0; stateIndex < node.stateIndexes.size(); ++stateIndex) {
                synchronizedStates[node.stateIndexes[stateIndex]] = result.states.at(stateIndex);
            }
            auto& metrics = nodeMetrics[index];
            ++metrics.invocations;
            metrics.executedSubsteps += node.substeps;
            metrics.evaluatedContributions += node.substeps * (node.contributions.size() + node.algebraicTasks.size());
            metrics.computeNanoseconds += result.computeNanoseconds;
        }
        const auto synchronizationElapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now() - synchronizationStartedAt).count();
        synchronizationComputeNanoseconds += static_cast<std::uint64_t>(std::max<std::int64_t>(0, synchronizationElapsed));
        states = std::move(synchronizedStates);
        const auto elapsed = std::min(targetTime, startTime + static_cast<double>(step + 1) * globalTimeStep);
        currentTime = elapsed;
        // The states algebraic relationships set, from the states the step reached, at its end: every
        // node reads them from the next step's synchronization snapshot.
        evaluateAlgebraicRelationships(executionPlan, states, runControl.parameterValues, runControl.activeSchedules, currentTime);
        if (!stabilityMonitoredNodeIds.empty()) {
            auto newFindings = stabilityMonitor.observeGlobalStep(states, currentTime);
            stabilityFindings.insert(stabilityFindings.end(),
                std::make_move_iterator(newFindings.begin()), std::make_move_iterator(newFindings.end()));
        }
        while (pacing.mode != PacingMode::fastest) {
            const auto targetDuration = std::chrono::duration<double>(synchronizationStep / pacing.ratio);
            const auto spent = std::chrono::steady_clock::now() - wallStepStarted;
            if (spent >= targetDuration) break;
            const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(targetDuration - spent);
            pacingWait(std::min(remaining, std::chrono::milliseconds(20)));
            refreshRunControl(true);
            pacing = runControl.pacing;
            if (runControl.executionState != RunState::running) break;
        }
        if (elapsed + 1e-12 >= nextOutputTime || step + 1 == steps) {
            samples.push_back({elapsed, states});
            appendStreamRecord("sample", elapsed, states);
            // A checkpoint is captured at every output boundary (not only the final step) so any
            // displayed sample is forkable, matching the documented design intent (see "Result
            // output samples already occur at global synchronization boundaries" in
            // docs/resultExploration.md's "Checkpoints and reproducibility" section) -- previously
            // only the first and last checkpoints existed for an uninterrupted run, so "Fork here"
            // at an arbitrary scrubbed time silently snapped to the nearest of just those two.
            if (elapsed > checkpoints.back().time + 1e-12) {
                checkpoints.push_back({createUuid(), elapsed, states, captureProviderStates()});
                appendStreamRecord("checkpoint", elapsed, states, checkpoints.back().uuid);
            }
            while (nextOutputTime <= elapsed + 1e-12) nextOutputTime += outputInterval;
            const auto publicationTime = std::chrono::steady_clock::now();
            if (step + 1 == steps || publicationTime - lastPublishedAt >= std::chrono::milliseconds(250)) {
                writeResult(step + 1 == steps ? "completed" : "running", elapsed, step + 1 == steps);
                lastPublishedAt = publicationTime;
            }
        }
    }
}

}
