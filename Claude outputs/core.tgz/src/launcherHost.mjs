/* Copyright © 2026 Zenin Easa Panthakkalakath */

// The host side of launcher add-ons (docs/proposals/launcherAddons.md): a guided starting window that
// can ask the host to run one of its declared importers, run one of its declared scenarios, open the
// result in the canvas, and export it with a provenance manifest. The window never sees a file path,
// a file's contents, or the model: it names declared ids, and this module does the work.

import { spawn } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { basename, join, resolve, sep } from 'node:path';
import { pathToFileURL } from 'node:url';
import { Worker } from 'node:worker_threads';
import { startEngineRun } from './engineAdapter.mjs';
import { encodeProjectFile } from './projectFile.mjs';
import { addonCacheDirectory, createAddonCache, maximumAgeDaysLimit } from './addonCache.mjs';
import { addonFilesDirectory, createFileStore } from './addonFileStore.mjs';
import { keepAddonData, requestAddonData } from './projectAddonData.mjs';

const maximumInputBytes = 10 * 1024 * 1024;
// A binary input (a file role declared `binary`): one large file the importer reads as bytes and turns into text
// files of its other roles. It is read from disk when the importer runs and is never kept in memory or in a session.
export const maximumBinaryInputBytes = 1024 * 1024 * 1024;
// And all of a role's binary files together: they are in the importer's memory at once.
export const maximumBinaryTotalBytes = 2 * 1024 * 1024 * 1024;

// The binary files chosen for a role ([{ path, size }]), checked: each within the limit for one, and all within the
// limit together. Returns them as pending inputs. Throws a message naming the file, or the total, that is too large.
export function binaryChoice(chosen, role) {
    for (const { path, size } of chosen) {
        if (size > maximumBinaryInputBytes) throw new Error(`${basename(path)} is larger than the ${maximumBinaryInputBytes / 1024 / 1024} MB limit.`);
    }
    const total = chosen.reduce((sum, item) => sum + item.size, 0);
    if (total > maximumBinaryTotalBytes) throw new Error(`These files come to ${Math.round(total / 1024 / 1024).toLocaleString('en')} MB, more than the ${maximumBinaryTotalBytes / 1024 / 1024} MB they may come to together.`);
    return chosen.map(({ path, size }) => ({ role, name: basename(path), path, binary: true, bytes: size, sample: false }));
}
// The kinds of file a window asks to keep, named by their endings (["osm.pbf"]): checked, the open dialog's filter (which
// goes by a name's last extension only, so "osm.pbf" offers .pbf files) and a check of each file chosen by its whole
// ending, in any case, so a file the dialog let through all the same is refused before anything is copied. No kinds
// named, any file is kept, as before.
export function storedFileKinds(accept) {
    if (accept === undefined || accept === null) return { filters: [], check: () => {} };
    if (!Array.isArray(accept) || !accept.length || accept.length > 8 || !accept.every((ending) => typeof ending === 'string' && /^[a-z0-9]{1,12}(\.[a-z0-9]{1,12}){0,2}$/i.test(ending))) {
        throw new Error('A window names the files it keeps as up to 8 endings, such as ["osm.pbf"].');
    }
    const endings = accept.map((ending) => `.${ending.toLowerCase()}`);
    const named = endings.length === 1 ? endings[0] : `${endings.slice(0, -1).join(', ')} or ${endings.at(-1)}`;
    return {
        filters: [{ name: named, extensions: [...new Set(accept.map((ending) => ending.split('.').at(-1).toLowerCase()))] }],
        check(path) {
            if (!endings.some((ending) => basename(path).toLowerCase().endsWith(ending))) throw new Error(`${basename(path)} was not kept: only ${named} files are kept here.`);
        }
    };
}
const maximumDerivedFiles = 64;
// Long enough for an importer that builds a large region (routing every lane over a city's roads takes tens of seconds,
// more on a busy machine); short enough that one that hangs is still stopped.
const importerTimeoutMilliseconds = 120000;
const maximumImporterDataBytes = 8 * 1024 * 1024;
const maximumOptionsBytes = 2 * 1024 * 1024;
const maximumFetchBytes = 5 * 1024 * 1024;
const maximumSuppliedSamples = 5000;
// A run length the window chooses is limited by engine steps, not by time: models count time in whatever
// unit suits them (days, or seconds with a per-day conversion), so a cap in time units would be either
// too tight for one or too loose for another.
const maximumRunSteps = 500000;
const maximumFetchedTextBytes = 1024 * 1024;
const fetchTimeoutMilliseconds = 20000;
// A launcher's session, kept with the project: its window's own state, and the input files it was built from.
const maximumSessionWindowBytes = 2 * 1024 * 1024;
const maximumSessionInputBytes = 64 * 1024 * 1024;
const addonDataRequestMilliseconds = 5000;
const maximumRedirects = 3;

export const sha256 = (data) => createHash('sha256').update(data).digest('hex');

// Text as a spreadsheet may have saved it: UTF-8 (with or without a byte-order mark), UTF-16 with a mark, or,
// failing a strict UTF-8 read, Windows-1252, which is what Excel writes for "CSV" on Windows. The name of the
// encoding used is returned so the importer can tell the user when it was not UTF-8.
export function decodeText(bytes) {
    if (bytes[0] === 0xFF && bytes[1] === 0xFE) return { text: new TextDecoder('utf-16le').decode(bytes.subarray(2)), encoding: 'utf-16le' };
    if (bytes[0] === 0xFE && bytes[1] === 0xFF) return { text: new TextDecoder('utf-16be').decode(bytes.subarray(2)), encoding: 'utf-16be' };
    try {
        return { text: new TextDecoder('utf-8', { fatal: true }).decode(bytes), encoding: 'utf-8' };
    } catch {
        return { text: new TextDecoder('windows-1252').decode(bytes), encoding: 'windows-1252' };
    }
}

// ---- fetching ---------------------------------------------------------------------------------------------

// One HTTPS GET, only to a host the manifest lists, following at most a few redirects and only to listed hosts,
// with a size limit and a time limit. Returns the bytes; throws a message a user can act on.
export async function fetchAllowed({ url, hosts, fetchImpl = globalThis.fetch, userAgent = 'Konjugate' }) {
    const allowed = new Set(hosts.map((host) => host.toLowerCase()));
    let current;
    try { current = new URL(url); } catch { throw new Error('That is not a web address.'); }
    for (let hop = 0; hop <= maximumRedirects; hop += 1) {
        checkAddress(current, allowed);
        let response;
        try {
            response = await fetchImpl(current.href, { redirect: 'manual', headers: { 'User-Agent': userAgent, Accept: '*/*' }, signal: AbortSignal.timeout(fetchTimeoutMilliseconds) });
        } catch (error) {
            throw new Error(error.name === 'TimeoutError' ? `${current.hostname} did not answer within ${fetchTimeoutMilliseconds / 1000} seconds.` : `Could not reach ${current.hostname}. Check the connection.`);
        }
        if ([301, 302, 303, 307, 308].includes(response.status)) {
            const location = response.headers.get('location');
            if (!location) throw new Error(`${current.hostname} redirected without saying where.`);
            current = new URL(location, current);
            continue;
        }
        if (!response.ok) throw new Error(`${current.hostname} answered ${response.status}${response.status === 404 ? ' (not found: check the symbol)' : response.status === 429 ? ' (too many requests: wait a while)' : ''}.`);
        const declared = Number(response.headers.get('content-length'));
        if (declared > maximumFetchBytes) throw new Error('The answer is larger than the size limit.');
        const bytes = new Uint8Array(await response.arrayBuffer());
        if (bytes.length > maximumFetchBytes) throw new Error('The answer is larger than the size limit.');
        return bytes;
    }
    throw new Error('Too many redirects.');
}

// An address the window may ask for: https, no credentials, a host the manifest lists. Throws a message a user can act on.
function checkAddress(address, allowed) {
    if (address.protocol !== 'https:') throw new Error('Only https addresses can be fetched.');
    if (address.username || address.password) throw new Error('An address with a user name or password cannot be fetched.');
    if (!allowed.has(address.hostname.toLowerCase())) throw new Error(`This window may not connect to ${address.hostname}. It may reach: ${[...allowed].join(', ')}.`);
}
export function addressAllowed(url, hosts) {
    let address;
    try { address = new URL(url); } catch { throw new Error('That is not a web address.'); }
    checkAddress(address, new Set(hosts.map((host) => host.toLowerCase())));
    return address.href;
}

// A name safe to show and to key a file by: no path separators or control characters.
export const safeFileName = (name) => String(name ?? '').replace(/[^\p{L}\p{N} .&()_=^-]+/gu, '_').trim().slice(0, 60);

// ---- importers --------------------------------------------------------------------------------------

// What an importer says of its progress, made safe to show: `done` of `total` (numbers, done within 0 and total) and
// a short message. Null when it says nothing usable.
export function checkedProgress(progress) {
    const total = Number(progress?.total);
    const done = Number(progress?.done);
    if (!(total > 0) || !Number.isFinite(done)) return null;
    return { done: Math.min(total, Math.max(0, done)), total, message: typeof progress.message === 'string' ? progress.message.slice(0, 200) : '' };
}

// Runs a declared importer over the given files ([{ role, name, text }]) in a worker thread with a time
// limit, and checks the shape of what comes back before anyone uses it.
// A file of a binary role comes as { role, name, data } (a Uint8Array, handed over to the worker, not copied): an
// importer given one gets more time and memory, by its size.
// `onProgress` hears what the importer says of its progress (helpers.progress): { done, total, message }, checked.
export function runImporter({ addonDirectory, importer, files, options = {}, timeoutMilliseconds = null, onProgress = null }) {
    const binaryBytes = files.reduce((total, file) => total + (file.data?.byteLength ?? 0), 0);
    timeoutMilliseconds ??= importerTimeoutMilliseconds + Math.ceil(binaryBytes / (1024 * 1024)) * 500;
    return new Promise((resolvePromise, reject) => {
        const worker = new Worker(new URL('./importerWorker.mjs', import.meta.url), {
            workerData: { entry: importer.entry, packageRoot: addonDirectory, files, options },
            transferList: files.filter((file) => file.data).map((file) => file.data.buffer),
            resourceLimits: { maxOldGenerationSizeMb: binaryBytes ? 1536 : 512 }
        });
        const timer = setTimeout(() => {
            worker.terminate();
            reject(new Error(`The importer did not finish within ${timeoutMilliseconds / 1000} seconds.`));
        }, timeoutMilliseconds);
        worker.on('message', (message) => {
            // Progress, while it works: passed on, checked, and never taken for the result.
            if (message?.progress) {
                const progress = checkedProgress(message.progress);
                if (progress && onProgress) onProgress(progress);
                return;
            }
            clearTimeout(timer);
            worker.terminate();
            if (!message.ok) return reject(new Error(`The importer failed: ${message.message}`));
            const { result } = message;
            if (typeof result?.ok !== 'boolean' || !result.report) return reject(new Error('The importer returned an unexpected result.'));
            // A successful importer returns a model, or only `data` when it is a first step that needs the window to do more
            // (for example run an analysis) before the model can be built.
            if (result.ok && result.data === undefined && (!Array.isArray(result.document?.nodes) || !Array.isArray(result.document?.edges))) return reject(new Error('The importer reported success without a model.'));
            if (result.data !== undefined && JSON.stringify(result.data).length > maximumImporterDataBytes) return reject(new Error('The importer returned more data than a window may receive.'));
            try {
                if (result.derived !== undefined) result.derived = checkedDerived(importer, result.derived);
            } catch (error) {
                return reject(error);
            }
            resolvePromise(result);
        });
        worker.once('error', (error) => { clearTimeout(timer); reject(new Error(`The importer failed: ${error.message}`)); });
    });
}

// Why a chosen file could not be read, in words a user can act on: gone, not allowed (macOS keeps Desktop, Documents
// and Downloads private until the user allows an app in), or another reason, named.
export function unreadableFile(name, error) {
    if (error?.code === 'ENOENT') return `${name} could not be read: it is no longer where it was chosen. Choose it again.`;
    if (error?.code === 'EACCES' || error?.code === 'EPERM') {
        return `${name} could not be read: Konjugate is not allowed to read that folder. ${process.platform === 'darwin' ? 'On macOS, allow it under System Settings, Privacy & Security, Files and Folders, or move the file to a folder it may read, and choose it again.' : 'Allow it to read the folder, or move the file where it may, and choose it again.'}`;
    }
    return `${name} could not be read (${error?.code ?? error?.message ?? 'unknown reason'}). Choose it again.`;
}

// The inputs an importer is given for a run: those of its roles, and binary files only when the run asks for them
// (`options.useBinaryFiles`). A binary file is read from disk for each run it is given to, and may be a gigabyte: the
// steps that do not read it (most of them) do not wait for it or hold it.
export function importerInputs(pending, roles, options = {}) {
    return [...pending].filter((file) => roles.has(file.role) && (!file.binary || options?.useBinaryFiles === true));
}

// The text files an importer derived from what it was given (`derived: [{ role, name, text }]`), checked: each is of
// a role the importer declares that is not binary, and no larger than a chosen file may be. They take the place of
// the files of their roles, and of the binary files they were read from. Throws a message naming what is wrong.
export function checkedDerived(importer, derived) {
    if (!Array.isArray(derived) || derived.length > maximumDerivedFiles) throw new Error(`An importer may derive up to ${maximumDerivedFiles} files.`);
    const roles = new Map(importer.files.map((file) => [file.role, file]));
    const names = new Set();
    return derived.map((item) => {
        const file = roles.get(item?.role);
        if (!file || file.binary) throw new Error('An importer may derive files only of its own roles that are not binary.');
        if (typeof item.text !== 'string') throw new Error('A derived file must be text.');
        if (Buffer.byteLength(item.text) > maximumInputBytes) throw new Error(`A derived file is larger than the ${maximumInputBytes / 1024 / 1024} MB limit.`);
        const name = safeFileName(item.name);
        if (!name) throw new Error('A derived file needs a name.');
        const key = `${file.role}::${name}`;
        if (names.has(key) || (!file.multiple && [...names].some((other) => other.startsWith(`${file.role}::`)))) throw new Error('An importer derived two files where one is taken.');
        names.add(key);
        return { role: file.role, name, text: item.text, ...(typeof item.source === 'string' ? { source: item.source.slice(0, 200) } : {}) };
    });
}

// ---- sessions kept with the project ------------------------------------------------------------------

// What a launcher keeps with the project it opens in the canvas (docs/projectSchema.md, `addonData`): the window's
// own state, as the window gave it, and the input files the model was built from, so the session can be restored
// on any machine without fetching or choosing anything again. Throws a message a user can act on.
export function buildSessionEntry({ addon, window, inputs, savedAt = new Date().toISOString() }) {
    const windowText = JSON.stringify(window ?? null);
    if (windowText.length > maximumSessionWindowBytes) throw new Error('The window\'s session is larger than the host keeps.');
    // A binary input is not kept: what was derived from it is.
    const kept = inputs.filter((input) => !input.binary).map(({ role, name, text, encoding, url, retrievedAt, sha256: hash, bytes, sample, source }) => ({
        role, name, text, encoding: encoding ?? 'utf-8', sha256: hash, bytes, ...(url ? { url, retrievedAt } : {}), ...(sample ? { sample: true } : {}),
        // A derived file says what it was read from (the binary file's name).
        ...(source ? { source } : {})
    }));
    if (kept.reduce((total, input) => total + (input.text?.length ?? 0), 0) > maximumSessionInputBytes) {
        throw new Error(`The data this session was built from is larger than the ${maximumSessionInputBytes / 1024 / 1024} MB a project keeps.`);
    }
    return { version: 1, addonVersion: addon.version, savedAt, window: JSON.parse(windowText), inputs: kept };
}

// The project text with one launcher's entry in its addonData, leaving any other launcher's entry as it was.
export function attachAddonData(contentText, addonId, entry) {
    const document = JSON.parse(contentText);
    document.addonData = { ...(document.addonData ?? {}), [addonId]: entry };
    return JSON.stringify(document);
}

// The input files of a saved session that this launcher still declares, ready to be pending files again.
export function sessionInputs(entry, importers) {
    if (entry?.version !== 1 || !Array.isArray(entry.inputs)) return null;
    const roles = new Set((importers ?? []).flatMap((importer) => importer.files.map((file) => file.role)));
    const multiple = new Set((importers ?? []).flatMap((importer) => importer.files.filter((file) => file.multiple).map((file) => file.role)));
    return entry.inputs
        .filter((input) => roles.has(input.role) && typeof input.text === 'string' && typeof input.name === 'string')
        .map((input) => ({ key: multiple.has(input.role) ? `${input.role}::${input.name}` : input.role, file: {
            role: input.role, name: input.name, text: input.text, encoding: input.encoding ?? 'utf-8', sha256: input.sha256 ?? sha256(input.text),
            bytes: input.bytes ?? Buffer.byteLength(input.text), sample: Boolean(input.sample), ...(input.url ? { url: input.url, retrievedAt: input.retrievedAt } : {}), ...(typeof input.source === 'string' ? { source: input.source } : {}), restored: true
        } }));
}

// ---- scenarios --------------------------------------------------------------------------------------

// A fork time the window asks for (with the scenarioForkTime feature): from the start of the run up to, but not
// including, its end. The fork itself lands on the nearest kept checkpoint, one per output interval. Returns the
// fork time; throws a message a user can act on.
export function checkForkTime(forkAt, runTime) {
    if (!(Number.isFinite(forkAt) && forkAt >= 0 && forkAt < runTime)) {
        throw new Error(`The scenario must start at or after 0 and before the end of the run (${runTime}).`);
    }
    return forkAt;
}

// A run length the window asks for: after the scenario's fork, and at most maximumRunSteps of the model's own
// global step. Returns the run length; throws a message a user can act on.
export function checkRunLength(runTime, forkAt, globalTimeStep) {
    const step = Number.isFinite(globalTimeStep) && globalTimeStep > 0 ? globalTimeStep : 1;
    const maximum = maximumRunSteps * step;
    if (!(Number.isFinite(runTime) && runTime > forkAt && runTime <= maximum)) {
        throw new Error(`The run length must be more than ${forkAt} and at most ${maximum} (${maximumRunSteps.toLocaleString('en')} steps of ${step}).`);
    }
    return runTime;
}

// Turns a declared scenario into concrete parameter changes. A parameter is found by its `key` in the
// importer's parameter index: `chosen` targets the entry belonging to the entity the user picked, `all`
// every entry with that key, `global` the single entity-less entry. Throws a message a user can act on.
export function resolveInterventions(scenario, parameterIndex, chosenEntity, supplied = null) {
    const resolved = [];
    for (const intervention of scenario.interventions) {
        const entries = parameterIndex.filter((entry) => entry.key === intervention.parameter);
        if (intervention.target === 'supplied') {
            // The window's data for this parameter: its own entry under byParameter (with the suppliedPerParameter feature),
            // or else the data shared by every supplied intervention.
            const source = supplied?.byParameter?.[intervention.parameter] ?? supplied;
            const entities = source?.entities ?? [];
            if (!entities.length) throw new Error(`The scenario "${scenario.name}" needs the window to supply data${supplied?.byParameter ? ` for "${intervention.parameter}"` : ''}.`);
            for (const entity of entities) {
                const entry = entries.find((candidate) => candidate.entity === entity);
                if (!entry) throw new Error(`The scenario "${scenario.name}" changes "${intervention.parameter}", which this model does not have for ${entity}.`);
                if (!entry.live) throw new Error(`"${entry.name}" cannot be changed during a run.`);
                const clamp = (value) => Math.min(Math.max(value, entry.minimum ?? -Infinity), entry.maximum ?? Infinity);
                // A value outside the parameter's range is held to it, and the change says so, so the window can tell its
                // user rather than run something other than what it supplied without a word.
                const clamped = (values) => {
                    const count = values.filter((value) => value !== clamp(value)).length;
                    return count ? { clamped: { count, of: values.length, minimum: entry.minimum ?? null, maximum: entry.maximum ?? null } } : {};
                };
                if (intervention.samples) {
                    const samples = source.samples?.[entity];
                    if (!Array.isArray(samples) || samples.length < 2 || samples.length > maximumSuppliedSamples || !samples.every((pair) => Array.isArray(pair) && Number.isFinite(pair[0]) && Number.isFinite(pair[1]))) {
                        throw new Error(`The data supplied for ${entity} must be at least two, and at most ${maximumSuppliedSamples}, pairs of time and value.`);
                    }
                    resolved.push({
                        sharedParameterId: entry.sharedParameterId, name: entry.name, parameter: intervention.parameter, entity,
                        samples: samples.map(([time, value]) => ({ time, value: clamp(value) })), at: 0, duration: 0, baseValue: entry.value ?? 0,
                        ...clamped(samples.map(([, value]) => value))
                    });
                } else {
                    resolved.push({ sharedParameterId: entry.sharedParameterId, name: entry.name, parameter: intervention.parameter, entity, value: clamp(intervention.value), at: intervention.at ?? 0, duration: intervention.duration ?? 0, baseValue: entry.value ?? 0, ...clamped([intervention.value]) });
                }
            }
            continue;
        }
        const matching = intervention.target === 'global' ? entries.filter((entry) => entry.scope === 'global')
            : intervention.target === 'all' ? entries.filter((entry) => entry.entity !== undefined)
                : entries.filter((entry) => entry.entity === chosenEntity);
        if (!matching.length) {
            throw new Error(intervention.target === 'chosen' && !chosenEntity
                ? `The scenario "${scenario.name}" needs you to choose one first.`
                : `The scenario "${scenario.name}" changes "${intervention.parameter}", which this model does not have.`);
        }
        for (const entry of matching) {
            if (!entry.live) throw new Error(`"${entry.name}" cannot be changed during a run.`);
            const value = Number.isFinite(intervention.value) ? intervention.value : intervention.fractionOfMaximum * entry.maximum;
            resolved.push({
                sharedParameterId: entry.sharedParameterId, name: entry.name, parameter: intervention.parameter,
                entity: entry.entity ?? null, value: Math.min(Math.max(value, entry.minimum ?? -Infinity), entry.maximum ?? Infinity),
                at: intervention.at ?? 0, duration: intervention.duration ?? 0, baseValue: entry.value ?? 0
            });
        }
    }
    return resolved;
}

// Adjusts the interventions a scenario declares with values the window supplies, for parameters the importer has declared live.
// `overrides` is { parameterKey: { entityName | '*': { value, at?, duration? } | null } }: '*' names the one entity-less (global)
// entry, an entry replaces the declared change for that entity or adds one, and null removes it. With no overrides nothing changes,
// so a scenario that is run as declared is run exactly as it always was. Values outside a parameter's declared range are still held
// to it, as a backstop; the window is expected to check them first and say so.
export function applyOverrides(resolved, parameterIndex, overrides) {
    if (!overrides || !Object.keys(overrides).length) return resolved;
    const result = [...resolved];
    for (const [parameter, byEntity] of Object.entries(overrides)) {
        if (!byEntity || typeof byEntity !== 'object') throw new Error(`The changes for "${parameter}" must name the entities they apply to.`);
        for (const [entityName, change] of Object.entries(byEntity)) {
            const entry = parameterIndex.find((candidate) => candidate.key === parameter && (entityName === '*' ? candidate.scope === 'global' : candidate.entity === entityName));
            if (!entry) throw new Error(`This model has no "${parameter}" for ${entityName === '*' ? 'the whole model' : entityName}.`);
            if (!entry.live) throw new Error(`"${entry.name}" cannot be changed during a run.`);
            const at = result.findIndex((candidate) => candidate.sharedParameterId === entry.sharedParameterId);
            if (change === null) { if (at >= 0) result.splice(at, 1); continue; }
            const { value, at: delay = 0, duration = 0 } = change ?? {};
            if (![value, delay, duration].every(Number.isFinite) || delay < 0 || duration < 0) throw new Error(`The change to ${entry.name} needs a finite value, and a start and duration of zero or more.`);
            const replacement = {
                sharedParameterId: entry.sharedParameterId, name: entry.name, parameter, entity: entry.entity ?? null,
                value: Math.min(Math.max(value, entry.minimum ?? -Infinity), entry.maximum ?? Infinity), at: delay, duration, baseValue: entry.value ?? 0
            };
            if (at >= 0) result[at] = replacement; else result.push(replacement);
        }
    }
    return result;
}

// Samples of the forked branch as one continuous history: the parent's samples before the fork, then
// the child's from the fork on (the child's first sample is the fork point itself).
export function composeBranchSamples(parentSamples, childSamples, forkTime) {
    return [...parentSamples.filter((sample) => sample.time < forkTime - 1e-9), ...childSamples];
}

// { nodeName: { stateSymbol: [[time, value], ...] } } for the requested symbols, from a list of samples.
export function extractSeries(samples, document, symbols, maximumPoints = 400) {
    const stride = Math.max(1, Math.ceil(samples.length / maximumPoints));
    const picked = samples.filter((_sample, index) => index % stride === 0 || index === samples.length - 1);
    const series = {};
    for (const node of document.nodes) {
        for (const state of node.states) {
            if (!symbols.includes(state.symbol)) continue;
            series[node.name] ??= {};
            series[node.name][state.symbol] = picked.map((sample) => [sample.time, sample.states.find((item) => item.stateId === state.id)?.value ?? null]);
        }
    }
    return series;
}

const csvField = (value) => (/[",\n\r]/.test(String(value)) ? `"${String(value).replaceAll('"', '""')}"` : String(value));

// Long-format results, one row per branch, time, node and state: easy to pivot in a spreadsheet.
export function resultsToCsv(branches, document) {
    const lines = ['branch,time,node,state,unit,value'];
    for (const branch of branches) {
        for (const sample of branch.samples) {
            const values = new Map(sample.states.map((item) => [item.stateId, item.value]));
            for (const node of document.nodes) {
                for (const state of node.states) {
                    if (!values.has(state.id)) continue;
                    lines.push([branch.label, sample.time, node.name, state.name, state.unit ?? '', values.get(state.id)].map(csvField).join(','));
                }
            }
        }
    }
    return `${lines.join('\n')}\n`;
}

// The record that lets a result be reproduced and explained: what produced it, from which inputs, with
// what changes. Plain JSON, so it can be attached to a report and compared between runs.
export function buildRunManifest({ appVersion, addon, importerId, importerOptions = null, overrides = null, inputs, contentText, document, config, scenario, chosenEntity, interventions, files }) {
    return {
        manifestVersion: 1,
        createdAt: new Date().toISOString(),
        konjugate: { version: appVersion },
        package: { addonId: addon.addonId, name: addon.name, version: addon.version, importerId },
        // What the window asked for beyond the declared scenario: the options the importer was given, and the changes made to the
        // scenario's interventions. Absent when nothing was changed, so a run as declared records exactly what it always did.
        ...(importerOptions && Object.keys(importerOptions).length ? { importerOptions } : {}),
        ...(overrides && Object.keys(overrides).length ? { overrides } : {}),
        inputs: inputs.map(({ role, name, sha256: hash, bytes, url, retrievedAt }) => ({ role, name, sha256: hash, bytes, ...(url ? { url, retrievedAt } : {}) })),
        model: { sha256: sha256(contentText), nodes: document.nodes.length, edges: document.edges.length },
        runConfiguration: config,
        scenario: scenario ? {
            scenarioId: scenario.scenarioId, name: scenario.name, description: scenario.description, forkAt: scenario.forkAt,
            chosenEntity: chosenEntity ?? null, interventions
        } : null,
        files
    };
}

async function runToCompletion(content, config, engineOptions, prepare) {
    const execution = await startEngineRun(content, config, engineOptions, { retainResult: true });
    if (!execution.available) throw new Error('The simulation engine is unavailable.');
    if (prepare) await prepare(execution);
    const result = await execution.completion;
    return { result, resultPath: execution.resultPath, cleanup: execution.cleanup };
}

// Runs the model once as a baseline (cached by the caller) and once forked from it at the scenario's
// time with its interventions applied: the same fork the canvas makes, headless. The child is started
// paused so every change is in place before its first step (the engine drains queued control commands
// before integrating step 0), exactly as the canvas orders it.
export async function runScenarioBranches({ content, config, scenario, interventions, baseline, engineOptions }) {
    const checkpoint = baseline.result.checkpoints.reduce((closest, candidate) =>
        Math.abs(candidate.time - scenario.forkAt) < Math.abs(closest.time - scenario.forkAt) ? candidate : closest);
    const child = await runToCompletion(content, { ...config, targetTime: scenario.runTime, startCheckpoint: structuredClone(checkpoint) }, engineOptions, async (execution) => {
        await execution.setExecutionState('paused');
        for (const change of interventions) {
            // A path of values is followed as a piecewise schedule, its times counted from the fork; a change with a
            // duration is a pulse that returns to the parameter's base value when it ends.
            const schedule = change.samples
                ? { mode: 'piecewise', samples: change.samples.map((sample) => ({ time: checkpoint.time + sample.time, value: sample.value })), baseValue: change.baseValue ?? 0 }
                : change.duration > 0
                ? { mode: 'pulse', startTime: checkpoint.time + change.at, duration: change.duration, targetValue: change.value, baseValue: change.baseValue ?? 0 }
                : { mode: 'step', startTime: checkpoint.time + change.at, targetValue: change.value };
            await execution.scheduleParameterValue(change.sharedParameterId, schedule);
        }
        await execution.setExecutionState('running');
    });
    return { forkTime: checkpoint.time, child };
}

// ---- window and IPC ---------------------------------------------------------------------------------

// Whether the Python that runs inline providers (the one set under Provider toolchains, or found on the PATH) can
// import the modules a launcher's providers need, so a window can say what is missing before a run fails on it. Each
// module is imported for real, so a module that is installed but broken (built for another Python) counts as missing.
// Runs in the temporary directory, so nothing in the current directory is imported in place of a module.
export const maximumPythonModules = 8;
const pythonModuleCheck = [
    'import importlib, json, sys',
    'answer = {"version": sys.version.split()[0], "executable": sys.executable, "modules": {}}',
    'for name in sys.argv[1:]:',
    '    try:',
    '        module = importlib.import_module(name)',
    '        answer["modules"][name] = {"found": True, "version": str(getattr(module, "__version__", "")) or None}',
    '    except Exception as error:',
    '        answer["modules"][name] = {"found": False, "error": f"{type(error).__name__}: {error}"}',
    'print(json.dumps(answer))'
].join('\n');

export function runPythonProcess(interpreter, args, { timeoutMs = 60000 } = {}) {
    return new Promise((resolve) => {
        let child;
        try {
            child = spawn(interpreter, args, { cwd: tmpdir(), stdio: ['ignore', 'pipe', 'pipe'] });
        } catch (error) {
            resolve({ code: -1, stdout: '', stderr: error.message });
            return;
        }
        let stdout = '';
        let stderr = '';
        const timer = setTimeout(() => { child.kill(); stderr += `\nNo answer within ${timeoutMs / 1000} s.`; }, timeoutMs);
        child.stdout.on('data', (chunk) => { stdout += chunk; });
        child.stderr.on('data', (chunk) => { stderr += chunk; });
        child.on('error', (error) => { clearTimeout(timer); resolve({ code: -1, stdout: '', stderr: error.message }); });
        child.on('close', (code) => { clearTimeout(timer); resolve({ code, stdout, stderr }); });
    });
}

export async function checkPythonModules({ interpreter, chosen = false, modules, run = runPythonProcess }) {
    if (!Array.isArray(modules) || !modules.length || modules.length > maximumPythonModules || !modules.every((name) => typeof name === 'string' && /^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$/.test(name) && name.length <= 100)) {
        throw new Error(`Name between 1 and ${maximumPythonModules} Python modules to check, each a module's import name.`);
    }
    const where = chosen ? 'the Python set under Provider toolchains' : 'the Python found on the PATH (set another under Provider toolchains)';
    const result = interpreter ? await run(interpreter, ['-c', pythonModuleCheck, ...modules]) : { code: -1, stdout: '', stderr: 'No Python was found.' };
    let answer = null;
    try { answer = result.code === 0 ? JSON.parse(result.stdout.trim().split('\n').at(-1)) : null; } catch { answer = null; }
    if (!answer || typeof answer.modules !== 'object') {
        const reason = (result.stderr || result.stdout).trim().split('\n').at(-1) || `it exited with code ${result.code}`;
        return { found: false, interpreter: interpreter || null, chosen, version: null, modules: Object.fromEntries(modules.map((name) => [name, { found: false, error: null }])), message: `Python could not be run (${where}): ${reason}` };
    }
    const missing = modules.filter((name) => !answer.modules[name]?.found);
    return {
        found: true, interpreter, executable: answer.executable ?? null, chosen, version: answer.version ?? null,
        modules: Object.fromEntries(modules.map((name) => [name, answer.modules[name] ?? { found: false, error: null }])),
        message: missing.length ? `${missing.join(', ')} ${missing.length === 1 ? 'is' : 'are'} not importable in Python ${answer.version} at ${answer.executable} (${where}).` : `Python ${answer.version} at ${answer.executable} has ${modules.join(', ')}.`
    };
}

export function registerLauncherHandlers(deps) {
    const {
        ipcMain, dialog, BrowserWindow, app, screen, currentDir, iconPath, projectWindows, projectWindowState, installCustomWindowState,
        auxiliaryWindowBounds, auxiliaryWindowPresentation, engineOptions, decodeProjectForRenderer, addonRegistry, inferWithEngine, fetchImpl = (...args) => globalThis.fetch(...args),
        shell = null, checkPython = checkPythonModules
    } = deps;
    const workspaces = new Map();
    // Each add-on's cache of what it fetched (addonCache.mjs), made when first used.
    const caches = new Map();
    const cacheFor = (addon) => {
        const id = addon.manifest.addonId;
        if (!caches.has(id)) caches.set(id, createAddonCache({ directory: addonCacheDirectory(app.getPath('userData'), id) }));
        return caches.get(id);
    };

    function launcherContext(event) {
        for (const projectWindow of projectWindows) {
            const state = projectWindowState.get(projectWindow);
            if (state?.launcherWindow && !state.launcherWindow.isDestroyed() && state.launcherWindow.webContents === event.sender) {
                const addon = addonRegistry.get(state.launcherAddonId);
                if (!addon) break;
                return { projectWindow, state, addon, workspace: workspaces.get(event.sender.id) };
            }
        }
        throw new Error('This request did not come from an open launcher window.');
    }
    const can = (addon, permission) => (addon.manifest.permissions ?? []).includes(permission);
    const needs = (addon, permission) => { if (!can(addon, permission)) throw new Error(`This launcher was not granted ${permission}.`); };
    const declared = (list, key, id, description) => {
        const item = (list ?? []).find((candidate) => candidate[key] === id);
        if (!item) throw new Error(`The launcher named an undeclared ${description}.`);
        return item;
    };
    const insidePackage = (addon, relativePath) => {
        const target = resolve(addon.addonDirectory, relativePath);
        if (!target.startsWith(`${resolve(addon.addonDirectory)}${sep}`)) throw new Error('That file lies outside the add-on package.');
        return target;
    };
    // Every handler answers { ok: true, ... } or { ok: false, message }, so the window can show a reason.
    const guarded = (handler) => async (event, request = {}) => {
        try {
            return { ok: true, ...await handler(launcherContext(event), request, event) };
        } catch (error) {
            return { ok: false, message: error.message };
        }
    };
    const releaseRuns = async (workspace) => {
        const runs = [workspace.baseline, ...workspace.scenarios.values()].filter(Boolean);
        workspace.baseline = null;
        workspace.scenarios.clear();
        await Promise.all(runs.flatMap((run) => [run.cleanup?.(), run.child?.cleanup?.()]).filter(Boolean));
    };

    async function openLauncher(projectWindow, addon) {
        const state = projectWindowState.get(projectWindow);
        if (state.launcherWindow && !state.launcherWindow.isDestroyed() && state.launcherAddonId === addon.manifest.addonId) {
            state.launcherWindow.show();
            state.launcherWindow.focus();
            return;
        }
        state.launcherWindow?.destroy();
        state.launcherAddonId = addon.manifest.addonId;
        const window = new BrowserWindow({
            ...auxiliaryWindowBounds(projectWindow, 1180, 800, null, screen),
            minWidth: 900,
            minHeight: 620,
            ...auxiliaryWindowPresentation(projectWindow),
            title: addon.manifest.name,
            icon: iconPath,
            frame: false,
            backgroundColor: '#0b1620',
            show: false,
            webPreferences: {
                preload: join(currentDir, 'launcherPreload.cjs'),
                contextIsolation: true, nodeIntegration: false, sandbox: true
            }
        });
        window.once('ready-to-show', () => { if (!window.isDestroyed()) window.show(); });
        installCustomWindowState(window);
        state.launcherWindow = window;
        const id = window.webContents.id;
        workspaces.set(id, { pending: new Map(), imported: null, baseline: null, scenarios: new Map() });
        window.on('closed', async () => {
            const workspace = workspaces.get(id);
            workspaces.delete(id);
            if (state.launcherWindow === window) state.launcherWindow = null;
            if (workspace) await releaseRuns(workspace).catch(() => {});
        });
        projectWindow.once('closed', () => { if (!window.isDestroyed()) window.destroy(); });
        await window.loadFile(insidePackage(addon, addon.manifest.entry));
    }

    ipcMain.handle('launcherTitlebarStylesheet', (event) => {
        for (const projectWindow of projectWindows) {
            const state = projectWindowState.get(projectWindow);
            if (state?.launcherWindow && !state.launcherWindow.isDestroyed() && state.launcherWindow.webContents === event.sender) {
                return pathToFileURL(join(currentDir, 'addonTitlebar.css')).href;
            }
        }
        throw new Error('The titlebar stylesheet is available only to a launcher window.');
    });

    ipcMain.handle('launcherGetManifest', guarded(({ addon, workspace }) => {
        const { manifest } = addon;
        const contributes = manifest.contributes ?? {};
        return {
            addonId: manifest.addonId, name: manifest.name, version: manifest.version,
            network: { hosts: manifest.network?.hosts ?? [] },
            importers: (contributes.importers ?? []).map(({ importerId, name, guide, files }) => ({
                importerId, name, guide: guide ?? null,
                files: files.map(({ role, label, required = false, description = '', accept = ['csv'], sample, multiple = false, binary = false }) => ({ role, label, required, description, accept, multiple, binary, hasSample: Boolean(sample) }))
            })),
            scenarios: (contributes.scenarios ?? []).map(({ scenarioId, name, description, forkAt, runTime, choose, effects, interventions }) => ({ scenarioId, name, description, forkAt, runTime, choose: choose ?? null, effects: effects ?? [], interventions: (interventions ?? []).map(({ parameter, target, value, fractionOfMaximum, at, duration }) => ({ parameter, target, value: value ?? null, fractionOfMaximum: fractionOfMaximum ?? null, at: at ?? 0, duration: duration ?? 0 })) })),
            pages: (contributes.pages ?? []).map(({ pageId, label }) => ({ pageId, label })),
            // One entry per role; a role that accepts several files lists them all.
            files: (() => {
                const chosen = {};
                const multiple = new Set((contributes.importers ?? []).flatMap((importer) => importer.files.filter((file) => file.multiple).map((file) => file.role)));
                for (const file of workspace.pending.values()) {
                    const summary = { name: file.name, bytes: file.bytes, sample: file.sample, fetched: Boolean(file.url), ...(file.binary ? { binary: true } : {}), ...(file.source ? { derivedFrom: file.source } : {}) };
                    if (multiple.has(file.role)) (chosen[file.role] ??= []).push(summary);
                    else chosen[file.role] = summary;
                }
                return chosen;
            })(),
            imported: workspace.imported ? { importerId: workspace.imported.importerId, report: workspace.imported.report, entities: workspace.imported.entities } : null
        };
    }));

    // A pending file is kept under its role, or under role and name for a role that accepts several files.
    const pendingKey = (file, name) => (file.multiple ? `${file.role}::${name}` : file.role);
    const dropRole = (workspace, file) => { for (const [key, item] of workspace.pending) if (item.role === file.role) workspace.pending.delete(key); };

    ipcMain.handle('launcherChooseFile', guarded(async ({ addon, workspace, projectWindow, state }, { importerId, role }) => {
        needs(addon, 'data.import');
        const importer = declared(addon.manifest.contributes?.importers, 'importerId', importerId, 'importer');
        const file = declared(importer.files, 'role', role, 'file role');
        const extensions = file.accept ?? ['csv'];
        const chosen = await dialog.showOpenDialog(state.launcherWindow, {
            title: file.label, properties: file.multiple ? ['openFile', 'multiSelections'] : ['openFile'], filters: [{ name: extensions.join(', ').toUpperCase(), extensions }]
        });
        if (chosen.canceled || !chosen.filePaths.length) return { chosen: false };
        const paths = file.multiple ? chosen.filePaths : chosen.filePaths.slice(0, 1);
        if (file.binary) {
            // Noted, not read: read from disk when the importer runs. Choosing changes no other input until then. Those
            // chosen together replace the role's earlier ones.
            const entries = binaryChoice(await Promise.all(paths.map(async (path) => ({ path, size: (await stat(path)).size }))), role);
            dropRole(workspace, file);
            for (const entry of entries) workspace.pending.set(pendingKey(file, entry.name), entry);
            return { chosen: true, name: entries[0].name, names: entries.map((entry) => entry.name), bytes: entries.reduce((sum, entry) => sum + entry.bytes, 0) };
        }
        const read = [];
        for (const path of paths) {
            const bytes = await readFile(path);
            if (bytes.length > maximumInputBytes) throw new Error(`${basename(path)} is larger than the ${maximumInputBytes / 1024 / 1024} MB limit.`);
            read.push({ path, bytes });
        }
        if (!file.multiple) dropRole(workspace, file);
        for (const { path, bytes } of read) {
            const name = basename(path);
            workspace.pending.set(pendingKey(file, name), { role, name, path, ...decodeText(bytes), sha256: sha256(bytes), bytes: bytes.length, sample: false });
        }
        workspace.imported = null;
        await releaseRuns(workspace);
        return { chosen: true, name: basename(paths[0]), names: paths.map((path) => basename(path)), bytes: read[0].bytes.length };
    }));

    ipcMain.handle('launcherClearFile', guarded(async ({ addon, workspace }, { importerId, role, name }) => {
        needs(addon, 'data.import');
        const importer = declared(addon.manifest.contributes?.importers, 'importerId', importerId, 'importer');
        const file = declared(importer.files, 'role', role, 'file role');
        if (file.multiple && typeof name === 'string') workspace.pending.delete(pendingKey(file, name));
        else dropRole(workspace, file);
        workspace.imported = null;
        await releaseRuns(workspace);
        return {};
    }));

    ipcMain.handle('launcherUseSample', guarded(async ({ addon, workspace }, { importerId }) => {
        needs(addon, 'data.import');
        const importer = declared(addon.manifest.contributes?.importers, 'importerId', importerId, 'importer');
        workspace.pending.clear();
        for (const file of importer.files.filter((item) => item.sample)) {
            for (const sample of [file.sample].flat()) {
                const bytes = await readFile(insidePackage(addon, sample));
                workspace.pending.set(pendingKey(file, basename(sample)), { role: file.role, name: basename(sample), ...decodeText(bytes), sha256: sha256(bytes), bytes: bytes.length, sample: true });
            }
        }
        workspace.imported = null;
        await releaseRuns(workspace);
        return {};
    }));

    // Opens a page in the user's browser, on a host the manifest lists in links.hosts, over https: a map's directions
    // between two sites, say, for the user to read and type back. Nothing comes back to the window.
    ipcMain.handle('launcherOpenLink', guarded(async ({ addon }, { url }) => {
        needs(addon, 'links.open');
        const href = addressAllowed(url, addon.manifest.links?.hosts ?? []);
        if (!shell) throw new Error('This version of Konjugate cannot open pages in the browser.');
        await shell.openExternal(href);
        return {};
    }));

    // Whether the providers' Python can import the modules named (see checkPythonModules). Reads nothing of the user's
    // beyond which Python that is and its version.
    ipcMain.handle('launcherCheckPython', guarded(async (_context, { modules }) => {
        const options = await engineOptions();
        const interpreter = options.providerToolchains?.python?.interpreterPath || null;
        return checkPython({ interpreter, chosen: Boolean(options.providerToolchains?.python?.chosen), modules });
    }));

    // Fetches a page of text from a listed host and hands it to the window, for a launcher that needs an answer to show
    // (a symbol search, say) rather than a file to read. Same hosts, https, size and time limits as a file fetch.
    ipcMain.handle('launcherFetchText', guarded(async ({ addon }, { url }) => {
        needs(addon, 'network.fetch');
        const bytes = await fetchAllowed({ url, hosts: addon.manifest.network?.hosts ?? [], fetchImpl, userAgent: `Konjugate/${app.getVersion()}` });
        if (bytes.length > maximumFetchedTextBytes) throw new Error('The answer is larger than a window may receive as text.');
        return { text: new TextDecoder().decode(bytes) };
    }));

    // Fetches a file from the internet into a file role, from a host the manifest names. The bytes go through the
    // same reading as a chosen file, and the address and time are kept for the run manifest.
    //
    // With `cache: 'use'` (and `requires: ["fetchCache"]`), an answer fetched from the same address within `maximumAgeDays`
    // (30 by default) is read from the add-on's cache instead, and a fresh one is kept there; `cache: 'refresh'` always
    // fetches and keeps the answer; `cache: 'off'` (the default) neither reads nor keeps. The file's `retrievedAt` is when
    // it was really fetched, whichever way it came.
    ipcMain.handle('launcherFetchFile', guarded(async ({ addon, workspace }, { importerId, role, url, name, cache = 'off', maximumAgeDays = null }) => {
        needs(addon, 'network.fetch');
        needs(addon, 'data.import');
        const importer = declared(addon.manifest.contributes?.importers, 'importerId', importerId, 'importer');
        const file = declared(importer.files, 'role', role, 'file role');
        const fileName = safeFileName(name);
        if (!fileName) throw new Error('Give the series a name.');
        if (!['off', 'use', 'refresh'].includes(cache)) throw new Error('A fetch is cached with use, refresh or off.');
        const hosts = addon.manifest.network?.hosts ?? [];
        const store = cache === 'off' ? null : cacheFor(addon);
        const age = Number(maximumAgeDays) > 0 ? Math.min(Number(maximumAgeDays), maximumAgeDaysLimit) : undefined;
        // The address is checked before the cache is read, as it is before a fetch.
        const hit = cache === 'use' ? await store.get(addressAllowed(url, hosts), { maximumAgeDays: age }) : null;
        let bytes;
        let retrievedAt;
        if (hit) {
            bytes = new Uint8Array(hit.bytes);
            retrievedAt = hit.retrievedAt;
        } else {
            bytes = await fetchAllowed({ url, hosts, fetchImpl, userAgent: `Konjugate/${app.getVersion()}` });
            retrievedAt = new Date().toISOString();
            // A cache that cannot be written (a full disk) never stops a fetch.
            if (store) await store.put(addressAllowed(url, hosts), Buffer.from(bytes), { retrievedAt }).catch(() => {});
        }
        if (!file.multiple) dropRole(workspace, file);
        workspace.pending.set(pendingKey(file, fileName), { role, name: fileName, url, retrievedAt, ...decodeText(bytes), sha256: sha256(bytes), bytes: bytes.length, sample: false });
        workspace.imported = null;
        await releaseRuns(workspace);
        return { name: fileName, bytes: bytes.length, cached: Boolean(hit), retrievedAt };
    }));

    // How much the add-on's cache holds ({ entries, bytes, oldest, newest }), and clearing it: for a window that lets
    // the user see it and start afresh.
    ipcMain.handle('launcherCacheInfo', guarded(async ({ addon }) => {
        needs(addon, 'network.fetch');
        return cacheFor(addon).info();
    }));
    ipcMain.handle('launcherClearCache', guarded(async ({ addon }) => {
        needs(addon, 'network.fetch');
        await cacheFor(addon).clear();
        return {};
    }));

    // ---- large files kept for the user (addonFileStore.mjs) ----------------------------------------------------------
    const stores = new Map();
    const storeFor = (addon) => {
        const id = addon.manifest.addonId;
        if (!stores.has(id)) stores.set(id, createFileStore({ directory: addonFilesDirectory(app.getPath('userData'), id) }));
        return stores.get(id);
    };
    // A window sees an entry without the path its bytes are at.
    const shown = ({ path, ...entry }) => entry;
    const downloads = new Map(); // a window's download id -> its AbortController
    ipcMain.handle('launcherStoredFiles', guarded(async ({ addon }) => {
        needs(addon, 'files.store');
        const store = storeFor(addon);
        return { files: await store.list(), bytes: await store.usage() };
    }));
    // Brings files in from the user's disk, as copies: chosen in a dialog (any number, of the kinds the window names when
    // it names them), kept as the user's own.
    ipcMain.handle('launcherStoreFiles', guarded(async ({ addon, state }, { details = {}, accept = null, title = null }) => {
        needs(addon, 'files.store');
        const kinds = storedFileKinds(accept);
        const chosen = await dialog.showOpenDialog(state.launcherWindow, { title: typeof title === 'string' && title.trim() ? title.trim().slice(0, 80) : 'Files to keep', properties: ['openFile', 'multiSelections'], filters: kinds.filters });
        if (chosen.canceled || !chosen.filePaths.length) return { files: [] };
        for (const path of chosen.filePaths) kinds.check(path);
        const store = storeFor(addon);
        const files = [];
        for (const path of chosen.filePaths) {
            try { files.push(await store.putCopy({ path, details })); } catch (error) { throw new Error(error.code ? unreadableFile(basename(path), error) : error.message); }
        }
        return { files };
    }));
    // Downloads a file from a host the manifest declares, into the store, saying how far it has got.
    ipcMain.handle('launcherDownloadFile', guarded(async ({ addon, state }, { url, name = null, server = null, checksumUrl = null, details = {}, downloadId = null }) => {
        needs(addon, 'files.store');
        needs(addon, 'network.fetch');
        const controller = new AbortController();
        if (typeof downloadId === 'string') downloads.set(downloadId, controller);
        let last = 0;
        const onProgress = ({ done, total }) => {
            const now = Date.now();
            if (now - last < 200 && done !== total) return;
            last = now;
            if (state.launcherWindow && !state.launcherWindow.isDestroyed()) state.launcherWindow.webContents.send('launcherProgress', { stage: 'download', downloadId, done, total });
        };
        try {
            const entry = await storeFor(addon).download({ url, name, server, checksumUrl, details, hosts: addon.manifest.network?.hosts ?? [], onProgress, signal: controller.signal, fetchImpl, userAgent: `Konjugate/${app.getVersion()}` });
            return { file: entry };
        } finally {
            if (typeof downloadId === 'string') downloads.delete(downloadId);
        }
    }));
    // How large a file is before it is downloaded: asked of the server, at a declared host.
    ipcMain.handle('launcherFileSize', guarded(async ({ addon }, { url }) => {
        needs(addon, 'files.store');
        needs(addon, 'network.fetch');
        return { bytes: await storeFor(addon).size({ url, hosts: addon.manifest.network?.hosts ?? [], fetchImpl, userAgent: `Konjugate/${app.getVersion()}` }) };
    }));
    ipcMain.handle('launcherCancelDownload', guarded(async ({ addon }, { downloadId }) => {
        needs(addon, 'files.store');
        downloads.get(downloadId)?.abort();
        return {};
    }));
    ipcMain.handle('launcherDescribeStoredFile', guarded(async ({ addon }, { id, details }) => {
        needs(addon, 'files.store');
        return { file: await storeFor(addon).describe(id, details) };
    }));
    ipcMain.handle('launcherRemoveStoredFile', guarded(async ({ addon }, { id }) => {
        needs(addon, 'files.store');
        await storeFor(addon).remove(id);
        return {};
    }));
    // Stored files as a binary role's files, in place of any chosen: read when the importer is next asked to.
    ipcMain.handle('launcherUseStoredFiles', guarded(async ({ addon, workspace }, { importerId, role, ids }) => {
        needs(addon, 'files.store');
        needs(addon, 'data.import');
        const importer = declared(addon.manifest.contributes?.importers, 'importerId', importerId, 'importer');
        const file = declared(importer.files, 'role', role, 'file role');
        if (!file.binary) throw new Error('Stored files are given to a binary file role.');
        if (!Array.isArray(ids) || !ids.length || (!file.multiple && ids.length > 1)) throw new Error('Name the stored files to use.');
        const store = storeFor(addon);
        const entries = [];
        for (const id of ids) {
            const entry = await store.get(id);
            if (!entry) throw new Error('A stored file named is no longer kept.');
            entries.push(entry);
        }
        const pending = binaryChoice(entries.map((entry) => ({ path: entry.path, size: entry.bytes })), role);
        dropRole(workspace, file);
        pending.forEach((item, index) => workspace.pending.set(pendingKey(file, `${entries[index].id}-${entries[index].name}`), { ...item, name: entries[index].name, stored: entries[index].id }));
        return { files: entries.map(shown) };
    }));

    // Reads the chosen files from disk again, for data that another program keeps up to date. Sample files are
    // packaged and never change. Answers how many files changed.
    ipcMain.handle('launcherReloadFiles', guarded(async ({ addon, workspace }, { importerId }) => {
        needs(addon, 'data.import');
        declared(addon.manifest.contributes?.importers, 'importerId', importerId, 'importer');
        let changed = 0;
        const missing = [];
        for (const [key, file] of workspace.pending) {
            if (file.sample || file.binary || (!file.path && !file.url)) continue;
            let bytes;
            try { bytes = file.url ? await fetchAllowed({ url: file.url, hosts: addon.manifest.network?.hosts ?? [], fetchImpl, userAgent: `Konjugate/${app.getVersion()}` }) : await readFile(file.path); } catch { missing.push(file.name); continue; }
            if (bytes.length > maximumInputBytes) throw new Error(`${file.name} is larger than the ${maximumInputBytes / 1024 / 1024} MB limit.`);
            const hash = sha256(bytes);
            if (hash === file.sha256) continue;
            workspace.pending.set(key, { ...file, ...decodeText(bytes), sha256: hash, bytes: bytes.length, ...(file.url ? { retrievedAt: new Date().toISOString() } : {}) });
            changed += 1;
        }
        if (changed) { workspace.imported = null; await releaseRuns(workspace); }
        return { changed, missing };
    }));

    // Causal inference on a table the launcher supplies, for a launcher that builds its own model from data. The
    // CSV is Konjugate's inference format: a numeric, regularly spaced time column, then one column per series.
    ipcMain.handle('launcherInfer', guarded(async ({ addon }, { csv, config = {} }) => {
        needs(addon, 'analysis.infer');
        if (typeof csv !== 'string' || !csv.length) throw new Error('Provide the table as CSV text.');
        const result = await inferWithEngine(csv, config, await engineOptions());
        if (!result.available) throw new Error('The inference engine is not available.');
        return { edges: result.report.edges ?? [], selfTerms: result.report.selfTerms ?? [] };
    }));

    ipcMain.handle('launcherRunImport', guarded(async ({ addon, workspace, state }, { importerId, options = {} }) => {
        needs(addon, 'data.import');
        const importer = declared(addon.manifest.contributes?.importers, 'importerId', importerId, 'importer');
        const chosenRoles = new Set([...workspace.pending.values()].map((file) => file.role));
        const missing = importer.files.filter((file) => file.required && !chosenRoles.has(file.role));
        if (missing.length) throw new Error(`Choose ${missing.map((file) => file.label).join(' and ')} first.`);
        const roles = new Set(importer.files.map((file) => file.role));
        if (JSON.stringify(options ?? {}).length > maximumOptionsBytes) throw new Error('The options are larger than the host accepts.');
        const files = [];
        for (const file of importerInputs(workspace.pending.values(), roles, options)) {
            if (!file.binary) { files.push({ role: file.role, name: file.name, text: file.text, encoding: file.encoding }); continue; }
            // A binary input is read now, into memory of its own, and handed over to the importer.
            let bytes;
            try { bytes = await readFile(file.path); } catch (error) { throw new Error(unreadableFile(file.name, error)); }
            if (bytes.length > maximumBinaryInputBytes) throw new Error(`${file.name} is larger than the ${maximumBinaryInputBytes / 1024 / 1024} MB limit.`);
            // A large file comes in memory of its own, which is handed over as it is; a small one is copied out of the pool.
            const data = bytes.byteOffset === 0 && bytes.buffer.byteLength === bytes.length ? new Uint8Array(bytes.buffer) : Uint8Array.from(bytes);
            files.push({ role: file.role, name: file.name, data });
        }
        // The importer's progress, to the window that asked: a long read (a map extract of a gigabyte) is not a silence.
        const onProgress = (progress) => { if (state.launcherWindow && !state.launcherWindow.isDestroyed()) state.launcherWindow.webContents.send('launcherProgress', { stage: 'import', importerId, ...progress }); };
        const result = await runImporter({ addonDirectory: addon.addonDirectory, importer, files, options: options ?? {}, onProgress });
        // What the importer derived takes the place of the files of those roles. The binary files stay chosen (noted, not
        // held), to be read again for another step that asks for them: a larger area of the same map, say.
        if (result.ok && result.derived?.length) {
            for (const role of new Set(result.derived.map((item) => item.role))) dropRole(workspace, { role });
            for (const item of result.derived) {
                const file = importer.files.find((candidate) => candidate.role === item.role);
                const bytes = Buffer.from(item.text, 'utf8');
                workspace.pending.set(pendingKey(file, item.name), { role: item.role, name: item.name, text: item.text, encoding: 'utf-8', sha256: sha256(bytes), bytes: bytes.length, sample: false, ...(item.source ? { source: item.source } : {}) });
            }
            workspace.imported = null;
            await releaseRuns(workspace);
            if (!result.document) return { imported: false, report: result.report, data: result.data, derived: result.derived.map(({ role, name, text }) => ({ role, name, bytes: Buffer.byteLength(text) })) };
        }
        // A first step that returns only data leaves any earlier model alone and builds none.
        if (result.ok && !result.document) return { imported: false, report: result.report, data: result.data };
        await releaseRuns(workspace);
        if (!result.ok) {
            workspace.imported = null;
            return { imported: false, report: result.report, data: result.data };
        }
        const contentText = JSON.stringify(result.document);
        const entities = [...new Set((result.parameterIndex ?? []).map((entry) => entry.entity).filter(Boolean))];
        workspace.imported = { importerId, options: options ?? {}, document: result.document, contentText, parameterIndex: result.parameterIndex ?? [], report: result.report, entities };
        return { imported: true, report: result.report, entities, data: result.data };
    }));

    // One baseline per run length. Runs that ask for it at the same time share one engine run, and a run that needs a different length waits
    // for the one in progress. Changing the length replaces the baseline, so a batch of runs must all use the same length.
    async function ensureBaseline(workspace, runTime, notify) {
        for (;;) {
            if (workspace.baseline?.runTime === runTime) return workspace.baseline;
            const pending = workspace.baselinePending;
            if (!pending) break;
            if (pending.runTime === runTime) return pending.promise;
            await pending.promise.catch(() => {});
        }
        if (workspace.baseline) await Promise.all([workspace.baseline.cleanup?.()].filter(Boolean));
        workspace.baseline = null;
        const { document, contentText } = workspace.imported;
        const configuration = document.runConfigurations[0];
        const config = { name: 'Baseline', targetTime: runTime, globalTimeStep: configuration.globalTimeStep, outputInterval: configuration.outputInterval };
        notify({ stage: 'baseline', message: 'Running the baseline…' });
        const entry = { runTime, promise: null };
        entry.promise = (async () => {
            const run = await runToCompletion(contentText, config, await engineOptions());
            workspace.baseline = { runTime, config, uuid: randomUUID(), ...run };
            return workspace.baseline;
        })().finally(() => { if (workspace.baselinePending === entry) workspace.baselinePending = null; });
        workspace.baselinePending = entry;
        return entry.promise;
    }

    ipcMain.handle('launcherRunScenario', guarded(async ({ addon, workspace, state }, { scenarioId, entity = null, signals = [], runTime = null, forkAt = null, supplied = null, overrides = null, retain = true }) => {
        needs(addon, 'scenario.run');
        const declaredScenario = declared(addon.manifest.contributes?.scenarios, 'scenarioId', scenarioId, 'scenario');
        if (!workspace.imported) throw new Error('Import your data first.');
        // The window may choose when the scenario starts and how far ahead to run, and may supply the data a scenario
        // declares it takes. Supplied paths are counted from the fork, wherever it is.
        const chosenFork = forkAt === null ? declaredScenario.forkAt : checkForkTime(forkAt, runTime ?? declaredScenario.runTime);
        if (runTime !== null) checkRunLength(runTime, chosenFork, workspace.imported.document.runConfigurations?.[0]?.globalTimeStep);
        if (supplied !== null && JSON.stringify(supplied).length > maximumOptionsBytes) throw new Error('The supplied data is larger than the host accepts.');
        const scenario = { ...declaredScenario, forkAt: chosenFork, ...(runTime === null ? {} : { runTime }) };
        if (scenario.choose && !workspace.imported.entities.includes(entity)) throw new Error(`Choose ${scenario.choose.label.toLowerCase()} first.`);
        const notify = (progress) => { if (state.launcherWindow && !state.launcherWindow.isDestroyed()) state.launcherWindow.webContents.send('launcherProgress', progress); };
        if (overrides !== null && JSON.stringify(overrides).length > maximumOptionsBytes) throw new Error('The changes are larger than the host accepts.');
        const interventions = applyOverrides(resolveInterventions(scenario, workspace.imported.parameterIndex, scenario.choose ? entity : null, supplied), workspace.imported.parameterIndex, overrides);
        const { document, contentText } = workspace.imported;
        const baseline = await ensureBaseline(workspace, scenario.runTime, notify);
        notify({ stage: 'scenario', message: `Running “${scenario.name}”…` });
        const key = `${scenarioId}|${entity ?? ''}`;
        // A run that is not retained (one of many in a batch) is summarized and then released, so a batch does not keep a result file each.
        const previous = retain ? workspace.scenarios.get(key) : null;
        if (previous) await previous.child.cleanup?.();
        const { forkTime, child } = await runScenarioBranches({ content: contentText, config: baseline.config, scenario, interventions, baseline, engineOptions: await engineOptions() });
        const scenarioSamples = composeBranchSamples(baseline.result.samples, child.result.samples, forkTime);
        if (retain) workspace.scenarios.set(key, { scenarioId, entity, scenario, interventions, overrides, forkTime, child, samples: scenarioSamples, uuid: randomUUID() });
        const answer = {
            scenarioId, entity, forkTime, runTime: scenario.runTime, interventions,
            branches: [
                { id: 'baseline', label: 'Baseline', series: extractSeries(baseline.result.samples, document, signals) },
                { id: 'scenario', label: scenario.name, series: extractSeries(scenarioSamples, document, signals) }
            ]
        };
        if (!retain) await child.cleanup?.();
        notify({ stage: 'done', message: 'Done' });
        return answer;
    }));

    // The project the canvas would hold after these runs: the model with a baseline branch and, when a
    // scenario has run, its forked branch, exactly as the canvas's own Fork here would have built it.
    async function buildProject(workspace, scenarioKey, addonData = null) {
        const contentText = addonData ? attachAddonData(workspace.imported.contentText, addonData.addonId, addonData.entry) : workspace.imported.contentText;
        const branches = [];
        if (workspace.baseline) branches.push({ buffer: await readFile(workspace.baseline.resultPath), branchUuid: workspace.baseline.uuid, parentBranchUuid: null, forkTime: null, label: 'Baseline' });
        const run = scenarioKey ? workspace.scenarios.get(scenarioKey) : null;
        if (run && workspace.baseline) {
            branches.push({ buffer: await readFile(run.child.resultPath), branchUuid: run.uuid, parentBranchUuid: workspace.baseline.uuid, forkTime: run.forkTime, label: run.scenario.name });
        }
        return encodeProjectFile(contentText, { resultBranches: branches.length ? branches : null });
    }
    const keyFor = (workspace, scenarioId) => {
        if (!scenarioId) return null;
        const matches = [...workspace.scenarios.keys()].filter((key) => key.startsWith(`${scenarioId}|`));
        return matches.at(-1) ?? null;
    };

    ipcMain.handle('launcherOpenInCanvas', guarded(async ({ addon, workspace, projectWindow }, { scenarioId = null, focus = true, silent = false, session }) => {
        needs(addon, 'model.open');
        if (!workspace.imported) throw new Error('Import your data first.');
        // A launcher with project.data may keep its session with the project it opens: saved with it, restored from it.
        let addonData = null;
        if (session !== undefined) {
            needs(addon, 'project.data');
            addonData = { addonId: addon.manifest.addonId, entry: buildSessionEntry({ addon: addon.manifest, window: session, inputs: [...workspace.pending.values()] }) };
        }
        // Tell the project window a project is on its way before building it (which takes seconds for a large one): a
        // save there waits for it, rather than writing the project as it was before this change.
        if (!projectWindow.isDestroyed()) projectWindow.webContents.send('launcherOpenProjectPending');
        let payload;
        try {
            payload = await decodeProjectForRenderer(await buildProject(workspace, keyFor(workspace, scenarioId), addonData));
        } catch (error) {
            if (!projectWindow.isDestroyed()) projectWindow.webContents.send('launcherOpenProjectAbandoned');
            throw error;
        }
        if (projectWindow.isDestroyed()) throw new Error('The project window has been closed.');
        projectWindow.webContents.send('launcherOpenProject', { ...payload, silent, addonName: addon.manifest.name, suggestedFilename: `${addon.manifest.name.replaceAll(/[^A-Za-z0-9]+/g, '')}.kjt` });
        if (focus) {
            projectWindow.show();
            projectWindow.focus();
        }
        return {};
    }));

    // Keeps the window's session with the open project without opening a model (with `requires: ["keepSession"]`): work
    // in the window before anything is built (sites placed on a map, say) is then saved with the project, and restored.
    ipcMain.handle('launcherKeepSession', guarded(async ({ addon, workspace, projectWindow }, { session }) => {
        needs(addon, 'project.data');
        if (projectWindow.isDestroyed()) throw new Error('The project window has been closed.');
        const entry = buildSessionEntry({ addon: addon.manifest, window: session, inputs: [...workspace.pending.values()] });
        keepAddonData(projectWindow, addon.manifest.addonId, entry);
        return {};
    }));

    // Restores the session this launcher kept with the open project: its input files become the pending files again
    // (so its importer can run as before, offline), and the window gets back the state it saved.
    ipcMain.handle('launcherRestoreSession', guarded(async ({ addon, workspace, projectWindow }) => {
        needs(addon, 'project.data');
        if (projectWindow.isDestroyed()) throw new Error('The project window has been closed.');
        const entry = await requestAddonData({ ipcMain, projectWindow, addonId: addon.manifest.addonId, timeoutMilliseconds: addonDataRequestMilliseconds });
        const inputs = sessionInputs(entry, addon.manifest.contributes?.importers);
        if (!inputs) return { session: null };
        workspace.pending.clear();
        for (const { key, file } of inputs) workspace.pending.set(key, file);
        workspace.imported = null;
        await releaseRuns(workspace);
        return {
            session: entry.window ?? null, savedAt: entry.savedAt ?? null, addonVersion: entry.addonVersion ?? null,
            inputs: inputs.map(({ file }) => ({ role: file.role, name: file.name, bytes: file.bytes, ...(file.url ? { url: file.url, retrievedAt: file.retrievedAt } : {}), ...(file.source ? { derivedFrom: file.source } : {}) }))
        };
    }));

    ipcMain.handle('launcherExportResults', guarded(async ({ addon, workspace, state }, { scenarioId = null, summaryCsv = '' }) => {
        needs(addon, 'results.export');
        if (!workspace.imported) throw new Error('Import your data first.');
        if (!workspace.baseline) throw new Error('Run a scenario first, so there is something to export.');
        const scenarioKey = keyFor(workspace, scenarioId);
        const run = scenarioKey ? workspace.scenarios.get(scenarioKey) : null;
        const chosen = await dialog.showOpenDialog(state.launcherWindow, { title: 'Choose a folder for the results', properties: ['openDirectory', 'createDirectory'] });
        if (chosen.canceled || !chosen.filePaths[0]) return { exported: false };
        const stamp = new Date().toISOString().replaceAll(/[:.]/g, '-').slice(0, 19);
        const folder = join(chosen.filePaths[0], `stress-test-${stamp}`);
        await mkdir(folder, { recursive: true });
        const { document, contentText } = workspace.imported;
        const branches = [{ label: 'Baseline', samples: workspace.baseline.result.samples }];
        if (run) branches.push({ label: run.scenario.name, samples: run.samples });
        const written = {};
        const put = async (name, data) => { await writeFile(join(folder, name), data); written[name] = { sha256: sha256(data), bytes: Buffer.byteLength(data) }; };
        await put('results.csv', resultsToCsv(branches, document));
        if (summaryCsv) await put('summary.csv', String(summaryCsv).slice(0, 200000));
        await put('project.kjt', await buildProject(workspace, scenarioKey));
        const manifest = buildRunManifest({
            appVersion: app.getVersion(), addon: addon.manifest, importerId: workspace.imported.importerId,
            importerOptions: workspace.imported.options, overrides: run?.overrides ?? null,
            inputs: [...workspace.pending.values()], contentText, document, config: workspace.baseline.config,
            scenario: run?.scenario ?? null, chosenEntity: run?.entity ?? null,
            interventions: run?.interventions ?? [], files: written
        });
        await writeFile(join(folder, 'run-manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
        return { exported: true, folder, files: [...Object.keys(written), 'run-manifest.json'] };
    }));

    ipcMain.handle('launcherOpenPage', guarded(async ({ addon, state }, { pageId }) => {
        needs(addon, 'pages.open');
        const page = declared(addon.manifest.contributes?.pages, 'pageId', pageId, 'page');
        const target = insidePackage(addon, page.entry);
        state.launcherPages ??= new Map();
        const existing = state.launcherPages.get(pageId);
        if (existing && !existing.isDestroyed()) { existing.show(); existing.focus(); return {}; }
        const window = new BrowserWindow({
            width: 860, height: 760, title: page.label, icon: iconPath, backgroundColor: '#f5f3ee', autoHideMenuBar: true,
            webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true }
        });
        window.setMenu(null);
        window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
        window.webContents.on('will-navigate', (navigation) => navigation.preventDefault());
        state.launcherPages.set(pageId, window);
        window.on('closed', () => state.launcherPages.delete(pageId));
        await window.loadFile(target);
        return {};
    }));

    return { openLauncher };
}
