---
type: Guide
title: Package manager distribution
description: Automated packaging and distribution workflows for Chocolatey, the Microsoft Store, Homebrew Cask, Snap, and Flathub (winget is paused).
tags: [distribution, chocolatey, microsoft-store, homebrew, flatpak, release]
status: partially_implemented
---

<!-- Copyright © 2026 Zenin Easa Panthakkalakath -->

# Package manager distribution

Konjugate's release pipeline (`.github/workflows/release.yml`) already builds an unsigned DMG/EXE/AppImage on every `v*` tag and publishes them to a GitHub Release — see [releasePackaging.md](releasePackaging.md). This document covers the next layer: getting those same builds discoverable through Homebrew Cask, Chocolatey, the Microsoft Store, Snap, and Flathub. winget is paused (see below).

Two decisions shape everything below, both made deliberately: Konjugate ships **unsigned** for now (no Apple Developer ID, no Windows code-signing certificate — revisit once there's real traction), and none of the channels here cost anything to register on or publish through, so nothing is being skipped for budget reasons.

**Current status:** Chocolatey and Konjugate's own Homebrew tap have CI jobs in `release.yml` (`chocolateyRelease`, `homebrewTapRelease`) that run on every `v*` tag but are opt-in by secret — with `CHOCOLATEY_API_KEY` / `HOMEBREW_TAP_TOKEN` unset, the job skips its real step with a notice instead of failing, so a release never goes red for a channel that isn't set up yet. Each needs a one-time human setup step first (see their sections). The official Homebrew Cask and Snap are deferred with no job (the Cask is blocked by notarization and notability requirements; Snap by a missing store credential and an untested `snapcraft.yaml`), and Flathub is blocked by its own project-maturity and AI-content policies (see its section) — revisit once those no longer apply.

## Shared app metadata

`packaging/appMetadata.yml` is the one source for the descriptive text (name, summary, description, homepage, bugtracker, license, categories, screenshot) that more than one packaging format needs. It exists because that text was previously hand-copied separately into `packaging/linux/com.konjugate.Konjugate.metainfo.xml` and `distribution/snap/snapcraft.yaml`, and had already drifted — the two `description` fields differed by one punctuation mark before anyone noticed. Run `npm run generate:app-metainfo` (`scripts/generateAppMetainfo.mjs`) after editing it to regenerate the AppStream file; `appstreamcli validate` should still pass cleanly afterward.

`distribution/snap/snapcraft.yaml` is not generated from this yet — it isn't wired into `release.yml` today (see its own section below), so that's a real but lower-priority follow-up rather than something worth the risk of editing an unverified manifest alongside this change. Update it by hand to match if `appMetadata.yml` changes in the meantime.

The generated file's own `<releases>` entry and screenshot URL version tag are still only a last-known-good snapshot at the moment someone runs the generator — `Makefile`'s `distributableLinux` target unconditionally overwrites both with the live `package.json` version at actual AppImage build time regardless (see that target's own comment), so the shipped binary's embedded copy can never be stale even if the generator hasn't been re-run recently.

## Homebrew tap

**Automated:** the `homebrewTapRelease` job in `release.yml` runs after the GitHub Release is published. It runs `scripts/generateHomebrewCask.mjs --tap` (also `npm run homebrew:generate-tap-cask`), which downloads the just-published DMGs and AppImage, hashes them, and writes `Casks/konjugate.rb`, then commits that file to the tap repository `zenineasa/homebrew-konjugate`. It only runs its real step when the `HOMEBREW_TAP_TOKEN` secret is set. Users install with `brew install --cask zenineasa/konjugate/konjugate` (Homebrew adds the tap automatically) and update with `brew upgrade --cask konjugate`; the app lands in `/Applications` like any other, so nothing needs running afterwards.

**Why a tap and not the official cask:** the official `Homebrew/homebrew-cask` repository has the notarization and notability blockers described in the next section. A personal tap isn't held to those rules, so its cask can include a `postflight` step that removes macOS's quarantine flag (`xattr -dr com.apple.quarantine`). That step is what makes the install open without the "damaged" warning, and it was verified: installing the generated cask on a Mac leaves no quarantine flag, while an otherwise identical cask without the step leaves `com.apple.quarantine` on the app and every file inside it. The app is only ad-hoc signed, so `spctl` still rejects it — the flag removal skips Gatekeeper's check rather than satisfying it, which the cask's caveats say plainly. Only the Homebrew route gets this; a downloaded DMG still needs the steps in the ReadMe. The real fix is an Apple Developer ID plus notarization.

**One-time setup, in order:**
1. Create an empty public repository named `homebrew-konjugate` under the `zenineasa` account (Homebrew requires the `homebrew-` prefix for `brew tap zenineasa/konjugate` to find it). A short README is optional.
2. Create a fine-grained personal access token that can write contents to that one repository only, and store it as this repo's `HOMEBREW_TAP_TOKEN` secret.
3. Either wait for the next `v*` tag (the job generates and commits the cask), or commit `distribution/homebrew/tap/Casks/konjugate.rb` (from `npm run homebrew:generate-tap-cask`) to the tap's `Casks/` directory by hand.

**Caveats:** the tap is not discoverable through `brew search`, so the install command belongs in the ReadMe (it is there). The generated cask also covers the Linux AppImage; that part is untested.

## Homebrew Cask — deferred, two real blockers found

**Status: on hold, not wired into CI.** A real `brew audit --cask --new konjugate` run (see below) surfaced two hard requirements this project doesn't meet yet, confirmed directly against Homebrew's own review tooling, not just their docs:

1. **Notarized, signed macOS binaries.** Homebrew Cask requires distributed macOS binaries to be signed and notarized with an Apple Developer ID and pass Gatekeeper — the `xattr -cr` workaround in the cask's own `caveats` (needed because Konjugate ships unsigned today, see [releasePackaging.md](releasePackaging.md)) is exactly the kind of thing official casks aren't allowed to paper over. Resolved once Konjugate has a real Apple Developer ID and notarized builds — see this doc's intro note on signing.
2. **Notability.** New casks need roughly 75 GitHub stars or 30 forks/watchers. Konjugate isn't there yet.

Neither is a one-time setup step the way Snap's credentials are — both take real time (getting an Apple Developer ID and notarizing builds, growing the project's traction) rather than an afternoon of account setup. That's why, unlike winget and Snap, **there is no `homebrewCaskBump` job in `release.yml`** — a job that can only ever fail until both of these are true would just be permanent CI noise. Revisit this section once both are met.

What's kept, ready for when that's true:
- `scripts/generateHomebrewCask.mjs` (`npm run homebrew:generate-cask`) generates `distribution/homebrew/konjugate.rb` (gitignored) from the latest published release — both macOS DMGs and the Linux AppImage, via the same `on_macos`/`on_linux` + `app_image` pattern real casks like `cursor.rb`/`warp.rb` use (confirmed Homebrew Cask has real Linux support, not just macOS).
- Once notarization + notability are both true, the submission flow is: run the generator, fork `Homebrew/homebrew-cask`, copy the output to `Casks/k/konjugate.rb`, and follow their real PR checklist (`brew audit --cask --new`, `brew style --fix`, a real local install/uninstall cycle, plus their mandatory AI-usage disclosure if a tool helped draft it — see `docs.brew.sh/Responsible-AI-Usage`). Re-add a `homebrewCaskBump` job to `release.yml` (mirroring `wingetRelease`'s shape, using `eugenesvk/action-homebrew-bump-cask`) once that first PR is merged.

## winget (paused)

winget is not a release target at the moment. The first manifest submitted to `microsoft/winget-pkgs` was taking too long for Microsoft's moderators to approve to plan around, so the `wingetRelease` job in `release.yml` is commented out (not deleted), and so is the setup described below. winget users, if any, update with the plain download. To bring it back: get a first manifest merged into `microsoft/winget-pkgs`, set the `WINGET_TOKEN` secret, uncomment the `wingetRelease` job, restore the winget row in [updates.md](updates.md) and the winget wording of the update hint in `src/updatePanel.mjs`, and uncomment the section below.

<!-- The winget section as it was, kept for when winget is restored:

## winget

**Automated:** the `wingetRelease` job in `release.yml` runs after the GitHub Release is published and uses `vedantmgoyal9/winget-releaser` to open a version-bump PR against `microsoft/winget-pkgs`. It only runs its real step when the `WINGET_TOKEN` secret is set. That action's own first build step explicitly checks that the `identifier` already exists in `microsoft/winget-pkgs` and errors out if not (confirmed by reading its source directly, not assumed from its docs) — it calls `komac update`, never `komac new`, so it can't create the first listing. That's why the token must only be added after step 3 below has merged.

**One-time setup, in order:**
1. Decide the winget `PackageIdentifier` (winget's `Publisher.Package` convention) — `release.yml` uses `Konjugate.Konjugate`; if you pick another, use the same value in step 3 and in the job.
2. Fork `microsoft/winget-pkgs` under your own GitHub account.
3. Submit the first manifest by hand — either `wingetcreate new` or `komac submit`, pointed at a published `-setup.exe` release asset — as a PR to `microsoft/winget-pkgs`, and wait for it to merge.
4. Generate a **classic** PAT with `public_repo` scope, stored as this repo's `WINGET_TOKEN` secret.

From the next tag on, the job opens the bump PR automatically. Microsoft's bots validate it and the merge is outside this project's control, so a new version appears in winget some hours or days after the release, not instantly. The installer is unsigned, so reviewers' Defender scan occasionally flags a false positive that needs a manual resubmission.

-->

## Chocolatey

**Automated:** the `chocolateyRelease` job in `release.yml` runs on a Windows runner after the GitHub Release is published. It only runs its real step when the `CHOCOLATEY_API_KEY` secret is set. It runs `scripts/generateChocolateyPackage.mjs`, which fills the templates in `packaging/chocolatey/` (a `.nuspec`, `chocolateyInstall.ps1`, `chocolateyUninstall.ps1`) from the real published release and `packaging/appMetadata.yml`, then `choco pack` and `choco push` the result. The generator downloads the just-published `-setup.exe` and computes its sha256, so the checksum in the pushed package is verified against exactly what users get. The install script runs the NSIS installer with `/S` (the same silent path `release.yml` exercises in CI); the uninstall script finds the installer's Add/Remove Programs entry rather than hardcoding a path. Run `node scripts/generateChocolateyPackage.mjs [vTag]` locally to inspect the output in `out/chocolatey/` without pushing anything.

**One-time setup:**
1. Create an account on chocolatey.org and copy the API key from its account page.
2. Store it as this repo's `CHOCOLATEY_API_KEY` secret.

**What to expect:** a successful `choco push` only means the package entered Chocolatey's moderation queue, not that it's live. New packages go through automated checks (VirusTotal scan, install/uninstall test on a clean VM) and then human moderation, which for a first package can take days to weeks with back-and-forth. The unsigned installer can trigger a VirusTotal false positive; a rejection arrives by email and is answered on the package's page, not in CI. After a version has been approved, later versions are validated faster.

`iconUrl` in the nuspec points at `assets/icon.svg` through the jsDelivr CDN, pinned to the release tag (`https://cdn.jsdelivr.net/gh/zenineasa/Konjugate@v<version>/assets/icon.svg`), because the PNG/ICO icons are generated and gitignored and because Chocolatey moderation rejects `raw.githubusercontent.com` icon URLs (version 1.1.6 was sent back for that). `projectSourceUrl` points at the tagged source tree so it differs from `projectUrl`, which the moderation guidelines expect.

## Microsoft Store — live; automatic updates written but not yet run

**Status:** Konjugate is live in the Microsoft Store (product id `9P5C9S7DSRPJ`, https://apps.microsoft.com/detail/9p5c9s7dsrpj), submitted by hand through Partner Center from an MSIX built by CI. It passed certification on the second try: the first was rejected under policy 10.1.1.3 (Inaccurate Representation) because the listing's screenshots came from a Mac and showed macOS window chrome, so the Store listing's screenshots must be captured on Windows. `release.yml` builds an MSIX on every `v*` tag and can submit it as an update through `.github/workflows/microsoftStoreSubmit.yml`, but that submission step has not yet run against the real Store. `make distributableWindowsMsix` (run on Windows, after the usual `make` prerequisites) wraps the same `out/package/Konjugate-win32-<arch>` folder the NSIS installer wraps into an unsigned `out/msix/Konjugate-<version>-<arch>.msix`, using `scripts/createMsixPackage.mjs` (manifest generated in code, logos rendered from `assets/icon.svg` with `rsvg-convert`, `makeappx pack` from the Windows SDK). It is deliberately written to `out/msix/`, not `out/release/`, because `release.yml` publishes everything in `out/release/` and an unsigned build must never be attached to a GitHub Release.

**Why bother:** the Store signs MSIX packages itself on ingestion, so a Store install shows no SmartScreen warning and needs no code-signing certificate of ours — the one Windows channel that removes the unsigned-installer problem rather than working around it. The manifest also declares the `.kjt` file association and a `konjugate.exe` execution alias (a `konjugate` command on `PATH`; whether `--cli` output actually reaches a terminal from an Electron GUI-subsystem executable is a separate, untested question).

**Spike results (sideloaded, self-signed test package):** the app installs and runs; inline C++ providers compile and run; add-ons install (the fintech toolbox); double-clicking a `.kjt` opens it; `konjugate --cli validate` prints its result in a terminal. The C++ provider check initially failed with `Cannot open compiler generated file: 'C:\WINDOWS\system32\providerWorker.obj': Permission denied` — a latent engine bug, not an MSIX limitation: MSVC's `cl.exe` writes its `.obj` files into its working directory and the engine never set one, so it inherited the host process's (`System32` under MSIX; `C:\Program Files\Konjugate` from a shortcut would fail the same way). `engine/src/cppToolchain.cpp` now runs the compiler in the artifact's directory and removes the `.obj` files afterwards.

**What the spike set out to prove, and why:**
1. **Inline C++ providers still compile.** The engine spawns a host compiler (`src/main.mjs` searches for `cl.exe` and others) and needs headers from inside the install folder, which for MSIX is the locked-down `WindowsApps` directory. Child processes inherit the package identity so this probably works, but it is the most likely failure. Test it by running a model with an inline C++ provider from the installed MSIX.
2. **User data still lands somewhere sensible.** Writes under `%APPDATA%` are redirected into a per-package store, so add-ons, plugins and provider toolchains won't be where a user hand-editing `%APPDATA%\Konjugate` expects them. Check that installing add-ons and plugins works and survives a restart.
3. **`runFullTrust` is acceptable.** It is a restricted capability the Store reviews and asks to be justified; spawning host compilers and interpreters is the justification.

**Automated (once set up):** on a `v*` tag, the `build` job's Windows leg builds the MSIX from the packaged folder `make distributable` just produced (`node scripts/createMsixPackage.mjs`) and uploads it as the `msix-Windows-X64` workflow artifact. The `microsoftStoreRelease` job in `release.yml` then calls the reusable workflow `.github/workflows/microsoftStoreSubmit.yml`, which downloads that artifact, installs Microsoft's `msstore` CLI through its documented action (`microsoft/microsoft-store-apppublisher`), configures it with the Partner Center credentials and runs `msstore publish <msix> --appId 9P5C9S7DSRPJ` — the form Microsoft's own GitHub Actions guide uses for a pre-built MSIX. That creates a new submission from the last published one (so the listing text, screenshots and ratings carry over), attaches the package and commits it; it then waits in Microsoft's certification review (a few days) before going live. The build step is opt-in by the `MSIX_IDENTITY_NAME` repository **variable** (with `MSIX_PUBLISHER` and `MSIX_PUBLISHER_DISPLAY_NAME`) and the submission by the `MS_STORE_CLIENT_SECRET` **secret**, so releases are unaffected until you set them. The `release` job downloads only `release-*` artifacts, because it publishes everything it downloads and the unsigned MSIX must never be attached to the GitHub Release.

**Submitting without a release:** the same workflow can be started by hand — Actions → Microsoft Store submission → Run workflow, giving the number from an earlier Release run's URL (`.../actions/runs/<number>`) — and submits the MSIX that run built. That is how to try or retry the submission without cutting a release, and why it is a separate file: re-running a failed job inside an old run would use that run's old copy of the workflow, not the current one. The run must still have its artifact (kept 90 days by default).

**CI setup (one time):** register a Microsoft Entra ID application, then in Partner Center → Account settings → User management → Microsoft Entra applications, add it with the **Manager** role (Partner Center must already have a tenant associated). Create a client secret for it and add these repository secrets: `MS_STORE_TENANT_ID` (Entra → Overview → Tenant ID), `MS_STORE_CLIENT_ID` (the app registration's Application ID), `MS_STORE_CLIENT_SECRET` (the secret's value, shown only once) and `MS_STORE_SELLER_ID` (Partner Center → Account settings → Developer settings / Identifiers). The product id is written into the workflow because it is public. Free apps only: Microsoft's CLI doesn't yet support updating paid ones this way. The three `MSIX_*` repository variables (from Partner Center's product identity page) are already needed for the build step.

**Known gaps in the automation:** the submission step has never run for real, so expect to adjust it after the first attempt (Microsoft's CLI is a preview). Each new submission inherits the previous submission's listing, including its "What's new" text, so release notes in the Store stay stale until someone updates them. Microsoft's documented route for that is `msstore publish ... --noCommit`, then editing `Listings.'en-us'.BaseListing.ReleaseNotes` in the JSON from `msstore submission get`, then `msstore submission update` and `msstore submission publish`; publish has to come first, since it recreates the draft.

**Updating the Store listing by hand (what is used until the automation is set up):** the automation needs a Microsoft Entra ID directory with an application added to Partner Center, and when that was attempted in October 2026 creating the directory asked for payment details, so releases are submitted to the Store by hand. The release workflow still builds the MSIX on every tag and keeps it as the `msix-Windows-X64` artifact. After a tag's Release run finishes: download that artifact (a zip containing `Konjugate-x64.msix`) from the run's page; in Partner Center open Apps and games → Konjugate and start an update, which copies the current submission; on Packages remove the old package and upload the new `.msix`; on Store listings write the "What's new in this version" text and replace screenshots if the interface changed (they must be real Windows captures — see the rejection above); then submit. The version must be higher than the last one, which the build already guarantees (`x.y.z.0` from `package.json`). Certification takes up to three business days (usually less), and publishing then follows within minutes, or when you press Publish now if the submission was set to hold. Writing the notes yourself also avoids the stale "What's new" text the automated route would carry over.

**Local test, step by step** (elevated PowerShell on a Windows machine): build with `make distributableWindowsMsix`, run `packaging/windows/msix/signForTesting.ps1 -Msix out\msix\Konjugate-<version>-x64.msix` (creates and trusts a throwaway self-signed certificate, then signs), then `Add-AppxPackage` the signed file. Remove it afterwards with `Get-AppxPackage *Konjugate* | Remove-AppxPackage`.

**What the first Store submission needed (done):** a Microsoft Partner Center account (identity verification; free for individuals as far as I know — check the current sign-up terms), a reserved app name, and the `Identity Name` / `Publisher` Partner Center assigns to it, supplied to the build as `MSIX_IDENTITY_NAME` / `MSIX_PUBLISHER` (the defaults are local-test placeholders the Store rejects). The listing also needs a privacy policy URL, screenshots, an age rating and a `runFullTrust` justification; each submission goes through a certification review of a few days. Automating later submissions (the `msstore` CLI or the Store submission API from a release job) comes after the first manual one.

## Snap

**Automated today:** nothing — no `snapRelease` job exists in `release.yml` right now (removed rather than left permanently failing on a missing credential). It would rebuild the Linux package from source (there's no raw `out/package/Konjugate-linux-<arch>` tree published as an artifact, only the compressed AppImage) and publish via `canonical/action-build` + `canonical/action-publish`.

`distribution/snap/snapcraft.yaml` uses `confinement: classic`, not `strict`, deliberately: Konjugate's inline C++/Python provider feature spawns whichever host compiler/interpreter it finds (`src/main.mjs` — `clang++`/`cl.exe`/`g++`/`c++`, `python3`/`python`), which strict confinement's plug model has no clean way to grant. Classic confinement requires a one-time manual Canonical review before stable-channel publication — free, but human-gated, on top of the account setup below.

**One-time setup, in order:**
1. `snapcraft login`, then `snapcraft register konjugate` — claims the name under your own Ubuntu One account.
2. `snapcraft export-login --snaps=konjugate --acls package_access,package_push,package_update,package_release exported.txt` run locally.
3. Paste the contents of `exported.txt` into this repo's `SNAPCRAFT_STORE_CREDENTIALS` secret.
4. `distribution/snap/snapcraft.yaml` has not been run through a real `snapcraft pack` yet (no Linux machine was available while drafting it) — verify it builds locally before relying on CI to publish it.
5. Re-add a `snapRelease` job to `release.yml` (see this file's git history for the exact configuration that was removed) — `needs: release`, tag-gated, rebuilding the Linux package via `make packageLinux` then publishing via `canonical/action-build` + `canonical/action-publish`.
6. Once ready to leave the `edge` channel (which that job published to by default), request classic-confinement review via the Snap Store dashboard.

## Flathub

**Automated today:** nothing, and this one is materially further from ready than the other three. Flathub's build sandbox has no network access — every build-time dependency needs to be a pinned, checksummed source in the manifest, fetched before the sandboxed build starts. Because every vcpkg C++ dependency except METIS is statically linked (confirmed against a real build's `vcpkg_installed/*/lib/*.a`), the *runtime* needs none of them — this is purely a build-sandbox problem.

`distribution/flatpak/com.konjugate.Konjugate.yml` is a first-draft manifest, explicitly marked as not yet build-tested. What it captures: `boost-property-tree` and `eigen3` are header-only in this engine (no compiled library — `engine/CMakeLists.txt` only does `find_path`/uses `Eigen3::Eigen` as an INTERFACE target), so both use a single upstream tarball each, header-copied into the prefix, skipping vcpkg's own ~65-tarball transitive Boost port graph entirely. The remaining four (`zlib`, `openssl`, `abseil`, `protobuf`, `nlopt`) are genuinely compiled and need real `flatpak-builder` modules under `distribution/flatpak/modules/` — none of those files exist yet. Before hand-writing them: check `https://github.com/flathub/shared-modules` for existing definitions to reuse, and check whether `org.freedesktop.Sdk` already ships `zlib`/`openssl` dev headers (it's an unusually comprehensive base SDK — they may not need bundling at all).

The genuinely unsolved piece is the `konjugate` engine module: `engine/CMakePresets.json` always points `CMAKE_TOOLCHAIN_FILE` at vcpkg's own toolchain script, which would try to fetch every dependency over the network again inside the sandbox. This needs either a new CMake preset that skips the vcpkg toolchain file and resolves `find_package(...)` against the Flatpak module prefix (`CMAKE_PREFIX_PATH=/app`), or an additive `KONJUGATE_SKIP_VCPKG`-style CMake option. Neither exists yet — it's real engine-build-system work, scoped as its own task.

The npm/Electron half is more standard: `npm run flatpak:generate-sources` (`scripts/generateFlatpakNodeSources.mjs`) runs `flatpak-node-generator` against `package-lock.json` to produce an offline-installable `distribution/flatpak/generatedSources.json` (gitignored, regenerated on demand — mirrors `scripts/generateReportProtocol.mjs`'s codegen convention). `flatpak-node-generator` is a Python tool, installed via `pipx install git+https://github.com/flatpak/flatpak-builder-tools.git#subdirectory=node`, not an npm package.

**One-time setup, once the manifest actually builds:**
1. `flatpak-builder --user --install` locally against the manifest, iterating on the TODOs above until it's green — this is the real verification loop, not a one-shot check.
2. Submit as a new repo under the `flathub` GitHub org, per Flathub's new-submission intake — human-reviewed, same shape as Snap's classic-confinement review.
3. After acceptance, add an `x-checker-data` block to `packaging/linux/com.konjugate.Konjugate.metainfo.xml` so Flathub's own bot detects new GitHub releases automatically — no CI work needed in this repo for ongoing updates.
