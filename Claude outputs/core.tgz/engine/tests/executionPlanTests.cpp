/* Copyright © 2026 Zenin Easa Panthakkalakath */

#include "executionPlan.hpp"
#include "dependencyGraph.hpp"
#include "executionBackend.hpp"
#include "partitionPlan.hpp"
#include "partitionRuntime.hpp"
#include "taskExecutor.hpp"
#include <algorithm>
#include <boost/property_tree/json_parser.hpp>
#include <atomic>
#include <chrono>
#include <cmath>
#include <iostream>
#include <random>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>

namespace {

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

konjugate::CompiledExpression symbol(const std::string& name, std::size_t index = 0) {
    konjugate::CompiledExpression expression;
    expression.operation = konjugate::ExpressionOperation::symbol;
    expression.symbol = name;
    expression.symbolIndex = index;
    return expression;
}

konjugate::CompiledExpression add(std::initializer_list<konjugate::CompiledExpression> arguments) {
    konjugate::CompiledExpression expression;
    expression.operation = konjugate::ExpressionOperation::add;
    expression.arguments = arguments;
    return expression;
}

konjugate::CompiledExpression literal(double value) {
    konjugate::CompiledExpression expression;
    expression.literal = value;
    return expression;
}

konjugate::CompiledExpression operation(konjugate::ExpressionOperation kind, std::initializer_list<konjugate::CompiledExpression> arguments) {
    konjugate::CompiledExpression expression;
    expression.operation = kind;
    expression.arguments = arguments;
    return expression;
}

void conditionalExpressionsPickTheFirstMatchingBranch() {
    using Op = konjugate::ExpressionOperation;
    // cases: 10 if x > 1, 20 if 0 < x <= 1, otherwise 30
    const auto cases = operation(Op::conditional, {
        operation(Op::greater, {symbol("x"), literal(1)}), literal(10),
        operation(Op::less, {literal(0), symbol("x"), literal(1)}), literal(20),
        operation(Op::lessEqual, {symbol("x"), literal(1)}), literal(25),
        literal(1), literal(30)
    });
    require(cases.evaluate({2}) == 10, "The first true branch was not chosen.");
    require(cases.evaluate({0.5}) == 20, "A chained comparison was not evaluated pairwise.");
    require(cases.evaluate({1}) == 25, "A chained comparison should fail when any pair fails.");
    require(cases.evaluate({-1}) == 25, "Branches must be tried in order.");
    const auto otherwise = operation(Op::conditional, {operation(Op::greater, {symbol("x"), literal(0)}), literal(1), literal(1), literal(-1)});
    require(otherwise.evaluate({-5}) == -1, "The otherwise branch was not used.");
    // An untaken branch is never evaluated, so a division by zero there cannot poison the result.
    const auto guarded = operation(Op::conditional, {
        operation(Op::notEqual, {symbol("x"), literal(0)}), operation(Op::divide, {literal(1), symbol("x")}),
        literal(1), literal(0)
    });
    require(guarded.evaluate({0}) == 0, "An untaken branch affected the result.");
    const auto logic = operation(Op::conditional, {
        operation(Op::logicalAnd, {operation(Op::greaterEqual, {symbol("x"), literal(0)}), operation(Op::logicalNot, {operation(Op::equal, {symbol("x"), literal(3)})})}), literal(1),
        operation(Op::logicalOr, {operation(Op::equal, {symbol("x"), literal(3)}), operation(Op::less, {symbol("x"), literal(-10)})}), literal(2),
        literal(1), literal(3)
    });
    require(logic.evaluate({1}) == 1, "And/Not were not evaluated.");
    require(logic.evaluate({-20}) == 2, "Or was not evaluated.");
    require(logic.evaluate({-1}) == 3, "Logic fell through incorrectly.");
    bool threw = false;
    try {
        operation(Op::conditional, {operation(Op::greater, {symbol("x"), literal(0)}), literal(1)}).evaluate({-1});
    } catch (const std::runtime_error&) {
        threw = true;
    }
    require(threw, "A cases expression with no matching branch must fail loudly.");
}

void deterministicReductionUsesTaskSequence() {
    std::vector<konjugate::EvaluatedContribution> completedOutOfOrder = {
        {2, 1, 1},
        {0, 1, 1e16},
        {1, 1, -1e16}
    };
    const auto derivatives = konjugate::reduceContributions(std::move(completedOutOfOrder));
    require(derivatives.size() == 1, "Contributions for one state were not reduced together.");
    require(derivatives.front().second == 1, "Reduction did not preserve declared task order.");
}

void evaluationSeparatesLocalSnapshotAndLiveParameterInputs() {
    konjugate::NodeExecutionPlan node;
    node.nodeId = 1;
    konjugate::ContributionTask task;
    task.sequence = 0;
    task.outputStateId = 5;
    task.bindings = {
        {"local", konjugate::BindingSource::localState, 2},
        {"remote", konjugate::BindingSource::synchronizationSnapshot, 3},
        {"gain", konjugate::BindingSource::parameter, 4}
    };
    task.parameters = {{4, 3, true}};
    task.bindings[0].valueIndex = 0;
    task.bindings[1].valueIndex = 1;
    task.bindings[2].parameterIndex = 0;
    task.expression = add({symbol("local", 0), symbol("remote", 1), symbol("gain", 2)});
    require(task.expression.operationCount() == 4, "Static expression work was not counted recursively.");
    node.contributions.push_back(std::move(task));

    const konjugate::StateValues local = {2, 999};
    const konjugate::StateValues snapshot = {-1, 5};
    const konjugate::EntityValues overrides = {{4, 7}};
    const auto evaluated = konjugate::evaluateContributionTasks(
        node, local, snapshot, konjugate::resolveParameterValues(node, overrides));
    require(evaluated.size() == 1, "The contribution task was not evaluated.");
    require(std::abs(evaluated.front().value - 14) < 1e-12,
        "Evaluation did not respect local state, synchronization snapshot and live parameter boundaries.");
}

// A time binding reads the substep's start time in a differential contribution and its end time
// in an algebraic one.
void timeBindingReadsSubstepStartForDerivativesAndTheEvaluationTimeForAlgebraicStates() {
    konjugate::NodeExecutionPlan node;
    node.nodeId = 1;
    konjugate::ContributionTask differential;
    differential.outputStateId = 5;
    differential.outputStateIndex = 0;
    differential.bindings = {{"t", konjugate::BindingSource::simulationTime, 0}};
    differential.expression = symbol("t", 0);
    node.contributions.push_back(differential);
    const auto evaluated = konjugate::evaluateContributionTasks(
        node, {0}, {0}, konjugate::resolveParameterValues(node, {}), 3.0, 0.5);
    require(evaluated.size() == 1 && evaluated.front().value == 3.0, "A differential time binding must read the substep start time.");

    // An algebraic value is g(x, t) at the instant its states represent: integrateNode passes the
    // substep start before the derivatives and the step end after the last update.
    std::vector<konjugate::ContributionTask> algebraicTasks = {differential};
    konjugate::StateValues local = {0};
    konjugate::applyAlgebraicTasks(algebraicTasks, local, konjugate::resolveParameterValues(algebraicTasks, {}), 3.0, 0.5, nullptr);
    require(local[0] == 3.0, "An algebraic time binding must read the time it is evaluated at.");
}

void parameterScheduleEvaluatesEachModeAndSupersedesEarlierSchedules() {
    using konjugate::ParameterSchedule;
    using konjugate::evaluateParameterSchedule;

    ParameterSchedule step;
    step.mode = ParameterSchedule::Mode::step;
    step.targetValue = 42;
    require(evaluateParameterSchedule(step, 0) == 42 && evaluateParameterSchedule(step, 1000) == 42,
        "A step schedule must hold its target value regardless of simulation time.");

    ParameterSchedule ramp;
    ramp.mode = ParameterSchedule::Mode::ramp;
    ramp.startTime = 2;
    ramp.duration = 4;
    ramp.baseValue = 0;
    ramp.targetValue = 8;
    require(evaluateParameterSchedule(ramp, 1) == 0, "A ramp must hold its base value before startTime.");
    require(std::abs(evaluateParameterSchedule(ramp, 2) - 0) < 1e-12, "A ramp must begin exactly at baseValue.");
    require(std::abs(evaluateParameterSchedule(ramp, 4) - 4) < 1e-12, "A ramp must be halfway through its transition at its midpoint.");
    require(std::abs(evaluateParameterSchedule(ramp, 6) - 8) < 1e-12, "A ramp must reach targetValue exactly at startTime + duration.");
    require(evaluateParameterSchedule(ramp, 100) == 8, "A ramp must hold its target value after the transition completes.");

    ParameterSchedule pulse;
    pulse.mode = ParameterSchedule::Mode::pulse;
    pulse.startTime = 5;
    pulse.duration = 2;
    pulse.baseValue = 1;
    pulse.targetValue = 9;
    require(evaluateParameterSchedule(pulse, 4) == 1, "A pulse must read as its base value before startTime.");
    require(evaluateParameterSchedule(pulse, 5) == 9, "A pulse must read as its target value starting exactly at startTime.");
    require(evaluateParameterSchedule(pulse, 6.9) == 9, "A pulse must still read as its target value just before it ends.");
    require(evaluateParameterSchedule(pulse, 7) == 1, "A pulse must return to its base value exactly at startTime + duration.");

    ParameterSchedule piecewise;
    piecewise.mode = ParameterSchedule::Mode::piecewise;
    piecewise.baseValue = -1;
    piecewise.samples = {{0, 0}, {2, 10}, {4, 10}, {6, 0}};
    require(evaluateParameterSchedule(piecewise, -5) == 0, "Piecewise must edge-hold the first sample before its range.");
    require(std::abs(evaluateParameterSchedule(piecewise, 1) - 5) < 1e-12, "Piecewise must linearly interpolate between samples.");
    require(evaluateParameterSchedule(piecewise, 3) == 10, "Piecewise must hold a flat segment between two equal-valued samples.");
    require(evaluateParameterSchedule(piecewise, 100) == 0, "Piecewise must edge-hold the last sample past its range.");

    // A later intervention (startTime 10) layered onto an earlier one (startTime 0) for the same
    // parameter must take over the instant it begins, and the earlier one must still govern
    // before that -- resolveParameterValues' "latest schedule that has already started" rule.
    konjugate::NodeExecutionPlan node;
    konjugate::ContributionTask task;
    task.parameters = {{7, 0, true}};
    node.contributions.push_back(task);
    const konjugate::EntityValues noOverrides;
    ParameterSchedule earlier;
    earlier.parameterId = 7;
    earlier.mode = ParameterSchedule::Mode::step;
    earlier.startTime = 0;
    earlier.targetValue = 100;
    ParameterSchedule later;
    later.parameterId = 7;
    later.mode = ParameterSchedule::Mode::step;
    later.startTime = 10;
    later.targetValue = 200;
    const std::vector<ParameterSchedule> schedules = {earlier, later};
    require(konjugate::resolveParameterValues(node, noOverrides, schedules, 5).front().front() == 100,
        "Before the later schedule starts, the earlier one must still govern.");
    require(konjugate::resolveParameterValues(node, noOverrides, schedules, 10).front().front() == 200,
        "The later schedule must take over the instant it starts.");
    require(konjugate::resolveParameterValues(node, noOverrides, {}, 999).front().front() == 0,
        "With no active schedules at all, resolution must fall through to the compiled constant unchanged.");
}

konjugate::ContributionTask literalAlgebraicTask(konjugate::EntityId outputStateId, std::size_t outputStateIndex, double literal) {
    konjugate::ContributionTask task;
    task.outputStateId = outputStateId;
    task.outputStateIndex = outputStateIndex;
    task.expression.operation = konjugate::ExpressionOperation::literal;
    task.expression.literal = literal;
    return task;
}

// Proves the real, solver-generic "sets the value" mechanism (NodeExecutionPlan::algebraicTasks +
// applyAlgebraicTasks) that replaced the earlier Euler-specific pseudo-derivative trick: an
// algebraic state's value is recomputed directly from its expression -- no stepSize, no current-
// value feedback anywhere in the computation -- so it snaps exactly to the target on the very
// first substep regardless of how mismatched the state's prior value was, and would compose
// identically under any future solver (a genuine recompute, not an integration).
void applyAlgebraicTasksSnapsMismatchedStateToTargetImmediately() {
    const std::vector<konjugate::ContributionTask> algebraicTasks = {literalAlgebraicTask(5, 0, 42)};
    konjugate::StateValues local = {0}; // deliberately far from the target (42).
    konjugate::applyAlgebraicTasks(algebraicTasks, local, konjugate::resolveParameterValues(algebraicTasks, {}), 0.0, 0.5, nullptr);
    require(local[0] == 42, "applyAlgebraicTasks did not write the target value directly into localStates.");
}

// Two algebraic tasks where the second depends on the first's own output state -- proves
// dependency order is respected within one pass, so a later task sees the earlier task's
// freshly-recomputed value, not a stale one.
void applyAlgebraicTasksResolveDependencyOrderWithinOnePass() {
    konjugate::ContributionTask first = literalAlgebraicTask(5, 0, 10);
    konjugate::ContributionTask second;
    second.outputStateId = 6;
    second.outputStateIndex = 1;
    second.bindings = {{"y", konjugate::BindingSource::localState, 5}};
    second.bindings[0].valueIndex = 0; // state 5 (first's output) lives at local index 0.
    second.expression.operation = konjugate::ExpressionOperation::add;
    second.expression.arguments = {
        {konjugate::ExpressionOperation::symbol, 0, "y", 0, {}},
        {konjugate::ExpressionOperation::literal, 1, "", std::numeric_limits<std::size_t>::max(), {}}
    };
    const std::vector<konjugate::ContributionTask> algebraicTasks = {first, second}; // dependency-sorted order.

    konjugate::StateValues local = {0, 0};
    konjugate::applyAlgebraicTasks(algebraicTasks, local, konjugate::resolveParameterValues(algebraicTasks, {}), 0.0, 0.5, nullptr);
    require(local[0] == 10, "The first algebraic task's own value was not recomputed correctly.");
    require(local[1] == 11, "The second algebraic task did not see the first task's freshly-recomputed value (expected 10+1=11).");
}

void applyAlgebraicTasksRejectsANonFiniteResult() {
    konjugate::ContributionTask task = literalAlgebraicTask(5, 0, 0);
    task.expression.operation = konjugate::ExpressionOperation::divide;
    task.expression.arguments = {
        {konjugate::ExpressionOperation::literal, 1, "", std::numeric_limits<std::size_t>::max(), {}},
        {konjugate::ExpressionOperation::literal, 0, "", std::numeric_limits<std::size_t>::max(), {}}
    };
    const std::vector<konjugate::ContributionTask> algebraicTasks = {task};
    konjugate::StateValues local = {0};
    bool threw = false;
    try {
        konjugate::applyAlgebraicTasks(algebraicTasks, local, konjugate::resolveParameterValues(algebraicTasks, {}), 0.0, 0.5, nullptr);
    } catch (const std::exception&) {
        threw = true;
    }
    require(threw, "A non-finite algebraic result should throw rather than silently corrupt localStates.");
}

// End-to-end via the real (shared, deduplicated) integrateNode: an algebraic task and an ordinary
// differential contribution on the SAME node, where the differential contribution reads the
// algebraic state as one of its own bindings -- proves algebraic tasks are recomputed before
// differential contributions are evaluated in the same substep, so the latter sees the fresh
// value, not the previous substep's.
void integrateNodeAppliesAlgebraicTasksBeforeDifferentialContributionsEachSubstep() {
    konjugate::NodeExecutionPlan node;
    node.nodeId = 1;
    node.substeps = 1;
    node.stateIndexes = {0, 1}; // global positions in the snapshot: local index 0 -> global 0, local 1 -> global 1.
    node.algebraicTasks = {literalAlgebraicTask(5, 0, 10)}; // state id 5 (metadata only): algebraic, "y = 10".

    konjugate::ContributionTask differential;
    differential.outputStateId = 6;
    differential.outputStateIndex = 1;
    differential.bindings = {{"y", konjugate::BindingSource::localState, 5}};
    differential.bindings[0].valueIndex = 0;
    differential.expression = {konjugate::ExpressionOperation::symbol, 0, "y", 0, {}};
    node.contributions = {differential};

    const konjugate::StateValues snapshot = {0, 0}; // both states start at 0 (global-index order matches stateIndexes here).
    const auto result = konjugate::integrateNode(node, snapshot, {}, 0.0, 0.5);
    require(result.states[0] == 10, "The algebraic state was not recomputed by integrateNode.");
    require(result.states[1] == 5, "The differential contribution did not see the algebraic state's fresh value (expected 0 + 10*0.5 = 5).");
}

// x' = 1 and y = 2x on one node: after one step of 0.5 from x = 0, the node must hand back
// y = 2 * 0.5 beside x = 0.5, not the y computed from x = 0 before the update. Other nodes read the
// returned values, so a stale y would reach them one step late.
void integrateNodeHandsBackAlgebraicStatesThatMatchTheUpdatedStates() {
    konjugate::NodeExecutionPlan node;
    node.nodeId = 1;
    node.substeps = 2;
    node.stateIndexes = {0, 1};

    konjugate::ContributionTask rate = literalAlgebraicTask(5, 0, 1); // x' = 1
    rate.outputStateId = 5;
    rate.outputStateIndex = 0;
    node.contributions = {rate};

    konjugate::ContributionTask doubled;
    doubled.outputStateId = 6;
    doubled.outputStateIndex = 1;
    doubled.bindings = {{"x", konjugate::BindingSource::localState, 5}};
    doubled.bindings[0].valueIndex = 0;
    doubled.expression = {konjugate::ExpressionOperation::multiply, 0, "", 0,
        {{konjugate::ExpressionOperation::literal, 2, "", 0, {}}, {konjugate::ExpressionOperation::symbol, 0, "x", 0, {}}}};
    node.algebraicTasks = {doubled};

    const auto result = konjugate::integrateNode(node, {0, 0}, {}, 0.0, 0.5);
    require(std::abs(result.states[0] - 0.5) < 1e-12, "x' = 1 over 0.5 should reach 0.5.");
    require(std::abs(result.states[1] - 1.0) < 1e-12, "The node must hand back y = 2x for the updated x (expected 1).");
}

void taskExecutorBoundsConcurrentWorkAndPropagatesResults() {
    konjugate::TaskExecutor executor(2);
    std::atomic<int> active = 0;
    std::atomic<int> maximum = 0;
    std::vector<std::future<int>> futures;
    for (int value = 0; value < 8; ++value) {
        futures.push_back(executor.submit([value, &active, &maximum] {
            const auto current = ++active;
            auto observed = maximum.load();
            while (current > observed && !maximum.compare_exchange_weak(observed, current)) {}
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
            --active;
            return value * value;
        }));
    }
    for (int value = 0; value < 8; ++value) require(futures[value].get() == value * value, "A worker result was not propagated.");
    require(maximum.load() == 2, "The task executor did not use exactly its bounded worker count.");
    require(executor.workerCount() == 2, "The task executor reported an incorrect worker count.");
}

void taskSubmissionPrioritizesEstimatedWorkAndKeepsStableTies() {
    std::vector<konjugate::NodeExecutionPlan> nodes(4);
    nodes[0].estimatedOperationsPerSubstep = 2;
    nodes[0].substeps = 2;
    nodes[1].estimatedOperationsPerSubstep = 8;
    nodes[1].substeps = 1;
    nodes[2].estimatedOperationsPerSubstep = 4;
    nodes[2].substeps = 2;
    nodes[3].estimatedOperationsPerSubstep = 1;
    nodes[3].substeps = 1;
    require(konjugate::planTaskSubmissionOrder(nodes) == std::vector<std::size_t>({1, 2, 0, 3}),
        "Task submission did not prioritize estimated work with stable ties.");
}

void dependencyGraphAggregatesParallelTasksAndPreservesDirection() {
    konjugate::ExecutionPlan plan;
    plan.nodes.resize(4);
    for (std::size_t index = 0; index < plan.nodes.size(); ++index) {
        plan.nodes[index].nodeId = index + 1;
        plan.nodes[index].stateIds = {index + 101};
        plan.stateNodes[plan.nodes[index].stateIds.front()] = plan.nodes[index].nodeId;
    }
    plan.nodes[0].stateIds.push_back(105);
    plan.stateNodes[105] = 1;
    plan.nodes[1].substeps = 2;

    konjugate::ContributionTask firstForward;
    firstForward.sequence = 0;
    firstForward.outputStateId = 102;
    firstForward.bindings = {
        {"first", konjugate::BindingSource::synchronizationSnapshot, 101},
        {"second", konjugate::BindingSource::synchronizationSnapshot, 105}
    };
    firstForward.expression = add({symbol("first"), symbol("second")});
    konjugate::ContributionTask secondForward;
    secondForward.sequence = 1;
    secondForward.outputStateId = 102;
    secondForward.bindings = {{"first", konjugate::BindingSource::synchronizationSnapshot, 101}};
    secondForward.expression = symbol("first");
    plan.nodes[1].contributions = {firstForward, secondForward};
    plan.nodes[1].estimatedOperationsPerSubstep = 4;

    konjugate::ContributionTask reverse;
    reverse.sequence = 0;
    reverse.outputStateId = 101;
    reverse.bindings = {{"remote", konjugate::BindingSource::synchronizationSnapshot, 102}};
    reverse.expression = symbol("remote");
    plan.nodes[0].contributions = {reverse};
    plan.nodes[0].estimatedOperationsPerSubstep = 1;

    const auto graph = konjugate::buildDependencyGraph(plan);
    require(graph.nodes.size() == 4 && graph.dependencies.size() == 2, "Dependency graph has an incorrect shape.");
    require(graph.componentCount == 3, "Disconnected components were not identified deterministically.");
    require(graph.nodes[0].component == graph.nodes[1].component && graph.nodes[2].component != graph.nodes[0].component,
        "Connected nodes were assigned to incorrect components.");
    const auto forward = std::find_if(graph.dependencies.begin(), graph.dependencies.end(), [](const auto& dependency) {
        return dependency.sourceNodeId == 1 && dependency.targetNodeId == 2;
    });
    require(forward != graph.dependencies.end(), "The forward dependency is missing.");
    require(forward->contributionTaskCount == 2, "Parallel contribution tasks were not aggregated.");
    require(forward->remoteBindingsPerSubstep == 3 && forward->remoteStateIds.size() == 2,
        "Remote bindings and unique communicated states were conflated.");
    require(forward->estimatedDependentOperationsPerSynchronization == 8 && forward->communicationWeight == 2,
        "Dependency weights are incorrect.");
    require(std::any_of(graph.dependencies.begin(), graph.dependencies.end(), [](const auto& dependency) {
        return dependency.sourceNodeId == 2 && dependency.targetNodeId == 1;
    }), "Reverse data flow was not preserved as a separate directed dependency.");
}

void greedyPartitionerBalancesIndependentWork() {
    konjugate::DependencyGraph graph;
    graph.nodes = {
        {1, 1, 1, 8, 0},
        {2, 1, 1, 7, 1},
        {3, 1, 1, 6, 2},
        {4, 1, 1, 5, 3}
    };
    graph.componentCount = 4;
    const auto partitioned = konjugate::createGreedyPartitionPlan(graph, 2);
    require(partitioned.effectivePartitions == 2, "The requested partition count was not created.");
    require(partitioned.partitions[0].computeWeight == 13 && partitioned.partitions[1].computeWeight == 13,
        "Independent computation was not balanced.");
    require(std::abs(partitioned.greedy.computeImbalance - 1) < 1e-12,
        "Balanced partitions reported an incorrect imbalance.");
    require(partitioned.greedy.computeImbalance < partitioned.roundRobin.computeImbalance,
        "Greedy placement did not improve on round robin for uneven work.");
}

void greedyPartitionerCanKeepExpensiveCommunicationLocal() {
    konjugate::DependencyGraph graph;
    graph.nodes = {
        {1, 1, 1, 1, 0},
        {2, 1, 1, 1, 0},
        {3, 1, 1, 1, 1}
    };
    graph.dependencies = {{1, 2, {101}, 1, 1, 1, 100}};
    graph.componentCount = 2;
    const auto partitioned = konjugate::createGreedyPartitionPlan(graph, 2);
    require(partitioned.assignments[0].partition == partitioned.assignments[1].partition,
        "A high-communication dependency was cut unnecessarily.");
    require(partitioned.greedy.communicationCutWeight == 0 && partitioned.roundRobin.communicationCutWeight == 100,
        "Communication-cut comparison is incorrect.");
    const auto balanceOnly = konjugate::createGreedyPartitionPlan(graph, 2, 0);
    const auto targetPartition = balanceOnly.assignments[1].partition;
    require(balanceOnly.assignments[0].partition != targetPartition,
        "The balance-only reference plan did not cut the dependency as expected.");
    require(balanceOnly.partitions[targetPartition].boundaryStateCount == 1,
        "The receiving partition did not report its exchanged boundary state.");
    require(balanceOnly.partitions[0].localStateCount + balanceOnly.partitions[1].localStateCount == 3,
        "Partition-local state accounting is incorrect.");
}

void greedyPartitionerClustersACommunicationRing() {
    konjugate::DependencyGraph graph;
    for (std::size_t index = 0; index < 12; ++index) {
        graph.nodes.push_back({index + 1, 1, 1, 10, 0});
    }
    for (std::size_t index = 0; index < graph.nodes.size(); ++index) {
        graph.dependencies.push_back({
            graph.nodes[index].nodeId,
            graph.nodes[(index + 1) % graph.nodes.size()].nodeId,
            {index + 101}, 1, 1, 1, 1
        });
    }
    graph.componentCount = 1;
    const auto partitioned = konjugate::createGreedyPartitionPlan(graph, 3);
    require(partitioned.greedy.communicationCutWeight <= 3,
        "The greedy partitioner fragmented a simple communication ring.");
    require(partitioned.greedy.communicationCutWeight < partitioned.roundRobin.communicationCutWeight,
        "Communication-aware placement did not improve on round robin for a ring.");
}

void partitionerSelectionUsesMetisWhenAvailable() {
    konjugate::DependencyGraph graph;
    for (std::size_t index = 0; index < 12; ++index) {
        graph.nodes.push_back({index + 1, 1, 1, 10, 0});
    }
    for (std::size_t index = 0; index < graph.nodes.size(); ++index) {
        graph.dependencies.push_back({
            graph.nodes[index].nodeId, graph.nodes[(index + 1) % graph.nodes.size()].nodeId,
            {index + 101}, 1, 1, 1, 1
        });
    }
    const auto automatic = konjugate::createPartitionPlan(graph, 3);
    require(automatic.requestedAlgorithm == "automatic", "The requested partition algorithm was not recorded.");
    require(automatic.assignments.size() == graph.nodes.size(), "The selected partitioner omitted graph nodes.");
    require(automatic.selected.computeImbalance >= 1, "The selected partition metrics were not reported.");
    if (konjugate::metisPartitionerAvailable()) {
        if (automatic.algorithm == "communicationAwareGreedy" && automatic.fallbackReason == "metisPartitioningFailed") {
            bool metisErrorCaught = false;
            try {
                static_cast<void>(konjugate::createPartitionPlan(graph, 3, 4, "metisKway"));
            } catch (const std::runtime_error&) {
                metisErrorCaught = true;
            }
            require(metisErrorCaught, "Failed METIS partitioning did not throw when explicitly requested.");
        } else {
            require(automatic.algorithm == "metisKway", "Automatic partitioning did not prefer an available METIS build.");
            const auto explicitMetis = konjugate::createPartitionPlan(graph, 3, 4, "metisKway");
            require(explicitMetis.algorithm == "metisKway" && explicitMetis.fallbackReason.empty(),
                "Explicit METIS partitioning unexpectedly fell back.");
        }
    } else {
        require(automatic.algorithm == "communicationAwareGreedy" && automatic.fallbackReason == "metisUnavailable",
            "Automatic partitioning did not report its METIS fallback.");
        bool unavailableRejected = false;
        try {
            static_cast<void>(konjugate::createPartitionPlan(graph, 3, 4, "metisKway"));
        } catch (const std::runtime_error&) {
            unavailableRejected = true;
        }
        require(unavailableRejected, "An explicit METIS request was accepted by a build without METIS.");
    }
}

konjugate::ExecutionPlan singleNodeRuntimePlan() {
    konjugate::ExecutionPlan plan;
    plan.initialStates = {1};
    plan.stateIds = {2};
    plan.stateIndexes = {{2, 0}};
    plan.stateNodes = {{2, 1}};
    konjugate::NodeExecutionPlan node;
    node.nodeId = 1;
    node.stateIds = {2};
    node.stateIndexes = {0};
    konjugate::ContributionTask contribution;
    contribution.outputStateId = 2;
    contribution.outputStateIndex = 0;
    contribution.bindings = {{"state", konjugate::BindingSource::localState, 2}};
    contribution.bindings[0].valueIndex = 0;
    contribution.expression = symbol("state");
    node.contributions = {contribution};
    plan.nodes = {node};
    return plan;
}

void partitionTransportWaitsForDelayedMessagesAndRejectsDuplicates() {
    konjugate::InMemoryPartitionTransport transport;
    auto delayed = std::async(std::launch::async, [&] {
        return transport.receive(2, 7, std::chrono::milliseconds(200));
    });
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    transport.publish({1, 7, 2, {{3, 4}}});
    const auto received = delayed.get();
    require(received.states.at(3) == 4, "A delayed boundary message was not delivered intact.");

    transport.publish({1, 8, 2, {}});
    bool duplicateRejected = false;
    try {
        transport.publish({1, 8, 2, {}});
    } catch (const std::runtime_error&) {
        duplicateRejected = true;
    }
    require(duplicateRejected, "Duplicate boundary delivery was not rejected.");
}

void partitionTransportReportsMissingMessagesAndWorkerFailures() {
    konjugate::InMemoryPartitionTransport transport;
    bool missingRejected = false;
    try {
        static_cast<void>(transport.receive(0, 99, std::chrono::milliseconds(5)));
    } catch (const std::runtime_error&) {
        missingRejected = true;
    }
    require(missingRejected, "A missing boundary message did not time out.");

    const auto plan = singleNodeRuntimePlan();
    konjugate::PartitionRuntime runtime(0, plan, {0});
    auto failed = runtime.submit(transport, 1, {}, 0.1);
    transport.publish({1, 1, 0, {}});
    bool workerFailurePropagated = false;
    try {
        static_cast<void>(failed.get());
    } catch (const std::out_of_range&) {
        workerFailurePropagated = true;
    }
    require(workerFailurePropagated, "A partition worker failure was not propagated to the coordinator.");
}

void partitionRuntimeReplaysDeterministicallyThroughMessages() {
    const auto plan = singleNodeRuntimePlan();
    konjugate::PartitionRuntime runtime(0, plan, {0});
    konjugate::InMemoryPartitionTransport transport;
    const auto execute = [&](std::size_t synchronizationIndex) {
        auto future = runtime.submit(transport, synchronizationIndex, {}, 0.1);
        konjugate::PartitionBoundaryMessage message{1, synchronizationIndex, 0, {{2, 1}}};
        require(konjugate::partitionMessagePayloadBytes(message) == sizeof(konjugate::EntityId) + sizeof(double),
            "Boundary payload accounting is incorrect.");
        transport.publish(std::move(message));
        return future.get();
    };
    const auto first = execute(3);
    const auto replay = execute(3);
    require(first.nodes.size() == 1 && replay.nodes.size() == 1, "Partition execution omitted a node result.");
    require(first.nodes.front().states == replay.nodes.front().states &&
            std::abs(first.nodes.front().states.at(0) - 1.1) < 1e-12,
        "Partition replay was not deterministic.");
}

void automaticBackendSelectionAccountsForWorkAndCommunication() {
    using konjugate::BackendSelectionReason;
    using konjugate::ExecutionBackend;
    const auto light = konjugate::selectExecutionBackend(ExecutionBackend::automatic, 8, 800, 128, 0, 0, 0.25);
    require(light.backend == ExecutionBackend::serial && light.reason == BackendSelectionReason::belowParallelWorkThreshold,
        "A light model was parallelized automatically.");
    const auto independent = konjugate::selectExecutionBackend(ExecutionBackend::automatic, 8, 8192, 128, 0, 0, 0.25);
    require(independent.backend == ExecutionBackend::partitioned && independent.reason == BackendSelectionReason::independentParallelWork,
        "Independent heavy work did not select partitioned execution.");
    const auto connected = konjugate::selectExecutionBackend(ExecutionBackend::automatic, 8, 8192, 128, 2, 20, 0.25);
    require(connected.backend == ExecutionBackend::partitioned && std::abs(connected.communicationCutFraction - 0.1) < 1e-12,
        "A low-cut connected graph did not select partitioned execution.");
    const auto dense = konjugate::selectExecutionBackend(ExecutionBackend::automatic, 8, 8192, 128, 9, 20, 0.25);
    require(dense.backend == ExecutionBackend::threadPool && dense.reason == BackendSelectionReason::partitionCommunicationCutTooHigh,
        "A communication-heavy partition plan did not fall back to the shared-memory thread pool.");
    const auto explicitBackend = konjugate::selectExecutionBackend(ExecutionBackend::threadPool, 8, 8192, 128, 20, 20, 0);
    require(explicitBackend.backend == ExecutionBackend::threadPool && explicitBackend.reason == BackendSelectionReason::explicitSelection,
        "An explicit backend selection was overridden.");
}

}


// A shared parameter's stored schedule (sharedParameters[].schedule): compiled from the document
// itself, so every run follows it from step 0, beneath live control and recorded interventions.
konjugate::ExecutionPlan scheduledProject(const std::string& mode, const std::string& interpolation) {
    std::istringstream input(R"json({
        "format": "konjugate", "version": 1,
        "sharedParameters": [{"id": 30, "name": "Rate", "symbol": "rate", "value": 99, "mode": ")json" + mode + R"json(",
            "schedule": {"interpolation": ")json" + interpolation + R"json(", "samples": [[0, 1], [10, 3], [20, 3]]}}],
        "nodes": [{
            "id": 1, "name": "Tank",
            "states": [{"id": 11, "name": "X", "symbol": "x", "initialValue": 0}],
            "sourceTerms": [{
                "id": 21, "state": "x", "expression": "\\mathrm{rate}",
                "parameters": [{"id": 22, "name": "Rate", "symbol": "rate", "value": 5, "mode": "constant", "sharedParameterId": 30}],
                "expressionModel": {
                    "latex": "\\mathrm{rate}", "output": {"stateId": 11},
                    "bindings": [{"kind": "parameter", "parameterId": 22, "symbol": "rate", "label": "rate"}],
                    "mathJson": "rate"
                }
            }],
            "numerics": {"substepsPerGlobalStep": 4}
        }],
        "edges": []
    })json");
    boost::property_tree::ptree document;
    boost::property_tree::read_json(input, document);
    return konjugate::compileExecutionPlan(document);
}

void storedParameterSchedulesDriveTheParameterBeneathLiveControl() {
    using konjugate::ParameterSchedule;
    // Hold: a staircase, each value kept until the next sample.
    ParameterSchedule hold;
    hold.mode = ParameterSchedule::Mode::piecewise;
    hold.hold = true;
    hold.samples = {{0, 1}, {10, 3}, {20, 5}};
    require(konjugate::evaluateParameterSchedule(hold, -1) == 1, "A held schedule edge-holds its first sample.");
    require(konjugate::evaluateParameterSchedule(hold, 9.999) == 1, "A held schedule keeps a sample's value until the next sample.");
    require(konjugate::evaluateParameterSchedule(hold, 10) == 3, "A held schedule takes a sample's value exactly at its time.");
    require(konjugate::evaluateParameterSchedule(hold, 25) == 5, "A held schedule edge-holds its last sample.");

    // The binary search agrees with a plain linear scan over a long, uneven series.
    ParameterSchedule longSeries;
    longSeries.mode = ParameterSchedule::Mode::piecewise;
    std::mt19937 random(7);
    std::uniform_real_distribution<double> gap(0.1, 2.0);
    std::uniform_real_distribution<double> level(-50, 50);
    double time = 0;
    for (int index = 0; index < 400; ++index) longSeries.samples.emplace_back(time += gap(random), level(random));
    for (double at = -1; at < time + 1; at += 0.37) {
        double expected = longSeries.samples.front().second;
        if (at >= longSeries.samples.back().first) expected = longSeries.samples.back().second;
        else for (std::size_t index = 1; index < longSeries.samples.size(); ++index) {
            const auto [t1, v1] = longSeries.samples[index];
            const auto [t0, v0] = longSeries.samples[index - 1];
            if (at > t0 && at <= t1) { expected = v0 + (at - t0) / (t1 - t0) * (v1 - v0); break; }
        }
        require(std::abs(konjugate::evaluateParameterSchedule(longSeries, at) - expected) < 1e-9, "Interpolation must match a linear scan.");
    }

    // Compiled from the document: the linked parameter follows its shared parameter's schedule, not
    // its own value (5) or the shared constant (99).
    const auto plan = scheduledProject("constant", "hold");
    require(plan.nodes.size() == 1 && plan.nodes.front().hasParameterSchedules, "A node reading a scheduled parameter is marked as such.");
    const auto at = [&](double simulationTime, const konjugate::EntityValues& live = {}, const std::vector<ParameterSchedule>& active = {}) {
        return konjugate::resolveParameterValues(plan.nodes.front(), live, active, simulationTime).front().front();
    };
    require(at(5) == 1 && at(10) == 3 && at(15) == 3, "The parameter follows its stored schedule.");
    // A constant parameter ignores live control, scheduled or not.
    require(at(5, {{30, 7}}) == 1, "A constant scheduled parameter ignores a live value.");

    // Integrated through the same integrateNode the runner uses: dx/dt = rate over 20 s in 1 s
    // steps (4 substeps each) gives 1·10 + 3·10 = 40 when held, and a ramp in between when linear.
    const auto integrate = [](const konjugate::ExecutionPlan& compiled) {
        auto states = compiled.initialStates;
        for (int step = 0; step < 20; ++step) {
            const auto result = konjugate::integrateNode(compiled.nodes.front(), states, {}, static_cast<double>(step), 1.0);
            states.at(compiled.nodes.front().stateIndexes.front()) = result.states.front();
        }
        return states.at(compiled.nodes.front().stateIndexes.front());
    };
    require(std::abs(integrate(plan) - 40) < 1e-9, "A held schedule integrates to the sum of its periods.");
    // Linear: the rate ramps 1 -> 3 over [0, 10], read at each quarter-step start: sum of 1 + 0.2·t
    // over t = 0, 0.25, ..., 9.75 times 0.25, then 3 for ten more seconds.
    double expected = 0;
    for (int quarter = 0; quarter < 40; ++quarter) expected += 0.25 * (1 + 0.2 * quarter * 0.25);
    expected += 30;
    require(std::abs(integrate(scheduledProject("constant", "linear")) - expected) < 1e-9, "A linear schedule is read at every substep.");

    // Live: a live value overrides the schedule, and a recorded intervention overrides both.
    const auto live = scheduledProject("live", "hold");
    const auto liveAt = [&](double simulationTime, const konjugate::EntityValues& values, const std::vector<ParameterSchedule>& active) {
        return konjugate::resolveParameterValues(live.nodes.front(), values, active, simulationTime).front().front();
    };
    require(liveAt(15, {}, {}) == 3, "A live scheduled parameter follows its schedule until it is set.");
    require(liveAt(15, {{30, 7}}, {}) == 7, "A live value takes over from the schedule.");
    ParameterSchedule intervention;
    intervention.parameterId = 30;
    intervention.mode = ParameterSchedule::Mode::step;
    intervention.startTime = 12;
    intervention.targetValue = 11;
    require(liveAt(11, {}, {intervention}) == 3 && liveAt(12, {}, {intervention}) == 11, "An intervention takes over from the schedule when it begins.");
}

// A recorded intervention (a scenario fork's scheduled change) reaches a partition worker: the
// partitioned backend integrates a node under it exactly as the shared integrateNode does, and
// differently from the same step with no intervention.
void partitionRuntimeAppliesActiveParameterSchedules() {
    using konjugate::ParameterSchedule;
    const auto plan = scheduledProject("live", "hold");
    ParameterSchedule intervention;
    intervention.parameterId = 30;
    intervention.mode = ParameterSchedule::Mode::piecewise;
    intervention.samples = {{0, 8}, {100, 8}};
    konjugate::PartitionRuntime runtime(0, plan, {0});
    konjugate::InMemoryPartitionTransport transport;
    const auto execute = [&](std::size_t synchronizationIndex, std::vector<ParameterSchedule> active) {
        auto future = runtime.submit(transport, synchronizationIndex, {}, 1.0, 5.0, std::chrono::seconds(5), nullptr, std::move(active));
        transport.publish({1, synchronizationIndex, 0, {{11, 0}}});
        return future.get().nodes.front().states.front();
    };
    const auto expected = konjugate::integrateNode(plan.nodes.front(), plan.initialStates, {}, 5.0, 1.0, nullptr, {intervention}).states.front();
    require(std::abs(expected - 8) < 1e-12, "The shared integrateNode applies the intervention (dx/dt = 8 for one second).");
    require(std::abs(execute(1, {intervention}) - expected) < 1e-12, "A partition worker did not apply an active parameter schedule.");
    require(std::abs(execute(2, {}) - 1) < 1e-12, "Without an intervention a partition worker follows the stored schedule.");
}

// A node ("Mechanism", 1) whose computational-node provider reads a state of another node ("Motor", 2).
konjugate::ExecutionPlan planWithRemoteNodeProviderBinding() {
    std::istringstream json(R"json({
        "format": "konjugate", "version": 1,
        "nodes": [
            {"id": 1, "name": "Mechanism", "states": [{"id": 11, "symbol": "angle", "initialValue": 0}], "sourceTerms": [],
             "implementation": {"kind": "python", "providerApiVersion": 1, "source": "provider source",
                 "bindings": [{"key": "torque", "kind": "state", "nodeId": 2, "stateId": 21}],
                 "outputs": [{"key": "angle", "stateId": 11, "setsValue": true}]}},
            {"id": 2, "name": "Motor", "states": [{"id": 21, "symbol": "torque", "initialValue": 0}], "sourceTerms": []}
        ],
        "edges": []
    })json");
    boost::property_tree::ptree document;
    boost::property_tree::read_json(json, document);
    return konjugate::compileExecutionPlan(document);
}

class RecordingNodeEvaluator final : public konjugate::ProviderEvaluator {
public:
    std::vector<double> inputs;
    std::vector<double> evaluateBatch(const std::vector<const konjugate::ContributionTask*>&,
                                      const std::vector<std::span<const double>>&, double, double) override {
        throw std::runtime_error("This test expects only computational-node evaluation.");
    }
    std::vector<std::pair<std::string, double>> evaluateNode(
        const konjugate::NodeProviderTask&, std::span<const double> values, double, double) override {
        inputs.assign(values.begin(), values.end());
        return {{"angle", 1.0}};
    }
};

// The partitioned backend ships a node's remote states to it from its dependencies, so a node
// provider's reads of other nodes must be dependencies like an edge's.
void dependencyGraphCountsANodeProvidersReadsOfOtherNodes() {
    const auto graph = konjugate::buildDependencyGraph(planWithRemoteNodeProviderBinding());
    require(graph.dependencies.size() == 1, "A node provider's read of another node is not a dependency.");
    const auto& dependency = graph.dependencies.front();
    require(dependency.sourceNodeId == 2 && dependency.targetNodeId == 1, "The node provider's dependency has the wrong direction.");
    require(dependency.remoteStateIds == std::vector<konjugate::EntityId>{21}, "The node provider's remote state is not communicated.");
    require(graph.componentCount == 1, "A node provider and the node it reads should be one component.");
}

void partitionRuntimeHandsANodeProviderTheRemoteStatesItReads() {
    const auto plan = planWithRemoteNodeProviderBinding();
    konjugate::PartitionRuntime runtime(0, plan, {0});
    konjugate::InMemoryPartitionTransport transport;
    RecordingNodeEvaluator evaluator;
    auto future = runtime.submit(transport, 1, {}, 0.1, 0.0, std::chrono::milliseconds(1000), &evaluator);
    transport.publish({1, 1, 0, {{11, 0.0}, {21, 4.25}}});
    const auto result = future.get();
    require(evaluator.inputs.size() == 1 && evaluator.inputs.front() == 4.25,
        "A partition did not hand the node provider the other node's boundary value.");
    require(result.nodes.size() == 1 && result.nodes.front().states.at(0) == 1.0, "The partition lost the node provider's output.");
}

int main() {
    try {
        deterministicReductionUsesTaskSequence();
        conditionalExpressionsPickTheFirstMatchingBranch();
        evaluationSeparatesLocalSnapshotAndLiveParameterInputs();
        timeBindingReadsSubstepStartForDerivativesAndTheEvaluationTimeForAlgebraicStates();
        parameterScheduleEvaluatesEachModeAndSupersedesEarlierSchedules();
        storedParameterSchedulesDriveTheParameterBeneathLiveControl();
        applyAlgebraicTasksSnapsMismatchedStateToTargetImmediately();
        applyAlgebraicTasksResolveDependencyOrderWithinOnePass();
        applyAlgebraicTasksRejectsANonFiniteResult();
        integrateNodeAppliesAlgebraicTasksBeforeDifferentialContributionsEachSubstep();
        integrateNodeHandsBackAlgebraicStatesThatMatchTheUpdatedStates();
        taskExecutorBoundsConcurrentWorkAndPropagatesResults();
        taskSubmissionPrioritizesEstimatedWorkAndKeepsStableTies();
        dependencyGraphAggregatesParallelTasksAndPreservesDirection();
        dependencyGraphCountsANodeProvidersReadsOfOtherNodes();
        greedyPartitionerBalancesIndependentWork();
        greedyPartitionerCanKeepExpensiveCommunicationLocal();
        greedyPartitionerClustersACommunicationRing();
        partitionerSelectionUsesMetisWhenAvailable();
        partitionTransportWaitsForDelayedMessagesAndRejectsDuplicates();
        partitionTransportReportsMissingMessagesAndWorkerFailures();
        partitionRuntimeReplaysDeterministicallyThroughMessages();
        partitionRuntimeAppliesActiveParameterSchedules();
        partitionRuntimeHandsANodeProviderTheRemoteStatesItReads();
        automaticBackendSelectionAccountsForWorkAndCommunication();
        std::cout << "Execution plan tests passed.\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
