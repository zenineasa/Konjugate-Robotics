/* Copyright © 2026 Zenin Easa Panthakkalakath */

import assert from 'node:assert/strict';
import { join } from 'node:path';
import { mulberry32, gaussianFrom, buildThermalSystemCsv } from './fixtures/thermalSystemCsv.mjs';
import { unzipSync } from 'fflate';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { decodeProjectFile, encodeProjectFile } from '../src/projectFile.mjs';

// These 10 primitives, and every scenario below, operate on a "handle" -- a driver-produced
// object wrapping either a live Electron BrowserWindow (tests/drivers/electronWindowDriver.mjs)
// or a Playwright Page (tests/drivers/playwrightWebDriver.mjs) -- rather than a raw BrowserWindow
// directly, so the exact same scenario definitions run against both the desktop app and the web
// edition in a real browser. A handle exposes: evaluate(expression), mouseMove/mouseDown/mouseUp
// (point, opts?), click/rightClick(point, opts?), keyDown/keyUp(keyCode), onConsoleMessage
// (listener) -> unsubscribe, title(), close(), isDestroyed(), parent(). The driver itself (not a
// per-handle concern) additionally exposes: kind, mainHandle, allHandles(), waitForNewHandle(...),
// captureExport(trigger, opts?), simulateOsFileOpen(path), capabilities (a set of booleans a
// scenario checks to decide whether to skip itself -- see run()'s own skip option below), and
// dispose(). See either driver file's header comment for the full contract and why each method
// is shaped the way it is.

async function evaluate(window, expression) {
    return window.evaluate(expression);
}

// A renderer-side exception thrown synchronously inside a DOM event listener (e.g. from a
// synthetic element.click()) never rejects executeJavaScript's promise -- the browser's event
// dispatch loop swallows it and only reports it to the console as "Uncaught ...". Any assertion
// checking DOM/JS state after such a call can't distinguish "ran correctly" from "the handler
// crashed before reaching that state" (a value it never got to update just looks unchanged).
// This captures renderer console output around a task so callers can assert nothing was logged.
async function captureConsoleMessages(window, task) {
    const messages = [];
    const unsubscribe = window.onConsoleMessage((message) => messages.push(message));
    try {
        await task();
    } finally {
        unsubscribe();
    }
    return messages;
}

// Checks the rendered computed style rather than the `hidden` IDL property: a `hidden`
// element can still render if some other CSS rule sets `display` with equal or higher
// specificity than the UA stylesheet's `[hidden] { display: none }`, which the property
// alone would never reveal.
async function isRenderedVisible(window, selector) {
    return evaluate(window, `getComputedStyle(document.querySelector('${selector}')).display !== 'none'`);
}

async function waitFor(window, expression, message, timeout = 5000) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeout) {
        if (await evaluate(window, expression)) return;
        await new Promise((resolve) => setTimeout(resolve, 50));
    }
    const visibleError = await evaluate(window, `document.querySelector('#assistantError:not([hidden])')?.textContent ?? ''`);
    const assistantStatus = await evaluate(window, `document.querySelector('#assistantProposalStatus')?.textContent ?? ''`);
    throw new Error(`${message}${visibleError ? ` ${visibleError}` : ''}${assistantStatus ? ` Status: ${assistantStatus}` : ''}`);
}

// Run opens the Run dialog, and is disabled while the model is being (re)validated, as it is after any edit.
// Clicking a disabled button does nothing, so wait for it first, then for the dialog itself: a test that
// goes on to fill and submit the dialog would otherwise be working on one that never opened.
async function openRunDialog(window) {
    await waitFor(window, `!document.querySelector('#runButton').disabled`, 'Run was not available to open the Run dialog.', 15000);
    await evaluate(window, `document.querySelector('#runButton').click()`);
    await waitFor(window, `document.querySelector('#runLaunchDialog').open`, 'The Run dialog did not open.');
}

// Closing a window mid-validation cancels its engine process; let validation settle first.
async function closeWhenValidated(window, timeout = 10000) {
    await waitFor(window, `!document.querySelector('#validationSummary')?.classList.contains('pending')`, 'Model validation did not settle before closing the window.', timeout);
    await window.close();
}

// A single requestAnimationFrame apart is not a reliable "stopped moving" signal here: the main
// render loop (renderer.mjs's render(), which repositions every CSS2D label and applies
// OrbitControls damping) is throttled to 30fps, so two rAF ticks can both land inside the same
// un-rendered ~33ms window and report "unchanged" even while a real position update -- e.g.
// OrbitControls damping (dampingFactor 0.07) still easing off a preceding pan/zoom/rotate test --
// is genuinely pending on the next actual render tick. Requiring several consecutive matches,
// each spaced further apart (50ms) than the render throttle, actually observes real render ticks
// instead of possibly sampling twice inside a gap between them.
async function waitForStableRect(window, expression, message, timeout = 3000) {
    const startedAt = Date.now();
    let previous = null;
    let stableStreak = 0;
    while (Date.now() - startedAt < timeout) {
        const current = await evaluate(window, expression);
        if (current && current === previous) {
            stableStreak += 1;
            if (stableStreak >= 3) return;
        } else {
            stableStreak = 0;
        }
        previous = current;
        await new Promise((resolve) => setTimeout(resolve, 50));
    }
    throw new Error(message);
}

// Two things move every node, relationship and label on the screen without the model changing: the canvas sliding
// over when an editor card opens or closes (`.webglContainer` and `.css2dContainer` animate their `right` edge), and the
// camera still easing after a view change or a drag (its snap animation, or OrbitControls' damping). A screen point read
// during either is where the thing was, not where it will be when the click lands, so anything aiming at the canvas
// waits for both to stop first. `getAnimations()` flushes style, so a slide a click just started is already counted;
// the camera is at rest once the view cube's readout (distance, target and turn, to four places: the turn's
// matrix keeps drifting in its 40th decimal as damping decays) holds for a few frames.
async function waitForCanvasAtRest(window, timeout = 5000) {
    await waitFor(window, `!document.getAnimations().some((animation) => ['webglContainer', 'css2dContainer'].includes(animation.effect?.target?.id) && animation.playState !== 'finished')`,
        'The canvas did not stop sliding.', timeout);
    await waitForStableRect(window, `(() => { const cube = document.querySelector('#viewCube'); return [cube.dataset.cameraDistance, cube.dataset.cameraTarget, document.querySelector('#viewCubeObject').style.transform.replace(/(?<![a-z])-?[\\d.]+(e[-+]?\\d+)?/g, (number) => String(Math.round(Number(number) * 1e4) / 1e4 || 0))].join('|'); })()`,
        'The camera did not come to rest.', timeout);
}

// A test hook's screen point (window.__relationshipScreenPoint and the like), read once the canvas is at rest.
async function canvasPoint(window, expression) {
    await waitForCanvasAtRest(window);
    return evaluate(window, expression);
}

async function clickElement(window, expression, modifiers = []) {
    await waitForCanvasAtRest(window);
    const point = await evaluate(window, `(() => {
        const element = ${expression};
        const bounds = element.getBoundingClientRect();
        return { x: Math.round(bounds.left + bounds.width / 2), y: Math.round(bounds.top + bounds.height / 2) };
    })()`);
    await window.mouseMove(point, { modifiers });
    await window.mouseDown(point, { button: 'left', clickCount: 1, modifiers });
    await window.mouseUp(point, { button: 'left', clickCount: 1, modifiers });
}

// Re-resolves the element's screen position on every call rather than caching one set of
// coordinates -- a CSS2D label can shift by a pixel or two as selection/disabled styling changes
// its box (border, badge text), and a stale cached point can miss the element entirely on a
// later right-click in the same test.
async function rightClickElement(window, expression) {
    await waitForCanvasAtRest(window);
    const point = await evaluate(window, `(() => {
        const element = ${expression};
        const bounds = element.getBoundingClientRect();
        return { x: Math.round(bounds.left + bounds.width / 2), y: Math.round(bounds.top + bounds.height / 2) };
    })()`);
    await window.mouseMove(point);
    await window.mouseDown(point, { button: 'right', clickCount: 1 });
    await window.mouseUp(point, { button: 'right', clickCount: 1 });
}

// A CSS2D overlay (a node/edge label) always wins DOM hit-testing over the WebGL canvas
// beneath it regardless of 3D depth, so a point that's a valid 3D raycast target can still be
// undeliverable to the canvas as a real click if a label happens to cover it there -- and
// exactly where that is can shift with accumulated camera state this deep into the suite, even
// when nothing occludes it on a fresh load. Spiral outward until landing on a pixel the canvas
// itself owns, rather than assume the originally-computed point is still clear.
async function findCanvasPoint(window, point, maxRadius = 40) {
    if (!point) return null;
    await waitForCanvasAtRest(window);
    for (let radius = 0; radius <= maxRadius; radius += 4) {
        const offsets = radius === 0 ? [[0, 0]] : [[radius, 0], [-radius, 0], [0, radius], [0, -radius], [radius, radius], [-radius, -radius], [radius, -radius], [-radius, radius]];
        for (const [dx, dy] of offsets) {
            const candidate = { x: point.x + dx, y: point.y + dy };
            const isCanvas = await evaluate(window, `document.elementFromPoint(${candidate.x}, ${candidate.y})?.classList.contains('webglSurface') ?? false`);
            if (isCanvas) return candidate;
        }
    }
    return point;
}

// Generalizes the same spiral-until-clear idea to an arbitrary CSS2D label, rather than the
// WebGL canvas specifically. Two overlapping CSS2D overlays (e.g. a relationship bundle label
// whose midpoint happens to land near one of its own endpoint nodes' labels) can leave a point
// that's inside one element's bounding rect but actually owned by the *other* one for
// hit-testing purposes -- confirmed via document.elementFromPoint() returning the node's own
// objectLabel instead of the intended bundle label at the naive center point. Searches only
// within the target element's own bounding rect (not an unbounded radius), since wandering
// outside it would just find some other element's clear space, not a still-valid point on this
// one.
async function findUnoccludedPoint(window, elementExpression, maxRadius = 30) {
    await waitForCanvasAtRest(window);
    const rect = await evaluate(window, `(() => {
        const el = ${elementExpression};
        const r = el?.getBoundingClientRect();
        return r && { x: r.left + r.width / 2, y: r.top + r.height / 2, halfWidth: r.width / 2, halfHeight: r.height / 2 };
    })()`);
    if (!rect) return null;
    for (let radius = 0; radius <= maxRadius; radius += 3) {
        const offsets = radius === 0 ? [[0, 0]] : [[radius, 0], [-radius, 0], [0, radius], [0, -radius], [radius, radius], [-radius, -radius], [radius, -radius], [-radius, radius]];
        for (const [dx, dy] of offsets) {
            if (Math.abs(dx) > rect.halfWidth || Math.abs(dy) > rect.halfHeight) continue;
            const candidate = { x: Math.round(rect.x + dx), y: Math.round(rect.y + dy) };
            const owned = await evaluate(window, `(() => {
                const el = ${elementExpression};
                const hit = document.elementFromPoint(${candidate.x}, ${candidate.y});
                return Boolean(el && hit && el.contains(hit));
            })()`);
            if (owned) return candidate;
        }
    }
    return { x: Math.round(rect.x), y: Math.round(rect.y) };
}

// A handful of raw, pixel-coordinate pointer gestures (as opposed to clicking a known DOM
// element) are retried a few times rather than treated as a hard failure: a press-and-hold or a
// drag can still be cut short by a stray pointer event. (Most of their old flakiness was a point
// read while the canvas was still sliding after a card closed; see waitForCanvasAtRest.) `perform` re-runs from scratch each attempt (re-reading any screen
// points fresh) since a prior attempt may have nudged state slightly.
async function retryGesture(window, perform, checkExpression, times = 5, settleMs = 200) {
    for (let attempt = 0; attempt < times; attempt += 1) {
        await perform();
        await new Promise((resolve) => setTimeout(resolve, settleMs));
        if (await evaluate(window, checkExpression)) return true;
    }
    return false;
}

// Two edges (and, optionally, one source term) whose "gain" parameters all link to one shared
// parameter -- the fixture for the shared-parameter and parameters-table scenarios below.
function sharedParameterTestProject({ withSourceTerm = false } = {}) {
    const parameter = (id, name = 'Gain', symbol = 'gain') => ({ id, name, symbol, value: 5, mode: 'constant', sharedParameterId: 100 });
    const node = (id, name, stateId, position, sourceTerms = []) => ({
        id, name, position, sourceTerms, appearance: { type: 'primitive', shape: 'box', color: '#888888' },
        states: [{ id: stateId, name: 'Level', symbol: 'level', initialValue: 0 }]
    });
    const edge = (id, name, targetNodeId, targetStateId, parameterId) => ({
        id, name, source: { nodeId: 1, stateId: 2 }, target: { nodeId: targetNodeId, stateId: targetStateId }, directionality: 'directed',
        equation: '\\mathrm{gain}',
        equationModel: {
            latex: '\\mathrm{gain}', output: { role: 'target', stateId: targetStateId },
            bindings: [{ kind: 'parameter', parameterId, symbol: 'gain' }], mathJson: 'gain'
        },
        parameters: [parameter(parameterId)], appearance: { color: '#888888', offset: 0 }
    });
    const sourceTerm = {
        id: 13, state: 'level', expression: '\\mathrm{gain}',
        expressionModel: { latex: '\\mathrm{gain}', output: { stateId: 4 }, bindings: [{ kind: 'parameter', parameterId: 14, symbol: 'gain' }], mathJson: 'gain' },
        parameters: [parameter(14, 'Source gain')]
    };
    return {
        format: 'konjugate', version: 1, metadata: { units: 'SI' },
        sharedParameters: [{ id: 100, name: 'Shared gain', symbol: 'gain', value: 2, unit: 'x', mode: 'constant' }],
        nodes: [node(1, 'Source', 2, [-4, 0, 0]), node(3, 'Target X', 4, [4, 3, 0], withSourceTerm ? [sourceTerm] : []), node(5, 'Target Y', 6, [4, -3, 0])],
        edges: [edge(7, 'Feed X', 3, 4, 8), edge(9, 'Feed Y', 5, 6, 10)]
    };
}

export async function runInteractionTests(driver) {
    const window = driver.mainHandle;
    // Add-ons that live in their own repositories are installed per run by the runner scripts (see
    // scripts/interactionAddons.mjs); a test needing one that wasn't found is skipped, not failed.
    const installedAddons = new Set((process.env.KONJUGATE_INTERACTION_INSTALLED_ADDONS ?? '').split(',').filter(Boolean));
    const addonMissing = (addonId, repository) => !installedAddons.has(addonId) && `needs the ${addonId} add-on -- build ../${repository} (npm run build) or set KONJUGATE_INTERACTION_ADDONS`;
    let passedCount = 0;
    let skippedCount = 0;
    const only = process.env.KONJUGATE_INTERACTION_ONLY;
    const run = async (name, task, { skip } = {}) => {
        if (only && !name.includes(only)) return;
        if (skip) {
            console.log(`○ ${name} (skipped: ${skip})`);
            skippedCount += 1;
            return;
        }
        try {
            // Each test starts with the project window in front and drawing: a window an earlier test opened may cover
            // it, and a covered window can report itself hidden, which stops the canvas drawing, so labels a test clicks
            // or measures stay where they were. A window the test opens itself still opens on top.
            if (!await window.isDestroyed()) {
                await window.focus();
                await waitFor(window, `!document.hidden`, 'The project window stayed hidden.');
            }
            await task();
            passedCount += 1;
            console.log(`✓ ${name}`);
        } catch (error) {
            // Some errors (Electron's own "Script failed to execute") ignore a changed message, which
            // would leave the failure unnamed: wrap those instead, keeping the original as the cause.
            const named = `${name}: ${error?.message ?? error}`;
            try { error.message = named; } catch { /* read-only */ }
            if (error?.message !== named) throw new Error(named, { cause: error });
            throw error;
        }
    };

    await run('examples explorer loads a project copy', async () => {
        await evaluate(window, `document.querySelector('#exampleButton').click()`);
        await waitFor(window, `document.querySelector('#examplesExplorerDialog').open`, 'Examples explorer did not open.');
        await waitFor(window, `Boolean([...document.querySelectorAll('.examplesExplorerItem')].find((item) => item.querySelector('b').textContent === 'Thermal Management'))`, 'Examples explorer did not populate.');
        await evaluate(window, `[...document.querySelectorAll('.examplesExplorerItem')].find((item) => item.querySelector('b').textContent === 'Thermal Management').click()`);
        await waitFor(window, `document.querySelector('#examplesExplorerDetailTitle').textContent === 'Thermal Management'`, 'Selecting the example did not populate the detail preview.');
        assert.equal(await evaluate(window, `document.querySelector('#examplesExplorerDetailContent').hidden`), false);
        assert.match(await evaluate(window, `document.querySelector('#examplesExplorerDetailDescription').textContent`), /enclosed-air volume/i);
        await evaluate(window, `document.querySelector('#examplesExplorerLoad').click()`);
        // loadExample()'s click handler isn't awaited by the caller, and closing the dialog
        // happens in its `finally` block after the (also awaited-inside-loadExample) guide
        // window IPC round trip -- so the dialog can still be open for a moment after the model
        // itself has already finished loading. Wait for the actual close rather than the model
        // load alone, to avoid a race against that same handler's own tail end.
        await waitFor(window, `document.querySelectorAll('.node-label-container').length === 3`, 'Thermal example did not load.');
        assert.equal(await evaluate(window, `document.querySelector('.documentTitle').textContent`), 'thermalManagement');
        await waitFor(window, `!document.querySelector('#examplesExplorerDialog').open`, 'Examples explorer did not close after loading the example.');
    });

    await run('example selection opens its companion guide', async () => {
        // No "before" snapshot here, deliberately: loadExample()'s own click handler (the
        // previous scenario) may already have opened the guide window as a side effect before
        // this scenario even starts, so this must find ANY window matching the title, not one
        // that's merely new relative to a snapshot taken at this scenario's own start.
        const guideWindow = await driver.waitForNewHandle([], { titleIncludes: 'Example Guide' });
        await waitFor(guideWindow, `document.querySelector('#guideTitle').textContent.includes('Thermal Management')`, 'Example guide content did not render.');
        assert.match(await evaluate(guideWindow, `document.querySelector('#content').textContent`), /enclosed-air volume/i);
        assert.doesNotMatch(await evaluate(guideWindow, `document.querySelector('#content').textContent`), /Copyright/);
        await waitFor(guideWindow, `document.querySelectorAll('.equation .ML__latex').length > 0`, 'Example equations did not render with MathLive.');
        assert.equal(await evaluate(guideWindow, `document.querySelectorAll('math-field').length`), 0);
        assert.equal(await evaluate(guideWindow, `[...document.querySelectorAll('.equation [style]')].every((element) => element.style.length > 0)`), true);
        assert.equal(await evaluate(guideWindow, `document.querySelector('.equation').scrollWidth <= document.querySelector('.equation').clientWidth`), true);
        assert.equal(await evaluate(window, `document.querySelector('#exampleGuideButton').hidden`), false);
        await closeWhenValidated(guideWindow);
        await waitFor(window, `!document.querySelector('#exampleGuideButton').hidden`, 'Example guide reopen control disappeared.');
        const beforeReopen = driver.allHandles();
        await evaluate(window, `document.querySelector('#exampleGuideButton').click()`);
        await driver.waitForNewHandle(beforeReopen, { titleIncludes: 'Example Guide' });
    }, {
        // A real, previously-unknown web-edition gap, not a driver/test issue -- confirmed by
        // reading src/renderer/webShims/projectFiles.mjs's openExampleGuide(), not assumed:
        // it does `window.open(rawMarkdownFileUrl, '_blank')`, opening the unrendered .md file
        // directly rather than a guide page with the #guideTitle/#content/MathLive-rendered-
        // equations structure this scenario (and the desktop guide window) actually has. The
        // window.open() mechanism itself is real and portable (confirmed separately -- this
        // scenario's own waitForNewHandle call reliably finds the opened tab), so this is gated
        // on a missing renderer, not a missing capability category.
        skip: !driver.capabilities.renderedExampleGuide && "the web edition's Example Guide opens the raw .md file directly, not a rendered guide page (see docs/proposals/webEdition.md)"
    });

    await run('export simulation code writes a standalone C++ or Python program', async () => {
        for (const [language, parallelism, extension, expectedFragment] of [
            ['cpp', 'serial', 'cpp', 'int main('],
            ['cpp', 'openmp', 'cpp', '#pragma omp parallel for'],
            ['python', 'serial', 'py', 'def run('],
            ['python', 'mpi', 'py', 'from mpi4py import MPI']
        ]) {
            assert.equal(await evaluate(window, `document.querySelector('#exportCodeDialog').open`), false);
            await evaluate(window, `document.querySelector('#exportCodeButton').click()`);
            await waitFor(window, `document.querySelector('#exportCodeDialog').open`, 'Export code dialog did not open.');
            await evaluate(window, `document.querySelector('#exportCodeLanguage').value = '${language}'`);
            await evaluate(window, `document.querySelector('#exportCodeLanguage').dispatchEvent(new Event('change'))`);
            assert.equal(await evaluate(window, `document.querySelector('#exportCodeParallelismOpenmp').disabled`), language === 'python',
                'OpenMP/std::thread options should only be disabled for a Python export.');
            await evaluate(window, `document.querySelector('#exportCodeParallelism').value = '${parallelism}'`);
            const { bytes } = await driver.captureExport(async () => {
                await evaluate(window, `document.querySelector('#exportCodeSubmit').click()`);
                // The dialog closes once the file is fully written; reading earlier can see a partial file.
                await waitFor(window, `!document.querySelector('#exportCodeDialog').open`, 'Export dialog should close after a successful export.', 15000);
            }, { extension });
            const exportedSource = bytes.toString('utf8');
            assert.ok(exportedSource, `Export (${language}/${parallelism}) did not write a file.`);
            assert.match(exportedSource, /time \(s\)/);
            assert.ok(exportedSource.includes(expectedFragment), `Exported (${language}/${parallelism}) source is missing an expected "${expectedFragment}" fragment.`);
        }
    });

    await run('export simulation code as an FMU produces a real, valid FMI 2.0 Co-Simulation package', async () => {
        await evaluate(window, `document.querySelector('#exportCodeButton').click()`);
        await waitFor(window, `document.querySelector('#exportCodeDialog').open`, 'Export code dialog did not open.');
        await evaluate(window, `document.querySelector('#exportCodeFormat').value = 'fmu'`);
        await evaluate(window, `document.querySelector('#exportCodeFormat').dispatchEvent(new Event('change'))`);
        assert.equal(await evaluate(window, `document.querySelector('#exportCodeLanguagePython').disabled`), true,
            'Python should be unavailable once FMU format is selected.');
        assert.equal(await evaluate(window, `document.querySelector('#exportCodeParallelism').closest('label').hidden`), true,
            'The Execution row has no meaning for an FMU export and should be hidden.');
        const { bytes: exportedBuffer } = await driver.captureExport(async () => {
            await evaluate(window, `document.querySelector('#exportCodeSubmit').click()`);
            await waitFor(window, `!document.querySelector('#exportCodeDialog').open`, 'Export dialog should close after the FMU is written.', 60000);
        }, { extension: 'fmu', maxAttempts: 400 });
        assert.ok(exportedBuffer, 'FMU export did not write a file.');
        const entries = unzipSync(exportedBuffer);
        assert.ok(entries['modelDescription.xml'], 'The .fmu is missing modelDescription.xml.');
        const xml = Buffer.from(entries['modelDescription.xml']).toString('utf8');
        assert.match(xml, /fmiVersion="2\.0"/);
        assert.match(xml, /<CoSimulation /);
        const binaryEntry = Object.keys(entries).find((name) => name.startsWith('binaries/') && name !== 'binaries/');
        assert.ok(binaryEntry, 'The .fmu is missing a compiled binaries/<platform>/ shared library.');
        assert.equal(await evaluate(window, `document.querySelector('#exportCodeDialog').open`), false, 'Export dialog should close after a successful export.');
    }, { skip: !driver.capabilities.fmuExport && 'FMU export is not available in the web edition' });

    await run('a second project window opens independently and does not affect the first', async () => {
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const second = await driver.waitForNewHandle(before);
        await waitFor(second, `document.querySelector('.documentTitle')`, 'Second window did not finish loading.');

        // Independence: the new window starts blank regardless of what's loaded in the first
        // (the first window has an example loaded by this point in the suite).
        assert.equal(await evaluate(second, `document.querySelectorAll('.node-label-container').length`), 0);

        // Each project window gets its own auxiliary (Welcome) window. Auxiliary windows are not
        // parented to their project window (so either can be brought to the front without
        // minimizing the other), so each one is identified as the window that became a Welcome
        // window after its own openWelcome() call -- a project window reuses its guide window, so
        // that may be an existing window (e.g. an example guide opened earlier), not a new one.
        const welcomeHandles = async () => {
            const handles = [];
            for (const handle of driver.allHandles()) {
                if (!(await handle.isDestroyed()) && (await handle.title()).includes('Welcome')) handles.push(handle);
            }
            return handles;
        };
        const openWelcomeFrom = async (projectWindow) => {
            const existing = await welcomeHandles();
            await evaluate(projectWindow, `window.applicationInfo.openWelcome()`);
            const startedAt = Date.now();
            while (Date.now() - startedAt < 10000) {
                const opened = (await welcomeHandles()).find((handle) => !existing.includes(handle));
                if (opened) {
                    assert.equal(await opened.parent(), null, 'Auxiliary windows must not be parented to their project window.');
                    return opened;
                }
                await new Promise((resolve) => setTimeout(resolve, 50));
            }
            throw new Error('openWelcome() did not open a Welcome window for its project window.');
        };
        const welcomeFromFirst = await openWelcomeFrom(window);
        const welcomeFromSecond = await openWelcomeFrom(second);
        assert.notEqual(welcomeFromFirst, welcomeFromSecond, 'Each project window should get its own Welcome window.');
        await closeWhenValidated(welcomeFromFirst);
        await new Promise((resolve) => setTimeout(resolve, 200));
        assert.ok(!(await welcomeFromSecond.isDestroyed()), "Closing window A's Welcome window must not affect window B's.");
        await closeWhenValidated(welcomeFromSecond);

        // Closing a project window must not quit the app or affect the other window.
        await closeWhenValidated(second);
        await new Promise((resolve) => setTimeout(resolve, 200));
        assert.ok(!(await window.isDestroyed()), 'Closing the second window destroyed the first.');
        assert.equal(await evaluate(window, `1 + 1`), 2, 'The first window is no longer responsive after the second closed.');
    }, { skip: !driver.capabilities.multiWindow && 'multi-window and per-window Welcome-window scoping have no web-edition equivalent' });

    await run('an OS-initiated file open reuses an already-open window on the same file, otherwise opens a new one', async () => {
        // Simulates exactly what a real double-click (or a relaunch's second-instance argv, on
        // Windows/Linux) drives main.mjs's own app.on('open-file', ...) listener to do -- no OS
        // automation needed, since main.mjs never distinguishes a real 'open-file' from this one.
        const examplePath = join(process.cwd(), 'examples', 'pumpSuctionHydraulics.kjt');

        const beforeFirstOpen = driver.allHandles();
        await driver.simulateOsFileOpen(examplePath);
        const opened = await driver.waitForNewHandle(beforeFirstOpen);
        await waitFor(opened, `document.querySelectorAll('.node-label-container').length > 0`, 'The OS-opened file did not load into the new window.');
        assert.equal(await evaluate(opened, `document.querySelector('.documentTitle').textContent`), 'pumpSuctionHydraulics');
        // Give the new window's pathChanged push time to reach main before re-opening the same path.
        await new Promise((resolve) => setTimeout(resolve, 300));

        const beforeSecondOpen = driver.allHandles();
        await driver.simulateOsFileOpen(examplePath);
        await new Promise((resolve) => setTimeout(resolve, 300));
        assert.deepEqual(driver.allHandles(), beforeSecondOpen, 'Opening the same file again should focus the existing window, not open a duplicate.');
        await closeWhenValidated(opened);

        const beforeBadOpen = driver.allHandles();
        await driver.simulateOsFileOpen(join(process.cwd(), 'examples', 'doesNotExist.kjt'));
        const failedWindow = await driver.waitForNewHandle(beforeBadOpen);
        assert.ok(failedWindow, 'An OS-initiated open of a missing file did not open a window at all.');
        await waitFor(failedWindow, `document.querySelector('#statusText').textContent.startsWith('Load failed')`, 'A missing file did not surface a load-failed status instead of crashing.');
        await closeWhenValidated(failedWindow);
    }, { skip: !driver.capabilities.osFileOpen && 'OS-initiated file open has no web-edition equivalent' });

    await run('validation summary reports and displays a valid model', async () => {
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine'`, 'C++ validation report did not reach the UI.');
        assert.equal(await evaluate(window, `document.querySelector('#validationSummary').classList.contains('error')`), false);
        await evaluate(window, `document.querySelector('#validationSummary').click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#validationPanel').hidden`), true);
        assert.equal(await evaluate(window, `document.querySelector('#validationPanelTitle').textContent`), 'No issues');
        await evaluate(window, `document.querySelector('#closeValidationPanel').click()`);
    });

    await run('a newer model validation cancels the one it supersedes', async () => {
        const content = await decodeProjectFile(await readFile(join(process.cwd(), 'examples', 'heatedWaterTank.kjt')));
        const outcomes = await evaluate(window, `(async () => {
            const content = ${JSON.stringify(content)};
            const first = window.engine.validate(content, { supersede: 'interactionTest' });
            const second = window.engine.validate(content, { supersede: 'interactionTest' });
            return Promise.all([first, second]);
        })()`);
        assert.deepEqual(outcomes[0], { cancelled: true }, 'The superseded validation should report cancellation instead of a result.');
        assert.equal(outcomes[1].available, true);
        assert.equal(typeof outcomes[1].report.valid, 'boolean');
    }, { skip: !driver.capabilities.cancellableValidation && 'The web engine cannot cancel a validation in progress' });

    await run('local assistant prepares, validates and applies one undoable transaction', async () => {
        await evaluate(window, `window.dispatchEvent(new Event('resize')); document.querySelector('#assistantButton').click(); (() => {
            const prompt = document.querySelector('#assistantPrompt');
            prompt.value = 'Add an ambient boundary at 298 K and connect it to the battery with a conductance of 15 W/K.';
            document.querySelector('#assistantPromptForm').requestSubmit();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#assistantButton').parentElement.classList.contains('windowControls')`), true);
        assert.ok(await evaluate(window, `Math.abs(document.querySelector('#assistantPanel').getBoundingClientRect().top - document.querySelector('#canvas').getBoundingClientRect().top - 10)`) < 2);
        assert.ok(await evaluate(window, `Math.abs(document.querySelector('#assistantPanel').getBoundingClientRect().right - (window.innerWidth - 10))`) < 2);
        await waitFor(window, `!document.querySelector('#applyAssistantProposal').disabled`, 'The local assistant proposal was not ready to apply.');
        await waitFor(window, `document.querySelector('#assistantConfiguration').options.length === 1`, 'Assistant configurations did not load through the main process.');
        assert.match(await evaluate(window, `document.querySelector('#assistantConfiguration').selectedOptions[0].textContent`), /Local demonstration · Local/);
        assert.equal(await evaluate(window, `typeof window.aiProviders.getCredential`), 'undefined');
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container').length`), 3);
        assert.equal(await evaluate(window, `!document.querySelector('#assistantPanel').hidden && !document.querySelector('#applyAssistantProposal').disabled`), true);
        assert.match(await evaluate(window, `document.querySelector('#assistantProposalStatus').textContent`), /Native validation passed/);
        assert.match(await evaluate(window, `document.querySelector('#assistantProposalSummary').textContent`), /Battery module/);
        assert.equal(await evaluate(window, `document.querySelector('#generateAssistantProposal').textContent`), 'Revise proposal');
        await evaluate(window, `document.querySelector('#collapseAssistantPanel').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#assistantPanel').classList.contains('collapsed')`), true);
        assert.match(await evaluate(window, `document.querySelector('#assistantCollapsedStatus').textContent`), /Proposal ready/);
        await evaluate(window, `document.querySelector('#collapseAssistantPanel').click()`);
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#assistantPanel').hidden && !document.querySelector('#nodeEditor').classList.contains('hidden')`), true);
        await waitFor(window, `document.querySelector('#assistantPanel').getBoundingClientRect().right <= document.querySelector('#nodeEditor').getBoundingClientRect().left`, 'Assistant did not move beside the model inspector.');
        await evaluate(window, `document.querySelector('#nodeEditor [data-close-card]').click()`);
        assert.equal(await evaluate(window, `window.konjugateAssistant.applyProposal()`), true);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].some((label) => label.textContent.includes('Ambient boundary'))`, 'Applied assistant node did not appear on the canvas.');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await waitFor(window, `document.querySelectorAll('.node-label-container').length === 3`, 'Undo did not restore the original canvas.');
        await evaluate(window, `document.querySelector('#redoButton').click()`);
        await waitFor(window, `document.querySelectorAll('.node-label-container').length === 4`, 'Redo did not restore the assistant proposal.');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await waitFor(window, `document.querySelectorAll('.node-label-container').length === 3`, 'Undo did not restore the model before testing an assistant update.');
        await evaluate(window, `document.querySelector('#assistantButton').click(); (() => {
            document.querySelector('#assistantPrompt').value = 'Set the battery initial temperature to 325 K.';
            document.querySelector('#assistantPromptForm').requestSubmit();
        })()`);
        await waitFor(window, `!document.querySelector('#applyAssistantProposal').disabled`, 'The assistant update proposal was not ready.');
        assert.equal(await evaluate(window, `document.querySelectorAll('.assistantChange.update').length`), 1);
        assert.match(await evaluate(window, `document.querySelector('.assistantChange dd').textContent`), /353\.2 → 325/);
        await evaluate(window, `document.querySelector('.assistantChange button').click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#nodeEditor').classList.contains('hidden') && !document.querySelector('#assistantPanel').hidden`), true);
        assert.equal(await evaluate(window, `document.querySelector('#editNodeName').value`), 'Battery module');
        await evaluate(window, `document.querySelector('#discardAssistantProposal').click(); document.querySelector('#nodeEditor [data-close-card]').click(); document.querySelector('#closeAssistantPanel').click()`);
    }, { skip: !driver.capabilities.aiAssistant && 'AI-assisted authoring (including the local, non-credentialed demonstration provider) has no web-edition equivalent yet' });

    await run('local assistant can disable and enable a node and a relationship', async () => {
        const nodeLabel = `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module') && !label.textContent.includes('copy'))`;
        await evaluate(window, `document.querySelector('#assistantButton').click(); (() => {
            document.querySelector('#assistantPrompt').value = 'Disable the battery module.';
            document.querySelector('#assistantPromptForm').requestSubmit();
        })()`);
        await waitFor(window, `!document.querySelector('#applyAssistantProposal').disabled`, 'The disable-node proposal was not ready.');
        assert.equal(await evaluate(window, `document.querySelectorAll('.assistantChange.update').length`), 1);
        assert.match(await evaluate(window, `document.querySelector('.assistantChange dd').textContent`), /true → false/);
        assert.equal(await evaluate(window, `window.konjugateAssistant.applyProposal()`), true);
        // `?.` throughout: a plain top-level thrown exception during a polled evaluate() (not one
        // swallowed inside a click listener) surfaces from Electron as an opaque "Script failed to
        // execute" IPC error with no message, so a transient re-render leaving .find() briefly
        // unmatched would otherwise crash the whole test run rather than just failing one waitFor.
        await waitFor(window, `${nodeLabel}?.closest('.node-label-container').classList.contains('disabled')`, 'The assistant-applied node disable did not render.');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await waitFor(window, `${nodeLabel}?.closest('.node-label-container').classList.contains('disabled') === false`, 'Undo did not restore the assistant-applied node disable.');

        await evaluate(window, `document.querySelector('#assistantButton').click(); (() => {
            document.querySelector('#assistantPrompt').value = 'Disable the Heat source relationship.';
            document.querySelector('#assistantPromptForm').requestSubmit();
        })()`);
        await waitFor(window, `!document.querySelector('#applyAssistantProposal').disabled`, 'The disable-edge proposal was not ready.');
        assert.equal(await evaluate(window, `document.querySelectorAll('.assistantChange.update').length`), 1);
        assert.match(await evaluate(window, `document.querySelector('.assistantChange dd').textContent`), /true → false/);
        assert.equal(await evaluate(window, `window.konjugateAssistant.applyProposal()`), true);
        await waitFor(window, `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Electrical losses'))?.textContent.includes('Disabled')`, 'The assistant-applied edge disable did not render.');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await waitFor(window, `![...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Electrical losses'))?.textContent.includes('Disabled')`, 'Undo did not restore the assistant-applied edge disable.');
        await evaluate(window, `document.querySelector('#closeAssistantPanel').click()`);
    }, { skip: !driver.capabilities.aiAssistant && 'AI-assisted authoring (including the local, non-credentialed demonstration provider) has no web-edition equivalent yet' });

    await run('local assistant asks a clarifying question for an ambiguous request and resolves it from a suggestion', async () => {
        await evaluate(window, `document.querySelector('#assistantButton').click()`);
        // Reset first: earlier assistant tests in this suite already left turns in the bounded
        // conversation history (it deliberately survives an apply/discard/panel close, only an
        // explicit reset clears it), and this test wants a known, empty starting transcript.
        await evaluate(window, `window.konjugateAssistant.resetConversation()`);
        assert.equal(await evaluate(window, `document.querySelector('#assistantTranscript').hidden`), true);

        const temperatureNodeNames = await evaluate(window, `window.konjugateAssistant.getModelSummary().nodes
            .filter((node) => node.states.some((state) => state.symbol === 'temperature' || state.name.toLowerCase().includes('temperature')))
            .map((node) => node.name)`);
        assert.ok(temperatureNodeNames.length >= 2, `Expected at least two temperature-bearing nodes, found: ${temperatureNodeNames.join(', ')}`);

        await evaluate(window, `(() => {
            document.querySelector('#assistantPrompt').value = 'Set the temperature to 310 K.';
            document.querySelector('#assistantPromptForm').requestSubmit();
        })()`);
        await waitFor(window, `!document.querySelector('#assistantClarification').hidden`, 'The assistant did not ask a clarifying question for an ambiguous request.');
        assert.equal(await evaluate(window, `document.querySelector('#assistantPrompt').value`), '', 'The prompt should be cleared once a response has arrived.');
        assert.equal(await evaluate(window, `getComputedStyle(document.querySelector('#assistantEmpty')).display`), 'none', "The empty-state placeholder must not render behind the clarification (regression: .assistantEmpty's own display:grid was overriding [hidden]).");
        assert.equal(await evaluate(window, `document.querySelector('#generateAssistantProposal').textContent`), 'Answer');
        assert.match(await evaluate(window, `document.querySelector('#assistantClarificationQuestion').textContent`), /which node/i);
        const suggestionTexts = await evaluate(window, `[...document.querySelectorAll('.assistantClarificationOption')].map((button) => button.textContent)`);
        assert.deepEqual([...suggestionTexts].sort(), [...temperatureNodeNames].sort());
        assert.equal(await evaluate(window, `document.querySelectorAll('.assistantTranscriptTurn').length`), 1);
        assert.match(await evaluate(window, `document.querySelector('.assistantTranscriptOutcome').textContent`), /Asked:/);

        // Clicking a suggestion must only prefill the prompt, never submit it on its own.
        const firstSuggestion = await evaluate(window, `document.querySelector('.assistantClarificationOption').textContent`);
        await evaluate(window, `document.querySelector('.assistantClarificationOption').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#assistantPrompt').value`), firstSuggestion);
        assert.equal(await evaluate(window, `document.querySelector('#assistantClarification').hidden`), false);

        await evaluate(window, `(() => {
            document.querySelector('#assistantPrompt').value = ${JSON.stringify(`${firstSuggestion}, 310 K`)};
            document.querySelector('#assistantPromptForm').requestSubmit();
        })()`);
        await waitFor(window, `!document.querySelector('#applyAssistantProposal').disabled`, 'The clarification reply did not resolve into an appliable proposal.');
        assert.match(await evaluate(window, `document.querySelector('#assistantProposalSummary').textContent`), new RegExp(firstSuggestion));
        assert.equal(await evaluate(window, `document.querySelectorAll('.assistantTranscriptTurn').length`), 2);
        assert.match(await evaluate(window, `document.querySelectorAll('.assistantTranscriptOutcome')[1].textContent`), /Proposed:/);

        assert.equal(await evaluate(window, `window.konjugateAssistant.applyProposal()`), true);
        await waitFor(window, `document.querySelectorAll('.assistantTranscriptOutcome')[1]?.textContent.includes('Applied:')`, 'Applying did not update the transcript turn in place.');
        assert.equal(await evaluate(window, `document.querySelectorAll('.assistantTranscriptTurn').length`), 2, 'Applying should update the existing turn, not add a new one.');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `document.querySelector('#closeAssistantPanel').click()`);
    }, { skip: !driver.capabilities.aiAssistant && 'AI-assisted authoring (including the local, non-credentialed demonstration provider) has no web-edition equivalent yet' });

    await run('dismissing a clarification and starting a new conversation both clear it without submitting', async () => {
        await evaluate(window, `document.querySelector('#assistantButton').click()`);
        await evaluate(window, `window.konjugateAssistant.resetConversation()`);
        const temperatureNodeNames = await evaluate(window, `window.konjugateAssistant.getModelSummary().nodes
            .filter((node) => node.states.some((state) => state.symbol === 'temperature' || state.name.toLowerCase().includes('temperature')))
            .map((node) => node.name)`);
        assert.ok(temperatureNodeNames.length >= 2, `Expected at least two temperature-bearing nodes, found: ${temperatureNodeNames.join(', ')}`);

        await evaluate(window, `(() => {
            document.querySelector('#assistantPrompt').value = 'Set the temperature to 310 K.';
            document.querySelector('#assistantPromptForm').requestSubmit();
        })()`);
        await waitFor(window, `!document.querySelector('#assistantClarification').hidden`, 'The assistant did not ask a clarifying question.');
        assert.equal(await evaluate(window, `document.querySelector('#assistantPrompt').value`), '', 'The prompt should be cleared once a response (a clarifying question) has arrived.');
        assert.equal(await evaluate(window, `getComputedStyle(document.querySelector('#assistantEmpty')).display`), 'none', "The empty-state placeholder must not render behind the clarification (regression: .assistantEmpty's own display:grid was overriding [hidden]).");
        assert.equal(await evaluate(window, `document.querySelector('#generateAssistantProposal').textContent`), 'Answer');
        await evaluate(window, `document.querySelector('#dismissAssistantClarification').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#assistantClarification').hidden`), true);
        assert.equal(await evaluate(window, `document.querySelector('#assistantEmpty').hidden`), false);
        assert.equal(await evaluate(window, `getComputedStyle(document.querySelector('#assistantEmpty')).display`), 'grid');
        assert.equal(await evaluate(window, `document.querySelector('#generateAssistantProposal').textContent`), 'Generate proposal');
        assert.match(await evaluate(window, `document.querySelector('.assistantTranscriptOutcome').textContent`), /did not answer/i);
        assert.equal(await evaluate(window, `window.konjugateAssistant.getTurnHistory().length`), 1);

        // There's a turn in history to lose, so this must ask for confirmation first.
        await evaluate(window, `window.confirm = () => true; document.querySelector('#newAssistantConversation').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#assistantTranscript').hidden`), true);
        assert.equal(await evaluate(window, `window.konjugateAssistant.getTurnHistory().length`), 0);

        // Nothing left to lose now -- clicking it again must not block on a confirmation dialog
        // (this call deliberately does not stub window.confirm, so it would hang/timeout if the
        // implementation asked for confirmation here).
        await evaluate(window, `document.querySelector('#newAssistantConversation').click()`);
        await evaluate(window, `document.querySelector('#closeAssistantPanel').click()`);
    }, { skip: !driver.capabilities.aiAssistant && 'AI-assisted authoring (including the local, non-credentialed demonstration provider) has no web-edition equivalent yet' });

    await run('model configurations expose all provider adapters without renderer credential access', async () => {
        await evaluate(window, `document.querySelector('#assistantButton').click(); document.querySelector('#manageAssistantConfigurations').click()`);
        assert.deepEqual(await evaluate(window, `[...document.querySelector('#assistantConfigurationProvider').options].map((option) => option.value)`), [
            'localDemonstration', 'ollama', 'openAi', 'nvidia', 'huggingFace', 'gemini'
        ]);
        await evaluate(window, `document.querySelector('#newAssistantConfiguration').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#assistantCredentialField').hidden`), true);
        await evaluate(window, `(() => {
            document.querySelector('#assistantConfigurationName').value = 'Interaction Ollama';
            document.querySelector('#assistantConfigurationModel').value = '__custom__';
            document.querySelector('#assistantCustomModel').value = 'test-model';
            document.querySelector('#assistantConfigurationDialog').querySelector('form').requestSubmit();
        })()`);
        await waitFor(window, `[...document.querySelectorAll('#assistantConfiguration option')].some((option) => option.textContent.includes('Interaction Ollama'))`, 'Saved Ollama configuration did not appear.');
        assert.equal(await evaluate(window, `document.querySelector('#assistantConfigurationDialog').open`), true);
        assert.equal(await evaluate(window, `[...document.querySelectorAll('#assistantConfigurationList button')].some((button) => button.textContent.includes('Interaction Ollama'))`), true);
        assert.equal(await evaluate(window, `document.querySelector('#assistantConfigurationUuid').value.length > 0`), true);
        await evaluate(window, `window.confirm = () => true; document.querySelector('#deleteAssistantConfiguration').click()`);
        await waitFor(window, `document.querySelectorAll('#assistantConfiguration option').length === 1`, 'Deleted configuration remained available.');
        await evaluate(window, `document.querySelector('#cancelAssistantConfiguration').click(); document.querySelector('#closeAssistantPanel').click()`);
    }, { skip: !driver.capabilities.aiProviderCredentials && 'the credential-vault/provider-adapter architecture (window.aiProviders) has no web-edition equivalent' });

    await run('run configuration and node substeps are editable', async () => {
        // The numerics and execution settings live in the Run dialog; "Save settings" stores them with the
        // model without starting a run.
        await waitFor(window, `!document.querySelector('#runButton').disabled`, 'Run was not available to open the run settings.', 10000);
        await openRunDialog(window);
        assert.equal(await evaluate(window, `document.querySelector('#runExecutionBackend').value`), 'automatic');
        assert.equal(await evaluate(window, `document.querySelector('#runExecutionAdvanced').open`), false);
        await evaluate(window, `(() => {
            document.querySelector('#runGlobalTimeStep').value = '0.02';
            document.querySelector('#runOutputInterval').value = '0.1';
            document.querySelector('#runWorkerThreads').value = '2';
            document.querySelector('#runPartitionAlgorithm').value = 'automatic';
            document.querySelector('#runPartitionCount').value = '2';
            document.querySelector('#runPartitionCommunicationBias').value = '4';
            document.querySelector('#saveRunConfiguration').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#runLaunchDialog').open`), false);
        assert.equal(await evaluate(window, `document.querySelectorAll('#runPartitionAlgorithm option').length`), 3);
        // Applying the run configuration revalidates the model, which can rebuild the canvas labels: wait for
        // the node's label, then for its editor, rather than assuming both are there at once.
        const batteryLabel = `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module'))`;
        await waitFor(window, `Boolean(${batteryLabel})`, 'The Battery module label was not on the canvas.');
        await evaluate(window, `${batteryLabel}.click()`);
        await waitFor(window, `Boolean(document.querySelector('[data-node-tab="numerics"]')) && !document.querySelector('#nodeEditor').classList.contains('hidden')`, 'The node editor did not open.');
        await evaluate(window, `document.querySelector('[data-node-tab="numerics"]').click()`);
        await waitFor(window, `document.querySelector('#editNodeSubsteps').offsetParent !== null`, 'The numerics tab did not open.');
        await evaluate(window, `(() => { const input = document.querySelector('#editNodeSubsteps'); input.value = '2'; input.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        assert.equal(await evaluate(window, `document.querySelector('#editNodeSubsteps').value`), '2');
        assert.match(await evaluate(window, `document.querySelector('#nodeEffectiveTimeStep').textContent`), /0\.01/);
        await evaluate(window, `document.querySelector('#nodeEditor [data-close-card]').click()`);
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine'`, 'Updated numerical settings were not validated.');
    });

    await run('advanced provider execution mode selector persists a choice and warns for in-process', async () => {
        // Opening/saving this dialog awaits real IPC round trips before flipping dialog.open,
        // so each step below waits for that observable state change rather than assuming a
        // click's synchronous return means the async handler it triggered has finished.
        await evaluate(window, `document.querySelector('#providerToolchainsButton').click()`);
        await waitFor(window, `document.querySelector('#providerToolchainsDialog').open`, 'Provider Toolchains dialog did not open.');
        assert.equal(await evaluate(window, `document.querySelector('#providerExecutionMode').value`), '');
        assert.equal(await isRenderedVisible(window, '#providerExecutionModeWarning'), false);

        await evaluate(window, `(() => {
            const select = document.querySelector('#providerExecutionMode');
            select.value = 'inProcess';
            select.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await isRenderedVisible(window, '#providerExecutionModeWarning'), true);

        await evaluate(window, `(() => {
            const select = document.querySelector('#providerExecutionMode');
            select.value = 'sharedMemoryWorker';
            select.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await isRenderedVisible(window, '#providerExecutionModeWarning'), false);
        await evaluate(window, `document.querySelector('#providerToolchainsSave').click()`);
        await waitFor(window, `!document.querySelector('#providerToolchainsDialog').open`, 'Provider Toolchains dialog did not close after saving.');

        await evaluate(window, `document.querySelector('#providerToolchainsButton').click()`);
        await waitFor(window, `document.querySelector('#providerToolchainsDialog').open`, 'Provider Toolchains dialog did not reopen.');
        assert.equal(await evaluate(window, `document.querySelector('#providerExecutionMode').value`), 'sharedMemoryWorker');

        // Reset to Automatic so this machine-global (not project-scoped) preference does not
        // leak into later tests in this same run.
        await evaluate(window, `document.querySelector('#providerExecutionMode').value = ''`);
        await evaluate(window, `document.querySelector('#providerToolchainsSave').click()`);
        await waitFor(window, `!document.querySelector('#providerToolchainsDialog').open`, 'Provider Toolchains dialog did not close after resetting.');
    }, { skip: !driver.capabilities.providerExecutionModeSelector && 'sharedMemoryWorker/inProcess execution-mode selection has no web-edition equivalent' });

    // Shared across the three run() calls the "Run..."/"Results Analysis..."/"closing results..."
    // scenarios below split into (see docs/proposals/webEdition.md and this file's own driver
    // header comment): the Results Analysis add-on window has no web-edition equivalent, but the
    // main window must always end each of these three scenarios in the same state regardless of
    // whether the add-on portion actually ran, so scenario #16 (multi-selection...) always starts
    // clean. analysisHandle stays null when the add-on scenario is skipped.
    let analysisHandle = null;

    await run('Run invokes the C++ simulation and displays state results', async () => {
        assert.equal(await evaluate(window, `document.querySelector('#runButton').disabled`), false);
        const before = await evaluate(window, `document.querySelector('.node-label-container dd').textContent`);
        await openRunDialog(window);
        await evaluate(window, `(() => { document.querySelector('#runTargetTime').value = '1.5'; document.querySelector('#runOnlineMode').checked = true; document.querySelector('#runOnlineMode').dispatchEvent(new Event('change', { bubbles: true })); document.querySelector('#runPacingMode').value = 'realTime'; document.querySelector('#startRun').click(); })()`);
        await waitFor(window, `!document.querySelector('#resultTransport').hidden && document.querySelector('.resultMode small').textContent === 'Running · model locked'`, 'C++ simulation did not enter its running state.', 10000);
        assert.equal(await evaluate(window, `!document.querySelector('#simulationPacing').hidden && document.querySelector('#resultPlaybackRate').hidden`), true);
        assert.equal(await evaluate(window, `document.querySelector('#resultPlaybackControls').hidden && !document.querySelector('#simulationExecutionControls').hidden`), true);
        assert.equal(await evaluate(window, `[...document.querySelectorAll('.reviewControl')].every((control) => control.hidden) && document.querySelector('#continueRun').hidden`), true);
        assert.equal(await evaluate(window, `[...document.querySelectorAll('.reviewControl, #continueRun')].every((control) => getComputedStyle(control).display === 'none')`), true);
        assert.equal(await evaluate(window, `document.querySelector('.resultMode b').textContent`), 'Simulation');
        assert.equal(await evaluate(window, `getComputedStyle(document.querySelector('#simulationProgress')).display !== 'none' && document.querySelector('#simulationProgress').value.includes('/')`), true);
        assert.equal(await evaluate(window, `document.querySelector('.resultMode small').textContent`), 'Running · model locked');
        await evaluate(window, `document.querySelector('#simulationPauseResume').click()`);
        await waitFor(window, `document.querySelector('.resultMode small').textContent === 'Paused · model locked'`, 'Simulation did not pause at a synchronization boundary.', 3000);
        assert.equal(await evaluate(window, `document.querySelector('#closeResults').hidden`), true);
        await evaluate(window, `document.querySelector('#simulationPauseResume').click()`);
        await waitFor(window, `document.querySelector('.resultMode small').textContent === 'Model locked'`, 'Live simulation did not complete.', 5000);
        assert.equal(await evaluate(window, `document.querySelector('#simulationPacing').hidden && !document.querySelector('#resultPlaybackRate').hidden`), true);
        assert.equal(await evaluate(window, `!document.querySelector('#resultPlaybackControls').hidden && document.querySelector('#simulationExecutionControls').hidden`), true);
        assert.equal(await evaluate(window, `[...document.querySelectorAll('.reviewControl')].every((control) => !control.hidden) && !document.querySelector('#continueRun').hidden`), true);
        assert.equal(await evaluate(window, `getComputedStyle(document.querySelector('#continueRun')).display !== 'none' && document.querySelector('#continueRun').textContent === 'Extend simulation' && getComputedStyle(document.querySelector('#resultTimeline')).display !== 'none'`), true);
        assert.equal(await evaluate(window, `document.querySelector('.resultMode b').textContent`), 'Results');
        assert.equal(await evaluate(window, `getComputedStyle(document.querySelector('#simulationProgress')).display === 'none'`), true);
        assert.equal(await evaluate(window, `document.querySelector('#executionSummaryButton').hidden`), false);
        assert.equal(await evaluate(window, `!document.querySelector('#saveButton').disabled`), true);
        assert.equal(await evaluate(window, `!document.querySelector('#branchesButton').hidden && document.querySelector('#branchesPanel').hidden`), true);
        await evaluate(window, `document.querySelector('#branchesButton').click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#branchesPanel').hidden && !document.querySelector('#forkHereButton').hidden && document.querySelector('#forkHereLabel').textContent.startsWith('Fork at ')`), true);
        await evaluate(window, `document.querySelector('#branchesButton').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#branchesPanel').hidden`), true);
        await evaluate(window, `document.querySelector('#executionSummaryButton').click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#executionSummaryCard').classList.contains('hidden')`), true);
        assert.match(await evaluate(window, `document.querySelector('#executionSummaryTitle').textContent`), /(Serial|Thread pool|Partitioned) · \d+ workers?/);
        assert.ok(await evaluate(window, `document.querySelectorAll('#executionSummaryMetrics dt').length`) >= 8);
        assert.match(await evaluate(window, `document.querySelector('#executionSummaryMetrics').textContent`), /Partitioner.*Communication cut/);
        await evaluate(window, `document.querySelector('#closeExecutionSummary').click()`);
        assert.equal(await evaluate(window, `document.querySelector('[data-detail="nodes"]').classList.contains('active')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#canvas').classList.contains('showNodesDetails')`), true);
        const finalValue = await evaluate(window, `document.querySelector('.node-label-container dd').textContent`);
        assert.notEqual(finalValue, before);
        assert.ok(Number(await evaluate(window, `document.querySelector('#resultTimeline').max`)) > 0);
        assert.equal(await evaluate(window, `Number(document.querySelector('#resultTimeline').value)`), 1.5);
        assert.equal(await evaluate(window, `Number(document.querySelector('#resultTimeline').max)`), 1.5);
        assert.equal(await evaluate(window, `document.querySelector('#resultPlaybackRate').value`), '1');
        await evaluate(window, `(() => { const timeline = document.querySelector('#resultTimeline'); timeline.value = '0'; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        assert.equal(await evaluate(window, `document.querySelector('#resultCurrentTime').value`), '0 s');
        assert.notEqual(await evaluate(window, `document.querySelector('.node-label-container dd').textContent`), finalValue);
        await evaluate(window, `document.querySelector('#resultPlayPause').click()`);
        await waitFor(window, `Number(document.querySelector('#resultTimeline').value) > 0`, 'Result playback did not advance the timeline.', 3000);
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        await waitFor(window, `document.querySelector('.nodeResultsPanel').classList.contains('hasResults')`, 'Selected-node result plot did not render.', 5000);
        assert.equal(await evaluate(window, `document.querySelector('[data-node-tab="results"]').classList.contains('active')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#nodeModelActions').hidden`), true);
        assert.equal(await evaluate(window, `document.querySelector('#canvas').classList.contains('resultModeLocked')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#addButton').disabled && document.querySelector('[data-tool="move"]').disabled && document.querySelector('[data-action="delete"]').disabled`), true);
        assert.equal(await evaluate(window, `!document.querySelector('#nodeEditor [data-result-readonly]').hidden`), true);
        assert.ok(await evaluate(window, `document.querySelector('#nodeResultPlot').data.length`) > 0);
        assert.ok(await evaluate(window, `document.querySelector('#nodeResultPlot').layout.shapes.length`) > 0);
        assert.equal(await evaluate(window, `document.querySelector('#openResultsAnalysis')`), null);
    });

    await run('Results Analysis add-on inspects and exports a completed run', async () => {
        // The toolstrip command itself, not just the ability to click it, is desktop-only: the web
        // shim's window.addons.listToolstripContributions() always returns [] (confirmed by
        // reading src/renderer/webShims/misc.mjs directly), so no add-on toolstrip button ever
        // renders on the web edition regardless of which add-ons a real desktop install has.
        await waitFor(window, `Boolean(document.querySelector('.addonTool[data-addon-id="konjugate.resultPlotViewer"][data-command-id="openAnalysis"]:not([hidden])'))`, 'Manifest-declared add-on toolstrip command did not appear.');
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('.addonTool[data-addon-id="konjugate.resultPlotViewer"][data-command-id="openAnalysis"]').click()`);
        analysisHandle = await driver.waitForNewHandle(before);
        const analysisWindow = analysisHandle;
        await waitFor(analysisWindow, `Boolean(document.querySelector('.konjugateAddonTitlebar'))`, 'Host titlebar was not added to the add-on window.');
        assert.equal(await evaluate(analysisWindow, `document.querySelector('.konjugateAddonIdentity b').textContent`), 'Results Analysis');
        // Every add-on window carries Konjugate's own logo in its host titlebar, not a stand-in letter.
        await waitFor(analysisWindow, `Boolean(document.querySelector('.konjugateAddonIdentity > img'))`, 'The add-on titlebar did not get Konjugate\'s logo.');
        assert.match(await evaluate(analysisWindow, `document.querySelector('.konjugateAddonIdentity > img').src`), /^data:image\/svg\+xml;base64,/);
        assert.equal(await evaluate(analysisWindow, `document.querySelectorAll('.konjugateAddonWindowControls button').length`), 3);
        await waitFor(analysisWindow, `getComputedStyle(document.querySelector('.konjugateAddonTitlebar')).position === 'fixed'`, 'Host titlebar styles did not load.');
        await waitFor(analysisWindow, `document.querySelectorAll('.signalOption').length > 0 && document.querySelector('.plotWorkspace').classList.contains('hasSignals')`, 'Results Analysis did not load signals.', 5000);
        assert.equal(await evaluate(analysisWindow, `document.querySelector('.readOnlyBadge').textContent`), 'Completed');
        assert.equal(await evaluate(analysisWindow, `typeof require === 'undefined'`), true);
        assert.ok(await evaluate(analysisWindow, `document.querySelector('#analysisPlot').data.length`) > 0);

        await evaluate(analysisWindow, `(() => {
            const options = (id) => [...document.querySelector(id).options].map((option) => option.value);
            const xOptions = options('#scatterX');
            const yOptions = options('#scatterY').filter((value) => value !== xOptions[0]);
            document.querySelector('#scatterX').value = xOptions[0];
            document.querySelector('#scatterY').value = yOptions[0] ?? xOptions[0];
            document.querySelector('#scatterColor').value = options('#scatterColor').filter(Boolean)[0] ?? '';
            document.querySelector('#chartMode').value = 'scatter';
            document.querySelector('#chartMode').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').data[0]?.type === 'scatter' && document.querySelector('#analysisPlot').data[0]?.mode === 'markers'`, 'Scatter mode did not render a markers trace.', 3000);
        assert.equal(await evaluate(analysisWindow, `document.querySelector('#scatterPickers').hidden`), false);
        assert.equal(await evaluate(analysisWindow, `document.querySelector('#signalGroups').hidden`), true);
        assert.equal(await evaluate(analysisWindow, `document.querySelector('#resetTrail').hidden`), false);
        assert.equal(await evaluate(analysisWindow, `Array.isArray(document.querySelector('#analysisPlot').data[0].marker.color)`), true);

        // Scatter/distribution reveal samples progressively up to the timeline's current position
        // (a phase-space trail) -- seeking to 0 should empty it, seeking forward should refill it,
        // and axis ranges (fixed from the full run) should stay put across that Plotly.restyle-only
        // update rather than being reasserted from whatever's currently revealed.
        const rangeBeforeTrailScrub = await evaluate(analysisWindow, `document.querySelector('#analysisPlot').layout.xaxis.range`);
        await evaluate(analysisWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = '0'; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').data[0].x.length <= 1`, 'Scatter trail did not empty when seeking to time 0.', 3000);
        assert.deepEqual(await evaluate(analysisWindow, `document.querySelector('#analysisPlot').layout.xaxis.range`), rangeBeforeTrailScrub);
        await evaluate(analysisWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = timeline.max; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').data[0].x.length > 1`, 'Scatter trail did not refill when seeking forward.', 3000);
        await evaluate(analysisWindow, `document.querySelector('#resetTrail').click()`);
        await waitFor(analysisWindow, `document.querySelector('#timeline').value === '0' && document.querySelector('#analysisPlot').data[0].x.length <= 1`, 'Reset trail button did not empty the trail.', 3000);
        await evaluate(analysisWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = timeline.max; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').data[0].x.length > 1`, 'Scatter trail did not refill after reset.', 3000);

        await evaluate(analysisWindow, `(() => {
            document.querySelector('#chartMode').value = 'distribution';
            document.querySelector('#chartMode').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').data.length > 0 && document.querySelector('#analysisPlot').data.every((trace) => trace.type === 'histogram')`, 'Distribution mode did not render histogram traces.', 3000);
        assert.equal(await evaluate(analysisWindow, `document.querySelector('#scatterPickers').hidden`), true);
        assert.equal(await evaluate(analysisWindow, `document.querySelector('#signalGroups').hidden`), false);
        assert.equal(await evaluate(analysisWindow, `document.querySelector('#resetTrail').hidden`), false);
        const distributionRangeBeforeScrub = await evaluate(analysisWindow, `document.querySelector('#analysisPlot').layout.yaxis.range`);
        await evaluate(analysisWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = '0'; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').data[0].x.length <= 1`, 'Distribution trail did not empty when seeking to time 0.', 3000);
        assert.deepEqual(await evaluate(analysisWindow, `document.querySelector('#analysisPlot').layout.yaxis.range`), distributionRangeBeforeScrub);

        await evaluate(analysisWindow, `(() => {
            document.querySelector('#chartMode').value = 'timeSeries';
            document.querySelector('#chartMode').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').data.every((trace) => trace.type === 'scatter' && trace.mode === 'lines')`, 'Time series mode did not restore line traces after switching chart types.', 3000);
        assert.ok(await evaluate(analysisWindow, `document.querySelector('#analysisPlot').layout.shapes.length`) > 0);
        assert.equal(await evaluate(analysisWindow, `document.querySelector('#resetTrail').hidden`), true);

        // The cursor line itself, not just its presence -- seeking must actually move it.
        const cursorXBefore = await evaluate(analysisWindow, `document.querySelector('#analysisPlot').layout.shapes[0].x0`);
        await evaluate(analysisWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = String(Number(timeline.max) / 2); timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').layout.shapes[0].x0 !== ${JSON.stringify(cursorXBefore)}`,
            'Time series cursor line did not move when seeking on a completed run.', 3000);

        assert.equal(await evaluate(analysisWindow, `document.querySelector('#exportCsv').disabled`), false);
        const { bytes } = await driver.captureExport(async () => {
            await evaluate(analysisWindow, `document.querySelector('#exportCsv').click()`);
        }, { extension: 'csv' });
        const exportedCsv = bytes.toString('utf8');
        assert.ok(exportedCsv, 'Export data (CSV) did not write a file.');
        assert.match(exportedCsv, /^time \(s\)/);

        await evaluate(analysisWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = '0'; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await waitFor(window, `document.querySelector('#resultCurrentTime').value === '0 s'`, 'Visualizer seek did not synchronize to the project window.');
    }, { skip: (!driver.capabilities.addons && 'the Results Analysis add-on has no web-edition equivalent') || addonMissing('konjugate.resultPlotViewer', 'konjugate-resultplotviewer') });

    await run('closing results clears the main window and any add-on it opened', async () => {
        await evaluate(window, `document.querySelector('[data-node-tab="model"]').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#editNodeName').disabled`), true);
        await evaluate(window, `(() => { const input = document.querySelector('#editNodeName'); input.value = 'Changed during results'; input.dispatchEvent(new Event('change', { bubbles: true })); window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true })); })()`);
        assert.equal(await evaluate(window, `[...document.querySelectorAll('.objectLabel')].some((label) => label.textContent.includes('Battery module'))`), true);
        await evaluate(window, `document.querySelector('#closeResults').click()`);
        await waitFor(window, `document.querySelector('#closeResultsDialog').open`, 'Closing results did not request confirmation.');
        assert.match(await evaluate(window, `document.querySelector('#closeResultsMessage').textContent`), /save the project with simulation results.*removed from this session/i);
        await evaluate(window, `document.querySelector('#confirmCloseResults').click()`);
        if (analysisHandle) {
            for (let attempt = 0; attempt < 100 && !(await analysisHandle.isDestroyed()); attempt += 1) {
                await new Promise((resolve) => setTimeout(resolve, 25));
            }
            assert.equal(await analysisHandle.isDestroyed(), true);
        }
        await waitFor(window, `document.querySelector('#resultTransport').hidden`, 'Confirming did not close the results.');
        assert.equal(await evaluate(window, `document.querySelector('[data-detail="nodes"]').classList.contains('active')`), false);
        assert.equal(await evaluate(window, `document.querySelector('#editNodeName').disabled || document.querySelector('#nodeModelActions').hidden`), false);
        assert.equal(await evaluate(window, `document.querySelector('#canvas').classList.contains('resultModeLocked')`), false);
        assert.equal(await evaluate(window, `document.querySelector('.addonTool:not([hidden])') === null`), true);
    });

    await run('multi-selection copies, pastes and deletes a connected graph fragment transactionally', async () => {
        const before = await evaluate(window, `({
            nodes: [...document.querySelectorAll('.node-label-container')].filter((label) => getComputedStyle(label).display !== 'none').length,
            relationships: document.querySelectorAll('.modelStatus span')[1].textContent
        })`);
        await clickElement(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module'))`);
        await new Promise((resolve) => setTimeout(resolve, 250));
        await clickElement(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Enclosed air'))`, ['shift']);
        await waitFor(window, `document.querySelectorAll('.node-label-container.selected').length === 2`, 'Real Shift-click did not add the second node.');
        // Give the CSS2DRenderer a frame to reposition the bundle label after the selection
        // change before reading its bounding rect for the click below — under SwiftShader
        // software rendering (used in headless/CI test runs) this can otherwise still be
        // mid-transition, sending the click past the label onto the canvas underneath.
        // SwiftShader frames have been observed stalling well past 250ms, so wait for it to
        // actually settle rather than a single fixed delay.
        await waitForStableRect(window,
            `(() => { const rect = document.querySelector('.bundleLabel')?.getBoundingClientRect(); return rect && JSON.stringify(rect); })()`,
            'The bundle label did not settle into a stable position.');
        await clickElement(window, `document.querySelector('.bundleLabel')`, ['shift']);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.selected').length`), 2);
        const emptyPoint = await evaluate(window, `(() => { const bounds = document.querySelector('#webglContainer').getBoundingClientRect(); return { x: Math.round(bounds.left + 20), y: Math.round(bounds.top + 20) }; })()`);
        await window.mouseDown(emptyPoint, { button: 'left', clickCount: 1, modifiers: ['shift'] });
        await window.mouseUp(emptyPoint, { button: 'left', clickCount: 1, modifiers: ['shift'] });
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.selected').length`), 2);
        assert.equal(await evaluate(window, `document.querySelector('#copySelection').disabled`), false);
        await evaluate(window, `document.querySelector('#copySelection').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#pasteSelection').disabled`), false);
        await evaluate(window, `document.querySelector('#pasteSelection').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].some((label) => label.textContent.includes('Battery module copy')) && [...document.querySelectorAll('.objectLabel')].some((label) => label.textContent.includes('Enclosed air copy'))`, 'The copied graph fragment was not pasted.');
        assert.equal(await evaluate(window, `[...document.querySelectorAll('.node-label-container')].filter((label) => getComputedStyle(label).display !== 'none').length`), before.nodes + 2);
        assert.notEqual(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), before.relationships);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true }))`);
        await waitFor(window, `[...document.querySelectorAll('.node-label-container')].filter((label) => getComputedStyle(label).display !== 'none').length === ${before.nodes}`, 'Deleting the pasted multi-selection did not hide every copied node.');
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await waitFor(window, `[...document.querySelectorAll('.node-label-container')].filter((label) => getComputedStyle(label).display !== 'none').length === ${before.nodes + 2}`, 'Undo did not restore the pasted multi-selection.');
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await waitFor(window, `[...document.querySelectorAll('.node-label-container')].filter((label) => getComputedStyle(label).display !== 'none').length === ${before.nodes}`, 'Undoing paste did not remove the copied graph fragment.');
    });

    await run('Cmd/Ctrl+V pastes a single copied node', async () => {
        // Regression test: same root cause as the multi-selection test above (modelClipboard.read()
        // in src/preload.mjs used to decode the clipboard buffer with a bare `bytes.toString('utf8')`,
        // but `bytes` crosses the IPC boundary as a plain Uint8Array rather than a Node Buffer, so
        // the 'utf8' argument was silently ignored and JSON.parse always threw), isolated to the
        // keyboard-shortcut path (Cmd/Ctrl+C / Cmd/Ctrl+V) and a single node rather than a group.
        // Fixed by wrapping the read in Buffer.from(bytes) before .toString('utf8').
        const visibleNodeCount = () => `[...document.querySelectorAll('.node-label-container')].filter((label) => getComputedStyle(label).display !== 'none').length`;
        const before = await evaluate(window, visibleNodeCount());
        // Excludes "... copy" labels: a soft-deleted "Battery module copy" from an earlier test
        // can still be present (hidden) in the DOM, and a plain .includes('Battery module')
        // would match it too.
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module') && !label.textContent.includes('copy')).click()`);
        await waitFor(window, `document.querySelectorAll('.node-label-container.selected').length === 1`, 'Node selection did not register before the copy shortcut.');
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'c', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'v', metaKey: true, ctrlKey: true, bubbles: true }))`);
        // Wait on the actual visible count rather than the "... copy" label text existing: a
        // stale, soft-deleted (hidden) copy from an earlier test would satisfy a text-only wait
        // immediately, before this test's own paste has actually landed.
        await waitFor(window, `${visibleNodeCount()} === ${before} + 1`, 'The Cmd/Ctrl+V shortcut did not paste the copied node.');
        assert.equal(await evaluate(window, visibleNodeCount()), before + 1);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await waitFor(window, `${visibleNodeCount()} === ${before}`, 'Undo did not remove the pasted node.');
    });

    await run('rectangle tool selects visible nodes without opening an inspector', async () => {
        await evaluate(window, `document.querySelector('[data-tool="rectangleSelect"]').click()`);
        // The preceding paste/undo tests leave the CSS2DRenderer mid-reposition (same cause as the
        // bundle-label wait in the multi-selection test above); under SwiftShader software rendering
        // this can still be settling when we read the label rects below, silently skewing the
        // computed drag rectangle. Wait for it to actually settle, like that test does.
        const labelRectsSelector = `[...document.querySelectorAll('.node-label-container')]
            .filter((label) => (label.textContent.includes('Battery module') || label.textContent.includes('Enclosed air')) && !label.textContent.includes('copy'))
            .map((label) => label.getBoundingClientRect())`;
        await waitForStableRect(window, `JSON.stringify(${labelRectsSelector})`, 'The node labels did not settle into a stable position.');
        const bounds = await evaluate(window, `(() => {
            // Excludes "... copy" labels: a soft-deleted "Battery module copy" from the preceding
            // paste-undo test can still be present (hidden) in the DOM, and getBoundingClientRect()
            // on a display:none element returns all zeros, which would wreck these bounds.
            const labels = [...document.querySelectorAll('.node-label-container')];
            const battery = labels.find((label) => label.textContent.includes('Battery module') && !label.textContent.includes('copy')).getBoundingClientRect();
            const air = labels.find((label) => label.textContent.includes('Enclosed air') && !label.textContent.includes('copy')).getBoundingClientRect();
            return {
                start: { x: Math.round(Math.min(battery.left, air.left) - 220), y: Math.round(Math.min(battery.top, air.top) - 100) },
                end: { x: Math.round(Math.max(battery.right, air.right) + 20), y: Math.round(Math.max(battery.bottom, air.bottom) + 100) }
            };
        })()`);
        await window.mouseMove(bounds.start);
        await window.mouseDown(bounds.start, { button: 'left', clickCount: 1 });
        await window.mouseMove(bounds.end);
        await window.mouseUp(bounds.end, { button: 'left', clickCount: 1 });
        await waitFor(window, `document.querySelectorAll('.node-label-container.selected').length === 2`, 'Rectangle selection did not select the two enclosed nodes.');
        const selected = await evaluate(window, `[...document.querySelectorAll('.node-label-container.selected')].map((label) => label.textContent)`);
        assert.ok(selected.some((label) => label.includes('Battery module')));
        assert.ok(selected.some((label) => label.includes('Enclosed air')));
        assert.equal(await evaluate(window, `document.querySelector('#nodeEditor').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('[data-tool="rectangleSelect"]').classList.contains('active')`), true);
        await evaluate(window, `document.querySelector('[data-tool="select"]').click()`);
    });

    await run('selected nodes become a navigable undoable subsystem', async () => {
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.selected').length`), 2);
        assert.equal(await evaluate(window, `document.querySelector('#createSubsystem').disabled`), false);
        await evaluate(window, `document.querySelector('#createSubsystem').click()`);
        await waitFor(window, `document.querySelector('#subsystemDialog').open`, 'Subsystem dialog did not open.');
        await evaluate(window, `(() => { document.querySelector('#subsystemName').value = 'Thermal enclosure'; document.querySelector('#subsystemCreate').click(); })()`);
        await waitFor(window, `[...document.querySelectorAll('.subsystemLabel')].some((label) => label.textContent.includes('Thermal enclosure'))`, 'Subsystem proxy did not appear.');
        await waitFor(window, `[...document.querySelectorAll('.node-label-container')].filter((label) => /Battery module|Enclosed air/.test(label.textContent) && !label.textContent.includes('copy')).every((label) => getComputedStyle(label).display === 'none')`, 'Wrapped nodes remained visible outside the subsystem.');
        await clickElement(window, `[...document.querySelectorAll('.subsystemLabel')].find((label) => label.textContent.includes('Thermal enclosure'))`);
        await waitFor(window, `!document.querySelector('#subsystemBreadcrumb').hidden`, 'Subsystem navigation did not enter the subsystem.');
        await waitFor(window, `[...document.querySelectorAll('.node-label-container')].filter((label) => /Battery module|Enclosed air/.test(label.textContent) && !label.textContent.includes('copy')).every((label) => getComputedStyle(label).display !== 'none')`, 'Subsystem members did not appear after entering.');
        await evaluate(window, `document.querySelector('[data-subsystem-parent]').click()`);
        await waitFor(window, `document.querySelector('#subsystemBreadcrumb').hidden`, 'Subsystem navigation did not return to the model.');
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await waitFor(window, `[...document.querySelectorAll('.node-label-container')].filter((label) => getComputedStyle(label).display !== 'none').length === 3`, 'Undo did not unwrap the subsystem.');
    });

    await run('icon-only toolstrip controls expose custom accessible tooltips', async () => {
        const controls = await evaluate(window, `[...document.querySelectorAll('.toolstrip .squareTool')].map((button) => ({
            label: button.getAttribute('aria-label'),
            tooltip: button.dataset.tooltip,
            nativeTitle: button.getAttribute('title')
        }))`);
        assert.ok(controls.length >= 5);
        assert.ok(controls.every((control) => control.label && control.tooltip && control.nativeTitle === null));
        assert.deepEqual(await evaluate(window, `[...document.querySelectorAll('.toolstrip .toolGroup')].map((group) => group.getAttribute('aria-label'))`), [
            'Create', 'History', 'Selection tools', 'Selection actions'
        ]);
    });

    await run('canvas help reflects left-click inspection and right-click action controls', async () => {
        const help = await evaluate(window, `document.querySelector('.canvasHelp').textContent.replace(/\\s+/g, ' ').trim()`);
        assert.match(help, /Left click inspect/);
        assert.match(help, /Right click actions/);
        assert.match(help, /Drag move or orbit/);
        assert.match(help, /Shift-drag pan/);
        assert.match(help, /Scroll or −\/\+ zoom/);
    });

    await run('left-click opens node and relationship inspectors', async () => {
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#nodeEditor').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#nodeEditorTitle').textContent`), 'Battery module');
        await evaluate(window, `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#edgeEditor').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#edgeEditor .doneButton') === null`), true);
    });

    await run('live parameters expose labelled slider bounds with validation', async () => {
        const labels = await evaluate(window, `[...document.querySelectorAll('.editorParameterRow:first-child .parameterField > span')].map((label) => label.textContent)`);
        assert.deepEqual(labels.slice(0, 5), ['Name', 'Symbol', 'Initial value', 'Unit', 'Mode']);
        await evaluate(window, `(() => {
            const mode = document.querySelector('.editorParameterRow:first-child [data-field="mode"]');
            mode.value = 'live';
            mode.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `!document.querySelector('.editorParameterRow:first-child .parameterControlFields').hidden`), true);
        const controlLabels = await evaluate(window, `[...document.querySelectorAll('.editorParameterRow:first-child .parameterControlFields .parameterField > span')].map((label) => label.textContent)`);
        assert.deepEqual(controlLabels, ['Slider minimum', 'Slider maximum', 'Slider step']);
        await evaluate(window, `(() => {
            const minimum = document.querySelector('.editorParameterRow:first-child [data-control-field="minimum"]');
            minimum.value = '30';
            minimum.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        assert.match(await evaluate(window, `document.querySelector('.editorParameterRow:first-child .parameterControlError').textContent`), /Minimum must be less than maximum/);
    });

    await run('a live-mode parameter cannot also be marked tunable, and switching to live clears any existing tuning bounds', async () => {
        // Continues from the previous test, which already left this row's Mode at "live" --
        // fitting a parameter against measured data (Tuning) and interactively adjusting it
        // during a run (Live) are different phases of use, but a value that's live-adjustable at
        // run time has no fixed "fitted" baseline worth calibrating beforehand, so the two are
        // mutually exclusive here.
        assert.equal(await evaluate(window, `document.querySelector('.editorParameterRow:first-child [data-field="mode"]').value`), 'live');
        assert.equal(await evaluate(window, `document.querySelector('.editorParameterRow:first-child [data-field="tunable"]').disabled`), true);
        assert.equal(await evaluate(window, `document.querySelector('.editorParameterRow:first-child [data-field="tunable"]').checked`), false);

        // Switch back to constant: the checkbox re-enables, and checking it commits tuning bounds.
        await evaluate(window, `(() => {
            const mode = document.querySelector('.editorParameterRow:first-child [data-field="mode"]');
            mode.value = 'constant';
            mode.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('.editorParameterRow:first-child [data-field="tunable"]').disabled`), false);
        await evaluate(window, `(() => {
            const checkbox = document.querySelector('.editorParameterRow:first-child [data-field="tunable"]');
            checkbox.checked = true;
            checkbox.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await waitFor(window, `!document.querySelector('.editorParameterRow:first-child .parameterTuningFields').hidden`,
            'Checking Tunable in constant mode did not reveal the fitting-bounds fields.');
        const editedEdgeName = await evaluate(window, `document.querySelector('#editEdgeName').value`);
        const firstParameterOf = (document_) => document_.edges.find((edge) => edge.name === editedEdgeName).parameters[0];
        let document_ = await evaluate(window, `window.__debugCausalInference.document()`);
        assert.ok(firstParameterOf(document_).tuning, 'Expected the committed document to carry tuning bounds after checking Tunable.');

        // Switching back to live must clear that tuning data, not just hide it behind a disabled checkbox.
        await evaluate(window, `(() => {
            const mode = document.querySelector('.editorParameterRow:first-child [data-field="mode"]');
            mode.value = 'live';
            mode.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('.editorParameterRow:first-child [data-field="tunable"]').checked`), false);
        assert.equal(await evaluate(window, `document.querySelector('.editorParameterRow:first-child [data-field="tunable"]').disabled`), true);
        document_ = await evaluate(window, `window.__debugCausalInference.document()`);
        assert.equal(firstParameterOf(document_).tuning, undefined, 'Switching Mode to Live should clear any existing tuning bounds, not just hide them.');
    });

    await run('equation editor switches between visual and LaTeX modes', async () => {
        await evaluate(window, `document.querySelector('[data-equation-mode="latex"]').click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#editEdgeMathField').hidden && document.querySelector('#editEdgeEquation').hidden`), false);
        await evaluate(window, `document.querySelector('[data-equation-mode="visual"]').click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#editEdgeMathField').hidden && document.querySelector('#editEdgeEquation').hidden`), true);
    });

    await run('relationship editor authors an inline C++ provider implementation', async () => {
        const kindSelect = `document.querySelector('#editEdgeImplementationKind')`;
        await evaluate(window, `(() => {
            const select = ${kindSelect};
            select.value = 'cpp';
            select.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await isRenderedVisible(window, '#editEdgeProviderSection'), true);
        assert.equal(await isRenderedVisible(window, '#editEdgeEquationHeading'), false);
        assert.equal(await isRenderedVisible(window, '#editEdgeMathField'), false);
        assert.match(await evaluate(window, `document.querySelector('#editEdgeProviderSource').value`), /#include <konjugate\/relationshipProvider\.hpp>/);

        const source = 'int main() {}';
        await evaluate(window, `(() => {
            const textarea = document.querySelector('#editEdgeProviderSource');
            textarea.value = ${JSON.stringify(source)};
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
            textarea.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeProviderSource').value`), source);

        const bindingCountBefore = await evaluate(window, `document.querySelectorAll('.providerBindingRow').length`);
        await evaluate(window, `document.querySelector('#editAddProviderBinding').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.providerBindingRow').length`), bindingCountBefore + 1);

        await evaluate(window, `(() => {
            const key = document.querySelector('.providerBindingRow:last-child [data-field="key"]');
            key.value = 'delta';
            key.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('.providerBindingRow:last-child [data-field="key"]').value`), 'delta');

        await evaluate(window, `(() => {
            const outputKey = document.querySelector('#editProviderOutputKey');
            outputKey.value = 'gradient';
            outputKey.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#editProviderOutputKey').value`), 'gradient');

        await evaluate(window, `(() => {
            window.confirm = () => true;
            document.querySelector('#editInsertProviderTemplate').click();
        })()`);
        const regeneratedSource = await evaluate(window, `document.querySelector('#editEdgeProviderSource').value`);
        assert.match(regeneratedSource, /ScalarPort\{"delta", "delta", ""\}/);
        assert.match(regeneratedSource, /ScalarPort\{"gradient", "gradient", ""\}/);

        // Switch back to Equation so the following equation-editor tests see their expected state.
        await evaluate(window, `(() => {
            const select = ${kindSelect};
            select.value = 'equation';
            select.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await isRenderedVisible(window, '#editEdgeEquationHeading'), true);
        assert.equal(await isRenderedVisible(window, '#editEdgeMathField'), true);
        assert.equal(await isRenderedVisible(window, '#editEdgeProviderSection'), false);
    });

    await run('provider editor window syntax-highlights, validates and applies C++ source', async () => {
        const kindSelect = `document.querySelector('#editEdgeImplementationKind')`;
        await evaluate(window, `(() => {
            const select = ${kindSelect};
            select.value = 'cpp';
            select.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        const validCpp = await evaluate(window, `document.querySelector('#editEdgeProviderSource').value`);
        const beforeEditorOpen = driver.allHandles();
        await evaluate(window, `document.querySelector('#editOpenProviderEditor').click()`);

        const editorWindow = await driver.waitForNewHandle(beforeEditorOpen, { titleIncludes: 'Provider source' });
        await waitFor(editorWindow, `document.querySelector('.cm-editor') !== null`, 'CodeMirror did not mount in the provider editor window.');
        assert.equal(await evaluate(editorWindow, `document.querySelector('#editorKindLabel').textContent`), 'C++');

        // body { user-select: none } now covers this window's chrome (see styles.css) -- confirm
        // that didn't drag CodeMirror's own editable content down with it. A real double-click
        // (word selection), not a scripted Selection API call, since user-select specifically
        // governs drag/click-driven selection, not programmatic Range/Selection calls.
        const codeWordPoint = await evaluate(editorWindow, `(() => {
            const line = document.querySelector('.cm-line');
            const r = line.getBoundingClientRect();
            return { x: Math.round(r.left + 10), y: Math.round(r.top + r.height / 2) };
        })()`);
        await editorWindow.mouseMove(codeWordPoint);
        await editorWindow.mouseDown(codeWordPoint, { button: 'left', clickCount: 1 });
        await editorWindow.mouseUp(codeWordPoint, { button: 'left', clickCount: 1 });
        await editorWindow.mouseDown(codeWordPoint, { button: 'left', clickCount: 2 });
        await editorWindow.mouseUp(codeWordPoint, { button: 'left', clickCount: 2 });
        await new Promise((resolve) => setTimeout(resolve, 200));
        assert.ok(await evaluate(editorWindow, `window.getSelection().toString().length`) > 0,
            'Double-clicking CodeMirror content did not select a word -- user-select: none on the window body may have leaked into the editor.');

        // These checks wait on a real clang invocation (plus the linter's own debounce),
        // which is far more variable than a DOM/JS operation, so give it real headroom
        // rather than the default timeout tuned for in-process checks.
        const compileCheckTimeout = 20000;
        await waitFor(editorWindow, `document.querySelector('#editorStatus').classList.contains('valid')`,
            'The starter template was not reported valid by the C++ syntax check.', compileCheckTimeout);

        await evaluate(editorWindow, `(() => {
            const view = window.__providerEditorView;
            view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: 'this is not valid c plus plus' } });
        })()`);
        await waitFor(editorWindow, `document.querySelector('#editorStatus').classList.contains('invalid')`,
            'Invalid C++ source was not flagged by the syntax check.', compileCheckTimeout);

        await evaluate(editorWindow, `(() => {
            const view = window.__providerEditorView;
            view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: ${JSON.stringify(validCpp)} } });
        })()`);
        await waitFor(editorWindow, `document.querySelector('#editorStatus').classList.contains('valid')`,
            'Restoring valid C++ source did not clear the invalid status.', compileCheckTimeout);

        await evaluate(editorWindow, `document.querySelector('#applyButton').click()`);
        await waitFor(window, `document.querySelector('#editEdgeProviderSource').value === ${JSON.stringify(validCpp)}`,
            'Applying from the provider editor window did not update the relationship editor.');

        await evaluate(editorWindow, `document.querySelector('#close').click()`);
        await new Promise((resolve) => setTimeout(resolve, 200));
        assert.ok(!driver.allHandles().includes(editorWindow), 'The provider editor window did not close.');
    }, { skip: !driver.capabilities.addons && 'the provider source editor window has no web-edition equivalent' });

    await run('relationship editor returns to equation mode after a provider-editor session', async () => {
        // Switch back to Equation so the following equation-editor tests see their expected state,
        // whether or not the provider-editor scenario above actually ran (see its own skip reason).
        await evaluate(window, `(() => {
            const select = document.querySelector('#editEdgeImplementationKind');
            select.value = 'equation';
            select.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await isRenderedVisible(window, '#editEdgeEquationHeading'), true);
        assert.equal(await isRenderedVisible(window, '#editEdgeMathField'), true);
        assert.equal(await isRenderedVisible(window, '#editEdgeProviderSection'), false);
    });

    await run('C++ validation rejects unknown equation symbols while typing', async () => {
        const originalEquation = await evaluate(window, `document.querySelector('#editEdgeMathField').value`);
        await evaluate(window, `(() => {
            const field = document.querySelector('#editEdgeMathField');
            field.setValue('randomCharacters');
            field.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine' && document.querySelector('#validationSummary').classList.contains('error')`, 'Unknown equation symbols were not rejected by the C++ validator.');
        assert.match(await evaluate(window, `document.querySelector('#validationIssues').textContent`), /randomCharacters/);
        await evaluate(window, `(() => {
            const field = document.querySelector('#editEdgeMathField');
            field.setValue(${JSON.stringify(originalEquation)});
            field.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine' && !document.querySelector('#validationSummary').classList.contains('error')`, 'Restoring the valid equation did not clear its validation error.');
    });

    await run('C++ validation accepts \\operatorname{} LaTeX for named functions like Max', async () => {
        // Regression test: an AI-generated equation once used \operatorname{Max}(...) --
        // standard LaTeX for an unfamiliar function name, and a reasonable thing for a model to
        // write even after being steered toward the shorter \max(...) form -- which the engine's
        // validator rejected as both an unsupported command and (since only the backslash+word
        // token was stripped, leaving "{Max}" behind) an unknown symbol.
        const originalEquation = await evaluate(window, `document.querySelector('#editEdgeMathField').value`);
        await evaluate(window, `(() => {
            const field = document.querySelector('#editEdgeMathField');
            field.setValue(${JSON.stringify('\\operatorname{Max}(1, 2)')});
            field.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine'`, 'Engine validation did not run.');
        assert.equal(await evaluate(window, `document.querySelector('#validationSummary').classList.contains('error')`), false, '\\operatorname{Max}(...) should be accepted the same as \\max(...).');

        // A name \operatorname{} doesn't recognize must still be rejected clearly, so this isn't
        // just papering over the shape of the LaTeX regardless of what it actually names.
        await evaluate(window, `(() => {
            const field = document.querySelector('#editEdgeMathField');
            field.setValue(${JSON.stringify('\\operatorname{Bogus}(1, 2)')});
            field.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine' && document.querySelector('#validationSummary').classList.contains('error')`, 'An unrecognized \\operatorname{} name was not rejected.');
        assert.match(await evaluate(window, `document.querySelector('#validationIssues').textContent`), /Bogus/);

        await evaluate(window, `(() => {
            const field = document.querySelector('#editEdgeMathField');
            field.setValue(${JSON.stringify(originalEquation)});
            field.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine' && !document.querySelector('#validationSummary').classList.contains('error')`, 'Restoring the valid equation did not clear its validation error.');
    });

    await run('Backspace edits MathLive without deleting the relationship', async () => {
        const equationBefore = await evaluate(window, `document.querySelector('#editEdgeMathField').value`);
        // A real pointer click (rather than a bare .focus() call) reliably restores keyboard
        // routing into MathLive's custom element, matching how an actual user would interact
        // with it after switching this relationship away from and back to Equation mode.
        await clickElement(window, `document.querySelector('#editEdgeMathField')`);
        await evaluate(window, `(() => {
            const field = document.querySelector('#editEdgeMathField');
            field.focus();
            field.executeCommand('selectAll');
        })()`);
        await window.keyDown('Backspace');
        await window.keyUp('Backspace');
        await waitFor(window, `document.querySelector('#editEdgeMathField').value !== ${JSON.stringify(equationBefore)}`, 'Backspace did not edit the equation.');
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
        await evaluate(window, `(() => {
            const field = document.querySelector('#editEdgeMathField');
            field.setValue(${JSON.stringify(equationBefore)});
            field.dispatchEvent(new Event('input', { bubbles: true }));
            document.querySelector('#edgeEditor [data-close-card]').click();
        })()`);
    });

    await run('node editor authors a source term with a programmable C++ implementation', async () => {
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Enclosed air')).click()`);
        await evaluate(window, `document.querySelector('#editAddSourceTerm').click()`);
        await evaluate(window, `[...document.querySelectorAll('.sourceTermOpen')].pop().click()`);
        assert.equal(await isRenderedVisible(window, '#sourceTermEditor'), true);

        await evaluate(window, `(() => {
            const select = document.querySelector('#termImplementationKind');
            select.value = 'cpp';
            select.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await isRenderedVisible(window, '#termProviderSection'), true);
        assert.equal(await isRenderedVisible(window, '#termEquationHeading'), false);
        assert.match(await evaluate(window, `document.querySelector('#termProviderSource').value`), /#include <konjugate\/relationshipProvider\.hpp>/);

        await evaluate(window, `(() => {
            document.querySelector('#termAddProviderBinding').click();
            const key = document.querySelector('#termProviderBindings .providerBindingRow [data-field="key"]');
            key.value = 'temperature';
            key.dispatchEvent(new Event('change', { bubbles: true }));
            const outputKey = document.querySelector('#termProviderOutputKey');
            outputKey.value = 'heatRate';
            outputKey.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);

        await evaluate(window, `(() => {
            window.confirm = () => true;
            document.querySelector('#termInsertProviderTemplate').click();
        })()`);
        const regenerated = await evaluate(window, `document.querySelector('#termProviderSource').value`);
        assert.match(regenerated, /ScalarPort\{"temperature", "temperature", ""\}/);
        assert.match(regenerated, /ScalarPort\{"heatRate", "heatRate", ""\}/);

        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine'`,
            'The programmable source term did not reach native validation.');
        assert.doesNotMatch(await evaluate(window, `document.querySelector('#validationIssues')?.textContent ?? ''`), /provider|programmable/i);

        // Clean up: remove the source term so later tests see the original model state.
        await evaluate(window, `document.querySelector('[data-delete-source-term]').click()`);
        assert.equal(await isRenderedVisible(window, '#sourceTermEditor'), false);
        assert.equal(await isRenderedVisible(window, '#nodeEditor'), true);
        await evaluate(window, `document.querySelector('#nodeEditor [data-close-card]').click()`);
    });

    await run('node appearance changes and participates in undo', async () => {
        const reopenAppearanceTab = `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click(); document.querySelector('[data-node-tab="appearance"]').click()`;
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `document.querySelector('#nodeModelActions').hidden`), false);
        await evaluate(window, `document.querySelector('[data-node-tab="appearance"]').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#nodeModelActions').hidden`), true);
        const originalColor = await evaluate(window, `document.querySelector('#editNodeColor').value`);

        const consoleMessages = await captureConsoleMessages(window, async () => {
            await evaluate(window, `(() => { const field = document.querySelector('#editNodeShape'); field.value = 'sphere'; field.dispatchEvent(new Event('change', { bubbles: true })); })()`);
            assert.equal(await evaluate(window, `document.querySelector('#editNodeShape').value`), 'sphere');
            await evaluate(window, reopenAppearanceTab);
            assert.equal(await evaluate(window, `document.querySelector('#editNodeColor').value`), originalColor);
            await evaluate(window, `document.querySelector('#editBrowseShapeLibrary').click()`);
            await waitFor(window, `document.querySelector('#shapeLibraryDialog').open`, 'Shape library did not open.');
            await evaluate(window, `document.querySelector('.shapeLibraryItem[data-shape-id="mechanical/spurGear"]').click()`);
            await waitFor(window, `!document.querySelector('#shapeLibraryDetailContent').hidden && document.querySelector('#shapeLibraryDetailTitle').textContent === 'Spur Gear'`, 'The shape preview did not populate.');
            await evaluate(window, `document.querySelector('#shapeLibraryApply').click()`);
            await waitFor(window, `!document.querySelector('#shapeLibraryDialog').open`, 'Shape library did not close after applying a shape.');
            await evaluate(window, reopenAppearanceTab);
            assert.equal(await evaluate(window, `document.querySelector('#editNodeShape').value`), '');
            assert.equal(await evaluate(window, `document.querySelector('#editNodeColor').value`), originalColor);
        });
        // Regression: switching the primitive shape (or applying a file/library shape) used to
        // build its appearance patch without a colour field, which wiped definition.color to
        // undefined outright (no fallback to the existing value). That failure doesn't reject
        // any of the assertions above -- it throws later, inside the click handler that reopens
        // the editor and reads definition.color.toString(16), and a synthetic element.click()
        // swallows an exception thrown inside its own listener rather than propagating it, so
        // only the console (captured here) actually catches it.
        assert.deepEqual(consoleMessages.filter((message) => /color|toString/i.test(message)), []);

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, reopenAppearanceTab);
        assert.equal(await evaluate(window, `document.querySelector('#editNodeShape').value`), 'box');
        assert.equal(await evaluate(window, `document.querySelector('#editNodeColor').value`), originalColor);
    });

    await run('shape library searches, filters by domain and previews and applies a shape', async () => {
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click(); document.querySelector('[data-node-tab="appearance"]').click()`);
        const statusBeforeSelect = await evaluate(window, `document.querySelector('#editGeometryStatus').textContent`);
        await evaluate(window, `document.querySelector('#editBrowseShapeLibrary').click()`);
        await waitFor(window, `document.querySelector('#shapeLibraryDialog').open`, 'Shape library did not open.');
        const shapeCount = await evaluate(window, `document.querySelectorAll('.shapeLibraryItem').length`);
        assert.ok(shapeCount > 0, 'Shape library did not list any shapes.');
        // Domain chip order follows first-appearance order in assets/shapes/manifest.json, not
        // alphabetical order -- "Robotics" was added between the structural and electrical
        // shapes when the robotics shape set was bundled, which is why it lands here rather than
        // at the end.
        assert.deepEqual(await evaluate(window, `[...document.querySelectorAll('#shapeLibraryDomains button')].map((button) => button.textContent)`),
            ['All', 'Mechanical', 'Structural', 'Robotics', 'Electrical', 'Fluid']);
        assert.equal(await evaluate(window, `document.querySelector('#shapeLibraryDetailEmpty').hidden`), false, 'The detail pane should start with nothing selected.');
        assert.equal(await evaluate(window, `document.querySelector('#shapeLibraryDetailContent').hidden`), true);

        // Cards get a static thumbnail passively -- without clicking anything -- generated by a
        // single reused offscreen renderer and cached, distinct from the live rotating preview.
        await waitFor(window,
            `document.querySelector('.shapeLibraryItem[data-shape-id="mechanical/spurGear"] img.examplesExplorerThumb')?.getAttribute('src')`,
            'The Spur Gear card did not get a thumbnail.');
        assert.ok((await evaluate(window,
            `document.querySelector('.shapeLibraryItem[data-shape-id="mechanical/spurGear"] img.examplesExplorerThumb').src`)).startsWith('data:image/png'),
            'The thumbnail src was not a PNG data URL.');

        const searchMessages = await captureConsoleMessages(window, async () => {
            await evaluate(window, `(() => { const input = document.querySelector('#shapeLibrarySearch'); input.value = 'gear'; input.dispatchEvent(new Event('input', { bubbles: true })); })()`);
            assert.deepEqual(await evaluate(window, `[...document.querySelectorAll('.shapeLibraryItem b')].map((element) => element.textContent)`), ['Spur Gear']);
            assert.equal(await evaluate(window, `document.querySelector('#shapeLibraryEmpty').hidden`), true);

            await evaluate(window, `(() => { const input = document.querySelector('#shapeLibrarySearch'); input.value = 'no such shape'; input.dispatchEvent(new Event('input', { bubbles: true })); })()`);
            assert.equal(await evaluate(window, `document.querySelectorAll('.shapeLibraryItem').length`), 0);
            assert.equal(await evaluate(window, `document.querySelector('#shapeLibraryEmpty').hidden`), false);

            await evaluate(window, `(() => { const input = document.querySelector('#shapeLibrarySearch'); input.value = ''; input.dispatchEvent(new Event('input', { bubbles: true })); })()`);
            await evaluate(window, `[...document.querySelectorAll('#shapeLibraryDomains button')].find((button) => button.textContent === 'Fluid').click()`);
        });
        // Regression: a thumbnail queued for a shape that then got filtered/searched away must
        // not throw trying to write into its now-detached card -- only the console (captured
        // here) would catch that, since it happens asynchronously well after these calls return.
        assert.deepEqual(searchMessages.filter((message) => /error|uncaught|exception/i.test(message)), []);
        // A shape's id path prefix reflects where its file lives, not every domain it's tagged
        // under -- a multi-domain shape like robotics/propellerRotor (tagged both "robotics" and
        // "fluid", since a propeller genuinely is an aerodynamic part) correctly appears here
        // despite its "robotics/" id. Check the rendered domain text instead of the id prefix.
        const fluidShapes = await evaluate(window,
            `[...document.querySelectorAll('.shapeLibraryItem')].map((item) => item.querySelector('small').textContent)`);
        assert.ok(fluidShapes.length > 0 && fluidShapes.every((domainText) => domainText.includes('Fluid')));

        // Switching back to "All" must show the Spur Gear thumbnail immediately from cache,
        // rather than a blank tile that gets refilled -- proving it wasn't regenerated.
        await evaluate(window, `[...document.querySelectorAll('#shapeLibraryDomains button')].find((button) => button.textContent === 'All').click()`);
        assert.ok((await evaluate(window,
            `document.querySelector('.shapeLibraryItem[data-shape-id="mechanical/spurGear"] img.examplesExplorerThumb')?.src`) ?? '').startsWith('data:image/png'),
            'The cached thumbnail was not shown immediately after re-filtering.');

        // Selecting a shape (a STEP file, exercising the occt-import-js path) previews it as a
        // live rotating 3D render rather than applying it immediately -- nothing on the node
        // should change until Apply is clicked explicitly.
        await evaluate(window, `document.querySelector('.shapeLibraryItem[data-shape-id="mechanical/lBracket"]').click()`);
        assert.equal(await evaluate(window, `document.querySelector('.shapeLibraryItem[data-shape-id="mechanical/lBracket"]').classList.contains('selected')`), true);
        await waitFor(window, `!document.querySelector('#shapeLibraryDetailContent').hidden && document.querySelector('#shapeLibraryDetailTitle').textContent === 'L-Bracket'`, 'The shape preview did not populate.');
        assert.equal(await evaluate(window, `document.querySelector('#editGeometryStatus').textContent`), statusBeforeSelect, 'Selecting a shape must not apply it yet.');

        // Switching the selection before the previous preview finishes loading (both requests
        // are in flight together here) must not leave a stale mesh/title from the shape that's
        // no longer selected -- this is the revision-guard in selectShapeLibraryPreview.
        await evaluate(window, `document.querySelector('.shapeLibraryItem[data-shape-id="fluid/valveBody"]').click()`);
        await waitFor(window, `document.querySelector('#shapeLibraryDetailTitle').textContent === 'Valve Body'`, 'Switching the selected shape did not update the preview.');

        // Apply a STEP-format shape (mechanical/lBracket) via the editor path.
        await evaluate(window, `document.querySelector('.shapeLibraryItem[data-shape-id="mechanical/lBracket"]').click()`);
        await waitFor(window, `document.querySelector('#shapeLibraryDetailTitle').textContent === 'L-Bracket'`, 'The shape preview did not populate.');
        await evaluate(window, `document.querySelector('#shapeLibraryApply').click()`);
        await waitFor(window, `!document.querySelector('#shapeLibraryDialog').open`, 'Shape library did not close after applying a shape.');
        assert.equal(await evaluate(window, `document.querySelector('#editGeometryStatus').textContent`), 'L-Bracket applied');
        assert.equal(await evaluate(window, `document.querySelector('#editNodeShape').value`), '');

        // Apply an STL-format shape via the "Add node" builder path.
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
        await evaluate(window, `document.querySelector('#builderBrowseShapeLibrary').click()`);
        await waitFor(window, `document.querySelector('#shapeLibraryDialog').open`, 'Shape library did not open from the node builder.');
        await evaluate(window, `document.querySelector('.shapeLibraryItem[data-shape-id="fluid/valveBody"]').click()`);
        await waitFor(window, `document.querySelector('#shapeLibraryDetailTitle').textContent === 'Valve Body'`, 'The shape preview did not populate.');
        await evaluate(window, `document.querySelector('#shapeLibraryApply').click()`);
        await waitFor(window, `!document.querySelector('#shapeLibraryDialog').open`, 'Shape library did not close after applying a shape.');
        assert.equal(await evaluate(window, `document.querySelector('#geometryImportStatus').textContent`), 'Valve Body ready');
        assert.equal(await evaluate(window, `document.querySelector('#newNodeShape').value`), 'imported');
        await evaluate(window, `document.querySelector('#nodeBuilder [data-close-card]').click()`);

        await evaluate(window, `document.querySelector('#undoButton').click()`);
    });

    await run('disabling a node greys it out, cascades to its edges, and is undoable', async () => {
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `document.querySelector('#toggleNodeEnabled').textContent`), 'Disable node');
        assert.equal(await evaluate(window, `document.querySelector('.node-label-container.disabled') === null`), true);

        await evaluate(window, `document.querySelector('#toggleNodeEnabled').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#toggleNodeEnabled').textContent`), 'Enable node');
        assert.equal(await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).closest('.node-label-container').classList.contains('disabled')`), true);

        // The edge cascades (renders as disabled) even though its own `enabled` field never
        // changed -- only the node's did. Its own toggle button must still read "Disable edge".
        await evaluate(window, `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `document.querySelector('#toggleEdgeEnabled').textContent`), 'Disable edge');
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);

        // Undo restores the node (and, since nothing about the edge's own state changed, its
        // cascaded edges too) in one step.
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `document.querySelector('#toggleNodeEnabled').textContent`), 'Disable node');
        assert.equal(await evaluate(window, `document.querySelector('.node-label-container.disabled') === null`), true);
        await evaluate(window, `document.querySelector('#nodeEditor [data-close-card]').click()`);
    });

    await run('disabling an edge directly is independent of its endpoint nodes and is undoable', async () => {
        await evaluate(window, `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `document.querySelector('#toggleEdgeEnabled').textContent`), 'Disable edge');

        await evaluate(window, `document.querySelector('#toggleEdgeEnabled').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#toggleEdgeEnabled').textContent`), 'Enable edge');
        // Its endpoint nodes are untouched -- only the edge itself is disabled.
        assert.equal(await evaluate(window, `document.querySelector('.node-label-container.disabled') === null`), true);
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `document.querySelector('#toggleEdgeEnabled').textContent`), 'Disable edge');
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
    });

    await run('Connect to chooses a canvas endpoint and creates through the shared relationship inspector', async () => {
        const relationshipCountBefore = await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`);
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Electrical losses')).click()`);
        await evaluate(window, `document.querySelector('#connectFromNode').click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#endpointPickBanner').hidden`), true);
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        assert.equal(await evaluate(window, `document.querySelector('#endpointPickBanner').hidden`), true);
        assert.equal(await evaluate(window, `!document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        assert.notEqual(await evaluate(window, `document.querySelector('#edgeTarget').value`), '');
        await evaluate(window, `document.querySelector('#newEdgeName').value = 'Connect to regression'; document.querySelector('#createEdge').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `!document.querySelector('#edgeEditor').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeName').value`), 'Connect to regression');
        assert.notEqual(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), relationshipCountBefore);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
    });

    // Excludes "... copy" matches: a soft-deleted "... copy" node from an earlier paste test can
    // still be present (hidden) in the DOM, and a plain .includes() would match it too, since
    // e.g. "Enclosed air copy" contains "Enclosed air" as a substring.
    const electricalLossesLabel = `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Electrical losses') && !label.textContent.includes('copy'))`;
    const batteryModuleLabel = `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module') && !label.textContent.includes('copy'))`;
    const enclosedAirLabel = `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Enclosed air') && !label.textContent.includes('copy'))`;
    const batteryBundleLabel = `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module') && !label.textContent.includes('copy'))`;

    await run('right-clicking a node opens a context menu with connect, disable and delete', async () => {
        await rightClickElement(window, electricalLossesLabel);
        await waitFor(window, `!document.querySelector('#nodeContextMenu').classList.contains('hidden')`, 'Right-clicking a node did not open its context menu.');
        assert.equal(await evaluate(window, `${electricalLossesLabel}.closest('.node-label-container').classList.contains('selected')`), true);
        assert.equal(await isRenderedVisible(window, '#nodeContextConnect'), true);
        assert.equal(await isRenderedVisible(window, '#nodeContextToggle'), true);
        assert.equal(await isRenderedVisible(window, '#nodeContextDisableAll'), false);
        assert.equal(await evaluate(window, `document.querySelector('#nodeContextToggleLabel').textContent`), 'Disable node');

        // "Connect from here" reuses the editor's own endpoint-pick flow.
        await evaluate(window, `document.querySelector('#nodeContextConnect').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#nodeContextMenu').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `!document.querySelector('#endpointPickBanner').hidden`), true);
        assert.equal(await evaluate(window, `document.querySelector('#edgeSource').value`), await evaluate(window, `${electricalLossesLabel}.closest('.node-label-container').dataset.node`));
        await evaluate(window, `${batteryModuleLabel}.click()`);
        assert.equal(await evaluate(window, `!document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        await evaluate(window, `document.querySelector('#edgeBuilder [data-close-card]').click()`);

        // Disable via the context menu toggle, then delete via the context menu, both undoable.
        await rightClickElement(window, electricalLossesLabel);
        await waitFor(window, `!document.querySelector('#nodeContextMenu').classList.contains('hidden')`, 'The node context menu did not reopen.');
        await evaluate(window, `document.querySelector('#nodeContextToggle').click()`);
        assert.equal(await evaluate(window, `${electricalLossesLabel}.closest('.node-label-container').classList.contains('disabled')`), true);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `${electricalLossesLabel}.closest('.node-label-container').classList.contains('disabled')`), false);

        const before = await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`);
        await rightClickElement(window, electricalLossesLabel);
        await waitFor(window, `!document.querySelector('#nodeContextMenu').classList.contains('hidden')`, 'The node context menu did not reopen for delete.');
        await evaluate(window, `document.querySelector('#nodeContextDelete').click()`);
        await waitFor(window, `document.querySelectorAll('.modelStatus span')[0].textContent !== '${before}'`, 'The context menu delete action did not remove the node.');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await waitFor(window, `document.querySelectorAll('.modelStatus span')[0].textContent === '${before}'`, 'Undo did not restore the deleted node.');
    });

    await run('right-clicking a multi-selected node offers bulk disable/enable all', async () => {
        // Shift-clicks both nodes rather than a plain click + shift-click: a plain click also
        // opens the node editor, and this deep into the suite the editor panel can overlap
        // where the second label renders, making a real mouse click land on the panel instead.
        await clickElement(window, batteryModuleLabel, ['shift']);
        await new Promise((resolve) => setTimeout(resolve, 250));
        await clickElement(window, enclosedAirLabel, ['shift']);
        await waitFor(window, `document.querySelectorAll('.node-label-container.selected').length === 2`, 'Shift-click did not build a two-node selection.');

        await rightClickElement(window, enclosedAirLabel);
        await waitFor(window, `!document.querySelector('#nodeContextMenu').classList.contains('hidden')`, 'Right-clicking a selected node did not open the context menu.');
        // Right-clicking a member of an existing multi-selection must not collapse it to one node.
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.selected').length`), 2);
        assert.equal(await isRenderedVisible(window, '#nodeContextConnect'), false);
        assert.equal(await isRenderedVisible(window, '#nodeContextToggle'), false);
        assert.equal(await isRenderedVisible(window, '#nodeContextDisableAll'), true);
        assert.equal(await isRenderedVisible(window, '#nodeContextEnableAll'), true);
        assert.equal(await evaluate(window, `document.querySelector('#nodeContextDeleteLabel').textContent`), 'Delete 2 nodes');

        await evaluate(window, `document.querySelector('#nodeContextDisableAll').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.disabled').length`), 2);

        // Chains straight into "enable all" while the selection is still intact -- undo/redo
        // deliberately clear the selection (see undo()/redo() in renderer.mjs), so exercising
        // that separately below rebuilds the selection first rather than assuming it survives.
        await rightClickElement(window, enclosedAirLabel);
        await waitFor(window, `!document.querySelector('#nodeContextMenu').classList.contains('hidden')`, 'The node context menu did not reopen for enable-all.');
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.selected').length`), 2);
        await evaluate(window, `document.querySelector('#nodeContextEnableAll').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.disabled').length`), 0);

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.disabled').length`), 2);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.disabled').length`), 0);
        await evaluate(window, `document.querySelector('#redoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.disabled').length`), 2);
        await evaluate(window, `document.querySelector('#redoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.disabled').length`), 0);
    });

    await run('right-clicking an edge label opens a context menu with disable and delete', async () => {
        await waitFor(window, `Boolean(${batteryBundleLabel})`, 'Battery module bundle label was not available.');
        await rightClickElement(window, batteryBundleLabel);
        await waitFor(window, `!document.querySelector('#edgeContextMenu').classList.contains('hidden')`, 'Right-clicking an edge did not open its context menu.');
        assert.equal(await evaluate(window, `document.querySelector('#edgeContextToggleLabel').textContent`), 'Disable edge');

        await evaluate(window, `document.querySelector('#edgeContextToggle').click()`);
        assert.equal(await evaluate(window, `document.querySelector('.node-label-container.disabled') === null`), true);
        assert.match(await evaluate(window, `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module')).textContent`), /Disabled/);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.doesNotMatch(await evaluate(window, `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module')).textContent`), /Disabled/);
    });

    await run('select all via Ctrl/Cmd+A and via the canvas context menu', async () => {
        const totalNodes = await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await waitFor(window, `document.querySelectorAll('.node-label-container.selected').length === ${totalNodes.match(/\d+/)[0]}`, 'Ctrl/Cmd+A did not select every node.');
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.selected').length`), Number(totalNodes.match(/\d+/)[0]));

        const emptyPoint = await evaluate(window, `(() => { const bounds = document.querySelector('#webglContainer').getBoundingClientRect(); return { x: Math.round(bounds.left + 20), y: Math.round(bounds.top + 20) }; })()`);
        await window.mouseMove(emptyPoint);
        await window.mouseDown(emptyPoint, { button: 'left', clickCount: 1 });
        await window.mouseUp(emptyPoint, { button: 'left', clickCount: 1 });
        await waitFor(window, `document.querySelectorAll('.node-label-container.selected').length === 0`, 'Clicking blank canvas did not clear the select-all selection.');

        await window.mouseMove(emptyPoint);
        await window.mouseDown(emptyPoint, { button: 'right', clickCount: 1 });
        await window.mouseUp(emptyPoint, { button: 'right', clickCount: 1 });
        await waitFor(window, `!document.querySelector('#addPalette').classList.contains('hidden')`, 'Right-clicking blank canvas did not open the add palette.');
        await evaluate(window, `document.querySelector('[data-action="select-all"]').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#addPalette').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.selected').length`), Number(totalNodes.match(/\d+/)[0]));
        await window.mouseMove(emptyPoint);
        await window.mouseDown(emptyPoint, { button: 'left', clickCount: 1 });
        await window.mouseUp(emptyPoint, { button: 'left', clickCount: 1 });
    });

    await run('right-click-drag pans without opening a context menu, but a stationary right-click still does', async () => {
        const start = await evaluate(window, `(() => { const bounds = document.querySelector('#webglContainer').getBoundingClientRect(); return { x: Math.round(bounds.left + bounds.width * 0.7), y: Math.round(bounds.top + 40) }; })()`);
        const end = { x: start.x + 60, y: start.y + 40 };

        await window.mouseMove(start);
        await window.mouseDown(start, { button: 'right', clickCount: 1 });
        await window.mouseMove(end);
        await window.mouseUp(end, { button: 'right', clickCount: 1 });
        await new Promise((resolve) => setTimeout(resolve, 200));
        assert.equal(await evaluate(window, `document.querySelector('#addPalette').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#nodeContextMenu').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#edgeContextMenu').classList.contains('hidden')`), true);

        await window.mouseMove(start);
        await window.mouseDown(start, { button: 'right', clickCount: 1 });
        await window.mouseUp(start, { button: 'right', clickCount: 1 });
        await waitFor(window, `!document.querySelector('#addPalette').classList.contains('hidden')`, 'A stationary right-click did not open the add palette.');
        await window.mouseMove(start);
        await window.mouseDown(start, { button: 'left', clickCount: 1 });
        await window.mouseUp(start, { button: 'left', clickCount: 1 });
    });

    await run('node creation closes its dialog and supports undo and redo', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
        await evaluate(window, `(() => {
            document.querySelector('#newNodeName').value = 'Interaction node';
            const values = { name: 'Pressure', symbol: 'pressure', value: '101325', unit: 'Pa' };
            Object.entries(values).forEach(([field, value]) => { const input = document.querySelector('.stateVariableRow [data-field="' + field + '"]'); input.value = value; input.dispatchEvent(new Event('input', { bubbles: true })); });
            document.querySelector('#createNode').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#nodeBuilder').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `!document.querySelector('#nodeEditor').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#editNodeName').value`), 'Interaction node');
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '4 nodes');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '3 nodes');
        await evaluate(window, `document.querySelector('#redoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '4 nodes');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
    });

    await run('an invalid state symbol shows a visible error instead of silently failing to create the node', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
        await evaluate(window, `(() => {
            document.querySelector('#newNodeName').value = 'Interaction temperature node';
            const values = { name: 'Temperature', symbol: 'T', value: '263', unit: 'K' };
            Object.entries(values).forEach(([field, value]) => { const input = document.querySelector('.stateVariableRow [data-field="' + field + '"]'); input.value = value; input.dispatchEvent(new Event('input', { bubbles: true })); });
            document.querySelector('#createNode').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#nodeBuilder').classList.contains('hidden')`), false);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '3 nodes');
        assert.match(await evaluate(window, `document.querySelector('#addNodeError').textContent`), /lowercase/);
        await evaluate(window, `(() => {
            const input = document.querySelector('.stateVariableRow [data-field="symbol"]');
            input.value = 'temperature';
            input.dispatchEvent(new Event('input', { bubbles: true }));
            document.querySelector('#createNode').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#nodeBuilder').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '4 nodes');
        assert.equal(await evaluate(window, `document.querySelector('#addNodeError').textContent`), '');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
    });

    await run('node builder creates a node with an inline Python source term', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
        await evaluate(window, `(() => {
            document.querySelector('#newNodeName').value = 'Interaction source node';
            const values = { name: 'Level', symbol: 'level', value: '10', unit: 'm' };
            Object.entries(values).forEach(([field, value]) => { const input = document.querySelector('.stateVariableRow [data-field="' + field + '"]'); input.value = value; input.dispatchEvent(new Event('input', { bubbles: true })); });
            document.querySelector('#addSourceTerm').click();
        })()`);
        await evaluate(window, `(() => {
            const kind = document.querySelector('.sourceTermRow .sourceTermKind');
            kind.value = 'python';
            kind.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('.sourceTermRow .sourceTermProviderFields').hidden`), false);
        assert.equal(await evaluate(window, `document.querySelector('.sourceTermRow .sourceExpression').hidden`), true);
        assert.match(await evaluate(window, `document.querySelector('.sourceTermRow .sourceTermProviderSource').value`), /from konjugate import/);

        await evaluate(window, `(() => {
            document.querySelector('.sourceTermRow .addSourceTermBinding').click();
            const key = document.querySelector('.sourceTermRow .providerBindingRow [data-field="key"]');
            key.value = 'level';
            document.querySelector('.sourceTermRow .sourceTermProviderOutputKey').value = 'levelRate';
            document.querySelector('#createNode').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '4 nodes');
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine'`,
            'The new node with a programmable source term did not reach native validation.');
        assert.doesNotMatch(await evaluate(window, `document.querySelector('#validationIssues')?.textContent ?? ''`), /provider|programmable/i);

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '3 nodes');
    });

    await run('edge creation explains why missing endpoints prevent creation', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
        await evaluate(window, `document.querySelector('#createEdge').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), false);
        assert.match(await evaluate(window, `document.querySelector('#addEdgeError').textContent`), /source and target/);
        assert.equal(await evaluate(window, `document.activeElement.id`), 'edgeSource');
        await evaluate(window, `document.querySelector('#edgeBuilder [data-close-card]').click()`);
    });

    await run('edge creation composes state references and supports undo', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
        await evaluate(window, `(() => {
            const choose = (selector, text) => { const field = document.querySelector(selector); field.value = [...field.options].find((option) => option.textContent === text).value; field.dispatchEvent(new Event('change', { bubbles: true })); };
            choose('#edgeSource', 'Electrical losses');
            choose('#edgeTarget', 'Enclosed air');
            document.querySelector('#newEdgeName').value = 'Interaction relationship';
            const field = document.querySelector('#edgeMathField');
            field.setValue('\\\\mathrm{sourceQDot}');
            field.dispatchEvent(new Event('input', { bubbles: true }));
            document.querySelector('#createEdge').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '4 relationships');
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `!document.querySelector('#edgeEditor').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeName').value`), 'Interaction relationship');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
    });

    await run('edge creation accepts a constant zero equation', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
        await evaluate(window, `(() => {
            const choose = (selector, text) => { const field = document.querySelector(selector); field.value = [...field.options].find((option) => option.textContent === text).value; field.dispatchEvent(new Event('change', { bubbles: true })); };
            choose('#edgeSource', 'Electrical losses');
            choose('#edgeTarget', 'Enclosed air');
            document.querySelector('#newEdgeName').value = 'Zero relationship';
            const field = document.querySelector('#edgeMathField');
            field.setValue('0');
            field.dispatchEvent(new Event('input', { bubbles: true }));
            document.querySelector('#createEdge').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeName').value`), 'Zero relationship');
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
    });

    await run('edge creation offers a directionality choice, defaulting to directed', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#newEdgeDirectionality').value`), 'directed');
        await evaluate(window, `(() => {
            const choose = (selector, text) => { const field = document.querySelector(selector); field.value = [...field.options].find((option) => option.textContent === text).value; field.dispatchEvent(new Event('change', { bubbles: true })); };
            choose('#edgeSource', 'Electrical losses');
            choose('#edgeTarget', 'Enclosed air');
            document.querySelector('#newEdgeName').value = 'Interaction bidirectional relationship';
            document.querySelector('#newEdgeDirectionality').value = 'bidirectional';
            const field = document.querySelector('#edgeMathField');
            field.setValue('\\\\mathrm{sourceQDot}');
            field.dispatchEvent(new Event('input', { bubbles: true }));
            document.querySelector('#createEdge').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '4 relationships');
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeName').value`), 'Interaction bidirectional relationship');
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeDirectionality').value`), 'bidirectional',
            'The directionality chosen at creation time should have been saved onto the new edge.');
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
    });

    await run('an invalid edge parameter symbol shows a visible error instead of silently failing to create the edge', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
        await evaluate(window, `(() => {
            const choose = (selector, text) => { const field = document.querySelector(selector); field.value = [...field.options].find((option) => option.textContent === text).value; field.dispatchEvent(new Event('change', { bubbles: true })); };
            choose('#edgeSource', 'Electrical losses');
            choose('#edgeTarget', 'Enclosed air');
            document.querySelector('#newEdgeName').value = 'Interaction invalid symbol relationship';
            const field = document.querySelector('#edgeMathField');
            field.setValue('\\\\mathrm{sourceQDot}');
            field.dispatchEvent(new Event('input', { bubbles: true }));
            const symbolInput = document.querySelector('.parameterRow [data-field="symbol"]');
            symbolInput.value = 'K';
            symbolInput.dispatchEvent(new Event('input', { bubbles: true }));
            document.querySelector('#createEdge').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), false);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
        assert.match(await evaluate(window, `document.querySelector('#addEdgeError').textContent`), /lowercase/);
        await evaluate(window, `(() => {
            const symbolInput = document.querySelector('.parameterRow [data-field="symbol"]');
            symbolInput.value = 'k';
            symbolInput.dispatchEvent(new Event('input', { bubbles: true }));
            document.querySelector('#createEdge').click();
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '4 relationships');
        assert.equal(await evaluate(window, `document.querySelector('#addEdgeError').textContent`), '');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
    });

    await run('edge builder creates a new relationship with an inline Python provider', async () => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
        await evaluate(window, `(() => {
            const choose = (selector, text) => { const field = document.querySelector(selector); field.value = [...field.options].find((option) => option.textContent === text).value; field.dispatchEvent(new Event('change', { bubbles: true })); };
            choose('#edgeSource', 'Electrical losses');
            choose('#edgeTarget', 'Enclosed air');
            document.querySelector('#newEdgeName').value = 'Interaction provider relationship';
            const kind = document.querySelector('#edgeImplementationKind');
            kind.value = 'python';
            kind.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await isRenderedVisible(window, '#edgeProviderSection'), true);
        assert.equal(await isRenderedVisible(window, '#edgeEquationHeading'), false);
        assert.match(await evaluate(window, `document.querySelector('#edgeProviderSource').value`), /from konjugate import/);
        await evaluate(window, `(() => {
            document.querySelector('#addProviderBinding').click();
            const key = document.querySelector('#providerBindingRows .providerBindingRow [data-field="key"]');
            key.value = 'sourceQDot';
            key.dispatchEvent(new Event('change', { bubbles: true }));
            document.querySelector('#providerOutputKey').value = 'targetHeatGradient';
            window.confirm = () => true;
            document.querySelector('#insertProviderTemplate').click();
        })()`);
        const builderSource = await evaluate(window, `document.querySelector('#edgeProviderSource').value`);
        assert.match(builderSource, /ScalarPort\("sourceQDot", "sourceQDot", ""\)/);
        assert.match(builderSource, /ScalarPort\("targetHeatGradient", "targetHeatGradient", ""\)/);
        await evaluate(window, `document.querySelector('#createEdge').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '4 relationships');
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine'`, 'The new provider relationship did not reach native validation.');
        // The edge builder leaves source/target stateId null for every new relationship
        // regardless of implementation kind, which the native validator separately flags
        // (a pre-existing gap unrelated to provider support); only assert that the new
        // implementation fields themselves did not produce a provider-specific diagnostic.
        assert.doesNotMatch(await evaluate(window, `document.querySelector('#validationIssues')?.textContent ?? ''`), /provider|programmable/i);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
    });

    await run('a point read once the canvas stops sliding is where a click lands', async () => {
        // Opening and closing an editor card slides the canvas; every scenario that clicks the canvas waits for the slide
        // to finish (waitForCanvasAtRest). Checked here so a change to the slide (its timing, or how it is done) cannot
        // quietly turn those clicks back into misses.
        const label = `[...document.querySelectorAll('.objectLabel')].find((element) => element.textContent.includes('Enclosed air'))`;
        await evaluate(window, `${label}.click()`);
        await waitFor(window, `!document.querySelector('#nodeEditor').classList.contains('hidden')`, 'Clicking the node did not open its editor.');
        await waitForCanvasAtRest(window);
        await evaluate(window, `document.querySelector('#nodeEditor [data-close-card]').click()`);
        assert.equal(await evaluate(window, `document.getAnimations().some((animation) => animation.effect?.target?.id === 'webglContainer' && animation.playState !== 'finished')`), true,
            'Closing the card did not start the canvas slide this scenario guards against.');
        await waitForCanvasAtRest(window);
        const settled = await canvasPoint(window, `window.__relationshipScreenPoint('Heat source')`);
        await new Promise((resolve) => setTimeout(resolve, 400));
        assert.deepEqual(await evaluate(window, `window.__relationshipScreenPoint('Heat source')`), settled, 'The relationship still moved after the canvas came to rest.');
    });

    await run('clicking a relationship after replacing a deleted one selects the new edge', async () => {
        // Regression test: deleting a relationship only soft-deletes it (definition.deleted =
        // true, line/marker hidden via .visible = false) -- its mesh is never removed from
        // relationshipPickTargets, which is only ever cleared on a full project reload. A new
        // relationship created between the same two nodes renders at the same curve (same node
        // pair, default zero offset), so without a .visible filter, firstIntersection() could
        // resolve the tie to the invisible, deleted original instead of the new one. Fixed by
        // having firstIntersection() skip non-visible hits (Three.js's Raycaster does not check
        // .visible itself -- confirmed in node_modules/three/src/core/Raycaster.js).
        const createEdge = async (name) => {
            await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
            await evaluate(window, `(() => {
                const choose = (selector, text) => { const field = document.querySelector(selector); field.value = [...field.options].find((option) => option.textContent === text).value; field.dispatchEvent(new Event('change', { bubbles: true })); };
                choose('#edgeSource', 'Electrical losses');
                choose('#edgeTarget', 'Enclosed air');
                document.querySelector('#newEdgeName').value = ${JSON.stringify(name)};
                const field = document.querySelector('#edgeMathField');
                field.setValue('\\\\mathrm{sourceQDot}');
                field.dispatchEvent(new Event('input', { bubbles: true }));
                document.querySelector('#createEdge').click();
            })()`);
            assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true);
        };

        await createEdge('First relationship');
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '4 relationships');
        await evaluate(window, `document.querySelector('[data-action="delete"]').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');

        await createEdge('Second relationship');
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '4 relationships');

        if (await evaluate(window, `!document.querySelector('#edgeEditor').classList.contains('hidden')`)) {
            await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
        }

        // Click a point on the new relationship that no other relationship (or its label) covers. It shares
        // its source node with "Heat source", so its midpoint can lie on or beside that one's line or label,
        // depending on the window's size and the screen's scale.
        await waitForCanvasAtRest(window);
        const point = await evaluate(window, `(() => {
            const others = ['Heat source', 'Air convection gain', 'Battery convection loss'];
            const otherPoints = others.flatMap((title) => Array.from({ length: 41 }, (_, index) => window.__relationshipScreenPoint(title, index / 40)).filter(Boolean));
            let best = null;
            for (let index = 6; index <= 34; index += 1) {
                const candidate = window.__relationshipScreenPoint('Second relationship', index / 40);
                if (!candidate) continue;
                const onCanvas = document.elementFromPoint(candidate.x, candidate.y)?.tagName === 'CANVAS';
                const clearance = Math.min(...otherPoints.map((other) => Math.hypot(other.x - candidate.x, other.y - candidate.y)));
                if (onCanvas && (!best || clearance > best.clearance)) best = { ...candidate, clearance };
            }
            return best;
        })()`);
        assert.ok(point, 'Could not find a point on the new relationship that nothing else covers.');
        await window.mouseMove(point);
        await window.mouseDown(point, { button: 'left', clickCount: 1 });
        await window.mouseUp(point, { button: 'left', clickCount: 1 });
        await waitFor(window, `!document.querySelector('#edgeEditor').classList.contains('hidden')`, 'Clicking the relationship did not open the edge editor.');
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeName').value`), 'Second relationship');

        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
    });

    // Waypoint-handle dragging goes through the same dragControls instance as node dragging,
    // which is only enabled while currentTool === 'select' -- ensure that's actually the
    // active tool rather than assume it, since an earlier test in the suite may have left a
    // different tool (rotate/scale/rectangleSelect) selected. Shared by both waypoint tests
    // below since either could run with a leftover tool from whichever ran just before it.
    const selectWaypointTestTool = () => evaluate(window, `document.querySelector('[data-tool="select"]').click()`);

    const createWaypointTestEdge = async (name) => {
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
        await evaluate(window, `(() => {
            const choose = (selector, text) => { const field = document.querySelector(selector); field.value = [...field.options].find((option) => option.textContent === text).value; field.dispatchEvent(new Event('change', { bubbles: true })); };
            choose('#edgeSource', 'Electrical losses');
            choose('#edgeTarget', 'Enclosed air');
            document.querySelector('#newEdgeName').value = ${JSON.stringify(name)};
            const field = document.querySelector('#edgeMathField');
            field.setValue('\\\\mathrm{sourceQDot}');
            field.dispatchEvent(new Event('input', { bubbles: true }));
            document.querySelector('#createEdge').click();
        })()`);
        await waitFor(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`, `Edge builder did not close after creating ${name}.`);
        if (await evaluate(window, `!document.querySelector('#edgeEditor').classList.contains('hidden')`)) {
            await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
        }
        assert.deepEqual(await evaluate(window, `window.__relationshipWaypoints(${JSON.stringify(name)})`), []);
    };

    const pressAndHold = async (point) => {
        await window.mouseMove(point);
        await window.mouseDown(point, { button: 'left', clickCount: 1 });
        await new Promise((resolve) => setTimeout(resolve, 600));
        await window.mouseUp(point, { button: 'left', clickCount: 1 });
    };

    const deleteWaypointTestEdge = async (name) => {
        const cleanedUp = await retryGesture(window, async () => {
            const cleanupPoint = await canvasPoint(window, `window.__relationshipScreenPoint(${JSON.stringify(name)})`);
            await window.mouseMove(cleanupPoint);
            await window.mouseDown(cleanupPoint, { button: 'left', clickCount: 1 });
            await new Promise((resolve) => setTimeout(resolve, 60));
            await window.mouseUp(cleanupPoint, { button: 'left', clickCount: 1 });
        }, `!document.querySelector('#edgeEditor').classList.contains('hidden')`);
        assert.ok(cleanedUp, 'Clicking the edge did not reopen the edge editor for cleanup after 5 attempts.');
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeName').value`), name);
        await evaluate(window, `document.querySelector('[data-action="delete"]').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
    };

    await run('pressing and holding an edge enters waypoint mode, and dragging a waypoint reroutes it with undo/redo', async () => {
        await selectWaypointTestTool();
        await createWaypointTestEdge('Waypoint drag test edge');

        // Pressing and holding (rather than a quick click) selects the edge -- which is what
        // already makes its waypoint handles visible -- without popping its editor card open
        // over the canvas. A quick click still opens the editor, unaffected (checked in the
        // sibling add/remove test below, which relies on quick clicks throughout).
        // t=0.75, not the curve's default 0.5 -- the relationship's own CSS2D bundle label
        // anchors at getPoint(0.5) (every edge gets one, even an unbundled "bundle of one"), so
        // a click there can land on the label's DOM element instead of the canvas beneath it.
        const held = await retryGesture(window, async () => {
            // A genuine real mouse movement during the artificial 600ms hold window (this test
            // runs in a real, visible window, not headless -- incidental cursor movement from
            // whoever's at the machine can inject a real pointermove that cancels the hold
            // timer, same as a real drag would) can leave a stray "quick click" open the editor
            // on a failed attempt. Close it defensively before each attempt so that residue
            // from a prior failed attempt can't cause the eventual successful one to be judged
            // against stale editor-visibility state.
            if (!await evaluate(window, `document.querySelector('#edgeEditor').classList.contains('hidden')`)) {
                await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
            }
            const holdPoint = await canvasPoint(window, `window.__relationshipScreenPoint('Waypoint drag test edge', 0.75)`);
            await pressAndHold(holdPoint);
        }, `document.querySelector('#statusText').textContent === 'Editing waypoints · Waypoint drag test edge' && document.querySelector('#edgeEditor').classList.contains('hidden')`);
        assert.ok(held, 'Press-and-hold did not report entering waypoint mode without opening the edge editor after 5 attempts.');

        const added = await retryGesture(window, async () => {
            const linePoint = await canvasPoint(window, `window.__relationshipScreenPoint('Waypoint drag test edge', 0.75)`);
            await window.mouseMove(linePoint);
            await window.mouseDown(linePoint, { button: 'right', clickCount: 1 });
            await new Promise((resolve) => setTimeout(resolve, 60));
            await window.mouseUp(linePoint, { button: 'right', clickCount: 1 });
        }, `!document.querySelector('#edgeContextMenu').classList.contains('hidden')`);
        assert.ok(added, 'Right-clicking the edge line did not open its context menu after 5 attempts.');
        assert.equal(await evaluate(window, `document.querySelector('#edgeContextAddWaypoint').hidden`), false, 'Add-waypoint action was not offered for a click on the edge line.');
        await evaluate(window, `document.querySelector('#edgeContextAddWaypoint').click()`);

        const initialWaypoints = await evaluate(window, `window.__relationshipWaypoints('Waypoint drag test edge')`);
        assert.equal(initialWaypoints.length, 1, 'Right-clicking the edge line did not add a waypoint.');
        const initialWaypointJson = JSON.stringify(initialWaypoints[0]);
        // Adding the waypoint also hides this edge's bundle label (it would otherwise sit right
        // on top of the new handle, re-anchored to the curve's new midpoint) -- give the
        // renderer a moment to actually apply that display:none before synthesizing a drag,
        // rather than risk racing a hit-test against a still-composited previous frame.
        await new Promise((resolve) => setTimeout(resolve, 300));

        // Drag the handle and confirm the underlying model's waypoint position actually moved
        // (not just the handle mesh) -- this is the same live-mutate-during-gesture idiom node
        // dragging already uses, so the model and the handle should never be out of sync mid-drag.
        // A short pause between each synthetic pointer event (rather than firing all four back
        // to back) matters: DragControls needs its own 'pointerdown' handler to actually run
        // (setting its internal _selected) before a 'pointermove' arrives, and a zero-delay
        // burst of sendInputEvent calls can reach Chromium's input queue faster than that JS
        // callback gets a turn to run. A short, fixed offset (not toward wherever's convenient)
        // keeps the dragged position clear of the endpoint nodes' own pick geometry -- landing
        // on or near a node would route later clicks to the node's context menu instead of the
        // waypoint's, since the contextmenu handler checks for a node hit first.
        const dragged = await retryGesture(window, async () => {
            const currentHandlePoint = await findCanvasPoint(window, await canvasPoint(window, `window.__waypointScreenPoint('Waypoint drag test edge', 0)`));
            if (!currentHandlePoint) return;
            const dragTo = { x: currentHandlePoint.x + 15, y: currentHandlePoint.y - 12 };
            const midDrag = { x: Math.round((currentHandlePoint.x + dragTo.x) / 2), y: Math.round((currentHandlePoint.y + dragTo.y) / 2) };
            await window.mouseMove(currentHandlePoint);
            await window.mouseDown(currentHandlePoint, { button: 'left', clickCount: 1 });
            await new Promise((resolve) => setTimeout(resolve, 60));
            await window.mouseMove(midDrag);
            await new Promise((resolve) => setTimeout(resolve, 60));
            await window.mouseMove(dragTo);
            await new Promise((resolve) => setTimeout(resolve, 60));
            await window.mouseUp(dragTo, { button: 'left', clickCount: 1 });
        }, `JSON.stringify(window.__relationshipWaypoints('Waypoint drag test edge')[0]) !== ${JSON.stringify(initialWaypointJson)}`);
        assert.ok(dragged, 'Dragging the waypoint handle did not move it after 5 attempts.');
        const draggedWaypoint = (await evaluate(window, `window.__relationshipWaypoints('Waypoint drag test edge')`))[0];

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await waitFor(window, `JSON.stringify(window.__relationshipWaypoints('Waypoint drag test edge')[0]) === ${JSON.stringify(JSON.stringify(initialWaypoints[0]))}`, 'Undo did not revert the dragged waypoint.');
        await evaluate(window, `document.querySelector('#redoButton').click()`);
        await waitFor(window, `JSON.stringify(window.__relationshipWaypoints('Waypoint drag test edge')[0]) === ${JSON.stringify(JSON.stringify(draggedWaypoint))}`, 'Redo did not restore the dragged waypoint.');

        await deleteWaypointTestEdge('Waypoint drag test edge');
    });

    await run('right-click adds and removes an edge waypoint via its own context menus', async () => {
        await selectWaypointTestTool();
        await createWaypointTestEdge('Waypoint add-remove test edge');

        const added = await retryGesture(window, async () => {
            const linePoint = await canvasPoint(window, `window.__relationshipScreenPoint('Waypoint add-remove test edge', 0.75)`);
            await window.mouseMove(linePoint);
            await window.mouseDown(linePoint, { button: 'right', clickCount: 1 });
            await new Promise((resolve) => setTimeout(resolve, 60));
            await window.mouseUp(linePoint, { button: 'right', clickCount: 1 });
        }, `!document.querySelector('#edgeContextMenu').classList.contains('hidden')`);
        assert.ok(added, 'Right-clicking the edge line did not open its context menu after 5 attempts.');
        assert.equal(await evaluate(window, `document.querySelector('#edgeContextAddWaypoint').hidden`), false, 'Add-waypoint action was not offered for a click on the edge line.');
        await evaluate(window, `document.querySelector('#edgeContextAddWaypoint').click()`);
        await waitFor(window, `window.__relationshipWaypoints('Waypoint add-remove test edge').length === 1`, 'Right-clicking the edge line did not add a waypoint.');
        // See the drag test above for why this delay matters: the label hiding that keeps a
        // fresh handle clickable needs a moment to actually apply.
        await new Promise((resolve) => setTimeout(resolve, 300));

        const removed = await retryGesture(window, async () => {
            const handlePoint = await findCanvasPoint(window, await canvasPoint(window, `window.__waypointScreenPoint('Waypoint add-remove test edge', 0)`));
            if (!handlePoint) return;
            await window.mouseMove(handlePoint);
            await window.mouseDown(handlePoint, { button: 'right', clickCount: 1 });
            await new Promise((resolve) => setTimeout(resolve, 60));
            await window.mouseUp(handlePoint, { button: 'right', clickCount: 1 });
        }, `!document.querySelector('#waypointContextMenu').classList.contains('hidden')`);
        assert.ok(removed, 'Right-clicking the waypoint handle did not open its context menu after 5 attempts.');
        await evaluate(window, `document.querySelector('#waypointContextRemove').click()`);
        await waitFor(window, `window.__relationshipWaypoints('Waypoint add-remove test edge').length === 0`, 'Removing the waypoint did not clear it.');
        assert.equal(await canvasPoint(window, `window.__waypointScreenPoint('Waypoint add-remove test edge', 0)`), null, 'The waypoint handle was not removed from the scene once its waypoint was deleted.');

        await deleteWaypointTestEdge('Waypoint add-remove test edge');
    });

    await run('deleting a node hides connected relationships and undo restores them', async () => {
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Electrical losses')).click(); document.querySelector('[data-action="delete"]').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '2 nodes');
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '2 relationships');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), '3 nodes');
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), '3 relationships');
    });

    await run('view cube changes the camera to a named view', async () => {
        await evaluate(window, `document.querySelector('[data-nav-view="top"]').click()`);
        await waitFor(window, `document.querySelector('[data-nav-view="top"]').classList.contains('active')`, 'Top camera view did not become active.', 2000);
    });

    await run('camera controls provide wheel-free zoom and model fitting', async () => {
        assert.equal(await evaluate(window, `document.querySelector('[data-nav-action="zoomIn"]').ariaLabel`), 'Zoom camera in');
        // A camera move left animating by an earlier test would overwrite the zoom when it ends: the camera still, first.
        await waitForStableRect(window, `document.querySelector('#viewCube').dataset.cameraDistance`, 'The camera did not come to rest before zooming.', 5000);
        const before = Number(await evaluate(window, `document.querySelector('#viewCube').dataset.cameraDistance`));
        await evaluate(window, `document.querySelector('[data-nav-action="zoomIn"]').click()`);
        await waitFor(window, `Number(document.querySelector('#viewCube').dataset.cameraDistance) < ${before}`, 'Camera zoom-in control did not reduce its target distance.');
        await evaluate(window, `document.querySelector('[data-nav-action="fit"]').click()`);
        assert.ok(Number(await evaluate(window, `document.querySelector('#viewCube').dataset.cameraDistance`)) > 0);
    });

    await run('camera controls provide button and keyboard panning', async () => {
        const before = await evaluate(window, `document.querySelector('#viewCube').dataset.cameraTarget`);
        await evaluate(window, `document.querySelector('[data-nav-pan="left"]').click()`);
        await waitFor(window, `document.querySelector('#viewCube').dataset.cameraTarget !== ${JSON.stringify(before)}`, 'Pan control did not move the camera target.');
        assert.equal(await evaluate(window, `document.querySelectorAll('[data-nav-pan]').length`), 4);
        assert.equal(await evaluate(window, `document.querySelector('.webglSurface').getAttribute('aria-label')`), '3D model canvas');
    });

    await run('the 2D lock toggle turns left-drag into pan and disables isometric corners', async () => {
        const point = await evaluate(window, `(() => { const bounds = document.querySelector('#webglContainer').getBoundingClientRect(); return { x: Math.round(bounds.left + 20), y: Math.round(bounds.top + 20) }; })()`);
        const dragTo = { x: point.x + 50, y: point.y + 30 };
        const cameraTargetExpression = `document.querySelector('#viewCube').dataset.cameraTarget`;
        const drag = async () => {
            await window.mouseMove(point);
            await window.mouseDown(point, { button: 'left', clickCount: 1 });
            await window.mouseMove(dragTo);
            await window.mouseUp(dragTo, { button: 'left', clickCount: 1 });
        };
        const readTarget = async () => (await evaluate(window, cameraTargetExpression)).split(',').map(Number);
        // OrbitControls' damping (dampingFactor 0.07) eases a pan's momentum into the target
        // exponentially and never reaches an exact fixed point to poll for -- unlike the
        // deterministic 650ms snap animation below, comparing "close enough" after a generous
        // settle is the reliable check here, not exact equality.
        const targetsClose = (a, b, epsilon = 0.02) => a.every((value, index) => Math.abs(value - b[index]) < epsilon);

        assert.equal(await evaluate(window, `document.querySelector('#lock2DButton').ariaPressed`), 'false');
        await evaluate(window, `document.querySelector('#lock2DButton').click()`);
        await waitFor(window, `document.querySelector('#lock2DButton').ariaPressed === 'true'`, '2D lock button did not report itself pressed.');
        assert.equal(await evaluate(window, `[...document.querySelectorAll('.cubeCorner')].every((corner) => corner.disabled)`), true, 'Isometric corner buttons should be disabled while locked.');
        // Engaging the lock snaps to the nearest orthogonal view via the existing 650ms animated
        // camera transition, which sets orbitControls.target once and then only lerps
        // camera.position -- genuinely stable to poll for, unlike a damped pan/rotate.
        await waitForStableRect(window, cameraTargetExpression, '2D lock camera snap did not settle.');

        const targetBeforeLockedDrag = await readTarget();
        await drag();
        await waitFor(window, `${cameraTargetExpression} !== ${JSON.stringify(targetBeforeLockedDrag.map((v) => v.toFixed(4)).join(','))}`, 'A left-drag while 2D-locked did not pan the camera.');
        await new Promise((resolve) => setTimeout(resolve, 3000));
        assert.ok(!targetsClose(targetBeforeLockedDrag, await readTarget()), 'A left-drag while 2D-locked did not pan the camera by a meaningful amount.');

        await evaluate(window, `document.querySelector('#lock2DButton').click()`);
        await waitFor(window, `document.querySelector('#lock2DButton').ariaPressed === 'false'`, '2D lock button did not report itself unpressed.');
        assert.equal(await evaluate(window, `[...document.querySelectorAll('.cubeCorner')].every((corner) => !corner.disabled)`), true, 'Isometric corner buttons should re-enable once unlocked.');

        const targetBeforeUnlockedDrag = await readTarget();
        await drag();
        await new Promise((resolve) => setTimeout(resolve, 3000));
        assert.ok(targetsClose(targetBeforeUnlockedDrag, await readTarget()), 'An unlocked left-drag should rotate around a fixed target, not pan it.');
    });

    await run('encrypted-save password feedback updates continuously', async () => {
        await evaluate(window, `document.querySelector('#saveEncryptedButton').click()`);
        await waitFor(window, `document.querySelector('#passwordDialog').open`, 'Password dialog did not open.');
        await evaluate(window, `(() => {
            const password = document.querySelector('#projectPassword');
            password.value = 'short'; password.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#passwordSubmit').disabled`), true);
        await evaluate(window, `(() => {
            const password = document.querySelector('#projectPassword');
            const confirmation = document.querySelector('#confirmProjectPassword');
            password.value = 'longEnoughPassword'; confirmation.value = 'longEnoughPassword';
            password.dispatchEvent(new Event('input', { bubbles: true })); confirmation.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#passwordSubmit').disabled`), false);
        await evaluate(window, `document.querySelector('#passwordCancel').click()`);
    });

    await run('project title editing applies camel case filenames', async () => {
        await evaluate(window, `(() => { document.querySelector('.documentTitle').click(); const input = document.querySelector('.documentTitleInput'); input.value = 'My Test Model'; input.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        assert.equal(await evaluate(window, `document.querySelector('.documentTitle').textContent`), 'myTestModel');
    });

    await run('interface zoom controls increase and reset application scale', async () => {
        const before = await evaluate(window, `window.uiZoom.get()`);
        await evaluate(window, `document.querySelector('#zoomInButton').click()`);
        assert.ok(await evaluate(window, `window.uiZoom.get()`) > before);
        await evaluate(window, `window.uiZoom.reset()`);
        assert.equal(Math.round((await evaluate(window, `window.uiZoom.get()`)) * 10) / 10, 1);
    });

    await run('component library places node templates and connects them with an auto-bound edge template', async () => {
        await evaluate(window, `document.querySelector('#componentLibraryButton').click()`);
        await waitFor(window, `!document.querySelector('#componentLibraryPanel').hidden`, 'Component library panel did not open.');
        await waitFor(window, `document.querySelectorAll('.componentLibraryItem').length > 0`, 'Component library did not load any templates.');
        assert.ok(await evaluate(window, `[...document.querySelectorAll('.componentLibrarySection h3')].some((h) => h.textContent === 'Thermal')`), 'Templates were not sectioned by domain when idle.');

        // Multi-select domain chips: filtering to "Mechanical" alone should hide the thermal-only
        // edge template but keep a mechanical one, and collapse from sectioned to a flat filtered list.
        await evaluate(window, `[...document.querySelectorAll('#componentLibraryDomainChips button')].find((b) => b.textContent === 'Mechanical').click()`);
        assert.equal(await evaluate(window, `document.querySelector('[data-template-id="conduction"]')`), null);
        assert.notEqual(await evaluate(window, `document.querySelector('[data-template-id="rotationalDrive"]')`), null);
        await evaluate(window, `[...document.querySelectorAll('#componentLibraryDomainChips button')].find((b) => b.textContent === 'Mechanical').click()`);

        const nodesBefore = await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`);
        const relationshipsBefore = await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`);

        // Two instances of the same node template, so the edge template below has a guaranteed
        // exact-symbol match on both ends without depending on the bundled example's own state names.
        await evaluate(window, `document.querySelector('[data-template-id="thermalMass"]').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].filter((l) => l.textContent.includes('Thermal mass')).length === 1`, 'The first thermal mass node template was not placed.');
        await evaluate(window, `document.querySelector('[data-template-id="thermalMass"]').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].filter((l) => l.textContent.includes('Thermal mass')).length === 2`, 'The second thermal mass node template was not placed.');
        assert.notEqual(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), nodesBefore);
        assert.equal(await evaluate(window, `!document.querySelector('#componentLibraryPanel').hidden`), true, 'The library panel closed itself after placing a node.');

        await evaluate(window, `document.querySelector('[data-template-id="conduction"]').click()`);
        await waitFor(window, `!document.querySelector('#endpointPickBanner').hidden`, 'Applying the edge template did not arm endpoint picking.');
        assert.match(await evaluate(window, `document.querySelector('#componentLibraryHint').textContent`), /Conduction/);
        assert.equal(await evaluate(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`), true, 'The edge builder should stay out of the way during the chained endpoint pick.');

        // Endpoint picking is wired to the CSS2D label's own click listener (not 3D raycasting),
        // so a plain .click() reaches it directly -- the same approach every other test in this
        // file already uses for .objectLabel, and it sidesteps CSS2DRenderer position/timing
        // entirely rather than needing real screen coordinates.
        const clickThermalMass = async (index) => {
            await evaluate(window, `[...document.querySelectorAll('.objectLabel')].filter((l) => l.textContent.includes('Thermal mass'))[${index}]?.click()`);
        };

        await clickThermalMass(0);
        await waitFor(window, `document.querySelector('#endpointPickTitle').textContent.includes('target')`, 'Picking did not chain from the source to the target endpoint after the first click.');
        await clickThermalMass(1);
        await waitFor(window, `!document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'The edge builder did not reappear once both endpoints were picked.');
        assert.equal(await evaluate(window, `document.querySelector('#componentLibraryHint').hidden`), true);
        assert.equal(await evaluate(window, `document.querySelector('#newEdgeName').value`), 'Conduction');
        assert.equal(await evaluate(window, `document.querySelector('#edgeParameterRows .parameterRow [data-field="symbol"]').value`), 'conductance');
        assert.equal(await evaluate(window, `document.querySelector('#builderEquationDiagnostics').classList.contains('valid')`), true, 'The name-matched ports did not auto-bind to a valid equation.');
        // Regression check: the builder's own default output (target's first state) is not
        // reliable across a chained two-endpoint pick -- see the explicit `output` field on every
        // bundled edge template -- so this specifically verifies the override actually lands on
        // target.temperature rather than getting stuck on an implicit source-side selection.
        assert.equal(await evaluate(window, `document.querySelector('#edgeEquationOutput').selectedOptions[0].textContent`), 'target.temperature');

        await evaluate(window, `document.querySelector('#createEdge').click()`);
        await waitFor(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'Creating the templated edge did not close the builder.');
        assert.notEqual(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), relationshipsBefore);
        // Conduction is bidirectional -- confirms the post-creation setRelationshipDirectionality
        // hook actually ran, not just that some edge got created. Opens the edge editor (same
        // bundle-label click precedent other tests in this file use) to read it back the same
        // way a real user would see it, rather than reaching into renderer module state. The
        // bundle label's header shows the connected node names ("Thermal mass ↔ Thermal mass"),
        // not the edge's own title -- clicking anywhere on a single-relationship bundle (not just
        // a specific row) opens that one relationship directly.
        await waitFor(window, `[...document.querySelectorAll('.bundleLabel')].some((l) => l.textContent.includes('Thermal mass'))`, 'The relationship bundle label for the new Conduction edge did not appear.');
        await evaluate(window, `[...document.querySelectorAll('.bundleLabel')].find((l) => l.textContent.includes('Thermal mass'))?.click()`);
        await waitFor(window, `!document.querySelector('#edgeEditor').classList.contains('hidden')`, 'Clicking the new Conduction relationship did not open the edge editor.');
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeDirectionality').value`), 'bidirectional', 'Conduction was not created as a bidirectional edge.');
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);

        // Undo the edge and both placed nodes so this scenario leaves the baseline model unchanged
        // before the next one starts.
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), nodesBefore);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), relationshipsBefore);

        // Second scenario: a node template with a self-referencing source term (Rotational link),
        // and an edge template with an explicit non-default output (Rotational drive updates
        // angularVelocity, not the target's declared-first state, angle) -- covers the two schema
        // additions the thermal scenario above doesn't exercise.
        await evaluate(window, `document.querySelector('[data-template-id="motor"]').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].some((l) => l.textContent.includes('Motor'))`, 'The motor node template was not placed.');
        await evaluate(window, `document.querySelector('[data-template-id="rotationalLink"]').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].some((l) => l.textContent.includes('Rotational link'))`, 'The rotational link node template was not placed.');
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((l) => l.textContent.includes('Rotational link'))?.click()`);
        await waitFor(window, `!document.querySelector('#nodeEditor').classList.contains('hidden')`, 'The placed rotational link node did not open its editor.');
        assert.equal(await evaluate(window, `document.querySelector('#nodeEditorSourceTerms .sourceTermPreview')?.textContent`), 'Updates angle', "The template's self-referencing source term was not applied to the placed node.");
        await evaluate(window, `document.querySelector('#nodeEditor [data-close-card]').click()`);

        const clickLabelContaining = async (text) => {
            await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((l) => l.textContent.includes(${JSON.stringify(text)}))?.click()`);
        };

        await evaluate(window, `document.querySelector('[data-template-id="rotationalDrive"]').click()`);
        await waitFor(window, `!document.querySelector('#endpointPickBanner').hidden`, 'Applying the rotational drive edge template did not arm endpoint picking.');
        await clickLabelContaining('Motor');
        await waitFor(window, `document.querySelector('#endpointPickTitle').textContent.includes('target')`, 'Picking did not chain to the target endpoint for rotational drive.');
        await clickLabelContaining('Rotational link');
        await waitFor(window, `!document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'The edge builder did not reappear once both endpoints were picked for rotational drive.');
        assert.equal(await evaluate(window, `document.querySelector('#edgeEquationOutput').selectedOptions[0].textContent`),
            'target.angularVelocity', "The explicit output override did not select angularVelocity over the target's default first state, angle.");
        assert.equal(await evaluate(window, `document.querySelector('#builderEquationDiagnostics').classList.contains('valid')`), true);

        await evaluate(window, `document.querySelector('#createEdge').click()`);
        await waitFor(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'Creating the rotational drive edge did not close the builder.');
        assert.notEqual(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), relationshipsBefore);

        // Undo the edge and both placed nodes so this scenario leaves the baseline model unchanged
        // before the next one starts.
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), nodesBefore);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), relationshipsBefore);

        // Third scenario: a cross-domain node (Motor, tagged both electrical and mechanical) and
        // two edge templates whose ports declare more than one expected symbol on the same side
        // (target: current AND angularVelocity) -- covers the array-valued ports the scenarios
        // above only exercise with a single symbol per role.
        //
        // "Motor" was also used (and undone) in the second scenario -- a soft-deleted node's label
        // stays in the DOM, just hidden, so counting/selecting by text alone here could pick up
        // that stale one. visibleLabelsWith() filters on the CSS2DObject's own root element
        // (.node-label-container, what CSS2DRenderer actually toggles display:none on), matching
        // the same distinction the multi-selection and Cmd/Ctrl+V paste tests above are careful
        // about for the same reason.
        const visibleLabelsWith = (text) => `[...document.querySelectorAll('.objectLabel')].filter((l) => l.textContent.includes(${JSON.stringify(text)}) && getComputedStyle(l.closest('.node-label-container')).display !== 'none')`;
        await evaluate(window, `document.querySelector('[data-template-id="motor"]').click()`);
        await waitFor(window, `${visibleLabelsWith('Motor')}.length === 1`, 'The motor node template was not placed.');
        await evaluate(window, `document.querySelector('[data-template-id="voltageSource"]').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].some((l) => l.textContent.includes('Voltage source'))`, 'The voltage source node template was not placed.');
        await evaluate(window, `document.querySelector('[data-template-id="torqueLoad"]').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].some((l) => l.textContent.includes('Torque load'))`, 'The torque load node template was not placed.');
        assert.equal(await evaluate(window, `Number.parseInt(document.querySelectorAll('.modelStatus span')[0].textContent, 10)`),
            Number.parseInt(nodesBefore, 10) + 3, 'Placing the three node templates did not add exactly three nodes.');

        await evaluate(window, `document.querySelector('[data-template-id="armatureDynamics"]').click()`);
        await waitFor(window, `!document.querySelector('#endpointPickBanner').hidden`, 'Applying the armature dynamics edge template did not arm endpoint picking.');
        assert.match(await evaluate(window, `document.querySelector('#componentLibraryHint').textContent`),
            /"current"\/"angularVelocity"/, 'The hint did not list both target port symbols for a multi-symbol port.');
        await clickLabelContaining('Voltage source');
        await waitFor(window, `document.querySelector('#endpointPickTitle').textContent.includes('target')`, 'Picking did not chain to the target endpoint for armature dynamics.');
        await evaluate(window, `${visibleLabelsWith('Motor')}[0]?.click()`);
        await waitFor(window, `!document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'The edge builder did not reappear once both endpoints were picked for armature dynamics.');
        assert.equal(await evaluate(window, `document.querySelector('#builderEquationDiagnostics').classList.contains('valid')`), true,
            'A latex expression referencing two states on the same side did not auto-bind to a valid equation.');
        assert.equal(await evaluate(window, `document.querySelector('#edgeEquationOutput').selectedOptions[0].textContent`), 'target.current');
        await evaluate(window, `document.querySelector('#createEdge').click()`);
        await waitFor(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'Creating the armature dynamics edge did not close the builder.');
        assert.equal(await evaluate(window, `Number.parseInt(document.querySelectorAll('.modelStatus span')[0].textContent, 10)`),
            Number.parseInt(nodesBefore, 10) + 3, 'Creating the armature dynamics edge unexpectedly changed the node count.');

        await evaluate(window, `document.querySelector('[data-template-id="shaftDynamics"]').click()`);
        await waitFor(window, `!document.querySelector('#endpointPickBanner').hidden`, 'Applying the shaft dynamics edge template did not arm endpoint picking.');
        await clickLabelContaining('Torque load');
        await waitFor(window, `document.querySelector('#endpointPickTitle').textContent.includes('target')`, 'Picking did not chain to the target endpoint for shaft dynamics.');
        await evaluate(window, `${visibleLabelsWith('Motor')}[0]?.click()`);
        await waitFor(window, `!document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'The edge builder did not reappear once both endpoints were picked for shaft dynamics.');
        assert.equal(await evaluate(window, `document.querySelector('#builderEquationDiagnostics').classList.contains('valid')`), true);
        assert.equal(await evaluate(window, `document.querySelector('#edgeEquationOutput').selectedOptions[0].textContent`),
            'target.angularVelocity', 'Shaft dynamics did not override the default output to angularVelocity.');
        await evaluate(window, `document.querySelector('#createEdge').click()`);
        await waitFor(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'Creating the shaft dynamics edge did not close the builder.');

        await evaluate(window, `document.querySelector('#closeComponentLibraryPanel').click()`);
        assert.equal(await evaluate(window, `document.querySelector('#componentLibraryPanel').hidden`), true);

        for (let undo = 0; undo < 5; undo += 1) await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`), nodesBefore);
        assert.equal(await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`), relationshipsBefore);
    });

    // Shared with the two run() calls below (see the analogous analysisHandle comment above scenario
    // #15's split for why): the Pose Visualizer add-on has no web-edition equivalent, but the
    // simulation run it inspects, and the cleanup afterward, are both main-window/portable and must
    // always happen so the next scenario starts from a clean canvas either way.
    let firstBodyId = null;

    await run('Pose Visualizer add-on auto-detects and renders a 6-DOF free body node', async () => {
        const idsBeforeBodies = new Set(await evaluate(window, `window.__debugTransform.allNodeIds()`));
        await evaluate(window, `document.querySelector('#componentLibraryButton').click()`);
        await waitFor(window, `!document.querySelector('#componentLibraryPanel').hidden`, 'Component library panel did not open.');
        await waitFor(window, `document.querySelectorAll('.componentLibraryItem').length > 0`, 'Component library did not load any templates.');
        await evaluate(window, `document.querySelector('[data-template-id="freeBody"]').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].filter((l) => l.textContent.includes('Free body')).length === 1`, 'The first free body node template was not placed.');
        await evaluate(window, `document.querySelector('[data-template-id="freeBody"]').click()`);
        await waitFor(window, `[...document.querySelectorAll('.objectLabel')].filter((l) => l.textContent.includes('Free body')).length === 2`, 'The second free body node template was not placed.');
        await evaluate(window, `document.querySelector('#closeComponentLibraryPanel').click()`);

        // Give the first free body a known editor rotation/scale (must happen before the run
        // below locks the transform tools in result mode) so the add-on's "Editor shapes,
        // colors & transforms" toggle has a real, non-identity transform to verify downstream.
        const bodyIds = (await evaluate(window, `window.__debugTransform.allNodeIds()`)).filter((id) => !idsBeforeBodies.has(id));
        assert.equal(bodyIds.length, 2, 'Expected exactly two new free body nodes.');
        [firstBodyId] = bodyIds;
        const selectFirstBody = `document.querySelector('.node-label-container[data-node="${firstBodyId}"] .objectLabel').click()`;
        await evaluate(window, selectFirstBody);
        await evaluate(window, `document.querySelector('[data-tool="rotate"]').click()`);
        await evaluate(window, `window.__debugTransform.simulateDragTo(0.4, 0, 0)`);
        await evaluate(window, selectFirstBody);
        await evaluate(window, `document.querySelector('[data-tool="scale"]').click()`);
        await evaluate(window, `window.__debugTransform.simulateDragTo(2, 1, 1)`);
        await evaluate(window, `document.querySelector('[data-tool="select"]').click()`);

        // A manual edge between the two free bodies (rather than a component-library template,
        // none of which connect two freeBody nodes) so the add-on's edge-line/label feature has
        // a real connection to render -- the equation's content is irrelevant here, only that
        // sourceNodeId/targetNodeId land on two detected 6-DOF bodies.
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="edge"]').click()`);
        await evaluate(window, `(() => {
            const options = (selector) => [...document.querySelector(selector).options].filter((option) => option.textContent === 'Free body');
            const source = document.querySelector('#edgeSource');
            source.value = options('#edgeSource')[0].value;
            source.dispatchEvent(new Event('change', { bubbles: true }));
            const target = document.querySelector('#edgeTarget');
            target.value = options('#edgeTarget')[1].value;
            target.dispatchEvent(new Event('change', { bubbles: true }));
            document.querySelector('#newEdgeName').value = 'Pose link';
            const field = document.querySelector('#edgeMathField');
            field.setValue('\\\\mathrm{sourceX}');
            field.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#builderEquationDiagnostics').classList.contains('valid')`), true);
        await evaluate(window, `document.querySelector('#createEdge').click()`);
        await waitFor(window, `document.querySelector('#edgeBuilder').classList.contains('hidden')`, 'Creating the Pose link edge did not close the builder.');

        await openRunDialog(window);
        await evaluate(window, `(() => { document.querySelector('#runTargetTime').value = '1'; document.querySelector('#startRun').click(); })()`);
        await waitFor(window, `document.querySelector('.resultMode b').textContent === 'Results'`, 'Offline run did not complete.', 15000);
    });

    await run('Pose Visualizer add-on inspects a completed run with two free bodies', async () => {
        // The toolstrip command itself, not just the ability to click it, is desktop-only -- see
        // the identical note on the Results Analysis add-on's own split above.
        await waitFor(window, `Boolean(document.querySelector('.addonTool[data-addon-id="konjugate.poseVisualizer"][data-command-id="openPoseVisualizer"]:not([hidden])'))`, 'Pose Visualizer toolstrip command did not appear.');
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('.addonTool[data-addon-id="konjugate.poseVisualizer"][data-command-id="openPoseVisualizer"]').click()`);
        const poseWindow = await driver.waitForNewHandle(before);

        const consoleMessages = await captureConsoleMessages(poseWindow, async () => {
            await waitFor(poseWindow, `Boolean(document.querySelector('.konjugateAddonTitlebar'))`, 'Host titlebar was not added to the Pose Visualizer window.');
            assert.equal(await evaluate(poseWindow, `document.querySelector('.konjugateAddonIdentity b').textContent`), 'Pose Visualizer');
            await waitFor(poseWindow, `getComputedStyle(document.querySelector('.konjugateAddonTitlebar')).position === 'fixed'`, 'Host titlebar styles did not load.');
            await waitFor(poseWindow, `document.querySelectorAll('.bodyOption').length === 2`, 'Pose Visualizer did not detect both free body nodes.');
            assert.match(await evaluate(poseWindow, `document.querySelector('.bodyOption b').textContent`), /Free body/);
            assert.equal(await evaluate(poseWindow, `document.querySelector('.sceneWorkspace').classList.contains('hasBodies')`), true);
            assert.ok(await evaluate(poseWindow, `document.querySelector('#scene').clientWidth`) > 0);
            assert.equal(await evaluate(poseWindow, `typeof require === 'undefined'`), true);

            assert.equal(await evaluate(poseWindow, `document.querySelector('#edgeLabels').children.length`), 0);
            await evaluate(poseWindow, `document.querySelector('#showConnections').click()`);
            await waitFor(poseWindow, `document.querySelector('#edgeLabels').children.length === 1`, 'Enabling connections did not draw the edge line/label.');
            assert.equal(await evaluate(poseWindow, `document.querySelector('.edgeLabel').textContent`), 'Pose link');
            await evaluate(poseWindow, `document.querySelector('#showConnections').click()`);
            assert.equal(await evaluate(poseWindow, `document.querySelector('#edgeLabels').children.length`), 0);

            await evaluate(poseWindow, `document.querySelector('#useEditorShapes').click()`);
            assert.equal(await evaluate(poseWindow, `document.querySelector('#useEditorShapes').checked`), true);
            const editorShapeTransform = await evaluate(poseWindow, `window.__debugPoseVisualizer.shapeTransform(${firstBodyId})`);
            assert.ok(editorShapeTransform, 'Pose Visualizer did not build a shape sub-group for the rotated/scaled body.');
            assert.deepEqual(editorShapeTransform.rotation.map((v) => Math.round(v * 100) / 100), [0.4, 0, 0]);
            assert.deepEqual(editorShapeTransform.scale, [2, 1, 1]);
            await evaluate(poseWindow, `document.querySelector('#useEditorShapes').click()`);
            assert.equal(await evaluate(poseWindow, `document.querySelector('#useEditorShapes').checked`), false);
            const defaultShapeTransform = await evaluate(poseWindow, `window.__debugPoseVisualizer.shapeTransform(${firstBodyId})`);
            assert.deepEqual(defaultShapeTransform, { rotation: [0, 0, 0], scale: [1, 1, 1] });

            await evaluate(poseWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = String(Number(timeline.max) / 2); timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
            await waitFor(window, `document.querySelector('#resultCurrentTime').value !== '0 s'`, 'Visualizer seek did not synchronize to the project window.');

            await evaluate(poseWindow, `document.querySelector('.bodyOption input').click()`);
            assert.equal(await evaluate(poseWindow, `document.querySelector('.bodyOption input').checked`), false);

            await waitFor(poseWindow, `document.querySelector('#runLifecycle').textContent === 'Completed'`, 'Pose Visualizer did not report the run as completed.');
            assert.equal(await evaluate(poseWindow, `document.querySelector('#playPause').disabled`), false);
            await evaluate(poseWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = '0'; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
            await waitFor(window, `document.querySelector('#resultCurrentTime').value === '0 s'`, 'Resetting the add-on timeline to zero did not synchronize.');
            await evaluate(poseWindow, `document.querySelector('#playPause').click()`);
            assert.equal(await evaluate(poseWindow, `document.querySelector('#playPause').textContent`), '❚❚');
            await waitFor(poseWindow, `document.querySelector('#playPause').textContent === '▶'`, 'Add-on-driven playback did not reach the end and stop.', 5000);
            assert.equal(await evaluate(poseWindow, `document.querySelector('#timeline').value`), await evaluate(poseWindow, `document.querySelector('#timeline').max`));
            await waitFor(window, `document.querySelector('#resultCurrentTime').value === '1 s'`, 'Main window did not sync to the end of add-on-driven playback.');

            await evaluate(poseWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = '0'; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
            await evaluate(poseWindow, `document.querySelector('#playPause').click()`);
            assert.equal(await evaluate(poseWindow, `document.querySelector('#playPause').textContent`), '❚❚');
            await evaluate(poseWindow, `(() => { const timeline = document.querySelector('#timeline'); timeline.value = '0.5'; timeline.dispatchEvent(new Event('input', { bubbles: true })); })()`);
            assert.equal(await evaluate(poseWindow, `document.querySelector('#playPause').textContent`), '▶', 'Manually scrubbing the timeline did not stop playback.');
        });
        assert.deepEqual(consoleMessages.filter((message) => /error|uncaught|exception/i.test(message)), []);

        await closeWhenValidated(poseWindow);
        for (let attempt = 0; attempt < 100 && !(await poseWindow.isDestroyed()); attempt += 1) {
            await new Promise((resolve) => setTimeout(resolve, 25));
        }
        assert.equal(await poseWindow.isDestroyed(), true);
    }, { skip: (!driver.capabilities.addons && 'the Pose Visualizer add-on has no web-edition equivalent') || addonMissing('konjugate.poseVisualizer', 'konjugate-posevisualizer') });

    await run('Pose Visualizer add-on keeps body mappings with the project and naming conventions for the user', async () => {
        const toolstripCommand = `document.querySelector('.addonTool[data-addon-id="konjugate.poseVisualizer"][data-command-id="openPoseVisualizer"]')`;
        const openPoseWindow = async () => {
            const before = driver.allHandles();
            await evaluate(window, `${toolstripCommand}.click()`);
            const handle = await driver.waitForNewHandle(before);
            await waitFor(handle, `Boolean(document.querySelector('.konjugateAddonTitlebar'))`, 'The Pose Visualizer window did not open.');
            return handle;
        };
        const closePoseWindow = async (handle) => {
            await closeWhenValidated(handle);
            for (let attempt = 0; attempt < 100 && !(await handle.isDestroyed()); attempt += 1) {
                await new Promise((resolve) => setTimeout(resolve, 25));
            }
        };
        const row = (entityId) => `document.querySelector('.bodyRow:has(.bodyOption[data-entity-id="${entityId}"])')`;
        const hints = `[...document.querySelectorAll('.bodyOption small')].map((hint) => hint.textContent)`;
        const bodyIds = (await evaluate(window, `window.__debugTransform.allNodeIds()`)).filter((id) => id !== firstBodyId);

        let poseWindow = await openPoseWindow();
        const consoleMessages = await captureConsoleMessages(poseWindow, async () => {
            await waitFor(poseWindow, `document.querySelectorAll('.bodyOption').length === 2`, 'Pose Visualizer did not detect both free body nodes.');
            const secondBodyId = await evaluate(poseWindow, `Number([...document.querySelectorAll('.bodyOption')].map((option) => option.dataset.entityId).find((id) => Number(id) !== ${firstBodyId}))`);
            assert.ok(bodyIds.includes(secondBodyId));

            // Without Konjugate's own names, neither node is a body ...
            await evaluate(poseWindow, `document.querySelector('#conventions .conventionRow input').click()`);
            await waitFor(poseWindow, `document.querySelectorAll('.bodyOption').length === 0`, 'Turning off the default convention did not remove its bodies.');
            assert.equal(await evaluate(poseWindow, `document.querySelector('.sceneWorkspace').classList.contains('hasBodies')`), false);
            // ... until a convention of the user's own finds a 2-DOF body in each.
            await evaluate(poseWindow, `document.querySelector('#newConvention').click()`);
            await evaluate(poseWindow, `(() => {
                const form = document.querySelector('#conventionForm');
                form.elements.name.value = 'Planar';
                form.elements.x.value = 'x';
                form.elements.y.value = 'y';
                form.requestSubmit();
            })()`);
            await waitFor(poseWindow, `document.querySelectorAll('.bodyOption').length === 2`, 'A new convention did not find its bodies.');
            assert.deepEqual(await evaluate(poseWindow, hints), ['x, y', 'x, y']);

            // A role mapped by hand for one node: the first free body also turns about z.
            await evaluate(poseWindow, `${row(firstBodyId)}.querySelector('.iconButton').click()`);
            await evaluate(poseWindow, `(() => {
                const select = ${row(firstBodyId)}.querySelector('select[aria-label^="Yaw"]');
                select.value = [...select.options].find((option) => option.textContent.startsWith('yaw')).value;
                select.dispatchEvent(new Event('change', { bubbles: true }));
            })()`);
            await waitFor(poseWindow, `${row(firstBodyId)}?.querySelector('small').textContent === 'x, y, yaw'`, 'Mapping yaw by hand did not reach the body.');
            // And the other node is no body at all, but can be added back.
            await evaluate(poseWindow, `${row(secondBodyId)}.querySelector('.iconButton').click()`);
            await evaluate(poseWindow, `[...${row(secondBodyId)}.querySelectorAll('.editorActions button')].find((button) => button.textContent === 'Remove body').click()`);
            await waitFor(poseWindow, `document.querySelectorAll('.bodyOption').length === 1`, 'Removing a body did not take it out of the scene.');
            assert.equal(await evaluate(poseWindow, `[...document.querySelector('#addBody').options].some((option) => option.value === '${secondBodyId}')`), true);
        });
        assert.deepEqual(consoleMessages.filter((message) => /error|uncaught|exception/i.test(message)), []);
        await closePoseWindow(poseWindow);

        // Reopened, the window has both back: the convention from the user's settings, the mapping and the removal from the project.
        poseWindow = await openPoseWindow();
        await waitFor(poseWindow, `document.querySelectorAll('.bodyOption').length === 1`, 'The project did not keep the removed body out.');
        assert.deepEqual(await evaluate(poseWindow, hints), ['x, y, yaw']);
        assert.deepEqual(await evaluate(poseWindow, `[...document.querySelectorAll('#conventions .conventionRow')].map((entry) => [entry.querySelector('b').textContent, entry.querySelector('input').checked])`), [['Konjugate', false], ['Planar', true]]);

        // Put the user's settings back as they were for the rest of the suite.
        await evaluate(poseWindow, `document.querySelector('#conventions .conventionRow input').click()`);
        await evaluate(poseWindow, `document.querySelector('#conventions .conventionRow:nth-child(2) button[aria-label^="Delete"]').click()`);
        await waitFor(poseWindow, `document.querySelectorAll('#conventions .conventionRow').length === 1`, 'Deleting the convention did not remove it.');
        await closePoseWindow(poseWindow);
    }, { skip: (!driver.capabilities.addons && 'the Pose Visualizer add-on has no web-edition equivalent') || addonMissing('konjugate.poseVisualizer', 'konjugate-posevisualizer') });

    await run('closing results and removing the free-body nodes cleans up the pose scenario', async () => {
        await evaluate(window, `document.querySelector('#closeResults').click()`);
        await waitFor(window, `document.querySelector('#closeResultsDialog').open`, 'Closing results did not request confirmation.');
        await evaluate(window, `document.querySelector('#confirmCloseResults').click()`);
        await waitFor(window, `document.querySelector('#addButton') && !document.querySelector('#addButton').disabled`, 'Model editing did not re-enable after closing results.');
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((l) => l.textContent.includes('Free body'))?.click()`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true }))`);
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((l) => l.textContent.includes('Free body'))?.click()`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true }))`);
    });

    await run('importing a node shape file also saves it into the user shape library', async () => {
        // Deliberately operates on whatever node is already on the canvas at this point in the
        // suite, rather than loading a fresh example -- by now the document is dirty from many
        // earlier tests, and loading a new example would raise a native "Discard changes?"
        // dialog that executeJavaScript can't click. The specific project content is irrelevant
        // to what's under test here (the upload-to-library wiring), so any node will do.
        await waitFor(window, `document.querySelectorAll('.objectLabel').length > 0`, 'No node available to select for the upload test.');
        await evaluate(window, `document.querySelector('.objectLabel').click()`);
        await waitFor(window, `!document.querySelector('#nodeEditor').classList.contains('hidden')`, 'Node editor did not open.');
        await evaluate(window, `document.querySelector('[data-node-tab="appearance"]').click()`);
        await waitFor(window, `!document.querySelector('[data-node-panel="appearance"]').hidden`, 'Appearance tab did not open.');

        const stlContent = 'solid uploadTest\nfacet normal 0 0 1\nouter loop\nvertex 0 0 0\nvertex 1 0 0\nvertex 0 1 0\nendloop\nendfacet\nendsolid uploadTest\n';
        await evaluate(window, `(() => {
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(new File([${JSON.stringify(stlContent)}], 'uploadTest.stl', { type: 'model/stl' }));
            const input = document.querySelector('#editNodeGeometryFile');
            input.files = dataTransfer.files;
            input.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await waitFor(window, `document.querySelector('#editGeometryStatus').textContent.includes('saved to shape library')`, 'Upload did not report being saved to the shape library.');

        const shapes = await evaluate(window, `window.shapeLibrary.list()`);
        const uploaded = shapes.find((shape) => shape.domain === 'userUploaded' && shape.name === 'uploadTest');
        assert.ok(uploaded, `Expected an uploaded shape library entry, got: ${JSON.stringify(shapes.map((s) => s.id))}`);

        await evaluate(window, `document.querySelector('#editBrowseShapeLibrary').click()`);
        await waitFor(window, `document.querySelector('#shapeLibraryDialog').open`, 'Shape library dialog did not open.');
        assert.ok(await evaluate(window, `[...document.querySelectorAll('#shapeLibraryDomains button')].some((b) => b.textContent === 'User uploaded')`), 'No "User uploaded" domain chip appeared.');
        assert.ok(await evaluate(window, `[...document.querySelectorAll('.shapeLibraryItem b')].some((b) => b.textContent === 'uploadTest')`), 'Uploaded shape did not appear in the library grid.');
        await evaluate(window, `document.querySelector('#shapeLibraryCancel').click()`);
    });

    await run('rotate and scale tools transform a node with undo/redo and persist through copy/paste', async () => {
        await waitFor(window, `document.querySelectorAll('.objectLabel').length > 0`, 'No node available to select.');
        await evaluate(window, `document.querySelector('.objectLabel').click()`);
        const nodeId = await evaluate(window, `window.__debugTransform.selectedId()`);
        assert.ok(nodeId, 'No node was selected.');

        // --- Rotate ---
        await evaluate(window, `document.querySelector('[data-tool="rotate"]').click()`);
        assert.equal(await evaluate(window, `window.__debugTransform.mode()`), 'rotate');
        assert.equal(await evaluate(window, `window.__debugTransform.attachedId()`), nodeId);
        await evaluate(window, `window.__debugTransform.simulateDragTo(0.3, 0.5, 0.7)`);
        let rotation = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'rotation')`);
        assert.deepEqual(rotation.map((v) => Math.round(v * 100) / 100), [0.3, 0.5, 0.7]);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        rotation = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'rotation')`);
        assert.deepEqual(rotation, [0, 0, 0]);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, shiftKey: true, bubbles: true }))`);
        rotation = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'rotation')`);
        assert.deepEqual(rotation.map((v) => Math.round(v * 100) / 100), [0.3, 0.5, 0.7]);

        // --- Scale ---
        // undo()/redo() unconditionally clearSelection() before replaying (renderer.mjs) -- an
        // existing, intentional app behavior, not specific to rotate/scale -- so the node needs
        // reselecting here regardless of which tool is active.
        await evaluate(window, `document.querySelector('.objectLabel').click()`);
        await evaluate(window, `document.querySelector('[data-tool="scale"]').click()`);
        assert.equal(await evaluate(window, `window.__debugTransform.mode()`), 'scale');
        assert.equal(await evaluate(window, `window.__debugTransform.attachedId()`), nodeId);
        await evaluate(window, `window.__debugTransform.simulateDragTo(2, 1.5, 3)`);
        let scale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);
        assert.deepEqual(scale, [2, 1.5, 3]);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        scale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);
        assert.deepEqual(scale, [1, 1, 1]);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, shiftKey: true, bubbles: true }))`);
        scale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);
        assert.deepEqual(scale, [2, 1.5, 3]);

        // --- Appearance tab: precise rotation/scale number inputs ---
        // The scale redo just above clears selection/closes the editor (same undo()/redo()
        // clearSelection() behavior noted earlier), so the node needs reselecting before its
        // Appearance tab fields can be read or edited.
        await evaluate(window, `document.querySelector('.objectLabel').click()`);
        await evaluate(window, `document.querySelector('[data-node-tab="appearance"]').click()`);
        let rotationDegrees = await evaluate(window, `[document.querySelector('#editNodeRotationX').value, document.querySelector('#editNodeRotationY').value, document.querySelector('#editNodeRotationZ').value].map(Number)`);
        assert.deepEqual(rotationDegrees.map((v) => Math.round(v)), [17, 29, 40]);
        let scaleFields = await evaluate(window, `[document.querySelector('#editNodeScaleX').value, document.querySelector('#editNodeScaleY').value, document.querySelector('#editNodeScaleZ').value].map(Number)`);
        assert.deepEqual(scaleFields, [2, 1.5, 3]);

        // Typing a precise value commits it, going through the same node-object mutation and
        // undo history as a gizmo drag.
        await evaluate(window, `(() => { const input = document.querySelector('#editNodeRotationX'); input.value = '90'; input.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        rotation = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'rotation')`);
        assert.deepEqual(rotation.map((v) => Math.round(v * 100) / 100), [1.57, 0.5, 0.7]);

        // Live gizmo drags refresh the open Appearance tab fields too, not just typed edits.
        await evaluate(window, `document.querySelector('[data-tool="scale"]').click()`);
        await evaluate(window, `window.__debugTransform.simulateDragTo(4, 1.5, 3)`);
        scaleFields = await evaluate(window, `[document.querySelector('#editNodeScaleX').value, document.querySelector('#editNodeScaleY').value, document.querySelector('#editNodeScaleZ').value].map(Number)`);
        assert.deepEqual(scaleFields, [4, 1.5, 3]);

        // Zero/negative scale is rejected (would collapse or invert the geometry) and the field
        // snaps back to the last valid value instead of committing.
        await evaluate(window, `(() => { const input = document.querySelector('#editNodeScaleY'); input.value = '0'; input.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        scaleFields = await evaluate(window, `[document.querySelector('#editNodeScaleX').value, document.querySelector('#editNodeScaleY').value, document.querySelector('#editNodeScaleZ').value].map(Number)`);
        assert.deepEqual(scaleFields, [4, 1.5, 3]);
        scale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);
        assert.deepEqual(scale, [4, 1.5, 3]);

        // Undo back through the gizmo scale-drag and the typed rotation edit (the rejected
        // scale never recorded history) to restore what the earlier gizmo section left behind,
        // so the copy/paste assertions below still see [0.3, 0.5, 0.7] / [2, 1.5, 3].
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await evaluate(window, `document.querySelector('.objectLabel').click()`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        rotation = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'rotation')`);
        scale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);
        assert.deepEqual(rotation.map((v) => Math.round(v * 100) / 100), [0.3, 0.5, 0.7]);
        assert.deepEqual(scale, [2, 1.5, 3]);

        // --- Persistence through copy/paste, which round-trips via the same
        // serializeProjectDocument -> hydrateProjectDocument path a real save/reload would. ---
        await evaluate(window, `document.querySelector('[data-tool="select"]').click()`);
        await evaluate(window, `document.querySelector('.objectLabel').click()`);
        const nodeCountBefore = await evaluate(window, `document.querySelectorAll('.node-label-container').length`);
        // Diffing the node-ID set (rather than matching on a " copy" title suffix) avoids
        // mistaking this for some unrelated leftover "X copy" node other tests earlier in the
        // full suite may have already created and left on the canvas.
        const idsBefore = new Set(await evaluate(window, `window.__debugTransform.allNodeIds()`));
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'c', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'v', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await waitFor(window, `document.querySelectorAll('.node-label-container').length === ${nodeCountBefore + 1}`, 'Paste did not create a new node.');
        const idsAfter = await evaluate(window, `window.__debugTransform.allNodeIds()`);
        const pastedId = idsAfter.find((id) => !idsBefore.has(id));
        assert.ok(pastedId, 'Could not find the pasted node.');
        const pastedRotation = await evaluate(window, `window.__debugTransform.nodeTransform(${pastedId}, 'rotation')`);
        const pastedScale = await evaluate(window, `window.__debugTransform.nodeTransform(${pastedId}, 'scale')`);
        assert.deepEqual(pastedRotation.map((v) => Math.round(v * 100) / 100), [0.3, 0.5, 0.7]);
        assert.deepEqual(pastedScale, [2, 1.5, 3]);

        // Cleanup: undo the paste and the scale/rotate changes so this test doesn't leave the
        // canvas mutated for whatever runs after it.
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
    });

    await run('shift held during a scale drag forces uniform scaling, even mid-drag', async () => {
        // window.__debugTransform.scaleDrag drives the real objectChange handler's Shift-uniform
        // override step by step (mouseDown / move / mouseUp), letting a test toggle Shift
        // between movement steps the same way a real drag would -- rather than real screen
        // coordinates raycast against the gizmo's 3D handle geometry, `move` sets the object's
        // scale directly to stand in for whatever a real per-axis drag would have produced, and
        // sets TransformControls' own pointStart/pointEnd (all uniformScaleFactorForDrag reads)
        // for the Shift-held steps.
        await waitFor(window, `document.querySelectorAll('.objectLabel').length > 0`, 'No node available to select.');
        await evaluate(window, `document.querySelector('.objectLabel').click()`);
        const nodeId = await evaluate(window, `window.__debugTransform.selectedId()`);
        assert.ok(nodeId, 'No node was selected.');
        await evaluate(window, `document.querySelector('[data-tool="scale"]').click()`);
        assert.equal(await evaluate(window, `window.__debugTransform.mode()`), 'scale');
        const startScale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);

        await evaluate(window, `window.__debugTransform.scaleDrag.mouseDown()`);

        // Without Shift, a normal (non-uniform) per-axis drag is left untouched.
        let scale = await evaluate(window, `window.__debugTransform.scaleDrag.move({ manualScale: [2, 1, 1], shiftHeld: false })`);
        assert.deepEqual(scale, [2, 1, 1]);

        // Pressing Shift mid-drag immediately snaps to uniform scaling, computed from the drag's
        // *original* start scale (captured at mouseDown, not the intermediate value above) and
        // the pointStart/pointEnd distance ratio TransformControls' own centre-handle math uses
        // -- this is the actual scenario that was reported broken (Shift pressed mid-drag).
        scale = await evaluate(window, `window.__debugTransform.scaleDrag.move({ pointStart: [1, 0, 0], pointEnd: [2, 0, 0], shiftHeld: true })`);
        assert.deepEqual(scale, startScale.map((value) => value * 2));

        // Releasing Shift mid-drag resumes normal per-axis behaviour.
        scale = await evaluate(window, `window.__debugTransform.scaleDrag.move({ manualScale: [3, 1, 1], shiftHeld: false })`);
        assert.deepEqual(scale, [3, 1, 1]);

        await evaluate(window, `window.__debugTransform.scaleDrag.mouseUp()`);
        scale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);
        assert.deepEqual(scale, [3, 1, 1]);

        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        scale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);
        assert.deepEqual(scale, startScale);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, shiftKey: true, bubbles: true }))`);
        scale = await evaluate(window, `window.__debugTransform.nodeTransform(${nodeId}, 'scale')`);
        assert.deepEqual(scale, [3, 1, 1]);

        // Cleanup: undo back to the starting scale so this test doesn't leave the canvas
        // mutated for whatever runs after it.
        await evaluate(window, `document.querySelector('.objectLabel').click()`);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        await evaluate(window, `document.querySelector('[data-tool="select"]').click()`);
    });

    await run('rotate tool revolves a multi-node selection around the pivot as a rigid group', async () => {
        // Fresh nodes, not nodes already on the canvas, so both start at a guaranteed identity
        // rotation -- letting the revolve math below be checked with plain 2D rotation
        // trigonometry instead of needing to account for whatever pre-existing orientation an
        // example project's nodes might carry.
        const idsBefore = new Set(await evaluate(window, `window.__debugTransform.allNodeIds()`));
        await evaluate(window, `document.querySelector('#componentLibraryButton').click()`);
        await waitFor(window, `!document.querySelector('#componentLibraryPanel').hidden`, 'Component library panel did not open.');
        await waitFor(window, `document.querySelectorAll('.componentLibraryItem').length > 0`, 'Component library did not load any templates.');
        await evaluate(window, `document.querySelector('[data-template-id="freeBody"]').click()`);
        await evaluate(window, `document.querySelector('[data-template-id="freeBody"]').click()`);
        await evaluate(window, `document.querySelector('#closeComponentLibraryPanel').click()`);
        const newIds = (await evaluate(window, `window.__debugTransform.allNodeIds()`)).filter((id) => !idsBefore.has(id));
        assert.equal(newIds.length, 2, 'Expected exactly two new free body nodes.');
        const [pivotId, otherId] = newIds;
        const selectPivot = `document.querySelector('.node-label-container[data-node="${pivotId}"] .objectLabel').click()`;
        const selectOther = `document.querySelector('.node-label-container[data-node="${otherId}"] .objectLabel').click()`;

        // CSS2D labels for freshly-created nodes aren't inserted into the DOM synchronously --
        // CSS2DRenderer only appends them on the next throttled render tick (~30fps), the same
        // reasoning documented on addNode() in the edge-groups test below. Both nodes were
        // created back to back with little work between them, so without this wait, the clicks
        // further down can intermittently fire before one or both labels have actually rendered.
        await waitFor(window,
            `Boolean(document.querySelector('.node-label-container[data-node="${pivotId}"] .objectLabel')) `
            + `&& Boolean(document.querySelector('.node-label-container[data-node="${otherId}"] .objectLabel'))`,
            'The free body nodes\' labels did not render.');

        // Earlier tests in the suite pan and zoom the camera and never reset it, so by this
        // point it can be framed anywhere -- fit it to the model first so both freshly-placed
        // nodes are reliably on screen and clickable for the real mouse clicks below, rather
        // than landing wherever a prior test happened to leave the view.
        await evaluate(window, `document.querySelector('[data-nav-action="fit"]').click()`);

        assert.deepEqual(await evaluate(window, `window.__debugTransform.nodeTransform(${pivotId}, 'rotation')`), [0, 0, 0]);
        assert.deepEqual(await evaluate(window, `window.__debugTransform.nodeTransform(${otherId}, 'rotation')`), [0, 0, 0]);
        const pivotPosition = await evaluate(window, `window.__debugTransform.nodeTransform(${pivotId}, 'position')`);

        // Give the second node a known, meaningful offset from the pivot first, so the revolve
        // assertions below check real, non-trivial movement rather than however the component
        // library happened to place these two nodes relative to each other.
        await evaluate(window, selectOther);
        await evaluate(window, `document.querySelector('[data-tool="move"]').click()`);
        await evaluate(window, `window.__debugTransform.simulateDragTo(${pivotPosition[0] + 2}, ${pivotPosition[1]}, ${pivotPosition[2]})`);
        const otherStartPosition = await evaluate(window, `window.__debugTransform.nodeTransform(${otherId}, 'position')`);
        assert.deepEqual(otherStartPosition, [pivotPosition[0] + 2, pivotPosition[1], pivotPosition[2]]);

        // Select the pivot and switch to the rotate tool first, so the gizmo attaches to it --
        // then add the other node to the selection via window.__debugTransform.selectAdditive
        // (selectNode's own additive path, the same one a real Shift-click drives) rather than a
        // real screen-coordinate Shift-click. Whether a Shift-click lands on the right on-screen
        // label is a real-mouse/CSS2D-layout concern the existing multi-selection copy/paste
        // test already covers; what this test needs a multi-selection *for* is the group-rotate
        // math below, so establishing it directly keeps the test focused on that and avoids
        // depending on wherever this point in the full suite happens to leave the camera framed.
        // selectNode() reassigns the "primary" selectedNode to whichever node was added last
        // (needed so the node editor tracks it), but only reattaches the gizmo when the
        // currently-attached node has fallen out of the selection -- since the pivot stays
        // selected throughout, the gizmo (and this drag's pivot) stays on it rather than jumping
        // to the other node.
        await evaluate(window, selectPivot);
        await evaluate(window, `document.querySelector('[data-tool="rotate"]').click()`);
        assert.equal(await evaluate(window, `window.__debugTransform.attachedId()`), pivotId);
        await evaluate(window, `window.__debugTransform.selectAdditive(${otherId})`);
        assert.equal(await evaluate(window, `document.querySelectorAll('.node-label-container.selected').length`), 2);
        assert.equal(await evaluate(window, `window.__debugTransform.attachedId()`), pivotId, 'The gizmo should stay on the originally-selected node.');

        // A pure 90 degree rotation around Z, so the other node's expected revolved position can
        // be checked with plain 2D rotation trigonometry.
        await evaluate(window, `window.__debugTransform.simulateDragTo(0, 0, Math.PI / 2)`);

        // The `|| 0` normalizes -0 to 0 -- quaternion-to-Euler conversion can legitimately land
        // on -0 for a component that's mathematically exactly zero (e.g. via an internal
        // atan2(-0, 1)), which is numerically harmless but would otherwise fail a strict
        // deepEqual against a literal 0 below.
        const round2 = (values) => values.map((v) => Math.round(v * 100) / 100 || 0);
        const round3 = (values) => values.map((v) => Math.round(v * 1000) / 1000 || 0);

        const pivotEndPosition = await evaluate(window, `window.__debugTransform.nodeTransform(${pivotId}, 'position')`);
        assert.deepEqual(pivotEndPosition, pivotPosition, "The pivot node's own position must not move during a rotate drag.");
        const pivotEndRotation = round2(await evaluate(window, `window.__debugTransform.nodeTransform(${pivotId}, 'rotation')`));
        assert.deepEqual(pivotEndRotation, [0, 0, 1.57]);
        const otherEndRotation = round2(await evaluate(window, `window.__debugTransform.nodeTransform(${otherId}, 'rotation')`));
        assert.deepEqual(otherEndRotation, pivotEndRotation, "Every selected node's own orientation should spin by the same amount.");

        // Rotating (1, 0, 0) by 90 degrees around Z gives (0, 1, 0): the other node, 2 units
        // along X from the pivot, should end up 2 units along Y from the pivot instead of
        // staying put and just spinning in place around its own centre.
        const expectedOtherPosition = round3([pivotPosition[0], pivotPosition[1] + 2, pivotPosition[2]]);
        const otherEndPosition = round3(await evaluate(window, `window.__debugTransform.nodeTransform(${otherId}, 'position')`));
        assert.deepEqual(otherEndPosition, expectedOtherPosition, 'The other selected node should revolve around the pivot, not spin in place.');

        // Undo restores both nodes' position and rotation together in one step; redo re-applies
        // the whole group rotation again.
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, bubbles: true }))`);
        assert.deepEqual(await evaluate(window, `window.__debugTransform.nodeTransform(${pivotId}, 'rotation')`), [0, 0, 0]);
        assert.deepEqual(await evaluate(window, `window.__debugTransform.nodeTransform(${otherId}, 'rotation')`), [0, 0, 0]);
        assert.deepEqual(await evaluate(window, `window.__debugTransform.nodeTransform(${otherId}, 'position')`), otherStartPosition);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', metaKey: true, ctrlKey: true, shiftKey: true, bubbles: true }))`);
        const otherRedoPosition = round3(await evaluate(window, `window.__debugTransform.nodeTransform(${otherId}, 'position')`));
        assert.deepEqual(otherRedoPosition, expectedOtherPosition);

        // Cleanup: delete both newly-created nodes so this test doesn't leave the canvas
        // mutated for whatever runs after it.
        await evaluate(window, `document.querySelector('[data-tool="select"]').click()`);
        await evaluate(window, selectPivot);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true }))`);
        await evaluate(window, selectOther);
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true }))`);
    });

    await run('edge group meshes a selection, saves a shared equation, and supports detach/delete/undo', async () => {
        const nodeLabel = (name) => `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes(${JSON.stringify(name)}) && !label.textContent.includes('copy'))`;
        const nodeIdFor = (name) => `Number(${nodeLabel(name)}.closest('.node-label-container').dataset.node)`;
        // The move tool is active so #createNode's own "attach the gizmo to whatever was just
        // created" behavior lets simulateDragTo spread each node to a distinct position --
        // #createNode always spawns at the same [0, -0.7, 0], and three nodes left coincident
        // would leave every one of their CSS2D labels (and, in turn, every mesh edge's midpoint
        // bundle label) stacked at the same screen point, making click targeting ambiguous.
        await evaluate(window, `document.querySelector('[data-tool="move"]').click()`);
        const addNode = async (name, x) => {
            await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
            await evaluate(window, `(() => {
                document.querySelector('#newNodeName').value = ${JSON.stringify(name)};
                const values = { name: 'Temperature', symbol: 'temperature', value: '300', unit: 'K' };
                Object.entries(values).forEach(([field, value]) => {
                    const input = document.querySelector('.stateVariableRow [data-field="' + field + '"]');
                    input.value = value;
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                });
                document.querySelector('#createNode').click();
            })()`);
            // A newly created node's CSS2D label isn't inserted into the DOM synchronously with
            // model.nodes.push() -- CSS2DRenderer only appends it on the next throttled render
            // tick (~30fps). Three nodes created back to back with little work between them can
            // otherwise all fire before that tick ever lands.
            await waitFor(window, `Boolean(${nodeLabel(name)})`, `The label for "${name}" did not render.`);
            await evaluate(window, `window.__debugTransform.simulateDragTo(${x}, 0, 0)`);
        };
        const bundleLabel = (name) => `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes(${JSON.stringify(name)}))`;
        const relationshipCount = async () => Number((await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`)).match(/\d+/)[0]);
        // Real Shift-click's own screen-coordinate targeting is already covered by the
        // multi-selection copy/paste and bulk-disable tests above; this test's own subject is
        // edge-group behavior, so selection is built the same debug-hook way the multi-node
        // rotate/scale tests above build theirs.
        const selectAll = async (...names) => {
            await evaluate(window, `document.querySelector('[data-tool="select"]').click()`);
            // A real, exclusive click on the first node -- reliable now that addNode spreads
            // nodes apart -- clears whatever the selection happened to be left at by a prior
            // step; selectAdditive then builds the rest without depending on any more real
            // screen-coordinate targeting.
            await clickElement(window, nodeLabel(names[0]));
            await waitFor(window, `document.querySelectorAll('.node-label-container.selected').length === 1`,
                'The exclusive click did not select the first node.');
            let expected = 1;
            for (const name of names.slice(1)) {
                expected += 1;
                const id = await evaluate(window, nodeIdFor(name));
                const isSelected = () => evaluate(window, `document.querySelector('.node-label-container[data-node="${id}"]')?.classList.contains('selected')`);
                // Confirmed via instrumented runs: this environment's SwiftShader-throttled
                // render loop can occasionally leave a call's effect un-landed even several
                // seconds later (not just briefly stale). Retry the call itself, not just the
                // wait -- but only when this specific node's own selected state genuinely never
                // flipped; selectAdditive toggles, so re-issuing it after a call that actually
                // landed (just slow to be observed) would deselect the node instead of fixing
                // anything.
                for (let attempt = 0; attempt < 3; attempt++) {
                    if (!(await isSelected())) await evaluate(window, `window.__debugTransform.selectAdditive(${id})`);
                    try {
                        await waitFor(window, `document.querySelectorAll('.node-label-container.selected').length === ${expected}`,
                            `selectAdditive did not add "${name}" to the selection.`, 2000);
                        break;
                    } catch (error) {
                        if (attempt === 2) throw error;
                    }
                }
            }
        };

        await addNode('Group test A', 0);
        await addNode('Group test B', 3);
        await addNode('Group test C', 6);
        const before = await relationshipCount();

        await selectAll('Group test A', 'Group test B', 'Group test C');
        assert.equal(await evaluate(window, `document.querySelector('#createEdgeGroup').disabled`), false);

        const consoleMessages = await captureConsoleMessages(window, async () => {
            await evaluate(window, `document.querySelector('#createEdgeGroup').click()`);
            await waitFor(window, `!document.querySelector('#edgeGroupEditor').classList.contains('hidden')`, 'The edge group editor did not open.');
            // 3 members -> N(N-1) = 6 mesh edges: one directed edge each way per pair (see
            // docs/edgeDirectionality.md for why groups use directed pairs, not one bidirectional
            // edge per pair).
            await waitFor(window, `document.querySelectorAll('.modelStatus span')[1].textContent === '${before + 6} relationships'`, 'The mesh did not create 6 edges.');

            await evaluate(window, `(() => {
                const output = document.querySelector('#groupEquationOutput');
                output.value = 'temperature';
                output.dispatchEvent(new Event('change', { bubbles: true }));
                const field = document.querySelector('#groupMathField');
                field.setValue('\\\\mathrm{sourceTemperature}-\\\\mathrm{targetTemperature}');
                field.dispatchEvent(new Event('input', { bubbles: true }));
            })()`);
            await waitFor(window, `document.querySelector('#groupEquationDiagnostics').classList.contains('valid')`, 'The group equation did not validate.');
            // Autosaves live, like the node/edge editors -- the "change" event (matching a real
            // blur) is what finishes the equation-typing session and commits its undo step,
            // there is no separate Save action to click anymore.
            await evaluate(window, `document.querySelector('#groupMathField').dispatchEvent(new Event('change', { bubbles: true }))`);
        });
        assert.deepEqual(consoleMessages, [], 'Saving the edge group logged unexpected console messages.');
        assert.equal(await evaluate(window, `document.querySelector('#groupEquationDiagnostics').classList.contains('valid')`), true);

        await waitFor(window, `Boolean(${bundleLabel('Group test A')})`, 'A mesh edge bundle label was not available.');
        // Whole pixels: the camera's damping can keep a freshly framed label creeping by fractions of
        // a pixel for longer than the wait, which never matters for the click that follows.
        await waitForStableRect(window,
            `(() => { const el = ${bundleLabel('Group test A')}; const rect = el?.getBoundingClientRect(); return rect && JSON.stringify([rect.left, rect.top, rect.width, rect.height].map(Math.round)); })()`,
            'The mesh edge bundle label did not settle into a stable position.', 6000);
        // The bundle label's naive center point can be occluded by one of its own endpoint
        // nodes' labels at this camera framing (confirmed: document.elementFromPoint() there
        // resolves to the node's objectLabel, not the bundle label) -- find a point within the
        // bundle label's own rect that it actually owns for hit-testing before clicking it.
        const openedGroupMenu = await retryGesture(window,
            async () => {
                const point = await findUnoccludedPoint(window, bundleLabel('Group test A'));
                await window.mouseMove(point);
                await window.mouseDown(point, { button: 'right', clickCount: 1 });
                await window.mouseUp(point, { button: 'right', clickCount: 1 });
            },
            `!document.querySelector('#edgeContextMenu').classList.contains('hidden')`);
        assert.ok(openedGroupMenu, 'Right-clicking a mesh edge did not open its context menu after 5 attempts.');
        assert.equal(await evaluate(window, `document.querySelector('#edgeContextOpenGroup').hidden`), false);
        assert.equal(await evaluate(window, `document.querySelector('#edgeContextDelete').hidden`), true);
        await evaluate(window, `document.querySelector('#edgeContextOpenGroup').click()`);
        await waitFor(window, `!document.querySelector('#edgeGroupEditor').classList.contains('hidden')`, 'Opening the edge group from its context menu failed.');
        assert.equal(await evaluate(window, `document.querySelectorAll('#groupMembersList .groupMemberRow').length`), 3);

        await evaluate(window, `[...document.querySelectorAll('#groupMembersList .groupMemberRow')].find((row) => row.textContent.includes('Group test C')).querySelector('.removeBuilderRow').click()`);
        await waitFor(window, `document.querySelectorAll('#groupMembersList .groupMemberRow').length === 2`, 'Detach did not remove the member row.');
        // Detaching C from the 3-member mesh un-groups its 4 edges (both directions to A and to
        // B) as ordinary edges -- nothing is deleted, so the total is still all 6 mesh edges.
        assert.equal(await relationshipCount(), before + 6, 'Detaching a member should leave its edges behind as ordinary edges, not delete them.');

        await evaluate(window, `document.querySelector('[data-delete-edge-group]').click()`);
        await waitFor(window, `document.querySelector('#edgeGroupEditor').classList.contains('hidden')`, 'Deleting the group did not close its editor.');
        // Only the group's own remaining mesh (A<->B, the sole pair with both endpoints still
        // members: 2 directed edges) is removed; C's 4 now-ordinary edges are untouched.
        assert.equal(await relationshipCount(), before + 4, 'Deleting the group should remove only its remaining mesh edges, leaving the 4 detached ones.');

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await relationshipCount(), before + 6, 'Undoing the group deletion did not restore its edges.');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await relationshipCount(), before + 6, 'Undoing the detach did not restore membership.');

        // Cleanup: delete the three throwaway nodes (and, with them, every mesh/detached edge)
        // so this test doesn't leave the canvas mutated for whatever runs after it.
        await selectAll('Group test A', 'Group test B', 'Group test C');
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true }))`);
        assert.equal(await relationshipCount(), before);
    });

    await run('causal inference proposes a lagged edge and materializes it as one undoable step', async () => {
        // columnA follows a genuine AR(1) process, and columnB[t] = 3*columnA[t-1] + noise, with
        // columnA independent of columnB -- the same one-directional generative shape validated
        // in engine/tests/causalInferenceTests.cpp's inferGraphFindsAOneDirectionalLaggedEdge.
        function buildLaggedPairCsv(rowCount = 60) {
            const random = mulberry32(2002);
            const a = [0.2];
            for (let t = 1; t < rowCount; t += 1) a.push(0.5 * a[t - 1] + 0.3 * gaussianFrom(random));
            const lines = ['time,columnA,columnB'];
            for (let t = 0; t < rowCount; t += 1) {
                const previousA = t > 0 ? a[t - 1] : a[0];
                lines.push(`${t},${a[t]},${3.0 * previousA + 0.05 * gaussianFrom(random)}`);
            }
            return `${lines.join('\n')}\n`;
        }

        const nodeLabel = (name) => `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes(${JSON.stringify(name)}) && !label.textContent.includes('copy'))`;
        const nodeCount = async () => Number((await evaluate(window, `document.querySelectorAll('.modelStatus span')[0].textContent`)).match(/\d+/)[0]);
        const relationshipCount = async () => Number((await evaluate(window, `document.querySelectorAll('.modelStatus span')[1].textContent`)).match(/\d+/)[0]);

        // An existing node whose state symbol exactly matches the CSV's "columnA" header --
        // exercising the "match an existing state, don't create a new node" mapping path.
        // "columnB" has no existing match, exercising "create a new node" instead.
        await evaluate(window, `document.querySelector('[data-tool="move"]').click()`);
        await evaluate(window, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
        await evaluate(window, `(() => {
            document.querySelector('#newNodeName').value = 'Import test A';
            const values = { name: 'Column A', symbol: 'columnA', value: '0', unit: '' };
            Object.entries(values).forEach(([field, value]) => {
                const input = document.querySelector('.stateVariableRow [data-field="' + field + '"]');
                input.value = value;
                input.dispatchEvent(new Event('input', { bubbles: true }));
            });
            document.querySelector('#createNode').click();
        })()`);
        await waitFor(window, `Boolean(${nodeLabel('Import test A')})`, 'The label for "Import test A" did not render.');
        await evaluate(window, `window.__debugTransform.simulateDragTo(0, 0, 0)`);

        const nodesBefore = await nodeCount();
        const edgesBefore = await relationshipCount();

        await evaluate(window, `document.querySelector('#causalInferenceButton').click()`);
        await waitFor(window, `!document.querySelector('#causalInference').classList.contains('hidden')`, 'The causal inference card did not open.');

        // A real OS file-picker dialog can't be driven by this harness (no Playwright
        // setInputFiles/CDP bridge) -- window.__debugCausalInference.loadCsv exercises the exact
        // same code path the real file input's change handler calls.
        await evaluate(window, `window.__debugCausalInference.loadCsv(${JSON.stringify(buildLaggedPairCsv())})`);
        await waitFor(window, `!document.querySelector('#causalInferenceMappingSection').hidden`, 'The column mapping section did not appear.');
        assert.equal(await evaluate(window, `document.querySelectorAll('#causalInferenceMappingRows .causalInferenceMappingRow').length`), 2);
        const mappingSelectValue = (index) => evaluate(window, `document.querySelectorAll('#causalInferenceMappingRows select')[${index}].value`);
        assert.notEqual(await mappingSelectValue(0), 'create', 'columnA should auto-match the existing node/state, not default to creating one.');
        assert.equal(await mappingSelectValue(1), 'create', 'columnB has no existing match and should default to creating a new node.');

        await evaluate(window, `document.querySelector('#runCausalInference').click()`);
        await waitFor(window, `!document.querySelector('#causalInferenceCandidatesSection').hidden`, 'The candidate list did not appear.', 15000);
        assert.equal(await evaluate(window, `
            [...document.querySelectorAll('#causalInferenceCandidateRows .causalInferenceCandidateMain')].some((span) => span.textContent.includes('columnA → columnB'))
        `), true, 'Expected a columnA -> columnB candidate.');
        assert.equal(await evaluate(window, `
            [...document.querySelectorAll('#causalInferenceCandidateRows .causalInferenceCandidateMain')].some((span) => span.textContent.includes('columnB → columnA'))
        `), false, 'Did not expect a spurious columnB -> columnA candidate.');
        assert.equal(await evaluate(window, `document.querySelector('#causalInferenceCandidateRows .causalInferenceCandidateTag.continuousLagged') !== null`), true,
            'Expected the accepted candidate to be tagged continuousLagged.');

        const consoleMessages = await captureConsoleMessages(window, async () => {
            await evaluate(window, `document.querySelector('#commitCausalInference').click()`);
            await waitFor(window, `document.querySelector('#causalInference').classList.contains('hidden')`, 'The causal inference card did not close after commit.', 15000);
        });
        assert.deepEqual(consoleMessages.filter((message) => /error|uncaught|exception/i.test(message)), []);

        assert.equal(await nodeCount(), nodesBefore + 1, 'Committing should have created exactly one new node for columnB.');
        assert.equal(await relationshipCount(), edgesBefore + 1, 'Committing should have created exactly one new edge.');

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await nodeCount(), nodesBefore, 'Undo should remove the created node.');
        assert.equal(await relationshipCount(), edgesBefore, 'Undo should remove the created edge.');

        await evaluate(window, `document.querySelector('#redoButton').click()`);
        assert.equal(await nodeCount(), nodesBefore + 1, 'Redo should restore the created node.');
        assert.equal(await relationshipCount(), edgesBefore + 1, 'Redo should restore the created edge.');

        // Cleanup: undo the import again, then delete the throwaway "Import test A" node so this
        // test doesn't leave the canvas mutated for whatever runs after it. replaceModelContents
        // (which every undo/redo above runs through) rebuilds every CSS2D label from scratch,
        // and that render is throttled to ~30fps -- after three rapid-fire history operations,
        // clickElement's own getBoundingClientRect() needs the label to have actually reappeared
        // in the DOM first.
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await nodeCount(), nodesBefore);
        await waitFor(window, `Boolean(${nodeLabel('Import test A')})`, 'The label for "Import test A" did not re-render after undo.');
        await evaluate(window, `document.querySelector('[data-tool="select"]').click()`);
        await clickElement(window, nodeLabel('Import test A'));
        await waitFor(window, `document.querySelector('#editNodeName').value === 'Import test A'`, 'Clicking "Import test A" did not open its node editor.');
        await evaluate(window, `window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true }))`);
        assert.equal(await evaluate(window, `document.querySelector('#nodeEditor').classList.contains('hidden')`), true,
            'Deleting a node should close the editor that was open on it.');
    });

    await run('causal inference with curvature allowed recovers a quadratic edge equation', async () => {
        // Same deterministic-noise reasoning and AR(1)-driven columnP as the lagged-pair test
        // above, but columnQ[t] = 2*columnP[t-1] + 0.5*columnP[t-1]^2 + noise -- an exact
        // quadratic relationship, matching engine/tests/causalInferenceTests.cpp's
        // makeQuadraticPairSeries. That C++ test found 300 rows necessary for a robust fit at
        // this construction (fewer let a spurious reverse edge slip through finite-sample
        // overfitting on the richer degree-2 feature set); this test uses the same row count.
        function buildQuadraticPairCsv(rowCount = 300) {
            const random = mulberry32(5005);
            const p = [0.2];
            for (let t = 1; t < rowCount; t += 1) p.push(0.5 * p[t - 1] + 0.3 * gaussianFrom(random));
            const lines = ['time,columnP,columnQ'];
            for (let t = 0; t < rowCount; t += 1) {
                const previousP = t > 0 ? p[t - 1] : p[0];
                lines.push(`${t},${p[t]},${2.0 * previousP + 0.5 * previousP * previousP + 0.05 * gaussianFrom(random)}`);
            }
            return `${lines.join('\n')}\n`;
        }

        await evaluate(window, `document.querySelector('#causalInferenceButton').click()`);
        await waitFor(window, `!document.querySelector('#causalInference').classList.contains('hidden')`, 'The causal inference card did not open.');

        await evaluate(window, `window.__debugCausalInference.loadCsv(${JSON.stringify(buildQuadraticPairCsv())})`);
        await waitFor(window, `!document.querySelector('#causalInferenceMappingSection').hidden`, 'The column mapping section did not appear.');

        // Checks actual rendered visibility (getComputedStyle), not just the hidden DOM property --
        // .editorField's own `display: grid` is an author-stylesheet rule and so overrides the
        // browser's default `[hidden] { display: none }` regardless of selector specificity
        // (author rules beat user-agent rules at equal specificity); asserting only the property
        // previously let a real "field stays visible under Linear" bug pass silently.
        assert.equal(await isRenderedVisible(window, '#causalInferenceDegreeValueField'), false,
            '"Linear only" (the default) should not show the degree input.');

        await evaluate(window, `(() => {
            const select = document.querySelector('#causalInferenceDegreeMode');
            select.value = 'fixed';
            select.dispatchEvent(new Event('change', { bubbles: true }));
            document.querySelector('#causalInferenceDegreeValue').value = '2';
        })()`);
        assert.equal(await isRenderedVisible(window, '#causalInferenceDegreeValueField'), true,
            'Selecting "Allow curvature up to degree..." should reveal the degree input.');

        await evaluate(window, `document.querySelector('#runCausalInference').click()`);
        await waitFor(window, `!document.querySelector('#causalInferenceCandidatesSection').hidden`, 'The candidate list did not appear.', 15000);
        assert.equal(await evaluate(window, `
            [...document.querySelectorAll('#causalInferenceCandidateRows .causalInferenceCandidateMain')].some((span) => span.textContent.includes('columnP → columnQ'))
        `), true, 'Expected a columnP -> columnQ candidate.');
        assert.equal(await evaluate(window, `
            [...document.querySelectorAll('#causalInferenceCandidateRows .causalInferenceCandidateMain')].some((span) => span.textContent.includes('columnQ → columnP'))
        `), false, 'Did not expect a spurious columnQ -> columnP candidate.');

        // The candidate list UI has no dedicated display for fitted polynomial terms (only
        // source/target/lag/score/provenance), so this reads the raw candidate data the "Allow
        // curvature" config actually produced -- the real thing this test needs to prove, since
        // committing and reopening the resulting edge only re-renders the same terms through
        // latexForFittedEdge, not an independent check.
        const candidates = await evaluate(window, `window.__debugCausalInference.candidates()`);
        const aToB = candidates.find((candidate) => candidate.sourceColumn === 'columnP' && candidate.targetColumn === 'columnQ');
        assert.ok(aToB, 'Expected a columnP -> columnQ candidate in the raw candidate data.');
        assert.ok(aToB.terms.some((term) => term.degree === 2),
            `Expected a degree-2 term with "Allow curvature up to degree 2" selected, got terms: ${JSON.stringify(aToB.terms)}`);

        const consoleMessages = await captureConsoleMessages(window, async () => {
            await evaluate(window, `document.querySelector('#commitCausalInference').click()`);
            await waitFor(window, `document.querySelector('#causalInference').classList.contains('hidden')`, 'The causal inference card did not close after commit.', 15000);
        });
        assert.deepEqual(consoleMessages.filter((message) => /error|uncaught|exception/i.test(message)), []);

        // A node created by causal inference should default to a sphere (commitCausalInference's
        // addNode operations), not the generic assistant/manual default of a box.
        const nodeLabel = (name) => `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes(${JSON.stringify(name)}) && !label.textContent.includes('copy'))`;
        await waitFor(window, `Boolean(${nodeLabel('columnP')})`, 'The label for the newly-created "columnP" node did not render.');
        await clickElement(window, nodeLabel('columnP'));
        await waitFor(window, `!document.querySelector('#nodeEditor').classList.contains('hidden') && document.querySelector('#editNodeName').value === 'columnP'`, 'Clicking the new columnP node did not open its node editor.');
        assert.equal(await evaluate(window, `document.querySelector('#editNodeShape').value`), 'sphere',
            'A node created by causal inference should default to a sphere shape.');
        await evaluate(window, `document.querySelector('#nodeEditor [data-close-card]').click()`);

        // Cleanup: undo the commit (removes both new nodes and the edge in one step, mirroring
        // how commitCausalInference records a single history entry), leaving the canvas as found.
        const nodesBefore = await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[0].textContent.match(/\\d+/)[0])`);
        const edgesBefore = await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[1].textContent.match(/\\d+/)[0])`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[0].textContent.match(/\\d+/)[0])`), nodesBefore - 2,
            'Undo should remove both nodes created for columnP and columnQ.');
        assert.equal(await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[1].textContent.match(/\\d+/)[0])`), edgesBefore - 1,
            'Undo should remove the created edge.');
    });

    await run('causal inference recovers most of a realistic 8-node, 12-edge system', async () => {
        // An 8-node electronics-enclosure thermal/vibration system: 3 independent AR(1) roots
        // (ambientTemperature, motorLoad, solarIrradiance), 5 downstream nodes, 12 true lagged
        // edges (one quadratic: componentTemperature -> thermalStress). Originally built to
        // generate real end-to-end assets for a blog post about this feature, running it for real
        // surfaced a genuine engine bug: the stage-1 skeleton screened pairs using CONTEMPORANEOUS
        // (same-timestep) partial correlation, which is a poor proxy for a lagged relationship once
        // a graph has more than a couple of variables -- confirmed empirically (a true edge showed
        // near-zero contemporaneous partial correlation while an unrelated pair showed a misleading
        // one purely from shared AR-driven persistence). Fixed in causalInference.cpp by screening
        // with LAG-1 partial correlation instead (see its own comment there and
        // docs/causalInference.md). This test is the regression guard for that fix, and for two
        // remaining, *structural* (not fixable by more data or a bigger coefficient) collinearity
        // limitations found during the same investigation, both intentionally left unasserted
        // below: ambientTemperature and motorLoad each have a direct edge to a target that is ALSO
        // reachable through a near-single-parent mediator (componentTemperature's chain into
        // thermalStress; motorLoad's own near-deterministic proxy vibrationAmplitude into
        // fatigueAccumulation) -- ridge consistently attributes the shared effect to the mediator,
        // at any sample size. 10 of the 12 true edges are recovered; this test asserts exactly
        // those 10, plus that no *other* spurious candidate reaches a high (>= 0.5) score. Also
        // doubles as the regression guard for the continuous-time rate transform (every fitted
        // coefficient here is unit-compatible with Konjugate's dx/dt, not a raw discrete-step
        // multiplier -- see docs/proposals/continuousTimeConversion.md) and for self-terms
        // committing correctly as addSourceTerm operations, not edges.
        // [source, target, degree, trueCoefficient] terms for exactly the 10 unique edges this
        // construction recovers (11 entries: componentTemperature -> thermalStress carries both a
        // degree-1 and a degree-2 term on the same edge) -- see the comment above for the 2
        // structurally-unrecoverable exceptions.
        const expectedEdges = [
            ['ambientTemperature', 'enclosureTemperature', 1, 2.0],
            ['solarIrradiance', 'enclosureTemperature', 1, 1.5],
            ['motorLoad', 'vibrationAmplitude', 1, 3.0],
            ['ambientTemperature', 'componentTemperature', 1, 1.0],
            ['motorLoad', 'componentTemperature', 1, 1.0],
            ['enclosureTemperature', 'componentTemperature', 1, 2.5],
            ['componentTemperature', 'thermalStress', 1, 3.5],
            ['componentTemperature', 'thermalStress', 2, 0.8],
            ['vibrationAmplitude', 'fatigueAccumulation', 1, 1.2],
            ['componentTemperature', 'fatigueAccumulation', 1, 1.0],
            ['thermalStress', 'fatigueAccumulation', 1, 1.5]
        ];

        await evaluate(window, `document.querySelector('#causalInferenceButton').click()`);
        await waitFor(window, `!document.querySelector('#causalInference').classList.contains('hidden')`, 'The causal inference card did not open.');
        await evaluate(window, `window.__debugCausalInference.loadCsv(${JSON.stringify(buildThermalSystemCsv())})`);
        await waitFor(window, `!document.querySelector('#causalInferenceMappingSection').hidden`, 'The column mapping section did not appear.');
        assert.equal(await evaluate(window, `document.querySelectorAll('#causalInferenceMappingRows .causalInferenceMappingRow').length`), 8,
            'Expected one mapping row per CSV column.');

        await evaluate(window, `(() => {
            const select = document.querySelector('#causalInferenceDegreeMode');
            select.value = 'auto';
            select.dispatchEvent(new Event('change', { bubbles: true }));
            document.querySelector('#causalInferenceDegreeValue').value = '2';
        })()`);
        await evaluate(window, `document.querySelector('#runCausalInference').click()`);
        await waitFor(window, `!document.querySelector('#causalInferenceCandidatesSection').hidden`, 'The candidate list did not appear.', 20000);

        const candidates = await evaluate(window, `window.__debugCausalInference.candidates()`);
        for (const [source, target, degree, trueCoefficient] of expectedEdges) {
            const candidate = candidates.find((c) => c.sourceColumn === source && c.targetColumn === target);
            assert.ok(candidate, `Expected a ${source} -> ${target} candidate.`);
            const term = candidate.terms.find((t) => t.degree === degree);
            assert.ok(term, `Expected a degree-${degree} term on ${source} -> ${target}, got: ${JSON.stringify(candidate.terms)}`);
            const relativeError = Math.abs((term.coefficient - trueCoefficient) / trueCoefficient);
            assert.ok(relativeError < 0.25,
                `${source} -> ${target} degree ${degree}: expected ~${trueCoefficient}, got ${term.coefficient} (${(relativeError * 100).toFixed(1)}% off).`);
        }
        const expectedPairs = new Set(expectedEdges.map(([s, t]) => `${s}->${t}`));
        const otherCandidates = candidates.filter((c) => !expectedPairs.has(`${c.sourceColumn}->${c.targetColumn}`));
        for (const candidate of otherCandidates) {
            assert.ok(candidate.score < 0.5,
                `Unexpected candidate ${candidate.sourceColumn} -> ${candidate.targetColumn} has a high score (${candidate.score}), not a low-confidence residual.`);
        }

        // Every fitted coefficient here (and every target's own self-lag, otherwise discarded) is
        // a continuous-time rate, not a raw discrete-step multiplier -- see
        // docs/proposals/continuousTimeConversion.md. This CSV's own time column is 0,1,2,...
        // (timeStep == 1), so the exact-Euler-match transform (rate = coefficient/timeStep) leaves
        // cross-term coefficients numerically unchanged, which is why the direct trueCoefficient
        // comparison above still holds; what's new here is provenance and the self-terms.
        for (const candidate of candidates) {
            assert.notEqual(candidate.provenance, 'lagged',
                `A lagged candidate should be tagged continuousLagged, never the pre-consolidation discrete "lagged" `
                + `tag (${candidate.sourceColumn} -> ${candidate.targetColumn} was tagged ${candidate.provenance}).`);
        }
        const selfTerms = await evaluate(window, `window.__debugCausalInference.selfTerms()`);
        const laggedTargets = new Set(candidates.filter((c) => c.provenance === 'continuousLagged').map((c) => c.targetColumn));
        const selfTermTargets = new Set(selfTerms.map((t) => t.targetColumn));
        for (const target of laggedTargets) {
            assert.ok(selfTermTargets.has(target), `Expected a self-term for ${target}, which has an accepted continuous-time edge.`);
        }
        for (const term of selfTerms) {
            assert.ok(Number.isFinite(term.rate), `Self-term rate for ${term.targetColumn} should be a finite number, got ${term.rate}.`);
        }

        // Deselect any low-confidence residual candidate before committing, exactly as a real
        // reviewer would -- this also exercises the checkbox accept/reject path, which neither
        // existing causal-inference test does (both accept every candidate by default).
        for (const candidate of otherCandidates) {
            await evaluate(window, `(() => {
                const row = [...document.querySelectorAll('#causalInferenceCandidateRows .causalInferenceCandidateRow')]
                    .find((r) => r.querySelector('.causalInferenceCandidateMain').textContent.includes(${JSON.stringify(`${candidate.sourceColumn} → ${candidate.targetColumn}`)}));
                row.querySelector('input[type="checkbox"]').click();
            })()`);
        }

        const nodesBefore = await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[0].textContent.match(/\\d+/)[0])`);
        const edgesBefore = await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[1].textContent.match(/\\d+/)[0])`);
        const consoleMessages = await captureConsoleMessages(window, async () => {
            await evaluate(window, `document.querySelector('#commitCausalInference').click()`);
            await waitFor(window, `document.querySelector('#causalInference').classList.contains('hidden')`, 'The causal inference card did not close after commit.', 15000);
        });
        assert.deepEqual(consoleMessages.filter((message) => /error|uncaught|exception/i.test(message)), []);
        assert.equal(await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[0].textContent.match(/\\d+/)[0])`), nodesBefore + 8,
            'Committing should have created one new node per CSV column (8).');
        assert.equal(await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[1].textContent.match(/\\d+/)[0])`), edgesBefore + expectedPairs.size,
            `Committing should have created exactly the ${expectedPairs.size} accepted edges (componentTemperature -> thermalStress is one edge with two terms).`);

        // Candidates have no dedicated node/edge-style count to check self-terms landed correctly
        // against (a source term is local to a node, not a separate relationship on the canvas) --
        // read the committed document directly. Every self-term target should have exactly one
        // sourceTerm whose expression references that node's own state symbol (not a
        // source/target-prefixed edge symbol).
        const committedDocument = await evaluate(window, `window.__debugCausalInference.document()`);
        for (const target of laggedTargets) {
            const node = committedDocument.nodes.find((candidateNode) => candidateNode.name === target);
            assert.ok(node, `Expected a committed node named ${target}.`);
            assert.equal(node.sourceTerms.length, 1, `Expected exactly one source term on ${target}, got ${node.sourceTerms.length}.`);
            const symbol = node.states[0].symbol;
            assert.ok(node.sourceTerms[0].expression.includes(symbol),
                `${target}'s source term should reference its own state symbol "${symbol}", got: ${node.sourceTerms[0].expression}`);
        }

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[0].textContent.match(/\\d+/)[0])`), nodesBefore,
            'Undo should remove all 8 created nodes, and with them every source term that lived on them.');
        assert.equal(await evaluate(window, `Number(document.querySelectorAll('.modelStatus span')[1].textContent.match(/\\d+/)[0])`), edgesBefore,
            'Undo should remove all created edges.');
    });

    await run('digital-twin tuning fits source-term and edge parameters together from CSV and applies them atomically', async () => {
        // Add an independently-owned source-term parameter to Enclosed air. Its constant
        // derivative contribution and the edge's transfer coefficient affect the measured
        // target trajectory differently, so the optimizer can identify both in one fit.
        await waitFor(window, `Boolean([...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Enclosed air')))`,
            'The "Enclosed air" label did not settle back into the DOM after the previous test\'s undo.');
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Enclosed air')).click()`);
        await waitFor(window, `!document.querySelector('#nodeEditor').classList.contains('hidden')`, 'Enclosed air node editor did not open.');
        await evaluate(window, `document.querySelector('#editAddSourceTerm').click()`);
        await waitFor(window, `document.querySelectorAll('.sourceTermOpen').length > 0`, 'The new source term did not appear in the node editor.');
        await evaluate(window, `[...document.querySelectorAll('.sourceTermOpen')].pop().click()`);
        await waitFor(window, `!document.querySelector('#sourceTermEditor').classList.contains('hidden')`, 'Source-term editor did not open.');
        await evaluate(window, `document.querySelector('#termAddParameter').click()`);
        await evaluate(window, `(() => {
            const row = document.querySelector('#termParameters .editorParameterRow');
            row.querySelector('[data-field="name"]').value = 'Source bias';
            row.querySelector('[data-field="symbol"]').value = 'sourceBias';
            row.querySelector('[data-field="value"]').value = '0.5';
            row.querySelector('[data-field="symbol"]').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await evaluate(window, `[...document.querySelectorAll('#termStateReferenceChips button')].find((button) => button.textContent === 'sourceBias').click()`);
        await waitFor(window, `document.querySelector('#termEquationDiagnostics').classList.contains('valid')`, 'The source-bias equation did not become valid.');
        await evaluate(window, `(() => {
            const row = document.querySelector('#termParameters .editorParameterRow');
            const checkbox = row.querySelector('[data-field="tunable"]');
            checkbox.checked = true;
            checkbox.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await evaluate(window, `(() => {
            const row = document.querySelector('#termParameters .editorParameterRow');
            row.querySelector('[data-tuning-field="minimum"]').value = '-5';
            row.querySelector('[data-tuning-field="maximum"]').value = '5';
            row.querySelector('[data-tuning-field="minimum"]').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await evaluate(window, `document.querySelector('#sourceTermEditor [data-close-card]').click(); document.querySelector('#nodeEditor [data-close-card]').click()`);

        // Reuses the same edge the "live parameters" test above already opens -- Thermal
        // Management's Battery module -> Enclosed air relationship, whose one parameter is
        // "heatTransferCoefficient".
        await waitFor(window, `Boolean([...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')))`,
            'The "Battery module" label did not settle back into the DOM after the previous test\'s undo.');
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        await waitFor(window, `Boolean([...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module')))`,
            'The "Battery module" relationship bundle label did not appear.');
        await evaluate(window, `[...document.querySelectorAll('.bundleLabel')].find((label) => label.textContent.includes('Battery module')).click()`);
        await waitFor(window, `!document.querySelector('#edgeEditor').classList.contains('hidden')`, 'Edge editor did not open.');
        await waitFor(window, `document.querySelector('#edgeEditorParameters .editorParameterRow') !== null`, 'No parameter row rendered for this edge.');

        const beforeValue = await evaluate(window, `Number(document.querySelector('#edgeEditorParameters .editorParameterRow:first-child [data-field="value"]').value)`);
        assert.equal(await evaluate(window, `document.querySelector('#edgeEditorParameters .editorParameterRow:first-child .parameterTuningFields').hidden`), true);

        await evaluate(window, `(() => {
            const row = document.querySelector('#edgeEditorParameters .editorParameterRow:first-child');
            const checkbox = row.querySelector('[data-field="tunable"]');
            checkbox.checked = true;
            checkbox.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `document.querySelector('#edgeEditorParameters .editorParameterRow:first-child .parameterTuningFields').hidden`), false,
            'Checking "Tunable" should reveal the fitting-bounds fields.');
        await evaluate(window, `(() => {
            const row = document.querySelector('#edgeEditorParameters .editorParameterRow:first-child');
            row.querySelector('[data-tuning-field="minimum"]').value = '0';
            row.querySelector('[data-tuning-field="maximum"]').value = '50';
            row.querySelector('[data-tuning-field="minimum"]').dispatchEvent(new Event('change', { bubbles: true }));
            row.querySelector('[data-tuning-field="maximum"]').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);

        const document_ = await evaluate(window, `window.__debugCausalInference.document()`);
        const tunableEdge = document_.edges.find((edge) => (edge.parameters ?? []).some((parameter) => parameter.tuning));
        assert.ok(tunableEdge, 'Expected an edge with a tunable parameter in the committed document.');
        const tunableParameter = tunableEdge.parameters.find((parameter) => parameter.tuning);
        assert.deepEqual(tunableParameter.tuning, { minimum: 0, maximum: 50 });
        const tunableSourceTerm = document_.nodes.flatMap((node) => (node.sourceTerms ?? []).map((term) => ({ node, term })))
            .find(({ term }) => (term.parameters ?? []).some((parameter) => parameter.tuning));
        assert.ok(tunableSourceTerm, 'Expected a source term with a tunable parameter in the committed document.');
        const tunableSourceParameter = tunableSourceTerm.term.parameters.find((parameter) => parameter.tuning);
        assert.equal(tunableSourceParameter.symbol, 'sourceBias');
        assert.deepEqual(tunableSourceParameter.tuning, { minimum: -5, maximum: 5 });
        const sourceBeforeValue = tunableSourceParameter.value;
        const targetStateId = tunableEdge.equationModel?.output?.stateId ?? tunableEdge.target.stateId;
        const targetNode = document_.nodes.find((node) => (node.states ?? []).some((state) => state.id === targetStateId));
        const targetState = targetNode.states.find((state) => state.id === targetStateId);

        // A small, arbitrary measured series -- numerical recovery against real physics is
        // already proven at the C++ level (engine/tests/parameterFittingTests.cpp); this exercises
        // the UI's full mapping/run/review/apply path against the real engine end to end.
        const csvLines = [`time,${targetState.symbol}`];
        for (let row = 0; row < 10; row += 1) csvLines.push(`${row},${(targetState.initialValue ?? 290) + row}`);

        await evaluate(window, `document.querySelector('#parameterTuningButton').click()`);
        await waitFor(window, `!document.querySelector('#parameterTuning').classList.contains('hidden')`, 'Tuning panel did not open.');
        // The backend dropdown is populated from the real engine binary's own `capabilities`
        // report (window.engine.capabilities()), not a hardcoded list -- assert it actually
        // matches what that binary reports, not just that something got populated.
        await waitFor(window, `document.querySelector('#parameterTuningBackend').options.length > 0`,
            'The optimizer backend dropdown was not populated from the engine\'s capabilities report.');
        const reportedBackendIds = (await evaluate(window, `window.engine.capabilities()`)).capabilities.optimizerBackendIds;
        const renderedBackendIds = await evaluate(window, `[...document.querySelectorAll('#parameterTuningBackend option')].map((option) => option.value)`);
        assert.deepEqual(renderedBackendIds, reportedBackendIds,
            'The backend dropdown should list exactly the ids the engine binary itself reports supporting.');
        await evaluate(window, `window.__debugParameterTuning.loadCsv(${JSON.stringify(csvLines.join('\n'))})`);
        await waitFor(window, `!document.querySelector('#parameterTuningParametersSection').hidden`, 'Tunable parameters section did not appear.', 5000);
        assert.equal(await evaluate(window, `document.querySelectorAll('#parameterTuningParameterRows > div').length`), 2);

        await evaluate(window, `document.querySelector('#runParameterTuning').click()`);
        await waitFor(window, `!document.querySelector('#parameterTuningReviewSection').hidden`, 'Review section did not appear after running the fit.', 60000);
        const report = await evaluate(window, `window.__debugParameterTuning.report()`);
        assert.equal(report.finalParameters.length, 2);
        assert.deepEqual(new Set(report.finalParameters.map((entry) => entry.parameterId)), new Set([tunableParameter.id, tunableSourceParameter.id]));
        assert.equal(await evaluate(window, `document.querySelectorAll('#parameterTuningReviewRows label').length`), 2);

        // renderParameterTuningComparison() runs one more simulation with the fitted values
        // applied and plots it against the measured CSV; it catches its own errors into a status
        // message rather than throwing, so this checks the plot actually rendered rather than
        // just that nothing threw.
        await waitFor(window,
            `!document.querySelector('#parameterTuningComparisonStatus').textContent.includes('Running the fitted model')`,
            'The measured-vs-simulated comparison never finished.', 30000);
        assert.equal(await evaluate(window, `document.querySelector('#parameterTuningComparisonStatus').textContent`), '',
            'Expected the measured-vs-simulated comparison to succeed with no error status.');
        assert.equal(await evaluate(window, `document.querySelector('#parameterTuningComparisonPlot').hidden`), false);
        assert.equal(await evaluate(window, `document.querySelector('#parameterTuningComparisonPlot').data?.length`), 3,
            'Expected one measured, one simulated and one residual trace for the single mapped signal.');

        await evaluate(window, `document.querySelector('#commitParameterTuning').click()`);
        await waitFor(window, `document.querySelector('#parameterTuning').classList.contains('hidden') || document.querySelector('#parameterTuningReviewStatus').textContent.length > 0`, 'Tuning apply did not complete.', 5000);
        assert.equal(await evaluate(window, `document.querySelector('#parameterTuningReviewStatus').textContent`), '', 'Applying both fitted parameter types should not report an error.');
        assert.equal(await evaluate(window, `document.querySelector('#parameterTuning').classList.contains('hidden')`), true, 'Tuning panel did not close after apply.');
        const after = await evaluate(window, `window.__debugCausalInference.document()`);
        const appliedParameter = after.edges.flatMap((edge) => edge.parameters ?? []).find((parameter) => parameter.id === tunableParameter.id);
        const appliedSourceParameter = after.nodes.flatMap((node) => (node.sourceTerms ?? []).flatMap((term) => term.parameters ?? []))
            .find((parameter) => parameter.id === tunableSourceParameter.id);
        assert.equal(appliedParameter.value, report.finalParameters.find((entry) => entry.parameterId === tunableParameter.id).value,
            'The committed edge should carry its fitted value once applied.');
        assert.equal(appliedSourceParameter.value, report.finalParameters.find((entry) => entry.parameterId === tunableSourceParameter.id).value,
            'The committed source term should carry its fitted value once applied.');

        await evaluate(window, `document.querySelector('#undoButton').click()`);
        const afterUndo = await evaluate(window, `window.__debugCausalInference.document()`);
        const undoneParameter = afterUndo.edges.flatMap((edge) => edge.parameters ?? []).find((parameter) => parameter.id === tunableParameter.id);
        const undoneSourceParameter = afterUndo.nodes.flatMap((node) => (node.sourceTerms ?? []).flatMap((term) => term.parameters ?? []))
            .find((parameter) => parameter.id === tunableSourceParameter.id);
        assert.equal(undoneParameter.value, beforeValue, 'Undo should restore the pre-fit parameter value in one step.');
        assert.equal(undoneSourceParameter.value, sourceBeforeValue, 'The same undo should restore the source-term parameter value.');
        await evaluate(window, `document.querySelector('#redoButton').click()`);
    });

    await run('Results Analysis timeline seek only redraws the scatter trail once the run is completed, not while running or paused', async () => {
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const diagnosticWindow = await driver.waitForNewHandle(before);
        await waitFor(diagnosticWindow, `document.querySelector('.documentTitle')`, 'Diagnostic window did not finish loading.');

        await evaluate(diagnosticWindow, `document.querySelector('#exampleButton').click()`);
        await waitFor(diagnosticWindow, `document.querySelector('#examplesExplorerDialog').open`, 'Examples explorer did not open in the diagnostic window.');
        await waitFor(diagnosticWindow, `Boolean([...document.querySelectorAll('.examplesExplorerItem')].find((item) => item.querySelector('b').textContent === 'Thermal Management'))`, 'Examples explorer did not populate in the diagnostic window.');
        await evaluate(diagnosticWindow, `[...document.querySelectorAll('.examplesExplorerItem')].find((item) => item.querySelector('b').textContent === 'Thermal Management').click()`);
        await evaluate(diagnosticWindow, `document.querySelector('#examplesExplorerLoad').click()`);
        await waitFor(diagnosticWindow, `document.querySelectorAll('.node-label-container').length === 3`, 'Thermal example did not load in the diagnostic window.');

        // #runButton stays disabled until the C++ engine's async post-load model validation
        // finishes (renderValidationPending/-Status in renderer.mjs) -- clicking a disabled
        // button never dispatches 'click' at all, so a run started before this settles is a
        // silent no-op, not a visible failure.
        await waitFor(diagnosticWindow, `!document.querySelector('#runButton').disabled`, 'Model validation did not complete before Run could be started.', 10000);

        // A real ~10 wall-clock-second run under realTime pacing, matching the reported repro
        // exactly, rather than the near-instantaneous runs the rest of this suite uses.
        await openRunDialog(diagnosticWindow);
        await evaluate(diagnosticWindow, `(() => { document.querySelector('#runTargetTime').value = '10'; document.querySelector('#runOnlineMode').checked = true; document.querySelector('#runOnlineMode').dispatchEvent(new Event('change', { bubbles: true })); document.querySelector('#runPacingMode').value = 'realTime'; document.querySelector('#startRun').click(); })()`);
        await waitFor(diagnosticWindow, `document.querySelector('.resultMode small').textContent === 'Running · model locked'`, 'C++ simulation did not enter its running state in the diagnostic window.', 10000);

        // Pause rather than staying live: while running, the Analysis window's own timeline
        // value keeps auto-advancing on its own (a separate visualizerHostTimelineChange
        // broadcast tracking the live playhead, src/main.mjs), which would make a seek attempt's
        // effect indistinguishable from just the natural clock ticking during this test's own
        // waits. Paused, the timeline is static, so any redraw can only be the seek itself.
        await evaluate(diagnosticWindow, `document.querySelector('#simulationPauseResume').click()`);
        await waitFor(diagnosticWindow, `document.querySelector('.resultMode small').textContent === 'Paused · model locked'`, 'Simulation did not pause.', 5000);

        await waitFor(diagnosticWindow, `Boolean(document.querySelector('.addonTool[data-addon-id="konjugate.resultPlotViewer"][data-command-id="openAnalysis"]:not([hidden])'))`, 'Analysis toolstrip command did not appear during a live run.');
        await evaluate(diagnosticWindow, `document.querySelector('.addonTool[data-addon-id="konjugate.resultPlotViewer"][data-command-id="openAnalysis"]').click()`);
        const analysisWindow = await driver.waitForNewHandle([...before, diagnosticWindow]);
        await waitFor(analysisWindow, `document.querySelectorAll('.signalOption').length > 0`, 'Results Analysis did not load signals during a live run.', 5000);
        await evaluate(analysisWindow, `(() => {
            const options = (id) => [...document.querySelector(id).options].map((option) => option.value);
            const xOptions = options('#scatterX');
            const yOptions = options('#scatterY').filter((value) => value !== xOptions[0]);
            document.querySelector('#scatterX').value = xOptions[0];
            document.querySelector('#scatterY').value = yOptions[0] ?? xOptions[0];
            document.querySelector('#chartMode').value = 'scatter';
            document.querySelector('#chartMode').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await waitFor(analysisWindow, `document.querySelector('#analysisPlot').data[0]?.type === 'scatter'`, 'Scatter mode did not render during a live run.', 3000);

        // A genuine mouse drag on the native range input, not a scripted .value= + dispatchEvent
        // -- Chromium moves a native <input type=range>'s own displayed value on a real click
        // regardless of any JS listener's outcome, so this is the one gesture that can actually
        // distinguish "the seek request was accepted" from "the slider just looks like it moved."
        const dragTimeline = async (fraction) => {
            const rect = await evaluate(analysisWindow, `(() => { const r = document.querySelector('#timeline').getBoundingClientRect(); return { left: r.left, top: r.top + r.height / 2, width: r.width }; })()`);
            const start = { x: Math.round(rect.left + 4), y: Math.round(rect.top) };
            const end = { x: Math.round(rect.left + rect.width * fraction), y: Math.round(rect.top) };
            await analysisWindow.mouseMove(start);
            await analysisWindow.mouseDown(start, { button: 'left', clickCount: 1 });
            await analysisWindow.mouseMove(end);
            await analysisWindow.mouseUp(end, { button: 'left', clickCount: 1 });
            await new Promise((resolve) => setTimeout(resolve, 400));
        };

        // While paused, src/main.mjs's visualizerSeek handler silently no-ops
        // (['running','paused'].includes(lifecycle)) -- the native input still visibly jumps to
        // the dragged position, but the chart must NOT redraw, since the session's real time
        // never moved. This is the reported bug's actual mechanism: the slider looks connected:
        // dragging it, the chart doesn't change.
        const pausedTraceLengthBefore = await evaluate(analysisWindow, `document.querySelector('#analysisPlot').data[0].x.length`);
        await dragTimeline(0.5);
        const pausedTraceLengthAfter = await evaluate(analysisWindow, `document.querySelector('#analysisPlot').data[0].x.length`);
        assert.equal(pausedTraceLengthAfter, pausedTraceLengthBefore,
            'Expected the scatter trail to stay unchanged while paused/running, since src/main.mjs visualizerSeek blocks seeking then -- if this now redraws, the seek gate has changed and this assertion needs updating.');

        await evaluate(diagnosticWindow, `document.querySelector('#simulationPauseResume').click()`);
        await waitFor(diagnosticWindow, `document.querySelector('.resultMode small').textContent === 'Model locked'`, 'Live simulation did not complete in the diagnostic window.', 15000);
        await waitFor(analysisWindow, `document.querySelector('.readOnlyBadge').textContent === 'Completed'`, 'Analysis window did not observe run completion.', 5000);

        // Compare two deliberately-targeted positions rather than "before vs. after one drag":
        // where context.time happens to sit right as the run completes is itself a race (the
        // Analysis window's own catch-up broadcast vs. the main window's completion badge), so
        // an assertion anchored to an unknown starting point would be flaky. Two known targets
        // isn't.
        await dragTimeline(0.02);
        const earlyTraceLength = await evaluate(analysisWindow, `document.querySelector('#analysisPlot').data[0].x.length`);
        await dragTimeline(0.95);
        const lateTraceLength = await evaluate(analysisWindow, `document.querySelector('#analysisPlot').data[0].x.length`);
        assert.ok(lateTraceLength > earlyTraceLength,
            `Expected the revealed scatter trail to grow as the Analysis timeline is dragged forward once the run has completed (near t=0: ${earlyTraceLength} points, near the end: ${lateTraceLength} points).`);

        await closeWhenValidated(diagnosticWindow);
        for (let attempt = 0; attempt < 100 && !(await diagnosticWindow.isDestroyed()); attempt += 1) {
            await new Promise((resolve) => setTimeout(resolve, 25));
        }
    }, { skip: (!driver.capabilities.multiWindow && 'duplicates coverage #5/#15 already provide on the web driver; the addon-specific redraw-gating behavior itself has no web-edition equivalent') || addonMissing('konjugate.resultPlotViewer', 'konjugate-resultplotviewer') });

    await run('source terms expose parameters to equations and programmable bindings', async () => {
        await evaluate(window, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Enclosed air')).click()`);
        await evaluate(window, `document.querySelector('#editAddSourceTerm').click()`);
        await evaluate(window, `[...document.querySelectorAll('.sourceTermOpen')].pop().click()`);
        await evaluate(window, `document.querySelector('#termAddParameter').click()`);
        await evaluate(window, `(() => {
            const row = document.querySelector('#termParameters .editorParameterRow');
            row.querySelector('[data-field="name"]').value = 'Source gain';
            row.querySelector('[data-field="symbol"]').value = 'sourceGain';
            row.querySelector('[data-field="value"]').value = '2';
            row.querySelector('[data-field="symbol"]').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        assert.equal(await evaluate(window, `[...document.querySelectorAll('#termStateReferenceChips button')].some((button) => button.textContent === 'sourceGain')`), true);
        await evaluate(window, `[...document.querySelectorAll('#termStateReferenceChips button')].find((button) => button.textContent === 'sourceGain').click()`);
        await waitFor(window, `document.querySelector('#termEquationDiagnostics').classList.contains('valid')`, 'The source-term parameter was not accepted by the equation editor.');
        await evaluate(window, `(() => { const select = document.querySelector('#termImplementationKind'); select.value = 'cpp'; select.dispatchEvent(new Event('change', { bubbles: true })); document.querySelector('#termAddProviderBinding').click(); })()`);
        assert.equal(await evaluate(window, `[...document.querySelectorAll('#termProviderBindings option')].some((option) => option.textContent === 'sourceGain')`), true);
    });

    await run('numerical stability findings surface as a bottom-bar indicator, a findings panel, and a per-node badge', async () => {
        // A fresh window, not the shared one: this test authors its own tiny, deliberately
        // unstable model from scratch, which would otherwise disturb every later test that
        // assumes the shared document's existing content (see "Results Analysis timeline seek"
        // above for the same isolation reasoning).
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const diagnosticWindow = await driver.waitForNewHandle(before);
        await waitFor(diagnosticWindow, `document.querySelector('.documentTitle')`, 'Diagnostic window did not finish loading.');

        // One node, one state ("level"), one self-referencing growth term: d(level)/dt = level.
        // Explicit Euler's own stability condition is |1 + stepSize·λ| <= 1 -- for λ = +1 and any
        // stepSize > 0, that's |1 + stepSize| > 1 always, so this is unstable at every possible
        // timestep, not just a finely-tuned one. Unlike the engine-level fixtures
        // (tests/engine/duringRunStabilityMonitoring.mjs and friends), which deliberately sit just
        // past a specific boundary to test the boundary itself, this test only needs "definitely,
        // robustly unstable" -- so it doesn't need to match a particular rate against a particular
        // run-configuration timestep at all. The state is named "level", not the shorter "x": a
        // single-letter symbol wrapped in \mathrm{} (how insertSourceTermBinding() -- and every
        // "click a reference chip" flow in this editor -- represents ANY inserted symbol) trips a
        // MathLive/ComputeEngine parsing quirk specific to single-letter symbols ("Unknown symbol:
        // x_upright", confirmed by hand while writing this test) that a multi-character symbol
        // like "level" (or the existing suite's own "sourceBias"/"sourceGain") does not.
        await evaluate(diagnosticWindow, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
        await evaluate(diagnosticWindow, `(() => {
            document.querySelector('#newNodeName').value = 'Growth';
            const values = { name: 'Level', symbol: 'level', value: '1', unit: '' };
            Object.entries(values).forEach(([field, value]) => { const input = document.querySelector('.stateVariableRow [data-field="' + field + '"]'); input.value = value; input.dispatchEvent(new Event('input', { bubbles: true })); });
            document.querySelector('#createNode').click();
        })()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#nodeEditor').classList.contains('hidden')`, 'Growth node editor did not open after creation.');

        await evaluate(diagnosticWindow, `document.querySelector('#editAddSourceTerm').click()`);
        await waitFor(diagnosticWindow, `document.querySelectorAll('.sourceTermOpen').length > 0`, 'The new source term did not appear in the node editor.');
        await evaluate(diagnosticWindow, `[...document.querySelectorAll('.sourceTermOpen')].pop().click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#sourceTermEditor').classList.contains('hidden')`, 'Source-term editor did not open.');
        // A freshly created source term's math field defaults to the literal "0", not empty --
        // inserting a state reference without clearing it first produces malformed LaTeX like
        // "0\\mathrm{x}" (concatenated, not combined with an operator).
        await evaluate(diagnosticWindow, `(() => { const field = document.querySelector('#termMathField'); field.setValue(''); field.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await evaluate(diagnosticWindow, `[...document.querySelectorAll('#termStateReferenceChips button')].find((button) => button.textContent === 'level').click()`);
        await waitFor(diagnosticWindow, `document.querySelector('#termEquationDiagnostics').classList.contains('valid')`, 'The self-referencing growth equation did not become valid.');
        await evaluate(diagnosticWindow, `document.querySelector('#sourceTermEditor [data-close-card]').click()`);
        await evaluate(diagnosticWindow, `document.querySelector('#nodeEditor [data-close-card]').click()`);

        // A known, explicit run configuration -- not load-bearing for instability itself (see
        // above), just kept deterministic rather than depending on whatever default the app
        // happens to launch new projects with.
        await waitFor(diagnosticWindow, `!document.querySelector('#runButton').disabled`, 'Model validation did not complete before the run settings could be opened.', 10000);
        await openRunDialog(diagnosticWindow);
        await waitFor(diagnosticWindow, `document.querySelector('#runLaunchDialog').open`, 'Run dialog did not open.');
        await evaluate(diagnosticWindow, `(() => {
            document.querySelector('#runGlobalTimeStep').value = '0.1';
            document.querySelector('#runOutputInterval').value = '0.1';
            document.querySelector('#saveRunConfiguration').click();
        })()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#runLaunchDialog').open`, 'Run dialog did not close.');

        await waitFor(diagnosticWindow, `!document.querySelector('#runButton').disabled`, 'Model validation did not complete before Run could be started.', 10000);
        await openRunDialog(diagnosticWindow);
        await evaluate(diagnosticWindow, `(() => { document.querySelector('#runTargetTime').value = '1'; document.querySelector('#startRun').click(); })()`);
        // Not just .resultMode b's textContent: that field's own default HTML already reads
        // "Results" before any run has ever happened, so checking it alone can pass instantly
        // without actually waiting for anything -- #resultTransport itself starts `hidden` and
        // is only unhidden once a real result exists, which is the genuine signal.
        await waitFor(diagnosticWindow, `!document.querySelector('#resultTransport').hidden && document.querySelector('.resultMode b').textContent === 'Results'`,
            'Offline run did not complete.', 15000);

        // Bottom-bar indicator: present, colored, and counting at least one finding -- during-run
        // monitoring covers every node by default for an interactive run (engineAdapter.mjs's
        // startEngineRun), and the post-run fingerprint check runs automatically once the result
        // reaches "completed" (renderStabilityFindings(), src/renderer/renderer.mjs).
        assert.equal(await evaluate(diagnosticWindow, `document.querySelector('#stabilitySummaryButton').hidden`), false);
        assert.equal(await evaluate(diagnosticWindow, `document.querySelector('#stabilitySummaryButton').classList.contains('hasFindings')`), true);
        const findingsCount = Number(await evaluate(diagnosticWindow, `document.querySelector('#stabilityFindingsCount').textContent`));
        assert.ok(findingsCount > 0, `Expected at least one stability finding, got ${findingsCount}.`);

        // Per-node badge: the "Growth" node's own label should be flagged.
        assert.equal(await evaluate(diagnosticWindow, `document.querySelector('.node-label-container').classList.contains('hasStabilityFinding')`), true);

        // Findings panel: opens on click, lists real, name-resolved entries -- not raw ids or an
        // unresolved "undefined" (the exact bug this test would have caught: node display names
        // live on nodeObjects.get(id)?.userData?.definition?.title, not model.nodes[].name).
        await evaluate(diagnosticWindow, `document.querySelector('#stabilitySummaryButton').click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#stabilityFindingsCard').classList.contains('hidden')`, 'Stability findings card did not open.');
        const listText = await evaluate(diagnosticWindow, `document.querySelector('#stabilityFindingsList').textContent`);
        assert.match(listText, /Growth/, 'The findings list should show the node\'s real name.');
        assert.doesNotMatch(listText, /undefined|NaN/, 'The findings list should never leak an unresolved value.');

        // Clicking a finding selects the node and opens its editor -- the reciprocal of
        // navigateToValidationIssue's own click-an-issue-to-jump-to-its-entity behavior.
        await evaluate(diagnosticWindow, `document.querySelector('.stabilityFinding').click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#nodeEditor').classList.contains('hidden')`, 'Clicking a stability finding did not open the node editor.');
        assert.equal(await evaluate(diagnosticWindow, `document.querySelector('#editNodeName').value`), 'Growth');

        // "Check convergence" -- explicit, not automatic (engineAdapter.mjs's checkSubstepConvergenceWithEngine
        // is only ever invoked by this button): re-runs the model at doubled substep counts and
        // reports whether it actually converged, not just stayed finite.
        await evaluate(diagnosticWindow, `document.querySelector('#stabilitySummaryButton').click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#stabilityFindingsCard').classList.contains('hidden')`, 'Stability findings card did not reopen.');
        await evaluate(diagnosticWindow, `document.querySelector('.stabilityCheckConvergence').click()`);
        await waitFor(diagnosticWindow, `document.querySelector('.stabilityConvergenceResult')`, 'The convergence check never produced a result.', 30000);
        const convergenceResultText = await evaluate(diagnosticWindow, `document.querySelector('.stabilityConvergenceResult').textContent`);
        assert.doesNotMatch(convergenceResultText, /undefined|NaN/, 'The convergence result should never leak an unresolved value.');

        await closeWhenValidated(diagnosticWindow);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own isolated diagnostic window; no web-edition equivalent' });

    await run('clicking an attributed instability warning jumps straight to the offending parameter', async () => {
        // Fresh window: authors its own tiny, deliberately unstable model tuned to
        // decayRate*stepSize = 2.1, the same hand-verified shape as
        // engine/tests/stabilityAnalysisTests.cpp's decayProject fixture -- unlike the "Growth"
        // (dx/dt = level) fixture used elsewhere in this suite, this one has an actual parameter to
        // attribute the instability to, so the pre-run validator's numericsPotentiallyUnstable
        // warning is guaranteed to carry a resolved attributedParameter.
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const diagnosticWindow = await driver.waitForNewHandle(before);
        await waitFor(diagnosticWindow, `document.querySelector('.documentTitle')`, 'Diagnostic window did not finish loading.');

        await evaluate(diagnosticWindow, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
        await evaluate(diagnosticWindow, `(() => {
            document.querySelector('#newNodeName').value = 'Decay';
            const values = { name: 'Level', symbol: 'level', value: '1', unit: '' };
            Object.entries(values).forEach(([field, value]) => { const input = document.querySelector('.stateVariableRow [data-field="' + field + '"]'); input.value = value; input.dispatchEvent(new Event('input', { bubbles: true })); });
            document.querySelector('#createNode').click();
        })()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#nodeEditor').classList.contains('hidden')`, 'Decay node editor did not open after creation.');

        await evaluate(diagnosticWindow, `document.querySelector('#editAddSourceTerm').click()`);
        await waitFor(diagnosticWindow, `document.querySelectorAll('.sourceTermOpen').length > 0`, 'The new source term did not appear in the node editor.');
        await evaluate(diagnosticWindow, `[...document.querySelectorAll('.sourceTermOpen')].pop().click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#sourceTermEditor').classList.contains('hidden')`, 'Source-term editor did not open.');

        await evaluate(diagnosticWindow, `document.querySelector('#termAddParameter').click()`);
        await evaluate(diagnosticWindow, `(() => {
            const row = document.querySelector('#termParameters .editorParameterRow');
            row.querySelector('[data-field="name"]').value = 'Decay rate';
            row.querySelector('[data-field="symbol"]').value = 'decayRate';
            row.querySelector('[data-field="value"]').value = '21';
            row.querySelector('[data-field="symbol"]').dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        // dx/dt = -decayRate * level, matching decayProject(21, 1)'s own hand-verified math.
        await evaluate(diagnosticWindow, `(() => { const field = document.querySelector('#termMathField'); field.setValue('-\\\\mathrm{decayRate}\\\\cdot\\\\mathrm{level}'); field.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await waitFor(diagnosticWindow, `document.querySelector('#termEquationDiagnostics').classList.contains('valid')`, 'The decay equation did not become valid.');
        await evaluate(diagnosticWindow, `document.querySelector('#sourceTermEditor [data-close-card]').click()`);
        await evaluate(diagnosticWindow, `document.querySelector('#nodeEditor [data-close-card]').click()`);

        await waitFor(diagnosticWindow, `document.querySelector('#validationSummary').dataset.validationSource === 'engine' && !document.querySelector('#runButton').disabled`, 'Model validation did not settle before the run settings could be opened.', 10000);
        await openRunDialog(diagnosticWindow);
        await waitFor(diagnosticWindow, `document.querySelector('#runLaunchDialog').open`, 'Run dialog did not open.');
        await evaluate(diagnosticWindow, `(() => {
            document.querySelector('#runGlobalTimeStep').value = '0.1';
            document.querySelector('#runOutputInterval').value = '0.1';
            document.querySelector('#saveRunConfiguration').click();
        })()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#runLaunchDialog').open`, 'Run dialog did not close.');

        await waitFor(diagnosticWindow, `document.querySelector('#validationSummary').dataset.validationSource === 'engine'`, 'Model validation did not settle.', 10000);
        await evaluate(diagnosticWindow, `document.querySelector('#validationSummary').click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#validationPanel').hidden`, 'Validation panel did not open.');
        await waitFor(diagnosticWindow, `document.querySelector('#validationIssues').textContent.includes('Decay rate')`,
            'The unstable-node warning did not name the Decay rate parameter.', 10000);

        const issueText = await evaluate(diagnosticWindow, `document.querySelector('.validationIssue').textContent`);
        assert.match(issueText, /driven mainly by this node's own 'Decay rate' source-term parameter/,
            'The warning should name the specific parameter, not just the node.');
        assert.match(issueText, /raising this node's numerics\.substepsPerGlobalStep to at least 2/,
            'The warning should include a concrete requiredSubsteps recommendation.');

        await evaluate(diagnosticWindow, `document.querySelector('.validationIssue').click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#sourceTermEditor').classList.contains('hidden')`,
            'Clicking the attributed warning did not open the source-term editor.');
        await waitFor(diagnosticWindow, `document.activeElement?.dataset.field === 'value' && document.activeElement?.closest('#termParameters')`,
            "Clicking the attributed warning did not focus the specific parameter's value input.");
        assert.equal(
            await evaluate(diagnosticWindow, `document.activeElement.closest('.editorParameterRow').querySelector('[data-field="symbol"]').value`),
            'decayRate', "The focused row should be decayRate's own row, not some other parameter.");

        await closeWhenValidated(diagnosticWindow);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own isolated diagnostic window; no web-edition equivalent' });

    await run('the stability-monitoring toggle suppresses during-run findings without disabling the post-run check', async () => {
        // Fresh window + the same "Growth" (dx/dt = level) fixture as the stability-findings test
        // above -- deliberately reused since it is independently caught by BOTH systems (during-run
        // monitoring's own Jacobian re-check, and the post-run fingerprint's growth detection over
        // the completed trajectory): during-run findings always carry a real globalTime and their
        // own C++-authored message text (duringRunStabilityMonitor.cpp); post-run findings always
        // have globalTime: null and entirely different message text (resolvedStabilityFindings() in
        // renderer.mjs). A model both systems would flag is exactly what proves the toggle
        // suppresses the first without touching the second.
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const diagnosticWindow = await driver.waitForNewHandle(before);
        await waitFor(diagnosticWindow, `document.querySelector('.documentTitle')`, 'Diagnostic window did not finish loading.');

        await evaluate(diagnosticWindow, `document.querySelector('#addButton').click(); document.querySelector('[data-add-kind="node"]').click()`);
        await evaluate(diagnosticWindow, `(() => {
            document.querySelector('#newNodeName').value = 'Growth';
            const values = { name: 'Level', symbol: 'level', value: '1', unit: '' };
            Object.entries(values).forEach(([field, value]) => { const input = document.querySelector('.stateVariableRow [data-field="' + field + '"]'); input.value = value; input.dispatchEvent(new Event('input', { bubbles: true })); });
            document.querySelector('#createNode').click();
        })()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#nodeEditor').classList.contains('hidden')`, 'Growth node editor did not open after creation.');

        await evaluate(diagnosticWindow, `document.querySelector('#editAddSourceTerm').click()`);
        await waitFor(diagnosticWindow, `document.querySelectorAll('.sourceTermOpen').length > 0`, 'The new source term did not appear in the node editor.');
        await evaluate(diagnosticWindow, `[...document.querySelectorAll('.sourceTermOpen')].pop().click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#sourceTermEditor').classList.contains('hidden')`, 'Source-term editor did not open.');
        await evaluate(diagnosticWindow, `(() => { const field = document.querySelector('#termMathField'); field.setValue(''); field.dispatchEvent(new Event('input', { bubbles: true })); })()`);
        await evaluate(diagnosticWindow, `[...document.querySelectorAll('#termStateReferenceChips button')].find((button) => button.textContent === 'level').click()`);
        await waitFor(diagnosticWindow, `document.querySelector('#termEquationDiagnostics').classList.contains('valid')`, 'The self-referencing growth equation did not become valid.');
        await evaluate(diagnosticWindow, `document.querySelector('#sourceTermEditor [data-close-card]').click()`);
        await evaluate(diagnosticWindow, `document.querySelector('#nodeEditor [data-close-card]').click()`);

        await waitFor(diagnosticWindow, `document.querySelector('#validationSummary').dataset.validationSource === 'engine' && !document.querySelector('#runButton').disabled`, 'Model validation did not settle before the run settings could be opened.', 10000);
        await openRunDialog(diagnosticWindow);
        await waitFor(diagnosticWindow, `document.querySelector('#runLaunchDialog').open`, 'Run dialog did not open.');
        await evaluate(diagnosticWindow, `(() => {
            document.querySelector('#runGlobalTimeStep').value = '0.1';
            document.querySelector('#runOutputInterval').value = '0.1';
            document.querySelector('#saveRunConfiguration').click();
        })()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#runLaunchDialog').open`, 'Run dialog did not close.');

        await waitFor(diagnosticWindow, `!document.querySelector('#runButton').disabled`, 'Model validation did not complete before Run could be started.', 10000);
        await openRunDialog(diagnosticWindow);
        await evaluate(diagnosticWindow, `(() => {
            document.querySelector('#runTargetTime').value = '1';
            document.querySelector('#runStabilityMonitoring').checked = false;
            document.querySelector('#startRun').click();
        })()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#resultTransport').hidden && document.querySelector('.resultMode b').textContent === 'Results'`,
            'Offline run did not complete.', 15000);

        // Findings panel still opens (the post-run fingerprint check is unconditional and
        // independent of this toggle) -- but its content must carry none of during-run monitoring's
        // own wording.
        await evaluate(diagnosticWindow, `document.querySelector('#stabilitySummaryButton').click()`);
        await waitFor(diagnosticWindow, `!document.querySelector('#stabilityFindingsCard').classList.contains('hidden')`, 'Stability findings card did not open.');
        const listText = await evaluate(diagnosticWindow, `document.querySelector('#stabilityFindingsList').textContent`);
        assert.doesNotMatch(listText, /re-check of its current dynamics|has grown for \d+ consecutive/,
            'Unchecking stability monitoring should suppress during-run findings.');
        assert.match(listText, /grew substantially across the completed run|classic Explicit Euler instability signature/,
            'The post-run fingerprint check should still independently catch the same instability.');

        await closeWhenValidated(diagnosticWindow);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own isolated diagnostic window; no web-edition equivalent' });

    await run('equations use simulation time t and piecewise cases, from the editors through a run', async () => {
        // Heater: energy' = 2 while 0.95 <= t < 2.95, else 0 (a source term written with t).
        // Room: fed by the Warm room edge, which this test rewrites to 1 once t >= 1.95.
        // At dt = 0.1 over 5 s that gives energy = 2 * 2 = 4 and heat = 1 * 3 = 3.
        const time = { kind: 'time', symbol: 't' };
        const heaterLatex = String.raw`\begin{cases} 2 & 0.95 \le t < 2.95 \\ 0 & \text{otherwise} \end{cases}`;
        const project = {
            format: 'konjugate', version: 1, metadata: { units: 'SI' },
            runConfigurations: [{ id: 50, name: 'Default', globalTimeStep: 0.1, outputInterval: 0.1 }], activeRunConfigurationId: 50,
            nodes: [
                {
                    id: 1, name: 'Heater', position: [-4, 0, 0], appearance: { type: 'primitive', shape: 'box', color: '#888888' },
                    states: [{ id: 2, name: 'Energy', symbol: 'energy', initialValue: 0 }],
                    sourceTerms: [{
                        id: 3, state: 'energy', expression: heaterLatex,
                        expressionModel: {
                            latex: heaterLatex, output: { stateId: 2 },
                            bindings: [{ kind: 'state', nodeId: 1, stateId: 2, symbol: 'energy' }, time],
                            mathJson: ['Which', ['And', ['LessEqual', 0.95, 't'], ['Less', 't', 2.95]], 2, 'True', 0]
                        }
                    }]
                },
                {
                    id: 4, name: 'Room', position: [4, 0, 0], appearance: { type: 'primitive', shape: 'box', color: '#888888' },
                    states: [{ id: 5, name: 'Heat', symbol: 'heat', initialValue: 0 }], sourceTerms: []
                }
            ],
            edges: [{
                id: 6, name: 'Warm room', source: { nodeId: 1, stateId: 2 }, target: { nodeId: 4, stateId: 5 }, directionality: 'directed',
                equation: '0',
                equationModel: {
                    latex: '0', output: { role: 'target', stateId: 5 },
                    bindings: [
                        { kind: 'state', role: 'source', nodeId: 1, stateId: 2, symbol: 'sourceEnergy' },
                        { kind: 'state', role: 'target', nodeId: 4, stateId: 5, symbol: 'targetHeat' },
                        time
                    ],
                    mathJson: 0
                },
                parameters: [], appearance: { color: '#888888', offset: 0 }
            }]
        };
        const directory = await mkdtemp(join(tmpdir(), 'konjugate-time-'));
        const projectPath = join(directory, 'timeAndCases.kjt');
        await writeFile(projectPath, await encodeProjectFile(JSON.stringify(project)));
        const before = driver.allHandles();
        await driver.simulateOsFileOpen(projectPath);
        const opened = await driver.waitForNewHandle(before);
        await waitFor(opened, `document.querySelectorAll('.node-label-container').length === 2`, 'The time project did not load.');

        const setEdgeEquation = (latex) => evaluate(opened, `(() => {
            const field = document.querySelector('#editEdgeMathField');
            field.setValue(${JSON.stringify(latex)});
            field.dispatchEvent(new Event('input', { bubbles: true }));
        })()`);
        const diagnostics = () => evaluate(opened, `document.querySelector('#equationDiagnostics').textContent`);

        const point = await canvasPoint(opened, `window.__relationshipScreenPoint('Warm room')`);
        assert.ok(point, 'Could not locate the Warm room edge on screen.');
        await opened.mouseMove(point);
        await opened.mouseDown(point, { button: 'left', clickCount: 1 });
        await opened.mouseUp(point, { button: 'left', clickCount: 1 });
        await waitFor(opened, `document.querySelector('#editEdgeName').value === 'Warm room'`, 'The edge editor did not open.');

        // The time chip is offered alongside the state chips and inserts t.
        const timeChip = `[...document.querySelectorAll('#editStateReferenceChips button')].find((button) => button.textContent === 't (time)')`;
        assert.ok(await evaluate(opened, `Boolean(${timeChip})`), 'The edge editor must offer a t (time) chip.');
        assert.equal(await evaluate(opened, `${timeChip}.title`), 'Insert simulation time (seconds)');
        await setEdgeEquation('');
        await evaluate(opened, `${timeChip}.click()`);
        await waitFor(opened, `document.querySelector('#editEdgeMathField').value.trim() === 't'`, 'Clicking the time chip did not insert t.');

        // Editor-side checks for cases and comparisons.
        await setEdgeEquation(String.raw`\begin{cases} 1 & t \ge 1.95 \end{cases}`);
        assert.match(await diagnostics(), /otherwise/, 'A cases expression without an otherwise branch must be rejected.');
        await setEdgeEquation('t > 1');
        assert.match(await diagnostics(), /condition of a cases expression/, 'A bare comparison must be rejected.');
        await setEdgeEquation(String.raw`\begin{cases} 1 & t \ge 1.95 \\ 0 & \text{otherwise} \end{cases}`);
        assert.equal(await diagnostics(), 'Valid expression · MathJSON ready');
        await waitFor(opened, `document.querySelector('#validationSummary').dataset.validationSource === 'engine' && !document.querySelector('#validationSummary').classList.contains('error')`,
            'The engine must accept a cases expression using t.');

        // Providers get time from their evaluation context, so t is not offered as a provider binding.
        await evaluate(opened, `(() => { const select = document.querySelector('#editEdgeImplementationKind'); select.value = 'cpp'; select.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        await evaluate(opened, `document.querySelector('#editAddProviderBinding').click()`);
        const referenceOptions = await evaluate(opened, `[...document.querySelectorAll('#edgeEditor .providerBindingRow [data-field="reference"] option')].map((option) => option.textContent)`);
        assert.ok(referenceOptions.length > 0, 'The provider binding row must list references.');
        assert.ok(!referenceOptions.some((label) => label.includes('time')), `Provider bindings must not offer t (got ${referenceOptions.join(', ')}).`);
        await evaluate(opened, `(() => { const select = document.querySelector('#editEdgeImplementationKind'); select.value = 'equation'; select.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        await waitFor(opened, `!document.querySelector('#editEdgeMathField').hidden || !document.querySelector('#editEdgeEquation').hidden`, 'The edge editor did not return to equation mode.');
        await setEdgeEquation(String.raw`\begin{cases} 1 & t \ge 1.95 \\ 0 & \text{otherwise} \end{cases}`);
        assert.equal(await diagnostics(), 'Valid expression · MathJSON ready');
        await evaluate(opened, `document.querySelector('#edgeEditor [data-close-card]').click()`);

        // The source-term editor offers the same chip, and the loaded cases-on-t term is valid.
        await evaluate(opened, `[...document.querySelectorAll('.objectLabel')].find((label) => label.textContent.includes('Heater')).click()`);
        await evaluate(opened, `document.querySelector('.sourceTermOpen').click()`);
        await waitFor(opened, `[...document.querySelectorAll('#termStateReferenceChips button')].some((button) => button.textContent === 't (time)')`, 'The source-term editor must offer a t (time) chip.');
        assert.equal(await evaluate(opened, `document.querySelector('#termEquationDiagnostics').textContent`), 'Valid expression · MathJSON ready');

        // Run and check both time-dependent rates switched where they should.
        await openRunDialog(opened);
        await evaluate(opened, `(() => { document.querySelector('#runTargetTime').value = '5'; document.querySelector('#startRun').click(); })()`);
        await waitFor(opened, `document.querySelector('.resultMode b').textContent === 'Results'`, 'The run did not complete.', 15000);
        await waitFor(opened, `Number(document.querySelector('#resultTimeline').max) === 5 && Number(document.querySelector('#resultTimeline').value) === 5`, 'The results did not load to the end of the run.', 15000);
        const finalValue = (nodeId) => evaluate(opened, `Number.parseFloat(document.querySelector('.node-label-container[data-node="${nodeId}"] dd').textContent)`);
        assert.ok(Math.abs(await finalValue(1) - 4) < 1e-6, `Heater energy should be 4 (got ${await finalValue(1)}).`);
        assert.ok(Math.abs(await finalValue(4) - 3) < 1e-6, `Room heat should be 3 (got ${await finalValue(4)}).`);
        await closeWhenValidated(opened);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own project window through an OS-style file open; no web-edition equivalent' });

    await run('a parameter linked to a shared parameter edits and unlinks through the edge editor', async () => {
        // Two edges link one parameter to a project-level shared parameter: the linked row shows the
        // shared value (2), not its own stale one (5); editing it changes the shared definition, so
        // the sibling edge follows; and unlinking keeps the value in effect as the row's own.
        const project = sharedParameterTestProject();
        const directory = await mkdtemp(join(tmpdir(), 'konjugate-shared-'));
        const projectPath = join(directory, 'sharedParameters.kjt');
        await writeFile(projectPath, await encodeProjectFile(JSON.stringify(project)));

        const before = driver.allHandles();
        await driver.simulateOsFileOpen(projectPath);
        const opened = await driver.waitForNewHandle(before);
        await waitFor(opened, `document.querySelectorAll('.node-label-container').length > 0`, 'The shared-parameter project did not load.');
        const openEdge = async (name) => {
            const point = await canvasPoint(opened, `window.__relationshipScreenPoint(${JSON.stringify(name)})`);
            assert.ok(point, `Could not locate ${name} on screen.`);
            await opened.mouseMove(point);
            await opened.mouseDown(point, { button: 'left', clickCount: 1 });
            await opened.mouseUp(point, { button: 'left', clickCount: 1 });
            await waitFor(opened, `document.querySelector('#editEdgeName').value === ${JSON.stringify(name)}`, `The ${name} edge editor did not open.`);
        };
        const row = `document.querySelector('#edgeEditorParameters .editorParameterRow')`;
        await openEdge('Feed X');
        assert.equal(await evaluate(opened, `${row}.querySelector('[data-shared-select]').value`), '100');
        assert.equal(await evaluate(opened, `${row}.querySelector('[data-field="value"]').value`), '2', 'A linked row must show the shared value.');

        await evaluate(opened, `(() => { const input = ${row}.querySelector('[data-field="value"]'); input.value = '3'; input.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        await evaluate(opened, `document.querySelector('#edgeEditor [data-close-card]').click()`);
        await openEdge('Feed Y');
        assert.equal(await evaluate(opened, `${row}.querySelector('[data-field="value"]').value`), '3', 'The sibling edge must follow the shared value.');

        await evaluate(opened, `(() => { const select = ${row}.querySelector('[data-shared-select]'); select.value = ''; select.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        await waitFor(opened, `${row}.querySelector('[data-shared-select]').value === ''`, 'Unlinking did not take effect.');
        assert.equal(await evaluate(opened, `${row}.querySelector('[data-field="value"]').value`), '3', 'Unlinking keeps the value in effect as the parameter\'s own.');
        await closeWhenValidated(opened);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own project window through an OS-style file open; no web-edition equivalent' });

    await run('a node provider survives the canvas, with its body parts, and its shared parameter is listed and kept as used', async () => {
        // A node has no parameters of its own; its computational-node provider reads a shared one. The canvas must keep
        // the provider as written until the user edits it (under Program in the node editor), and count its binding as
        // a use of the shared parameter, or the live controls, the parameters table and a save would leave it out.
        const implementation = {
            kind: 'python', providerApiVersion: 1, source: 'provider source',
            bindings: [{ key: 'payload', kind: 'parameter', sharedParameterId: 100 }],
            outputs: [{ key: 'angle', stateId: 2, setsValue: true }]
        };
        // A body's shape, in the frame of the body whose pose states start with its prefix.
        const parts = [{ prefix: 'link', mesh: { position: [0, 0, 0, 0.1, 0, 0, 0, 0.1, 0], normal: [], index: [0, 1, 2] }, color: '#c0c0c0' }];
        const project = {
            format: 'konjugate', version: 1, metadata: { units: 'SI' },
            sharedParameters: [{ id: 100, name: 'Payload', symbol: 'payload', value: 2, unit: 'kg', mode: 'live', control: { minimum: 0, maximum: 5, step: 0.5 } }],
            nodes: [{
                id: 1, name: 'Mechanism', position: [0, 0, 0], sourceTerms: [], appearance: { type: 'primitive', shape: 'box', color: '#888888', parts },
                states: [{ id: 2, name: 'Angle', symbol: 'angle', initialValue: 0 }], implementation
            }],
            edges: [],
            runConfigurations: [{ id: 3, name: 'Default', globalTimeStep: 0.01, outputInterval: 0.01 }], activeRunConfigurationId: 3
        };
        const directory = await mkdtemp(join(tmpdir(), 'konjugate-node-provider-'));
        const projectPath = join(directory, 'nodeProvider.kjt');
        await writeFile(projectPath, await encodeProjectFile(JSON.stringify(project)));

        const before = driver.allHandles();
        await driver.simulateOsFileOpen(projectPath);
        const opened = await driver.waitForNewHandle(before);
        await waitFor(opened, `document.querySelectorAll('.node-label-container').length > 0`, 'The node-provider project did not load.');
        const saved = await evaluate(opened, `window.__debugProject.serialize()`);
        assert.deepEqual(saved.nodes[0].implementation, implementation, 'The canvas must keep a node\'s provider as it was authored.');
        assert.deepEqual(saved.nodes[0].appearance.parts, parts, 'The canvas must keep a node\'s body parts.');
        assert.deepEqual(saved.sharedParameters?.map(({ id }) => id), [100], 'A shared parameter only a provider reads must still be saved.');

        await evaluate(opened, `document.querySelector('#parametersButton').click()`);
        await waitFor(opened, `!document.querySelector('#parametersPanel').hidden`, 'The parameters panel did not open.');
        assert.match(await evaluate(opened, `document.querySelector('#parametersBody tr.sharedRow').textContent`), /Shared.*1 use/,
            'The provider\'s binding must count as a use of the shared parameter.');
        await evaluate(opened, `document.querySelector('[data-toggle-shared]').click()`);
        assert.equal(await evaluate(opened, `document.querySelector('#parametersBody tr.sharedUserRow').lastElementChild.textContent`), 'Mechanism · provider');
        await closeWhenValidated(opened);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own project window through an OS-style file open; no web-edition equivalent' });

    await run('the parameters table lists shared and ordinary parameters, edits inline, and jumps to owners', async () => {
        const project = sharedParameterTestProject({ withSourceTerm: true });
        // One ordinary parameter alongside the shared ones, so both row kinds are covered.
        project.edges[1].parameters.push({ id: 15, name: 'Offset', symbol: 'offset', value: 1, unit: 'm', mode: 'constant' });
        project.edges[1].equationModel.bindings.push({ kind: 'parameter', parameterId: 15, symbol: 'offset' });
        const directory = await mkdtemp(join(tmpdir(), 'konjugate-parameters-table-'));
        const projectPath = join(directory, 'parametersTable.kjt');
        await writeFile(projectPath, await encodeProjectFile(JSON.stringify(project)));

        const before = driver.allHandles();
        await driver.simulateOsFileOpen(projectPath);
        const opened = await driver.waitForNewHandle(before);
        await waitFor(opened, `document.querySelectorAll('.node-label-container').length > 0`, 'The parameters-table project did not load.');
        await evaluate(opened, `document.querySelector('#parametersButton').click()`);
        await waitFor(opened, `!document.querySelector('#parametersPanel').hidden`, 'The parameters panel did not open.');

        assert.equal(await evaluate(opened, `document.querySelector('#parametersSummary').textContent`), '2 parameters · 1 shared',
            'One shared parameter (with its three linked uses folded under it) plus one ordinary parameter.');
        assert.equal(await evaluate(opened, `document.querySelectorAll('#parametersBody tr').length`), 2);
        assert.match(await evaluate(opened, `document.querySelector('#parametersBody tr.sharedRow').textContent`), /Shared.*3 uses/,
            'Both edges and the source term must count as uses of the shared parameter.');

        await evaluate(opened, `document.querySelector('[data-toggle-shared]').click()`);
        assert.equal(await evaluate(opened, `[...document.querySelectorAll('#parametersBody tr.sharedUserRow')].map((row) => row.lastElementChild.textContent).join('|')`),
            'Feed X (Source → Target X)|Feed Y (Source → Target Y)|Target X · source term', 'The expanded rows must name each owner.');

        // Inline edit of the shared value goes through the shared definition, undoably.
        const sharedValue = `document.querySelector('#parametersBody tr.sharedRow input[data-field="value"]')`;
        await evaluate(opened, `(() => { const input = ${sharedValue}; input.value = '7'; input.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        assert.equal(await evaluate(opened, `${sharedValue}.value`), '7');
        await evaluate(opened, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(opened, `${sharedValue}.value`), '2', 'Undo must restore the shared value.');
        await evaluate(opened, `document.querySelector('#redoButton').click()`);

        // An out-of-range value for a live parameter is refused and marked, not applied.
        const modeSelect = `document.querySelector('#parametersBody tr:not(.sharedRow):not(.sharedUserRow) select[data-field="mode"]')`;
        await evaluate(opened, `(() => { const select = ${modeSelect}; select.value = 'live'; select.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        assert.equal(await evaluate(opened, `${modeSelect}.value`), 'live', 'An in-range value can switch to live.');
        const ordinaryValue = `document.querySelector('#parametersBody tr:not(.sharedRow):not(.sharedUserRow) input[data-field="value"]')`;
        await evaluate(opened, `(() => { const input = ${ordinaryValue}; input.value = '1e9'; input.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        assert.equal(await evaluate(opened, `${ordinaryValue}.classList.contains('invalid')`), true, 'A value outside the live slider range must be flagged.');

        // Filtering and search.
        await evaluate(opened, `(() => { const filter = document.querySelector('#parametersFilter'); filter.value = 'shared'; filter.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        assert.equal(await evaluate(opened, `document.querySelectorAll('#parametersBody tr:not(.sharedUserRow)').length`), 1);
        await evaluate(opened, `(() => { const filter = document.querySelector('#parametersFilter'); filter.value = 'all'; filter.dispatchEvent(new Event('change', { bubbles: true })); })()`);

        // Fit: marking the shared parameter tunable from the table makes it one fitting variable for the
        // tuning panel, and the Tunable filter finds it.
        const fitBox = `document.querySelector('#parametersBody tr.sharedRow input[data-field="tunable"]')`;
        await evaluate(opened, `(() => { const box = ${fitBox}; box.checked = true; box.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        assert.equal(await evaluate(opened, `document.querySelector('#parametersBody tr.sharedRow input[data-field="tuning-minimum"]').hidden`), false, 'Bounds must appear once tunable.');
        await evaluate(opened, `(() => { const filter = document.querySelector('#parametersFilter'); filter.value = 'tunable'; filter.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        assert.equal(await evaluate(opened, `document.querySelectorAll('#parametersBody tr:not(.sharedUserRow)').length`), 1, 'Only the tunable shared parameter should remain.');
        await evaluate(opened, `(() => { const filter = document.querySelector('#parametersFilter'); filter.value = 'all'; filter.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        await evaluate(opened, `document.querySelector('#parameterTuningButton').click()`);
        await waitFor(opened, `!document.querySelector('#parameterTuning').classList.contains('hidden')`, 'The tuning panel did not open.');
        await evaluate(opened, `window.__debugParameterTuning.loadCsv('time,level\\n0,0\\n1,1\\n2,2\\n3,3\\n4,4\\n5,5\\n6,6\\n7,7\\n8,8\\n9,9\\n10,10\\n11,11\\n')`);
        await waitFor(opened, `document.querySelector('#parameterTuningParameterRows').textContent.includes('Shared')`, 'The tuning panel did not offer the shared parameter.');
        assert.equal(await evaluate(opened, `document.querySelectorAll('#parameterTuningParameterRows > *').length`), 1, 'One shared parameter is one fitting variable however many parameters link to it.');
        await evaluate(opened, `document.querySelector('#parameterTuning [data-close-card]').click()`);

        // Clicking an owner opens its editor while the table stays open.
        await evaluate(opened, `document.querySelector('#parametersBody tr.sharedUserRow .ownerLink').click()`);
        await waitFor(opened, `!document.querySelector('#edgeEditor').classList.contains('hidden')`, 'Clicking an owner did not open its edge editor.');
        assert.equal(await evaluate(opened, `document.querySelector('#parametersPanel').hidden`), false, 'The table must stay open beside the editor.');
        assert.equal(await evaluate(opened, `document.querySelector('#edgeEditorParameters [data-shared-select]').value`), '100');

        // A source-term parameter links the same way: its row shows the shared value and can unlink.
        await evaluate(opened, `[...document.querySelectorAll('#parametersBody tr.sharedUserRow .ownerLink')].find((link) => link.textContent.includes('source term')).click()`);
        await waitFor(opened, `!document.querySelector('#sourceTermEditor').classList.contains('hidden')`, 'Clicking the source-term owner did not open its editor.');
        const termRow = `document.querySelector('#termParameters .editorParameterRow')`;
        assert.equal(await evaluate(opened, `${termRow}.querySelector('[data-shared-select]').value`), '100');
        assert.equal(await evaluate(opened, `${termRow}.querySelector('[data-field="value"]').value`), '7', 'The source-term row must show the shared value.');
        await evaluate(opened, `(() => { const select = ${termRow}.querySelector('[data-shared-select]'); select.value = ''; select.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        await waitFor(opened, `${termRow}.querySelector('[data-shared-select]').value === ''`, 'Unlinking the source-term parameter did not take effect.');
        assert.match(await evaluate(opened, `document.querySelector('#parametersSummary').textContent`), /· 1 shared/);
        assert.match(await evaluate(opened, `document.querySelector('#parametersBody tr.sharedRow').textContent`), /2 uses/, 'Unlinking must drop the source term from the shared parameter\'s uses.');
        await closeWhenValidated(opened);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own project window through an OS-style file open; no web-edition equivalent' });

    await run('a component bundle wires several edges among the selected nodes with a shared parameter, as one undoable step', async () => {
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const bundleWindow = await driver.waitForNewHandle(before);
        await waitFor(bundleWindow, `document.querySelector('.documentTitle')`, 'Bundle test window did not finish loading.');
        await evaluate(bundleWindow, `document.querySelector('#componentLibraryButton').click()`);
        await waitFor(bundleWindow, `document.querySelectorAll('.componentLibraryItem').length > 0`, 'Component library did not load any templates.');
        assert.match(await evaluate(bundleWindow, `document.querySelector('[data-template-id="batteryMotorDrive"] small').textContent`), /Bundle · 3 edges/);
        const edgeCount = `Number(document.querySelectorAll('.modelStatus span')[1].textContent.match(/\\d+/)[0])`;

        // Too few nodes selected: the bundle explains what it needs and changes nothing.
        await evaluate(bundleWindow, `document.querySelector('[data-template-id="batteryMotorDrive"]').click()`);
        assert.match(await evaluate(bundleWindow, `document.querySelector('#componentLibraryHint').textContent`), /Select 3 nodes first \(Battery, Motor, Thermal mass\)/);
        assert.equal(await evaluate(bundleWindow, edgeCount), 0);

        // Place the three nodes, deliberately in an order that does not match the bundle's endpoints:
        // assignment is by state symbols, so it should not matter.
        for (const id of ['thermalMass', 'motor', 'battery']) {
            await evaluate(bundleWindow, `document.querySelector('[data-template-id="${id}"]').click()`);
        }
        await waitFor(bundleWindow, `document.querySelectorAll('.objectLabel').length >= 3`, 'The three node templates were not placed.');
        await evaluate(bundleWindow, `document.querySelector('[data-action="select-all"]').click()`);
        await evaluate(bundleWindow, `document.querySelector('[data-template-id="batteryMotorDrive"]').click()`);
        await waitFor(bundleWindow, `${edgeCount} === 3`, 'The bundle did not create its three edges.');

        await evaluate(bundleWindow, `document.querySelector('#parametersButton').click()`);
        await waitFor(bundleWindow, `!document.querySelector('#parametersPanel').hidden`, 'The parameters panel did not open.');
        assert.match(await evaluate(bundleWindow, `document.querySelector('#parametersSummary').textContent`), /· 1 shared/);
        const sharedRow = await evaluate(bundleWindow, `document.querySelector('#parametersBody tr.sharedRow').textContent`);
        assert.match(sharedRow, /Winding resistance/);
        assert.match(sharedRow, /2 uses/, 'The armature and heating edges must both link the one winding resistance.');

        // One undo removes every edge and the shared parameter with them; redo restores both.
        await evaluate(bundleWindow, `document.querySelector('#undoButton').click()`);
        assert.equal(await evaluate(bundleWindow, edgeCount), 0);
        assert.equal(await evaluate(bundleWindow, `document.querySelectorAll('#parametersBody tr.sharedRow').length`), 0);
        await evaluate(bundleWindow, `document.querySelector('#redoButton').click()`);
        assert.equal(await evaluate(bundleWindow, edgeCount), 3);
        assert.match(await evaluate(bundleWindow, `document.querySelector('#parametersBody tr.sharedRow').textContent`), /2 uses/);

        // Applying it again on nodes that cannot fit reports which endpoint has no match.
        await evaluate(bundleWindow, `document.querySelector('[data-template-id="thermalMass"]').click()`);
        await waitFor(bundleWindow, `document.querySelectorAll('.objectLabel').length >= 4`, 'The extra node was not placed.');
        await evaluate(bundleWindow, `document.querySelector('[data-action="select-all"]').click()`);
        await evaluate(bundleWindow, `document.querySelector('[data-template-id="batteryMotorDrive"]').click()`);
        assert.match(await evaluate(bundleWindow, `document.querySelector('#componentLibraryHint').textContent`), /Select 3 nodes first/);
        await closeWhenValidated(bundleWindow);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own isolated window; no web-edition equivalent' });

    await run('an installed package that needs a newer Konjugate is not loaded, is explained in Extensions, and does not count as an update', async () => {
        // docs/proposals/packageCompatibility.md: two packages that need a Konjugate far newer than any, and a compatible control.
        const packagesDirectory = join(process.env.KONJUGATE_INTERACTION_USER_DATA, 'packages');
        const plant = async (type, id, name, files, minimumKonjugateVersion) => {
            const directory = join(packagesDirectory, `${type}s`, id, '1.0.0');
            await mkdir(directory, { recursive: true });
            await writeFile(join(directory, 'package.json'), JSON.stringify({
                format: 'konjugate-package', formatVersion: 1, packageType: type, packageId: id, name, version: '1.0.0',
                ...(minimumKonjugateVersion ? { minimumKonjugateVersion } : {}), contents: { manifest: `${type}.json` }
            }));
            for (const [file, content] of Object.entries(files)) await writeFile(join(directory, file), typeof content === 'string' ? content : JSON.stringify(content));
        };
        const template = (id) => ({ id, kind: 'node', name: id, domains: ['showcase'], description: 'A test node.', states: [{ symbol: 'level', label: 'Level', initialValue: 1 }] });
        const pluginManifest = (id, componentId) => ({ pluginId: id, name: id, version: '1.0.0', apiVersion: 1, permissions: [], contributes: [{ kind: 'component', componentId, apiVersion: 1, entry: `${componentId}.json` }] });
        await plant('addon', 'example.futureTool', 'Future Tool', {
            'addon.json': {
                addonId: 'example.futureTool', name: 'Future Tool', version: '1.0.0', apiVersion: 1, kind: 'resultVisualizer', entry: 'index.html', permissions: ['results.read'],
                contributes: { toolstrip: [{ commandId: 'open', label: 'Open', tooltip: 'Open Future Tool', symbol: 'F', when: 'resultsActive', contexts: ['resultSession'] }] }
            },
            'index.html': '<!doctype html>'
        }, '999.0.0');
        await plant('plugin', 'example.futurePlugin', 'Future Plugin', { 'plugin.json': pluginManifest('example.futurePlugin', 'futureNode'), 'futureNode.json': template('futureNode') }, '999.0.0');
        await plant('plugin', 'example.currentPlugin', 'Current Plugin', { 'plugin.json': pluginManifest('example.currentPlugin', 'currentNode'), 'currentNode.json': template('currentNode') });

        // The main process reports the incompatible ones, with what they need, and never as enabled.
        const listed = await evaluate(window, `window.extensions.list().then((all) => all.filter((entry) => entry.packageId.startsWith('example.future') || entry.packageId === 'example.currentPlugin').map((entry) => ({ id: entry.packageId, enabled: entry.enabled, incompatible: entry.incompatible ?? null })))`);
        const byId = Object.fromEntries(listed.map((entry) => [entry.id, entry]));
        assert.equal(byId['example.futureTool'].enabled, false);
        assert.equal(byId['example.futureTool'].incompatible.required, '999.0.0');
        assert.match(byId['example.futureTool'].incompatible.running, /^\d+\.\d+\.\d+/);
        assert.equal(byId['example.futurePlugin'].enabled, false);
        assert.equal(byId['example.currentPlugin'].enabled, true);
        assert.equal(byId['example.currentPlugin'].incompatible, null);

        // The Extensions dialog explains it and offers the way out; it is not an update.
        await evaluate(window, `document.querySelector('#extensionsButton').click()`);
        await waitFor(window, `document.querySelector('#extensionsDialog').open`, 'The Extensions dialog did not open.');
        // The dialog remembers its last tab from earlier scenarios, so choose the one this scenario needs.
        await evaluate(window, `document.querySelector('[data-extensions-tab="addon"]').click()`);
        await waitFor(window, `Boolean(document.querySelector('[data-package-key="addon:example.futureTool:1.0.0"]'))`, 'The incompatible add-on was not listed.');
        const row = `document.querySelector('[data-package-key="addon:example.futureTool:1.0.0"]')`;
        assert.equal(await evaluate(window, `${row}.classList.contains('isIncompatible')`), true);
        assert.equal(await evaluate(window, `${row}.querySelector('.extensionsIncompatiblePill').textContent`), 'Incompatible');
        assert.match(await evaluate(window, `${row}.querySelector('.extensionsItemMeta').textContent`), /Needs Konjugate 999\.0\.0 or later; this is Konjugate \d+\.\d+\.\d+/);
        // Other installed add-ons may have updates of their own; what matters is that this package is not offered one.
        assert.equal(await evaluate(window, `Boolean(${row}.querySelector('.extensionsUpdatePill'))`), false, 'an incompatible package is not an update');
        assert.equal(await evaluate(window, `${row}.classList.contains('hasUpdate')`), false);
        assert.doesNotMatch(await evaluate(window, `${row}.querySelector('.extensionsItemMeta').textContent`), /Disabled/, 'it is incompatible, which is not something the user disabled');
        await evaluate(window, `${row}.click()`);
        await waitFor(window, `!document.querySelector('#extensionsDetailCompatibilityNote').hidden`, 'The compatibility note was not shown.');
        assert.match(await evaluate(window, `document.querySelector('#extensionsDetailCompatibilityNote').textContent`), /Needs Konjugate 999\.0\.0 or later.*It is not loaded\. Installing a compatible version replaces it\./);
        assert.equal(await evaluate(window, `document.querySelector('#extensionsInstallCompatible').hidden`), false);
        assert.equal(await evaluate(window, `document.querySelector('#extensionsToggleEnabled').hidden`), true, 'an incompatible package cannot be enabled');
        assert.equal(await evaluate(window, `document.querySelector('#extensionsUpdate').hidden`), true);

        // A package that is not in the registry has no other release to install, and says so plainly.
        await evaluate(window, `document.querySelector('#extensionsInstallCompatible').click()`);
        await waitFor(window, `/Could not install a compatible version/.test(document.querySelector('#extensionsRestartNotice').textContent)`, 'The failed install was not reported.');
        assert.match(await evaluate(window, `document.querySelector('#extensionsRestartNotice').textContent`), /not in the registry|registry/i);
        assert.equal(await evaluate(window, `document.querySelector('#extensionsInstallCompatible').disabled`), false, 'the button is usable again after a failure');

        // The compatible plugin is listed as usual, with nothing wrong with it.
        await evaluate(window, `document.querySelector('[data-extensions-tab="plugin"]').click()`);
        await waitFor(window, `Boolean(document.querySelector('[data-package-key="plugin:example.currentPlugin:1.0.0"]'))`, 'The compatible plugin was not listed.');
        assert.equal(await evaluate(window, `document.querySelector('[data-package-key="plugin:example.currentPlugin:1.0.0"]').classList.contains('isIncompatible')`), false);
        assert.equal(await evaluate(window, `document.querySelector('[data-package-key="plugin:example.futurePlugin:1.0.0"]').classList.contains('isIncompatible')`), true);
        await evaluate(window, `document.querySelector('#extensionsDialog').close()`);

        // And what a package contributes only loads if it is compatible.
        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const libraryWindow = await driver.waitForNewHandle(before);
        await waitFor(libraryWindow, `document.querySelector('.documentTitle')`, 'The component library test window did not finish loading.');
        await evaluate(libraryWindow, `document.querySelector('#componentLibraryButton').click()`);
        await waitFor(libraryWindow, `document.querySelector('[data-template-id="currentNode"]')`, 'The compatible plugin\'s node template did not appear.');
        assert.equal(await evaluate(libraryWindow, `Boolean(document.querySelector('[data-template-id="futureNode"]'))`), false, 'the incompatible plugin\'s template must not load');
        await closeWhenValidated(libraryWindow);
    }, { skip: !driver.capabilities.multiWindow && 'packages are installed on disk by the desktop app; the web edition has none' });

    await run('a node template places source terms with their own and shared parameters, as one undoable step', async () => {
        const pluginDirectory = join(process.env.KONJUGATE_INTERACTION_USER_DATA, 'packages', 'plugins', 'example.stockpile', '0.1.0');
        await mkdir(pluginDirectory, { recursive: true });
        await writeFile(join(pluginDirectory, 'stockpile.json'), JSON.stringify({
            id: 'stockpile', kind: 'node', name: 'Stockpile', domains: ['showcase'], description: 'A draining stock with an order rule.',
            states: [{ symbol: 'stock', label: 'Stock', initialValue: 10 }, { symbol: 'orderRate', label: 'Order rate', initialValue: 0 }],
            sharedParameters: [
                { key: 'cover', name: 'Cover target', symbol: 'coverTarget', value: 3, scope: 'project' },
                { key: 'drain', name: 'Drain time', symbol: 'drainTime', value: 2 }
            ],
            sourceTerms: [
                { state: 'stock', expression: '-\\frac{\\mathrm{stock}}{\\mathrm{drainTime}}', parameters: [{ name: 'Drain time', symbol: 'drainTime', shared: 'drain' }] },
                {
                    state: 'orderRate', setsValue: true, expression: '\\mathrm{gain} \\cdot (\\mathrm{coverTarget} - \\mathrm{stock})',
                    parameters: [{ name: 'Gain', symbol: 'gain', value: 0.5 }, { name: 'Cover target', symbol: 'coverTarget', shared: 'cover' }]
                }
            ]
        }));
        await writeFile(join(pluginDirectory, 'plugin.json'), JSON.stringify({
            pluginId: 'example.stockpile', name: 'Stockpile', version: '0.1.0', apiVersion: 1, permissions: [],
            contributes: [{ kind: 'component', componentId: 'stockpile', apiVersion: 1, entry: 'stockpile.json' }]
        }));

        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const stockWindow = await driver.waitForNewHandle(before);
        await waitFor(stockWindow, `document.querySelector('.documentTitle')`, 'Node template test window did not finish loading.');
        await evaluate(stockWindow, `document.querySelector('#componentLibraryButton').click()`);
        await waitFor(stockWindow, `document.querySelector('[data-template-id="stockpile"]')`, 'The plugin node template did not appear in the component library.');
        await evaluate(stockWindow, `document.querySelector('[data-template-id="stockpile"]').click()`);
        await evaluate(stockWindow, `document.querySelector('[data-template-id="stockpile"]').click()`);
        await waitFor(stockWindow, `document.querySelectorAll('.objectLabel').length === 2`, 'The two stockpiles were not placed.');

        const sharedRows = `[...document.querySelectorAll('#parametersBody tr.sharedRow')].map((row) => row.textContent)`;
        await evaluate(stockWindow, `document.querySelector('#parametersButton').click()`);
        await waitFor(stockWindow, `!document.querySelector('#parametersPanel').hidden`, 'The parameters panel did not open.');
        // The project-scoped cover target is shared by both nodes; each node gets its own drain time.
        const rows = await evaluate(stockWindow, sharedRows);
        assert.equal(rows.length, 3, `Expected one shared cover target and two drain times, got: ${rows.join(' | ')}`);
        assert.match(rows.find((row) => row.includes('Cover target')), /2 uses/);
        assert.equal(rows.filter((row) => row.includes('Drain time') && /1 use/.test(row)).length, 2);

        await waitFor(stockWindow, `document.querySelector('#validationSummary').dataset.validationSource === 'engine'`, 'The placed stockpiles were not validated.', 10000);
        assert.equal(await evaluate(stockWindow, `document.querySelector('#validationSummary').classList.contains('error')`), false,
            'The engine should accept template source terms with parameters and an algebraic output.');

        // Undoing the second placement removes its own drain time but keeps the shared cover target.
        await evaluate(stockWindow, `document.querySelector('#undoButton').click()`);
        await waitFor(stockWindow, `${sharedRows}.length === 2`, 'Undo did not remove the second stockpile\'s own shared parameter.');
        assert.match((await evaluate(stockWindow, sharedRows)).find((row) => row.includes('Cover target')), /1 use/);
        await evaluate(stockWindow, `document.querySelector('#redoButton').click()`);
        await waitFor(stockWindow, `${sharedRows}.length === 3`, 'Redo did not restore the second stockpile\'s shared parameter.');
        await closeWhenValidated(stockWindow);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own isolated window; a plugin directory is written to the desktop userData' });

    await run('a plugin-contributed example appears in the Examples dialog and loads as an unsaved copy', async () => {
        // The suite runs with an isolated userData directory (KONJUGATE_INTERACTION_USER_DATA), which is
        // where installed packages live, so a plugin written there is discovered exactly like an installed one.
        const pluginDirectory = join(process.env.KONJUGATE_INTERACTION_USER_DATA, 'packages', 'plugins', 'example.exampleShowcase', '0.1.0');
        await mkdir(join(pluginDirectory, 'examples'), { recursive: true });
        const project = {
            format: 'konjugate', version: 1, metadata: { units: 'SI' },
            nodes: [{ id: 1, name: 'Plugin tank', position: [0, 0, 0], sourceTerms: [], appearance: { type: 'primitive', shape: 'box', color: '#888888' }, states: [{ id: 2, name: 'Level', symbol: 'level', initialValue: 1 }] }],
            edges: []
        };
        await writeFile(join(pluginDirectory, 'examples', 'pluginTank.kjt'), await encodeProjectFile(JSON.stringify(project)));
        await writeFile(join(pluginDirectory, 'examples', 'pluginTank.md'), '# Plugin tank\n\n## Overview\n\nA single tank shipped by a plugin.\n');
        await writeFile(join(pluginDirectory, 'plugin.json'), JSON.stringify({
            pluginId: 'example.exampleShowcase', name: 'Example Showcase', version: '0.1.0', apiVersion: 1, permissions: [],
            contributes: [
                { kind: 'example', apiVersion: 1, exampleId: 'pluginTank', name: 'Plugin tank', domains: ['showcase'], description: 'A single tank shipped by a plugin.', entry: 'examples/pluginTank.kjt', guide: 'examples/pluginTank.md' },
                { kind: 'example', apiVersion: 1, exampleId: 'escapes', name: 'Escapes its plugin', entry: '../escapes.kjt' },
                { kind: 'example', apiVersion: 1, exampleId: 'thermalManagement', name: 'Collides with a bundled example', entry: 'examples/pluginTank.kjt' }
            ]
        }));

        const before = driver.allHandles();
        await evaluate(window, `document.querySelector('#newWindowButton').click()`);
        const exampleWindow = await driver.waitForNewHandle(before);
        await waitFor(exampleWindow, `document.querySelector('.documentTitle')`, 'The example window did not finish loading.');
        await evaluate(exampleWindow, `document.querySelector('#exampleButton').click()`);
        await waitFor(exampleWindow, `document.querySelector('#examplesExplorerDialog').open`, 'Examples explorer did not open.');
        const labels = `[...document.querySelectorAll('.examplesExplorerItem b')].map((item) => item.textContent)`;
        await waitFor(exampleWindow, `${labels}.includes('Plugin tank')`, 'The plugin example did not appear in the Examples dialog.');
        const listed = await evaluate(exampleWindow, labels);
        assert.ok(!listed.includes('Escapes its plugin'), 'An example whose file escapes its plugin directory must be skipped.');
        assert.equal(listed.filter((label) => label === 'Thermal Management').length, 1, 'An example colliding with a bundled id must be skipped.');

        await evaluate(exampleWindow, `[...document.querySelectorAll('.examplesExplorerItem')].find((item) => item.querySelector('b').textContent === 'Plugin tank').click()`);
        await waitFor(exampleWindow, `document.querySelector('#examplesExplorerDetailTitle').textContent === 'Plugin tank'`, 'Selecting the plugin example did not populate the preview.');
        // The status line is the validation readout too: it says the example is an unsaved copy once its guide has
        // opened, and the model's validation may say its own a moment later. Every message it shows is recorded from
        // before the load, so the one saying so is seen however soon the next follows it.
        await evaluate(exampleWindow, `(() => {
            window.__statusMessages = [];
            const status = document.querySelector('#statusText');
            new MutationObserver(() => window.__statusMessages.push(status.textContent)).observe(status, { childList: true, characterData: true, subtree: true });
        })()`);
        await evaluate(exampleWindow, `document.querySelector('#examplesExplorerLoad').click()`);
        await waitFor(exampleWindow, `document.querySelector('.documentTitle').textContent === 'pluginTank'`, 'The plugin example did not load.');
        await waitFor(exampleWindow, `window.__statusMessages.some((message) => /unsaved copy/i.test(message))`, 'The plugin example was not said to be an unsaved copy.', 15000);
        // A label enters the page when the canvas next draws a frame, which is after the title is set.
        await waitFor(exampleWindow, `document.querySelectorAll('.node-label-container').length === 1`, 'The plugin example did not show its one node.');
        await closeWhenValidated(exampleWindow);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own isolated window; a plugin directory is written to the desktop userData' });

    await run('label detail cycles compact, expanded and hidden, keeping the selected label', async () => {
        // Sixteen nodes packed into a small area: far more labels than fit, the case that motivated the hidden state.
        const project = {
            format: 'konjugate', version: 1, metadata: { units: 'SI' }, edges: [],
            nodes: Array.from({ length: 16 }, (_unused, index) => ({
                id: 1 + index * 2, name: `Crowded ${index + 1}`, position: [(index % 4) * 0.5, Math.floor(index / 4) * 0.5, 0], sourceTerms: [],
                appearance: { type: 'primitive', shape: 'box', color: '#888888' },
                states: [{ id: 2 + index * 2, name: 'Level', symbol: 'level', initialValue: index }]
            }))
        };
        const directory = await mkdtemp(join(tmpdir(), 'konjugate-labels-'));
        const projectPath = join(directory, 'crowded.kjt');
        await writeFile(projectPath, await encodeProjectFile(JSON.stringify(project)));
        const before = driver.allHandles();
        await driver.simulateOsFileOpen(projectPath);
        const crowded = await driver.waitForNewHandle(before);
        await waitFor(crowded, `document.querySelectorAll('.node-label-container').length === 16`, 'The crowded project did not load.');
        const visibleLabels = `[...document.querySelectorAll('.node-label-container')].filter((label) => getComputedStyle(label).visibility !== 'hidden').length`;

        // The Nodes button cycles compact -> expanded -> hidden -> compact, and says which it is.
        const nodesButton = `document.querySelector('[data-detail="nodes"]')`;
        assert.equal(await evaluate(crowded, `${nodesButton}.dataset.mode`), 'compact');
        await evaluate(crowded, `${nodesButton}.click()`);
        assert.equal(await evaluate(crowded, `${nodesButton}.dataset.mode`), 'expanded');
        assert.equal(await evaluate(crowded, `document.querySelector('#canvas').classList.contains('showNodesDetails')`), true);
        assert.match(await evaluate(crowded, `${nodesButton}.title`), /expanded · click for hidden/);
        await evaluate(crowded, `${nodesButton}.click()`);
        assert.equal(await evaluate(crowded, `${nodesButton}.dataset.mode`), 'hidden');
        assert.equal(await evaluate(crowded, `document.querySelector('#canvas').classList.contains('hideNodeLabels')`), true);
        assert.equal(await evaluate(crowded, `document.querySelector('#canvas').classList.contains('showNodesDetails')`), false);
        assert.equal(await evaluate(crowded, visibleLabels), 0, 'Hidden node labels are all gone when nothing is selected.');

        // A selected node keeps its label, so it is never hard to tell what you have picked.
        await evaluate(crowded, `document.querySelector('.node-label-container[data-node="1"]').click()`);
        await waitFor(crowded, `${visibleLabels} === 1`, 'The selected node did not keep its label while labels were hidden.');
        assert.equal(await evaluate(crowded, `getComputedStyle(document.querySelector('.node-label-container[data-node="1"]')).visibility`), 'visible');
        await evaluate(crowded, `${nodesButton}.click()`);
        assert.equal(await evaluate(crowded, `${nodesButton}.dataset.mode`), 'compact');
        assert.equal(await evaluate(crowded, visibleLabels), 16);
        await closeWhenValidated(crowded);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own project window through an OS-style file open; no web-edition equivalent' });

    await run('opening a model with hundreds of relationships starts with relationship labels hidden', async () => {
        const node = (id, name) => ({ id, name, position: [id, 0, 0], sourceTerms: [], appearance: { type: 'primitive', shape: 'box', color: '#888888' }, states: [{ id: id + 1, name: 'Level', symbol: 'level', initialValue: 0 }] });
        const large = {
            format: 'konjugate', version: 1, metadata: { units: 'SI' }, nodes: [node(1, 'Left'), node(3, 'Right')],
            edges: Array.from({ length: 160 }, (_unused, index) => ({
                id: 10 + index, name: `Link ${index}`, source: { nodeId: 1, stateId: 2 }, target: { nodeId: 3, stateId: 4 }, directionality: 'directed',
                equation: '', parameters: [], appearance: { color: '#888888', offset: 0 }
            }))
        };
        const directory = await mkdtemp(join(tmpdir(), 'konjugate-large-'));
        const largePath = join(directory, 'large.kjt');
        await writeFile(largePath, await encodeProjectFile(JSON.stringify(large)));
        const before = driver.allHandles();
        await driver.simulateOsFileOpen(largePath);
        const largeWindow = await driver.waitForNewHandle(before);
        await waitFor(largeWindow, `document.querySelectorAll('.node-label-container').length === 2`, 'The large project did not load.');
        assert.equal(await evaluate(largeWindow, `document.querySelector('[data-detail="edges"]').dataset.mode`), 'hidden');
        assert.equal(await evaluate(largeWindow, `document.querySelector('[data-detail="nodes"]').dataset.mode`), 'compact', 'Node labels are left alone.');
        // The user can bring them back with one more cycle.
        await evaluate(largeWindow, `document.querySelector('[data-detail="edges"]').click()`);
        assert.equal(await evaluate(largeWindow, `document.querySelector('[data-detail="edges"]').dataset.mode`), 'compact');
        await closeWhenValidated(largeWindow);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own project window through an OS-style file open; no web-edition equivalent' });

    await run('a model of many nodes leaves out the node labels that would overlap, and says how many', async () => {
        // Forty nodes a fifth of a unit apart: their labels, cards of a fixed size on screen, would lie over each other.
        const crowded = {
            format: 'konjugate', version: 1, metadata: { units: 'SI' }, edges: [],
            nodes: Array.from({ length: 40 }, (_unused, index) => ({
                id: 1 + index * 2, name: `Site ${index + 1}`, position: [(index % 8) * 0.2, 0, Math.floor(index / 8) * 0.2], sourceTerms: [],
                appearance: { type: 'primitive', shape: 'box', color: '#888888' }, states: [{ id: 2 + index * 2, name: 'Level', symbol: 'level', initialValue: 0 }]
            }))
        };
        const directory = await mkdtemp(join(tmpdir(), 'konjugate-crowded-'));
        const crowdedPath = join(directory, 'crowded.kjt');
        await writeFile(crowdedPath, await encodeProjectFile(JSON.stringify(crowded)));
        const before = driver.allHandles();
        await driver.simulateOsFileOpen(crowdedPath);
        const crowdedWindow = await driver.waitForNewHandle(before);
        // Loaded means all forty labels are accounted for: drawn, or left out. Not "forty label elements exist":
        // a label is added to the page the first time it is drawn, so one left out before its first frame (the
        // left-out pass runs on its own timer, and can come first in a new window) never gets an element at all.
        await waitFor(crowdedWindow, `[...document.querySelectorAll('.node-label-container')].filter((label) => label.style.display !== 'none').length
            + Number(document.querySelector('#canvas').dataset.labelsLeftOut ?? 0) === 40`, 'The crowded project did not load.');
        await waitFor(crowdedWindow, `Number(document.querySelector('#canvas').dataset.labelsLeftOut) > 0`, 'No label was left out of a crowded canvas.', 5000);
        const leftOut = Number(await evaluate(crowdedWindow, `document.querySelector('#canvas').dataset.labelsLeftOut`));
        assert.ok(leftOut >= 10 && leftOut < 40, `${leftOut} of 40 labels left out`);
        await waitFor(crowdedWindow, `[...document.querySelectorAll('.node-label-container')].filter((label) => label.style.display !== 'none').length === ${40 - leftOut}`, 'The labels left out are still drawn.', 3000);
        // Those written do not lie over each other.
        const overlapping = await evaluate(crowdedWindow, `(() => {
            const boxes = [...document.querySelectorAll('.node-label-container')].filter((label) => label.style.display !== 'none').map((label) => label.querySelector('.objectLabel').getBoundingClientRect());
            let count = 0;
            for (let a = 0; a < boxes.length; a += 1) for (let b = a + 1; b < boxes.length; b += 1) {
                if (boxes[a].left < boxes[b].right && boxes[b].left < boxes[a].right && boxes[a].top < boxes[b].bottom && boxes[b].top < boxes[a].bottom) count += 1;
            }
            return count;
        })()`);
        assert.equal(overlapping, 0, 'No two written labels overlap.');
        assert.match(await evaluate(crowdedWindow, `document.querySelector('[data-detail="nodes"]').title`), new RegExp(`${leftOut} left out where they would overlap`));
        await closeWhenValidated(crowdedWindow);
    }, { skip: !driver.capabilities.multiWindow && 'opens its own project window through an OS-style file open; no web-edition equivalent' });

    // ---- Everything a toolbox can write, a user can write in the canvas ------------------------------------------------
    // A small model of two nodes joined by one edge, loaded into this window, for the scenarios below.
    const loadAuthoringProject = async (overrides = {}) => {
        const state = (id, symbol, initialValue = 0) => ({ id, name: symbol, symbol, initialValue });
        const project = {
            format: 'konjugate', version: 1, metadata: { units: 'SI' }, sharedParameters: [],
            nodes: [
                { id: 1, name: 'Mass', position: [-4, 0, 0], appearance: { type: 'primitive', shape: 'box', color: '#888888' },
                    states: [state(2, 'position', 1), state(3, 'speed')], sourceTerms: [] },
                { id: 4, name: 'Probe', position: [4, 0, 0], appearance: { type: 'primitive', shape: 'box', color: '#888888' },
                    states: [state(5, 'angle'), state(6, 'reading')], sourceTerms: [] }
            ],
            edges: [{
                id: 7, name: 'Sense', source: { nodeId: 1, stateId: 2 }, target: { nodeId: 4, stateId: 5 }, directionality: 'directed',
                equation: '0', equationModel: { latex: '0', output: { role: 'target', stateId: 5 }, bindings: [], mathJson: 0 },
                parameters: [], appearance: { color: '#888888', offset: 0 }
            }],
            ...overrides
        };
        await evaluate(window, `window.__debugProject.load(${JSON.stringify(project)})`);
        await waitFor(window, `document.querySelectorAll('.node-label-container').length === 2`, 'The authoring project did not load.');
    };
    const savedProject = async () => JSON.parse(await evaluate(window, `JSON.stringify(window.__debugProject.serialize())`));
    const openNode = async (title) => {
        const label = `[...document.querySelectorAll('.objectLabel')].find((item) => item.textContent.includes(${JSON.stringify(title)}))`;
        await waitFor(window, `Boolean(${label})`, `The ${title} label was not on the canvas.`);
        await evaluate(window, `${label}.click()`);
        await waitFor(window, `!document.querySelector('#nodeEditor').classList.contains('hidden') && document.querySelector('#editNodeName').value === ${JSON.stringify(title)}`, `The ${title} node editor did not open.`);
    };
    const openRelationship = async (title) => {
        // A third of the way along, clear of the label the canvas draws at the middle, once the view has stopped moving
        // (a model just loaded is still being fitted into view).
        const locate = () => canvasPoint(window, `JSON.stringify(window.__relationshipScreenPoint(${JSON.stringify(title)}, 0.3))`);
        let previous = null;
        let located = await locate();
        for (let attempt = 0; attempt < 40 && located !== previous; attempt += 1) {
            await new Promise((resolve) => setTimeout(resolve, 100));
            previous = located;
            located = await locate();
        }
        const point = JSON.parse(located);
        assert.ok(point, `Could not locate ${title} on screen.`);
        await window.mouseMove(point);
        await window.mouseDown(point, { button: 'left', clickCount: 1 });
        await window.mouseUp(point, { button: 'left', clickCount: 1 });
        await waitFor(window, `!document.querySelector('#edgeEditor').classList.contains('hidden') && document.querySelector('#editEdgeName').value === ${JSON.stringify(title)}`, `The ${title} edge editor did not open.`);
    };
    const typeInto = (selector, value, event = 'change') => evaluate(window, `(() => { const input = ${selector}; input.value = ${JSON.stringify(value)}; input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event(${JSON.stringify(event)}, { bubbles: true })); })()`);

    await run('atan2 is typed as most people write it, and the equation help lists every function', async () => {
        await loadAuthoringProject();
        await openRelationship('Sense');
        await evaluate(window, `document.querySelector('[data-equation-mode="latex"]').click()`);
        await typeInto(`document.querySelector('#editEdgeEquation')`, String.raw`\operatorname{atan2}(\mathrm{sourceSpeed},\mathrm{sourcePosition})`);
        await waitFor(window, `document.querySelector('#equationDiagnostics').classList.contains('valid')`, 'atan2 was not accepted.');
        assert.match(await evaluate(window, `document.querySelector('#edgeFunctions').textContent`), /atan2\(y, x\)/);
        assert.deepEqual((await savedProject()).edges[0].equationModel.mathJson, ['Arctan2', 'sourceSpeed', 'sourcePosition']);
        await evaluate(window, `document.querySelector('[data-equation-mode="visual"]').click()`);
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
    });

    await run('a node\'s states are reordered by button and by key, and each move is undone', async () => {
        await loadAuthoringProject();
        await openNode('Mass');
        const order = async () => (await savedProject()).nodes[0].states.map(({ symbol }) => symbol);
        const row = (symbol) => `[...document.querySelectorAll('#nodeEditorStates .editorStateRow')].find((item) => item.querySelector('[data-field="symbol"]').value === ${JSON.stringify(symbol)})`;
        assert.equal(await evaluate(window, `${row('position')}.querySelector('[data-move="-1"]').disabled`), true, 'The first state cannot move up.');
        // By button: the speed moves before the position it changes, as semi-implicit integration wants.
        await evaluate(window, `${row('speed')}.querySelector('[data-move="-1"]').click()`);
        assert.deepEqual(await order(), ['speed', 'position']);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.deepEqual(await order(), ['position', 'speed']);
        // Undo closes the inspector, as it always does; open it again.
        await openNode('Mass');
        // By key, from a field of the row, which keeps the keyboard on the moved row.
        await evaluate(window, `(() => { const field = ${row('position')}.querySelector('[data-field="name"]'); field.focus(); field.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', altKey: true, bubbles: true })); })()`);
        assert.deepEqual(await order(), ['speed', 'position']);
        assert.equal(await evaluate(window, `document.activeElement === ${row('position')}.querySelector('[data-field="name"]')`), true,
            `The moved row keeps the focus, not ${await evaluate(window, `document.activeElement?.outerHTML?.slice(0, 120)`)}.`);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.deepEqual(await order(), ['position', 'speed']);
    });

    // Waits for the engine's own verdict on the model as it now is.
    const engineVerdict = async (message) => {
        await waitFor(window, `document.querySelector('#validationSummary').dataset.validationSource === 'engine' && !document.querySelector('#validationSummary').classList.contains('pending')`, message, 15000);
        return evaluate(window, `!document.querySelector('#validationSummary').classList.contains('error')`);
    };
    const gainParameter = { id: 8, name: 'Gain', symbol: 'gain', value: 2, mode: 'constant' };
    const singleSense = {
        id: 7, name: 'Sense', source: { nodeId: 1, stateId: 2 }, target: { nodeId: 4, stateId: 5 }, directionality: 'bidirectional',
        equation: String.raw`\mathrm{sourceSpeed}`,
        equationModel: { latex: String.raw`\mathrm{sourceSpeed}`, output: { role: 'target', stateId: 6 }, bindings: [], mathJson: 'sourceSpeed' },
        parameters: [gainParameter], appearance: { color: '#888888', offset: 0 }
    };

    await run('a relationship gets several equations that set values, each written, named, moved and removed in the canvas', async () => {
        await loadAuthoringProject({ edges: [singleSense] });
        await openRelationship('Sense');
        const several = () => savedProject().then((project) => project.edges[0]);
        const rowSelector = (kind, index) => `document.querySelector('#editEdgeEquationsList .severalRow[data-kind="${kind}"][data-index="${index}"]')`;
        const setRowLatex = (kind, index, latex) => typeInto(`${rowSelector(kind, index)}.querySelector('textarea')`, latex);
        const select = (selector, value) => evaluate(window, `(() => { const element = ${selector}; element.value = ${JSON.stringify(value)}; element.dispatchEvent(new Event('change', { bubbles: true })); })()`);

        // The one equation becomes the first of several, setting its state; the relationship becomes directed.
        await select(`document.querySelector('#editEdgeImplementationKind')`, 'equations');
        await waitFor(window, `!document.querySelector('#editEdgeEquationsList').hidden`, 'The equations editor did not open.');
        let edge = await several();
        assert.equal(edge.directionality, 'directed');
        assert.deepEqual(edge.equationModel.outputs, [{ role: 'target', stateId: 6, latex: String.raw`\mathrm{sourceSpeed}`, mathJson: 'sourceSpeed', setsValue: true }]);
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeDirectionality').disabled`), true);
        await evaluate(window, `document.querySelector('[data-equation-mode="latex"]').click()`);

        // An intermediate quantity, renamed: the equations reading it follow.
        await evaluate(window, `document.querySelector('[data-add-several="definition"]').click()`);
        await setRowLatex('definition', 0, String.raw`2\cdot\mathrm{gain}`);
        await evaluate(window, `document.querySelector('[data-add-several="output"]').click()`);
        await waitFor(window, `Boolean(${rowSelector('output', 1)})`, 'The new equation row did not appear.');
        assert.equal(await evaluate(window, `${rowSelector('output', 1)}.querySelector('select').selectedOptions[0].textContent`), 'target.angle', 'A new equation sets a state no other equation sets.');
        await setRowLatex('output', 1, String.raw`\mathrm{q1}\cdot\mathrm{sourceSpeed}`);
        await waitFor(window, `${rowSelector('output', 1)}.querySelector('.equationDiagnostics').classList.contains('valid')`, 'The equation reading the quantity was not valid.');
        await typeInto(`${rowSelector('definition', 0)}.querySelector('[data-field="symbol"]')`, 'twice');
        edge = await several();
        assert.deepEqual(edge.equationModel.definitions, [{ symbol: 'twice', latex: String.raw`2\cdot\mathrm{gain}`, mathJson: ['Multiply', 2, 'gain'] }]);
        assert.equal(edge.equationModel.outputs[1].latex, String.raw`\mathrm{twice}\cdot\mathrm{sourceSpeed}`);
        assert.deepEqual([edge.equationModel.outputs[1].mathJson[0], ...edge.equationModel.outputs[1].mathJson.slice(1).sort()], ['Multiply', 'sourceSpeed', 'twice']);
        assert.deepEqual(edge.equationModel.bindings.map(({ symbol }) => symbol).sort(), ['gain', 'sourceSpeed']);
        assert.equal(await engineVerdict('The model with several equations was not validated.'), true, 'The engine should accept the equations written in the canvas.');

        // A reference chip inserts into the field last focused.
        await evaluate(window, `${rowSelector('output', 0)}.querySelector('textarea').focus()`);
        await evaluate(window, `(() => { const field = ${rowSelector('output', 0)}.querySelector('textarea'); field.setSelectionRange(field.value.length, field.value.length); })()`);
        await evaluate(window, `[...document.querySelectorAll('#editStateReferenceChips button')].find((chip) => chip.textContent === 'twice').click()`);
        await waitFor(window, `${rowSelector('output', 0)}.querySelector('textarea').value.endsWith('\\\\mathrm{twice}')`, 'The chip did not insert into the focused equation.');

        // Two equations setting one state are refused on the row, by name.
        await select(`${rowSelector('output', 1)}.querySelector('select')`, (await evaluate(window, `${rowSelector('output', 0)}.querySelector('select').value`)));
        assert.match(await evaluate(window, `${rowSelector('output', 1)}.querySelector('.equationDiagnostics').textContent`), /target\.reading is set by another equation/);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        await openRelationship('Sense');

        // Moved by button and by key, then removed.
        await evaluate(window, `${rowSelector('output', 1)}.querySelector('[data-move="-1"]').click()`);
        assert.deepEqual((await several()).equationModel.outputs.map(({ stateId }) => stateId), [5, 6]);
        await evaluate(window, `(() => { const field = ${rowSelector('output', 0)}.querySelector('textarea'); field.focus(); field.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', altKey: true, bubbles: true })); })()`);
        assert.deepEqual((await several()).equationModel.outputs.map(({ stateId }) => stateId), [6, 5]);
        await evaluate(window, `${rowSelector('output', 1)}.querySelector('[data-remove]').click()`);
        assert.deepEqual((await several()).equationModel.outputs.map(({ stateId }) => stateId), [6]);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.deepEqual((await several()).equationModel.outputs.map(({ stateId }) => stateId), [6, 5], 'Undo brings a removed equation back.');

        // Back to one equation: the first stays, with the quantity it reads written into it.
        await openRelationship('Sense');
        await evaluate(window, `window.__confirmAnswer = window.confirm; window.confirm = () => true`);
        await select(`document.querySelector('#editEdgeImplementationKind')`, 'equation');
        await evaluate(window, `window.confirm = window.__confirmAnswer`);
        edge = await several();
        assert.equal(edge.equationModel.outputs, undefined);
        assert.deepEqual(edge.equationModel.output, { role: 'target', stateId: 6 });
        assert.equal(await evaluate(window, `document.querySelector('#editEdgeDirectionality').disabled`), false);
        await evaluate(window, `document.querySelector('[data-equation-mode="visual"]').click()`);
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
    });

    await run('a relationship a toolbox wrote with several equations opens readable, and editing one equation keeps the others exactly', async () => {
        // As the robotics toolbox writes a joint: its own binding symbols, MathJSON, and LaTeX that is only for show.
        const written = {
            id: 7, name: 'Joint', source: { nodeId: 1, stateId: 2 }, target: { nodeId: 4, stateId: 5 }, directionality: 'directed',
            equation: '', parameters: [gainParameter], appearance: { color: '#888888', offset: 0 },
            equationModel: {
                bindings: [{ symbol: 'pX', kind: 'state', role: 'source', nodeId: 1, stateId: 2 }, { symbol: 'gain', kind: 'parameter', parameterId: 8 }],
                definitions: [{ symbol: 'cosq', mathJson: ['Cos', 'pX'], latex: String.raw`\cos\left(\mathrm{p}_{X}\right)` }],
                outputs: [
                    { role: 'target', stateId: 5, mathJson: ['Multiply', 'gain', 'cosq'], latex: String.raw`\mathrm{gain}\,\mathrm{cosq}`, setsValue: true },
                    { role: 'target', stateId: 6, mathJson: ['Add', 'pX', 1], setsValue: true }
                ]
            }
        };
        await loadAuthoringProject({ edges: [written] });
        assert.equal(await engineVerdict('The toolbox relationship was not validated.'), true);
        await openRelationship('Joint');
        await evaluate(window, `document.querySelector('[data-equation-mode="latex"]').click()`);
        const rowField = (kind, index) => `document.querySelector('#editEdgeEquationsList .severalRow[data-kind="${kind}"][data-index="${index}"] textarea')`;
        assert.equal(await evaluate(window, `${rowField('definition', 0)}.value`), String.raw`\cos\left(\mathrm{pX}\right)`, 'LaTeX that does not read back is shown as written from the MathJSON.');
        assert.equal(await evaluate(window, `${rowField('output', 1)}.value`), String.raw`\mathrm{pX}+1`, 'An equation with no LaTeX is shown as written from its MathJSON.');
        assert.equal(await evaluate(window, `[...document.querySelectorAll('#editEdgeEquationsList .equationDiagnostics')].every((item) => item.classList.contains('valid'))`), true);
        // Opening it changed nothing.
        assert.deepEqual((await savedProject()).edges[0].equationModel, written.equationModel);
        await typeInto(rowField('output', 1), String.raw`\mathrm{pX}+2`);
        const edited = (await savedProject()).edges[0].equationModel;
        assert.deepEqual(edited.outputs[1].mathJson, ['Add', 'pX', 2]);
        assert.deepEqual(edited.outputs[0].mathJson, written.equationModel.outputs[0].mathJson);
        assert.deepEqual(edited.definitions[0].mathJson, written.equationModel.definitions[0].mathJson);
        assert.deepEqual(edited.bindings, written.equationModel.bindings, 'The toolbox\'s bindings are kept as they were.');
        assert.equal(await engineVerdict('The edited relationship was not validated.'), true);
        await evaluate(window, `document.querySelector('[data-equation-mode="visual"]').click()`);
        await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);
    });

    await run('a shared parameter is given a schedule, edited, removed and undone from the parameters table', async () => {
        await loadAuthoringProject({
            sharedParameters: [{ id: 100, name: 'Price', symbol: 'price', value: 2, unit: '', mode: 'constant' }],
            edges: [{ ...singleSense, directionality: 'directed', equation: String.raw`\mathrm{gain}`,
                equationModel: { latex: String.raw`\mathrm{gain}`, output: { role: 'target', stateId: 6 }, bindings: [{ kind: 'parameter', parameterId: 8, symbol: 'gain' }], mathJson: 'gain' },
                parameters: [{ ...gainParameter, sharedParameterId: 100 }] }]
        });
        const shared = async () => (await savedProject()).sharedParameters.find(({ id }) => id === 100);
        if (await evaluate(window, `document.querySelector('#parametersPanel').hidden`)) await evaluate(window, `document.querySelector('#parametersButton').click()`);
        await waitFor(window, `!document.querySelector('#parametersPanel').hidden`, 'The parameters panel did not open.');
        const sharedRow = `document.querySelector('#parametersTable tr.sharedRow')`;
        await waitFor(window, `Boolean(${sharedRow}?.querySelector('.scheduleAdd'))`, 'The shared parameter has no schedule button.');
        await evaluate(window, `${sharedRow}.querySelector('.scheduleAdd').click()`);
        await waitFor(window, `document.querySelector('#scheduleDialog').open`, 'The schedule dialog did not open.');
        assert.equal(await evaluate(window, `document.querySelector('#scheduleSamples').value`), '0, 2', 'A new schedule starts from the constant it replaces.');
        // Times that do not increase cannot be saved, and the dialog says why.
        await typeInto(`document.querySelector('#scheduleSamples')`, 'time, price\n0, 2\n10, 3\n10, 4', 'input');
        assert.match(await evaluate(window, `document.querySelector('#scheduleError').textContent`), /times must increase/);
        assert.equal(await evaluate(window, `document.querySelector('#scheduleSave').disabled`), true);
        await typeInto(`document.querySelector('#scheduleSamples')`, 'time, price\n0, 2\n10, 3\n20, 4', 'input');
        assert.match(await evaluate(window, `document.querySelector('#scheduleSummary').textContent`), /3 samples, linearly interpolated/);
        // Saved by key, as by the button.
        await evaluate(window, `document.querySelector('#scheduleSamples').dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', ctrlKey: !/Mac/.test(navigator.platform), metaKey: /Mac/.test(navigator.platform), bubbles: true }))`);
        await waitFor(window, `!document.querySelector('#scheduleDialog').open`, 'Ctrl+Enter did not save the schedule.');
        assert.deepEqual((await shared()).schedule, { interpolation: 'linear', samples: [[0, 2], [10, 3], [20, 4]] });
        assert.equal(await engineVerdict('The scheduled parameter was not validated.'), true);
        // Edited: each value held.
        await evaluate(window, `${sharedRow}.querySelector('.scheduleOpen').click()`);
        await waitFor(window, `document.querySelector('#scheduleDialog').open`, 'The schedule did not open for editing.');
        assert.equal(await evaluate(window, `document.querySelector('#scheduleSamples').value`), '0, 2\n10, 3\n20, 4');
        await evaluate(window, `(() => { const select = document.querySelector('#scheduleInterpolation'); select.value = 'hold'; select.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        await evaluate(window, `document.querySelector('#scheduleSave').click()`);
        assert.equal((await shared()).schedule.interpolation, 'hold');
        // Removed from the dialog, and undone.
        await evaluate(window, `${sharedRow}.querySelector('.scheduleOpen').click()`);
        await evaluate(window, `document.querySelector('#scheduleRemove').click()`);
        assert.equal((await shared()).schedule, undefined);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal((await shared()).schedule?.interpolation, 'hold');
        await evaluate(window, `document.querySelector('#parametersButton').click()`);
    });

    await run('a node gets a program in the node editor: its language, inputs from any node or shared parameter, outputs and source', async () => {
        await loadAuthoringProject({ sharedParameters: [{ id: 100, name: 'Setpoint', symbol: 'setpoint', value: 10, unit: '', mode: 'constant' }] });
        await openNode('Mass');
        const program = async () => (await savedProject()).nodes[0].implementation;
        const select = (selector, value) => evaluate(window, `(() => { const element = ${selector}; element.value = ${JSON.stringify(value)}; element.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        await select(`document.querySelector('#editNodeProgramKind')`, 'python');
        await waitFor(window, `!document.querySelector('#nodeProgramFields').hidden`, 'The program fields did not open.');
        assert.match((await program()).source, /class Mass\(NodeProvider\)/, 'A new program starts from a template.');
        assert.match(await evaluate(window, `document.querySelector('#nodeProgramError').textContent`), /Add an output/);
        // An input reading another node's state, one reading a shared parameter, and an output setting a value.
        await evaluate(window, `document.querySelector('#editAddNodeProgramInput').click()`);
        await select(`document.querySelector('#nodeProgramInputs .nodeProgramRow select')`, 'state:4:6');
        await evaluate(window, `document.querySelector('#editAddNodeProgramInput').click()`);
        await select(`document.querySelectorAll('#nodeProgramInputs .nodeProgramRow')[1].querySelector('select')`, 'shared:100');
        await typeInto(`document.querySelectorAll('#nodeProgramInputs .nodeProgramRow')[1].querySelector('[data-field="key"]')`, 'setpoint');
        await evaluate(window, `document.querySelector('#editAddNodeProgramOutput').click()`);
        await evaluate(window, `(() => { const box = document.querySelector('#nodeProgramOutputs [data-field="setsValue"]'); box.checked = true; box.dispatchEvent(new Event('change', { bubbles: true })); })()`);
        let implementation = await program();
        assert.deepEqual(implementation.bindings, [{ key: 'input', kind: 'state', nodeId: 4, stateId: 6 }, { key: 'setpoint', kind: 'parameter', sharedParameterId: 100 }]);
        assert.deepEqual(implementation.outputs, [{ key: 'output', stateId: 2, setsValue: true }]);
        assert.equal(await evaluate(window, `document.querySelector('#nodeProgramError').textContent`), '');
        // The template is written again from the inputs and outputs, and the source is typed: one undo step each.
        await evaluate(window, `window.__confirmAnswer = window.confirm; window.confirm = () => true`);
        await evaluate(window, `document.querySelector('#editNodeProgramTemplate').click()`);
        await evaluate(window, `window.confirm = window.__confirmAnswer`);
        implementation = await program();
        assert.match(implementation.source, /ScalarPort\("setpoint", "setpoint", ""\)/);
        assert.match(implementation.source, /outputs\.add_gradient\("output", 0\.0\)/);
        await typeInto(`document.querySelector('#editNodeProgramSource')`, implementation.source.replace('0.0)', 'inputs["setpoint"])'));
        assert.match((await program()).source, /add_gradient\("output", inputs\["setpoint"\]\)/);
        assert.equal(await engineVerdict('The node with a program was not validated.'), true);
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.match((await program()).source, /add_gradient\("output", 0\.0\)/, 'Undo takes back the typing.');
        // C++, then none.
        await openNode('Mass');
        await select(`document.querySelector('#editNodeProgramKind')`, 'cpp');
        implementation = await program();
        assert.equal(implementation.kind, 'cpp');
        assert.match(implementation.source, /public konjugate::sdk::v1::NodeProvider/);
        assert.equal(implementation.bindings.length, 2, 'The inputs carry over to another language.');
        await select(`document.querySelector('#editNodeProgramKind')`, '');
        assert.equal(await program(), undefined);
    });

    await run('a node is computed by an installed FMU, wired under the FMU\'s own keys', async () => {
        // An FMU stand-in: what the Extensions explorer lists, and the ports the desktop reads from its modelDescription.
        await evaluate(window, `(() => {
            window.__extensionsList = window.extensions.list; window.__fmuPorts = window.extensions.fmuPorts;
            window.extensions.list = async () => [{ packageType: 'fmu', packageId: 'guid-1', name: 'Heater', version: '1.0', enabled: true }];
            window.extensions.fmuPorts = async () => ({ name: 'Heater', fmiVersion: '2.0', inputs: [{ key: 'power', name: 'power', causality: 'input' }], outputs: [{ key: 'temperature', name: 'temperature' }] });
        })()`);
        try {
            await loadAuthoringProject();
            await openNode('Mass');
            await evaluate(window, `(() => { const element = document.querySelector('#editNodeProgramKind'); element.value = 'fmi'; element.dispatchEvent(new Event('change', { bubbles: true })); })()`);
            await waitFor(window, `document.querySelectorAll('#nodeProgramInputs .nodeProgramRow').length === 1`, 'The FMU\'s input was not listed.');
            let implementation = (await savedProject()).nodes[0].implementation;
            assert.deepEqual(implementation, { kind: 'fmi', fmuId: 'guid-1', fmuVersion: '1.0', bindings: [{ key: 'power', kind: 'state', stateId: null }], outputs: [{ key: 'temperature', stateId: null, setsValue: true }] });
            assert.equal(await evaluate(window, `document.querySelector('#nodeProgramInputs [data-field="key"]').readOnly`), true, 'The FMU\'s keys are its own.');
            assert.equal(await evaluate(window, `document.querySelector('#editAddNodeProgramInput').hidden`), true);
            await evaluate(window, `(() => { const element = document.querySelector('#nodeProgramInputs select'); element.value = 'state:4:6'; element.dispatchEvent(new Event('change', { bubbles: true })); })()`);
            await evaluate(window, `(() => { const element = document.querySelector('#nodeProgramOutputs select'); element.value = '3'; element.dispatchEvent(new Event('change', { bubbles: true })); })()`);
            implementation = (await savedProject()).nodes[0].implementation;
            assert.deepEqual(implementation.bindings, [{ key: 'power', kind: 'state', nodeId: 4, stateId: 6 }]);
            assert.deepEqual(implementation.outputs, [{ key: 'temperature', stateId: 3, setsValue: true }]);
            assert.equal(await evaluate(window, `document.querySelector('#nodeProgramOutputs [data-field="setsValue"]').disabled`), true, 'An FMU reports values, never rates.');
        } finally {
            await evaluate(window, `window.extensions.list = window.__extensionsList; window.extensions.fmuPorts = window.__fmuPorts`);
        }
    }, { skip: driver.kind !== 'playwright' && 'stands in for an installed FMU, which the desktop bridge does not let a test replace; the FMU import fidelity tests cover real ones' });

    await run('a node is given body parts for result visualizers, each from a mesh file, named, coloured, replaced and removed', async () => {
        await loadAuthoringProject();
        await openNode('Mass');
        await evaluate(window, `document.querySelector('[data-node-tab="appearance"]').click()`);
        const parts = async () => (await savedProject()).nodes[0].appearance.parts;
        // A one-triangle STL in millimetres, chosen as a person picks a file.
        const choose = (selector, size) => evaluate(window, `(() => {
            const stl = ['solid t', 'facet normal 0 0 1', 'outer loop', 'vertex 0 0 0', 'vertex ${size} 0 0', 'vertex 0 ${size} 0', 'endloop', 'endfacet', 'endsolid t'].join(String.fromCharCode(10));
            const transfer = new DataTransfer();
            transfer.items.add(new File([stl], 'triangle.stl'));
            const input = ${selector};
            input.files = transfer.files;
            input.dispatchEvent(new Event('change', { bubbles: true }));
        })()`);
        await choose(`document.querySelector('#editAddNodePart')`, 1000);
        await waitFor(window, `document.querySelectorAll('#nodeParts .nodePartRow').length === 1`, 'The part was not added.');
        let saved = await parts();
        assert.deepEqual(saved, [{ prefix: '', color: '#888888', mesh: { position: [0, 0, 0, 1, 0, 0, 0, 1, 0], normal: [0, 0, 1, 0, 0, 1, 0, 0, 1], index: [0, 1, 2] } }]);
        assert.match(await evaluate(window, `document.querySelector('#nodeParts .nodePartProblem').textContent`), /no state x, y, z/, 'A part its node cannot place says so.');
        await typeInto(`document.querySelector('#nodeParts [data-field="prefix"]')`, 'arm');
        await typeInto(`document.querySelector('#nodeParts [data-field="color"]')`, '#d08b4a');
        await choose(`document.querySelector('#nodeParts .partMesh input')`, 500);
        await waitFor(window, `document.querySelector('#nodeParts .partMesh')?.textContent.startsWith('1 triangles')`, 'The replaced mesh was not shown.');
        saved = await parts();
        assert.equal(saved[0].prefix, 'arm');
        assert.equal(saved[0].color, '#d08b4a');
        assert.deepEqual(saved[0].mesh.position, [0, 0, 0, 0.5, 0, 0, 0, 0.5, 0]);
        await evaluate(window, `document.querySelector('#nodeParts .nodePartRow > button').click()`);
        assert.equal(await parts(), undefined, 'With no parts left, the node has none.');
        await evaluate(window, `document.querySelector('#undoButton').click()`);
        assert.equal((await parts())[0].prefix, 'arm');
    });

    await run('an installed plugin\'s provider is chosen for a relationship and for a source term', async () => {
        await evaluate(window, `(() => {
            window.__extensionsList = window.extensions.list;
            window.extensions.list = async () => [{ packageType: 'plugin', packageId: 'example.helloProvider', name: 'Hello', version: '0.1.0',
                enabled: true, manifest: { contributes: [{ providerId: 'example.helloWorld', runtime: 'python' }] } }];
        })()`);
        try {
            await loadAuthoringProject({ edges: [{ ...singleSense, directionality: 'directed' }] });
            const select = (selector, value) => evaluate(window, `(() => { const element = ${selector}; element.value = ${JSON.stringify(value)}; element.dispatchEvent(new Event('change', { bubbles: true })); })()`);
            const reference = JSON.stringify(['example.helloProvider', '0.1.0', 'example.helloWorld']);
            await openRelationship('Sense');
            await select(`document.querySelector('#editEdgeImplementationKind')`, 'plugin');
            await waitFor(window, `!document.querySelector('#editEdgePluginProviderFields').hidden && document.querySelector('#editEdgePluginProvider').options.length === 2`, 'The installed providers were not offered.');
            assert.equal(await evaluate(window, `document.querySelector('#editEdgeProviderCode').hidden`), true, 'A plugin provider has no source to edit.');
            await select(`document.querySelector('#editEdgePluginProvider')`, reference);
            let edge = (await savedProject()).edges[0];
            assert.deepEqual({ ...edge.implementation, output: undefined }, {
                kind: 'plugin', providerApiVersion: 1, pluginId: 'example.helloProvider', pluginVersion: '0.1.0', providerId: 'example.helloWorld', bindings: [], output: undefined
            });
            assert.equal(edge.implementation.output.stateId, 6, 'The state it updates carries over.');
            await select(`document.querySelector('#editEdgeImplementationKind')`, 'python');
            edge = (await savedProject()).edges[0];
            assert.match(edge.implementation.source, /RelationshipProvider/, 'A program starts from a template again.');
            await evaluate(window, `document.querySelector('#edgeEditor [data-close-card]').click()`);

            // A source term of the Mass node.
            await openNode('Mass');
            await evaluate(window, `document.querySelector('#editAddSourceTerm').click()`);
            if (await evaluate(window, `document.querySelector('#sourceTermEditor').classList.contains('hidden')`)) {
                await waitFor(window, `Boolean(document.querySelector('#nodeEditorSourceTerms .sourceTermOpen'))`, 'The source term was not added.');
                await evaluate(window, `[...document.querySelectorAll('#nodeEditorSourceTerms .sourceTermOpen')].at(-1).click()`);
            }
            await waitFor(window, `!document.querySelector('#sourceTermEditor').classList.contains('hidden')`, 'The source term editor did not open.');
            await select(`document.querySelector('#termImplementationKind')`, 'plugin');
            await waitFor(window, `!document.querySelector('#termPluginProviderFields').hidden && document.querySelector('#termPluginProvider').options.length === 2`, 'The installed providers were not offered for the source term.');
            await select(`document.querySelector('#termPluginProvider')`, reference);
            const term = (await savedProject()).nodes[0].sourceTerms.at(-1);
            assert.equal(term.implementation.kind, 'plugin');
            assert.equal(term.implementation.providerId, 'example.helloWorld');
        } finally {
            await evaluate(window, `window.extensions.list = window.__extensionsList`);
        }
    }, { skip: driver.kind !== 'playwright' && 'stands in for an installed plugin, which the desktop bridge does not let a test replace' });

    console.log(`Interaction tests: ${passedCount} passed, ${skippedCount} skipped, ${passedCount + skippedCount} total`);
}
