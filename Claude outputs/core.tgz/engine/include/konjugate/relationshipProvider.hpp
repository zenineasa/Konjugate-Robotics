/* Copyright © 2026 Zenin Easa Panthakkalakath */

#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace konjugate::sdk::v1 {

struct ScalarPort {
    std::string key;
    std::string name;
    std::string unit;
};

struct RelationshipDescription {
    std::string providerId;
    std::string name;
    std::vector<ScalarPort> inputs;
    ScalarPort output;
};

struct NodeProviderDescription {
    std::string providerId;
    std::string name;
    std::vector<ScalarPort> inputs;
    std::vector<ScalarPort> outputs;
};

struct InitializationContext {
    std::uint64_t instanceId = 0;
};

class InputView {
public:
    InputView(std::span<const double> values, std::span<const std::string_view> keys) noexcept
        : values_(values), keys_(keys) {}

    [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
    [[nodiscard]] double at(std::size_t index) const {
        if (index >= values_.size()) throw std::out_of_range("Relationship-provider input index is out of range.");
        return values_[index];
    }
    [[nodiscard]] double at(std::string_view key) const {
        for (std::size_t index = 0; index < keys_.size(); ++index) {
            if (keys_[index] == key) return values_[index];
        }
        throw std::out_of_range("Unknown relationship-provider input key.");
    }

private:
    std::span<const double> values_;
    std::span<const std::string_view> keys_;
};

struct EvaluationContext {
    double simulationTime = 0;
    double stepSize = 0;
    InputView inputs;
};

class OutputCollector {
public:
    void addGradient(double value) noexcept { gradient_ += value; }
    [[nodiscard]] double gradient() const noexcept { return gradient_; }

private:
    double gradient_ = 0;
};

class RelationshipProvider {
public:
    virtual ~RelationshipProvider() = default;
    [[nodiscard]] virtual RelationshipDescription describe() const = 0;
    virtual void initialize(const InitializationContext&) {}
    virtual void evaluate(const EvaluationContext&, OutputCollector&) = 0;
    virtual void shutdown() noexcept {}
};

class NodeOutputCollector {
public:
    void addGradient(std::string_view key, double value) {
        for (auto& output : gradients_) {
            if (output.first == key) {
                output.second += value;
                return;
            }
        }
        gradients_.emplace_back(std::string(key), value);
    }

    [[nodiscard]] const std::vector<std::pair<std::string, double>>& gradients() const noexcept {
        return gradients_;
    }

private:
    std::vector<std::pair<std::string, double>> gradients_;
};

class NodeProvider {
public:
    virtual ~NodeProvider() = default;
    [[nodiscard]] virtual NodeProviderDescription describe() const = 0;
    virtual void initialize(const InitializationContext&) {}
    virtual void evaluate(const EvaluationContext&, NodeOutputCollector&) = 0;
    // The engine treats this payload as fully opaque -- it never inspects or transforms it, and
    // restore() always runs after initialize() with no re-seed or reset in between (see
    // simulationRunner.cpp's startCheckpoint handling). A stochastic provider (e.g. a seeded PRNG
    // driving an SDE) therefore already gets bit-for-bit checkpoint/restore reproducibility for
    // free by serializing its PRNG's full internal state into these bytes and restoring it here --
    // no additional engine machinery is needed. See engine/tests/nodeProviderRuntimeTests.cpp's
    // AccumulatorNode for the same pattern applied to a plain double.
    [[nodiscard]] virtual std::vector<std::byte> checkpoint() const = 0;
    virtual void restore(std::span<const std::byte>) = 0;
    virtual void shutdown() noexcept {}
};

} // namespace konjugate::sdk::v1

std::unique_ptr<konjugate::sdk::v1::RelationshipProvider> createRelationshipProvider();

// Defined by node-provider-shaped inline C++ sources (see providerInProcessNodeShim.cpp), exactly
// like createRelationshipProvider() above is defined by relationship-shaped ones -- which factory
// a given artifact needs to define is determined entirely by which glue file it's compiled with.
std::unique_ptr<konjugate::sdk::v1::NodeProvider> createNodeProvider();
