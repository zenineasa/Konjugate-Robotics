/* Copyright © 2026 Zenin Easa Panthakkalakath */

#include "modelValidator.hpp"
#include "executionPlan.hpp"
#include "stabilityAnalysis.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <functional>
#include <regex>
#include <cstdlib>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <unordered_map>

namespace konjugate {
namespace {
// NOLINTBEGIN(bugprone-throwing-static-initialization) -- fixed, hand-written regex literals,
// verified valid; std::regex's constructor cannot actually throw for these at runtime.
const std::regex entityIdPattern("^[1-9][0-9]{0,15}$");
const std::regex symbolPattern("^[a-z][A-Za-z0-9]*$");
const std::regex providerKeyPattern("^[a-z][A-Za-z0-9]*$");
// NOLINTEND(bugprone-throwing-static-initialization)

ValidationIssue& add(ValidationResult& result, std::string code, std::string severity, std::string message,
         std::string kind = "model", std::string entityId = {}, std::string field = {}) {
    result.issues.push_back({std::move(code), std::move(severity), std::move(message), {std::move(kind), std::move(entityId), std::move(field)}, std::nullopt});
    return result.issues.back();
}

std::string value(const boost::property_tree::ptree& tree, const std::string& key) {
    return tree.get<std::string>(key, "");
}

EntityId idValue(const boost::property_tree::ptree& tree, const std::string& key) {
    return tree.get<EntityId>(key, 0);
}

struct ResolvedAttribution {
    AttributedParameter location;
    std::string phrase;
};

// Resolves a ParameterAttribution (an opaque sourceId/parameterId pair from the compiled plan --
// see stabilityAnalysis.hpp) back to both a human-facing phrase for the issue's own message text,
// and a structured AttributedParameter for precise click-to-focus navigation (see
// IssueAttributedParameterReport in protocol/engineProtocol.proto) -- one document search
// produces both, rather than searching twice. stabilityAnalysis.cpp never sees the document/ptree,
// so this disambiguation (an edge's parameter vs. a source term's) and name lookup can only happen
// here. Returns std::nullopt if the ids can't be resolved -- defensive only; should not happen for
// a ParameterAttribution produced from this same document's own compiled plan, but a warning
// message silently degrading is better than this pass throwing over it.
std::optional<ResolvedAttribution> resolveAttributedParameter(const boost::property_tree::ptree& document, const ParameterAttribution& attribution) {
    if (const auto edges = document.get_child_optional("edges")) {
        for (const auto& edgeEntry : *edges) {
            if (idValue(edgeEntry.second, "id") != attribution.sourceId) continue;
            if (const auto parameters = edgeEntry.second.get_child_optional("parameters")) {
                for (const auto& parameterEntry : *parameters) {
                    if (idValue(parameterEntry.second, "id") != attribution.parameterId) continue;
                    const auto edgeName = value(edgeEntry.second, "name");
                    std::ostringstream description;
                    description << "the edge" << (edgeName.empty() ? "" : " \"" + edgeName + "\"") << "'s '" << value(parameterEntry.second, "name") << "' parameter";
                    return ResolvedAttribution{
                        {"edge", std::to_string(attribution.sourceId), std::to_string(attribution.parameterId)},
                        description.str()
                    };
                }
            }
            return std::nullopt;
        }
    }
    if (const auto nodes = document.get_child_optional("nodes")) {
        for (const auto& nodeEntry : *nodes) {
            const auto terms = nodeEntry.second.get_child_optional("sourceTerms");
            if (!terms) continue;
            for (const auto& termEntry : *terms) {
                if (idValue(termEntry.second, "id") != attribution.sourceId) continue;
                if (const auto parameters = termEntry.second.get_child_optional("parameters")) {
                    for (const auto& parameterEntry : *parameters) {
                        if (idValue(parameterEntry.second, "id") != attribution.parameterId) continue;
                        return ResolvedAttribution{
                            {"sourceTerm", std::to_string(attribution.sourceId), std::to_string(attribution.parameterId)},
                            "this node's own '" + value(parameterEntry.second, "name") + "' source-term parameter"
                        };
                    }
                }
                return std::nullopt;
            }
        }
    }
    return std::nullopt;
}

// Same defensive-empty-string convention as resolveAttributedParameter above, and the same
// reason: dominantStateId comes from the compiled plan, which never sees the document, so
// resolving it to a human-facing symbol can only happen here.
std::string stateSymbol(const boost::property_tree::ptree& document, EntityId stateId) {
    if (const auto nodes = document.get_child_optional("nodes")) {
        for (const auto& nodeEntry : *nodes) {
            const auto states = nodeEntry.second.get_child_optional("states");
            if (!states) continue;
            for (const auto& stateEntry : *states) {
                if (idValue(stateEntry.second, "id") == stateId) return value(stateEntry.second, "symbol");
            }
        }
    }
    return {};
}

void validateProviderOutput(ValidationResult& result,
                            const boost::property_tree::ptree& implementation,
                            const std::unordered_map<std::string, std::set<std::string>>& stateIds,
                            const std::string& sourceNode,
                            const std::string& targetNode,
                            const std::string& edgeId) {
    const auto role = value(implementation, "output.role");
    const auto stateId = value(implementation, "output.stateId");
    const auto key = value(implementation, "output.key");
    if (key.empty() || !std::regex_match(key, providerKeyPattern)) {
        add(result, "providerOutputKeyInvalid", "error", "Provider output key must be lower camel case.", "edge", edgeId, "implementation");
    }
    if (role != "source" && role != "target") {
        add(result, "providerOutputMissing", "error", "Provider output role must be source or target.", "edge", edgeId, "implementation");
        return;
    }
    const auto nodeId = role == "source" ? sourceNode : targetNode;
    const auto states = stateIds.find(nodeId);
    if (stateId.empty() || states == stateIds.end() || !states->second.contains(stateId)) {
        add(result, "providerOutputMissing", "error", "Provider output must reference an existing endpoint state.", "edge", edgeId, "implementation");
    }
}

// Mirrors executionPlan.cpp's bidirectional-edge "other endpoint" defaulting exactly (a
// bidirectional edge's reciprocal contribution targets that node's own source/target.stateId when
// given, else its first state) -- needed so the setsValue "sole contributor" count below can see
// a bidirectional edge's implicit second target, not just its declared primary one.
std::string firstStateIdOf(const std::unordered_map<std::string, const boost::property_tree::ptree*>& nodesById, const std::string& nodeId) {
    const auto found = nodesById.find(nodeId);
    if (found == nodesById.end()) return {};
    const auto states = found->second->get_child_optional("states");
    if (!states || states->empty()) return {};
    return value(states->begin()->second, "id");
}

std::string upperFirst(std::string input) {
    if (!input.empty()) input[0] = static_cast<char>(std::toupper(static_cast<unsigned char>(input[0])));
    return input;
}

bool numericToken(const std::string& token) {
    if (token.empty()) return false;
    char* end = nullptr;
    std::strtod(token.c_str(), &end);
    return end == token.c_str() + token.size();
}

// Expressions are typed: numeric everywhere except the conditions of a "Which" (LaTeX cases),
// which must be comparisons or logic over comparisons. Keeping the two apart means a comparison's
// 1/0 never silently becomes a number in a derivative.
void validateTypedMathJson(const boost::property_tree::ptree& expression,
                           const std::set<std::string>& symbols,
                           std::vector<std::string>& errors,
                           bool condition) {
    if (expression.empty()) {
        const auto token = expression.data();
        if (token == "True" || token == "False") {
            if (!condition) errors.push_back("True/False can only be used as a condition.");
            return;
        }
        if (condition) {
            errors.push_back("A condition must be a comparison such as x > 0.");
            return;
        }
        if (!numericToken(token) && !symbols.contains(token)) errors.push_back("Unknown executable symbol: " + token + ".");
        return;
    }
    std::vector<const boost::property_tree::ptree*> items;
    for (const auto& item : expression) items.push_back(&item.second);
    if (items.empty() || !items.front()->empty()) {
        errors.push_back("The executable expression is malformed.");
        return;
    }
    const auto operation = items.front()->data();
    const auto arguments = items.size() - 1;
    const std::set<std::string> unary = {"Abs", "Arccos", "Arcsin", "Arctan", "Cos", "Exp", "Ln", "Log", "Negate", "Sin", "Sqrt", "Tan", "Tanh"};
    const std::set<std::string> binary = {"Arctan2", "Divide", "Max", "Min", "Power"};
    const std::set<std::string> comparisons = {"Less", "LessEqual", "Greater", "GreaterEqual", "Equal", "NotEqual"};
    const bool numericOperation = unary.contains(operation) || binary.contains(operation) || operation == "Add" || operation == "Multiply" || operation == "Which";
    const bool booleanOperation = comparisons.contains(operation) || operation == "And" || operation == "Or" || operation == "Not";
    if (!numericOperation && !booleanOperation) {
        errors.push_back("Unsupported or malformed executable operation: " + operation + ".");
        return;
    }
    if (booleanOperation && !condition) {
        errors.push_back("A comparison (" + operation + ") can only be used as the condition of a cases expression.");
        return;
    }
    if (numericOperation && condition) {
        errors.push_back("A condition must be a comparison such as x > 0.");
        return;
    }
    const bool malformed =
        (unary.contains(operation) && arguments != 1) || (binary.contains(operation) && arguments != 2) ||
        ((operation == "Add" || operation == "Multiply") && arguments < 2) ||
        (operation == "Which" && (arguments < 2 || arguments % 2 != 0)) ||
        (operation == "NotEqual" && arguments != 2) ||
        (comparisons.contains(operation) && arguments < 2) ||
        ((operation == "And" || operation == "Or") && arguments < 2) ||
        (operation == "Not" && arguments != 1);
    if (malformed) {
        errors.push_back("Unsupported or malformed executable operation: " + operation + ".");
        return;
    }
    if (operation == "Which") {
        for (std::size_t index = 1; index < items.size(); ++index) {
            validateTypedMathJson(*items[index], symbols, errors, index % 2 == 1);
        }
        const auto& lastCondition = *items[items.size() - 2];
        if (!lastCondition.empty() || lastCondition.data() != "True") {
            errors.push_back("A cases expression needs a final \\text{otherwise} branch.");
        }
        return;
    }
    const bool childCondition = operation == "And" || operation == "Or" || operation == "Not";
    for (std::size_t index = 1; index < items.size(); ++index) validateTypedMathJson(*items[index], symbols, errors, childCondition);
}

// The symbols an executable expression actually reads. A binding list can name more (the node
// editor binds every state of a node to each of its source terms), and only these are references.
void collectMathJsonSymbols(const boost::property_tree::ptree& expression, std::set<std::string>& symbols) {
    if (expression.empty()) {
        const auto token = expression.data();
        if (token != "True" && token != "False" && !numericToken(token)) symbols.insert(token);
        return;
    }
    bool operation = true;
    for (const auto& item : expression) {
        if (!operation) collectMathJsonSymbols(item.second, symbols);
        operation = false;
    }
}

void validateMathJson(const boost::property_tree::ptree& expression,
                      const std::set<std::string>& symbols,
                      std::vector<std::string>& errors) {
    validateTypedMathJson(expression, symbols, errors, false);
}

std::vector<std::string> equationErrors(const boost::property_tree::ptree& edge,
                                        const boost::property_tree::ptree& sourceNode,
                                        const boost::property_tree::ptree& targetNode) {
    const auto latex = value(edge, "equationModel.latex").empty() ? value(edge, "equation") : value(edge, "equationModel.latex");
    std::vector<std::string> errors;
    int braces = 0;
    for (const char character : latex) {
        if (character == '{') ++braces;
        else if (character == '}' && --braces < 0) break;
    }
    if (braces != 0) errors.push_back("The LaTeX expression has unbalanced braces.");
    // An equality condition inside cases is fine; top-level "a = b" is still caught here (and as a
    // misplaced comparison by the typed MathJSON check).
    const bool hasCases = latex.find("\\begin{cases}") != std::string::npos;
    if (!hasCases && latex.find('=') != std::string::npos) errors.push_back("Assignments are not supported in relationship expressions.");
    const std::regex environmentExpression(R"(\\begin\{([A-Za-z*]+)\})");
    for (auto match = std::sregex_iterator(latex.begin(), latex.end(), environmentExpression); match != std::sregex_iterator(); ++match) {
        if ((*match)[1].str() != "cases") errors.push_back("Unsupported LaTeX environment: " + (*match)[1].str() + ".");
    }

    std::set<std::string> knownSymbols;
    const auto addStates = [&](const boost::property_tree::ptree& node, const std::string& role) {
        if (const auto states = node.get_child_optional("states")) for (const auto& item : *states) {
            knownSymbols.insert(role + upperFirst(value(item.second, "symbol")));
        }
    };
    addStates(sourceNode, "source");
    addStates(targetNode, "target");
    if (const auto parameters = edge.get_child_optional("parameters")) for (const auto& item : *parameters) knownSymbols.insert(value(item.second, "symbol"));
    if (const auto bindings = edge.get_child_optional("equationModel.bindings")) for (const auto& item : *bindings) knownSymbols.insert(value(item.second, "symbol"));

    // \operatorname{Word} is standard LaTeX for an unfamiliar function name -- a common shape
    // for AI-generated equations even when the prompt is steered toward the shorter \max/\min
    // form. Accept it when Word names a real operator (case-insensitively) and strip the whole
    // construct before the general command/identifier scans below, so neither "operatorname"
    // nor the operator word itself get flagged again by those broader, name-agnostic checks.
    const std::set<std::string> operatorNames = {
        "abs", "cos", "exp", "ln", "log", "max", "min", "negate", "sin", "tan"
    };
    const std::regex operatornameExpression(R"(\\operatorname\{([A-Za-z]+)\})");
    for (auto match = std::sregex_iterator(latex.begin(), latex.end(), operatornameExpression); match != std::sregex_iterator(); ++match) {
        auto name = (*match)[1].str();
        std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (!operatorNames.contains(name)) errors.push_back("\\operatorname{} does not name a supported function: " + (*match)[1].str() + ".");
    }
    // Strip the cases environment markers and \text{...} labels ("if", "otherwise") so their words
    // aren't scanned as commands or symbols below.
    const std::regex casesMarkupExpression(R"(\\(?:begin|end)\{[A-Za-z*]+\}|\\text\{[^}]*\})");
    const auto latexWithoutOperatorname = std::regex_replace(std::regex_replace(latex, operatornameExpression, " "), casesMarkupExpression, " ");

    const std::set<std::string> supportedCommands = {
        "cdot", "cos", "exp", "frac", "left", "ln", "log", "max", "min", "mathrm", "right", "sin", "sqrt", "tan",
        // cases conditions
        "ge", "geq", "gt", "land", "le", "leq", "lnot", "lor", "lt", "ne", "neg", "neq", "vee", "wedge"
    };
    const std::regex commandExpression(R"(\\([A-Za-z]+))");
    for (auto match = std::sregex_iterator(latexWithoutOperatorname.begin(), latexWithoutOperatorname.end(), commandExpression); match != std::sregex_iterator(); ++match) {
        const auto command = (*match)[1].str();
        if (!supportedCommands.contains(command)) errors.push_back("Unsupported LaTeX command: \\" + command + ".");
    }

    // Remove command names before scanning identifiers. Their arguments remain,
    // so both plain symbols and symbols rendered as \mathrm{symbol} are checked.
    const auto expressionWithoutCommands = std::regex_replace(latexWithoutOperatorname, commandExpression, " ");
    const std::regex identifierExpression(R"([A-Za-z][A-Za-z0-9]*)");
    std::set<std::string> unknownSymbols;
    for (auto match = std::sregex_iterator(expressionWithoutCommands.begin(), expressionWithoutCommands.end(), identifierExpression);
         match != std::sregex_iterator(); ++match) {
        const auto symbol = match->str();
        if (!knownSymbols.contains(symbol)) unknownSymbols.insert(symbol);
    }
    for (const auto& symbol : unknownSymbols) errors.push_back("Unknown symbol: " + symbol + ".");
    return errors;
}
}

void validateAlgebraicRelationship(ValidationResult& result, const boost::property_tree::ptree& edge, const boost::property_tree::ptree& outputs,
                                   std::unordered_map<std::string, std::set<std::string>>& stateIds, const std::set<std::string>& parameterIds,
                                   const std::string& sourceNode, const std::string& targetNode, const std::string& id,
                                   std::set<std::string>& relationshipStateIds) {
    const auto implementationKind = value(edge, "implementation.kind");
    if (!implementationKind.empty() && implementationKind != "equation") {
        add(result, "relationshipOutputsInvalid", "error", "A relationship with several equations is written as equations, not a program.", "edge", id, "implementation");
    }
    if (value(edge, "directionality") == "bidirectional") {
        add(result, "relationshipOutputsInvalid", "error", "A relationship with several equations is directed: each equation names the state it sets.", "edge", id, "output");
    }
    std::set<std::string> symbols;
    if (const auto bindings = edge.get_child_optional("equationModel.bindings")) for (const auto& bindingEntry : *bindings) {
        const auto& binding = bindingEntry.second;
        symbols.insert(value(binding, "symbol"));
        if (value(binding, "kind") == "parameter") {
            if (!parameterIds.contains(value(binding, "parameterId"))) add(result, "edgeBindingMissing", "error", "Equation binding references a missing parameter.", "edge", id, "equation");
        } else if (value(binding, "kind") != "time") {
            const auto bindingNode = value(binding, "nodeId");
            if ((bindingNode != sourceNode && bindingNode != targetNode) || !stateIds[bindingNode].contains(value(binding, "stateId"))) {
                add(result, "edgeBindingMissing", "error", "Equation binding references a missing endpoint state.", "edge", id, "equation");
            }
        }
    }
    if (const auto definitions = edge.get_child_optional("equationModel.definitions")) for (const auto& definitionEntry : *definitions) {
        const auto& definition = definitionEntry.second;
        const auto symbol = value(definition, "symbol");
        std::vector<std::string> errors;
        const auto mathJson = definition.get_child_optional("mathJson");
        if (!mathJson) errors.push_back("Its expression is missing.");
        else validateMathJson(*mathJson, symbols, errors);
        if (!std::regex_match(symbol, std::regex("^[A-Za-z][A-Za-z0-9_]*$")) || !symbols.insert(symbol).second) {
            errors.push_back("A definition needs a name of its own (letters and digits).");
        }
        if (!errors.empty()) add(result, "relationshipDefinitionInvalid", "error", "Definition \"" + symbol + "\": " + errors.front(), "edge", id, "equation");
    }
    if (outputs.empty()) add(result, "edgeOutputMissing", "error", "A relationship with several equations needs at least one.", "edge", id, "output");
    std::set<std::string> outputStates;
    for (const auto& outputEntry : outputs) {
        const auto& output = outputEntry.second;
        const auto role = value(output, "role");
        const auto stateId = value(output, "stateId");
        const auto& candidates = role == "source" ? stateIds[sourceNode] : stateIds[targetNode];
        if ((role != "source" && role != "target") || !candidates.contains(stateId)) {
            add(result, "edgeOutputMissing", "error", "Each equation sets an existing state of one of the relationship's two nodes.", "edge", id, "output");
            continue;
        }
        if (value(output, "setsValue") != "true") {
            add(result, "relationshipOutputNotAlgebraic", "error", "Each equation of a relationship with several equations sets its state's value (setsValue).", "edge", id, "output");
        }
        if (!outputStates.insert(stateId).second) {
            add(result, "relationshipOutputDuplicate", "error", "A relationship sets each state with one equation.", "edge", id, "output");
        }
        std::vector<std::string> errors;
        const auto mathJson = output.get_child_optional("mathJson");
        if (!mathJson) errors.push_back("Equation requires a valid executable expression.");
        else validateMathJson(*mathJson, symbols, errors);
        if (!errors.empty()) add(result, "edgeEquationInvalid", "error", errors.front(), "edge", id, "equation");
        relationshipStateIds.insert(stateId);
    }
}

ValidationResult validateModel(const boost::property_tree::ptree& document) {
    ValidationResult result;
    if (value(document, "format") != "konjugate" || document.get<int>("version", 0) != 1) {
        add(result, "unsupportedProject", "error", "The project format or schema version is not supported.");
        result.valid = false;
        return result;
    }
    const auto nodesOptional = document.get_child_optional("nodes");
    const auto edgesOptional = document.get_child_optional("edges");
    if (!nodesOptional || !edgesOptional) {
        add(result, "invalidDocument", "error", "The project must contain node and edge arrays.");
        result.valid = false;
        return result;
    }

    std::set<std::string> allIds;
    std::unordered_map<std::string, std::set<std::string>> stateIds;
    std::unordered_map<std::string, std::set<std::string>> stateSymbols;
    std::unordered_map<std::string, const boost::property_tree::ptree*> nodesById;
    // Populated while walking source terms and edges below, then checked once at the end: a
    // source term authored as "sets the value" (setsValue) must be the SOLE contribution to its
    // state -- no other source term, no edge -- since a directly-set value and an
    // additively-summed derivative from anything else would silently fight each other every
    // substep. stateContributorCounts counts every enabled contribution (source term or edge)
    // targeting a given stateId; setsValueStateIds names which states have a setsValue source
    // term at all (most states have none, and never need the count checked).
    std::unordered_map<std::string, int> stateContributorCounts;
    std::set<std::string> setsValueStateIds;
    auto registerId = [&](const std::string& id, const std::string& kind, const std::string& entityId, const std::string& label) {
        bool validId = std::regex_match(id, entityIdPattern);
        if (validId) {
            try { validId = std::stoull(id) <= 9007199254740991ULL; } catch (...) { validId = false; }
        }
        if (!validId) add(result, "invalidId", "error", label + " does not have a valid positive integer id.", kind, entityId, "id");
        else if (!allIds.insert(id).second) add(result, "duplicateId", "error", label + " reuses an existing id.", kind, entityId, "id");
    };

    // Project-level shared parameters: one definition that any number of relationship or
    // source-term parameters link to (via sharedParameterId), so a single value or live control
    // drives all of them. Their ids share the project-wide id space.
    std::set<std::string> sharedParameterIds;
    std::set<std::string> sharedParameterSymbols;
    if (const auto sharedParameters = document.get_child_optional("sharedParameters")) for (const auto& entry : *sharedParameters) {
        const auto& shared = entry.second;
        const auto sharedId = value(shared, "id");
        registerId(sharedId, "sharedParameter", sharedId, "Shared parameter \"" + value(shared, "name") + "\"");
        sharedParameterIds.insert(sharedId);
        const auto symbol = value(shared, "symbol");
        if (!std::regex_match(symbol, symbolPattern)) add(result, "parameterSymbolInvalid", "error", "Shared parameter symbol must be lower camel case.", "sharedParameter", sharedId, "symbol");
        else if (!sharedParameterSymbols.insert(symbol).second) add(result, "parameterSymbolDuplicate", "error", "Shared parameter symbol \"" + symbol + "\" is duplicated.", "sharedParameter", sharedId, "symbol");
        const auto mode = value(shared, "mode");
        if (mode != "constant" && mode != "live") add(result, "parameterModeInvalid", "error", "Parameter mode must be constant or live.", "sharedParameter", sharedId, "mode");
        if (!shared.get_optional<double>("value") || !std::isfinite(*shared.get_optional<double>("value"))) {
            add(result, "parameterValueInvalid", "error", "A shared parameter needs a finite value.", "sharedParameter", sharedId, "value");
        }
        if (shared.get_child_optional("tuning")) {
            const auto tuningMinimum = shared.get_optional<double>("tuning.minimum");
            const auto tuningMaximum = shared.get_optional<double>("tuning.maximum");
            const auto tuningValue = shared.get_optional<double>("value");
            if (!tuningMinimum || !tuningMaximum || !tuningValue || !std::isfinite(*tuningMinimum) || !std::isfinite(*tuningMaximum) ||
                !(*tuningMinimum < *tuningMaximum) || *tuningValue < *tuningMinimum || *tuningValue > *tuningMaximum) {
                add(result, "parameterTuningInvalid", "error", "Tunable parameter fitting bounds require minimum < maximum and an initial value within the bounds.", "sharedParameter", sharedId, "tuning");
            }
        }
        // A stored schedule: the parameter follows these samples over simulation time.
        if (const auto schedule = shared.get_child_optional("schedule")) {
            const auto interpolation = schedule->get<std::string>("interpolation", "linear");
            if (interpolation != "linear" && interpolation != "hold") {
                add(result, "parameterScheduleInvalid", "error", "A parameter schedule's interpolation must be linear or hold.", "sharedParameter", sharedId, "schedule");
            }
            std::size_t count = 0;
            bool wellFormed = true;
            double previousTime = -std::numeric_limits<double>::infinity();
            if (const auto samples = schedule->get_child_optional("samples")) for (const auto& sampleItem : *samples) {
                std::vector<double> pair;
                try {
                    for (const auto& component : sampleItem.second) pair.push_back(component.second.get_value<double>());
                } catch (const boost::property_tree::ptree_error&) {
                    pair.clear();
                }
                if (pair.size() != 2 || !std::isfinite(pair[0]) || !std::isfinite(pair[1]) || !(pair[0] > previousTime)) wellFormed = false;
                else previousTime = pair[0];
                ++count;
            }
            if (!count || !wellFormed) {
                add(result, "parameterScheduleInvalid", "error", "A parameter schedule needs at least one [time, value] sample, every number finite and the times strictly increasing.", "sharedParameter", sharedId, "schedule");
            }
            if (shared.get_child_optional("tuning")) {
                add(result, "parameterScheduleTuned", "error", "A parameter that follows a schedule cannot also be a fitting target.", "sharedParameter", sharedId, "tuning");
            }
        }
        if (mode == "live" && shared.get_child_optional("control")) {
            const auto minimum = shared.get_optional<double>("control.minimum");
            const auto maximum = shared.get_optional<double>("control.maximum");
            const auto step = shared.get_optional<double>("control.step");
            const auto initialValue = shared.get_optional<double>("value");
            if (!minimum || !maximum || !step || !initialValue || !std::isfinite(*minimum) || !std::isfinite(*maximum) ||
                !std::isfinite(*step) || !std::isfinite(*initialValue) || !(*minimum < *maximum) || !(*step > 0) ||
                *initialValue < *minimum || *initialValue > *maximum) {
                add(result, "parameterControlInvalid", "error", "Live parameter slider settings require minimum < maximum, step > 0 and an initial value within the bounds.", "sharedParameter", sharedId, "control");
            }
        }
    }
    // A parameter linked to a shared one takes its value and mode from it, so the link must
    // resolve and the parameter cannot also carry its own fitting bounds (a shared parameter
    // carries them instead, and fitting it moves every parameter linked to it).
    auto validateSharedLink = [&](const boost::property_tree::ptree& parameter, const std::string& kind, const std::string& ownerId, const std::string& field) {
        if (!parameter.get_child_optional("sharedParameterId")) return;
        if (!sharedParameterIds.contains(value(parameter, "sharedParameterId"))) {
            add(result, "sharedParameterMissing", "error", "Parameter \"" + value(parameter, "name") + "\" links to a shared parameter that does not exist.", kind, ownerId, field);
        }
        if (parameter.get_child_optional("tuning")) {
            add(result, "sharedParameterTuningUnsupported", "error", "A parameter linked to a shared parameter cannot be marked as tunable.", kind, ownerId, field);
        }
    };

    std::set<std::string> runConfigurationIds;
    // Populated when the active run configuration parses cleanly, for the stability-diagnostic
    // pass near the end of this function -- the pre-run phase of
    // docs/proposals/numericalStabilityDiagnostics.md needs a concrete step size to check against,
    // and the active run configuration is the closest thing a static document has to "the step
    // size this model will actually run at." Left empty (no check performed) when the document has
    // no run configurations at all, or the active one fails to parse -- there is nothing honest to
    // check against in either case.
    std::optional<double> activeGlobalTimeStep;
    if (const auto configurations = document.get_child_optional("runConfigurations")) {
        const auto activeId = value(document, "activeRunConfigurationId");
        for (const auto& configurationEntry : *configurations) {
            const auto& configuration = configurationEntry.second;
            const auto configurationId = value(configuration, "id");
            registerId(configurationId, "runConfiguration", configurationId, "Run configuration \"" + value(configuration, "name") + "\"");
            runConfigurationIds.insert(configurationId);
            try {
                const auto globalTimeStep = configuration.get<double>("globalTimeStep");
                const auto outputInterval = configuration.get<double>("outputInterval");
                if (!(globalTimeStep > 0) || !(outputInterval > 0) ||
                    !std::isfinite(globalTimeStep) || !std::isfinite(outputInterval)) throw std::out_of_range("configuration");
                const auto ratio = outputInterval / globalTimeStep;
                if (outputInterval < globalTimeStep || std::abs(ratio - std::round(ratio)) > 1e-9) throw std::out_of_range("configuration");
                if (configurationId == activeId) activeGlobalTimeStep = globalTimeStep;
            } catch (...) {
                add(result, "runConfigurationInvalid", "error", "Numerical configuration values must be finite and positive; output interval must be an integer multiple of the global timestep.", "runConfiguration", configurationId, "numerics");
            }
        }
        if (!configurations->empty() && !runConfigurationIds.contains(value(document, "activeRunConfigurationId"))) {
            add(result, "activeRunConfigurationMissing", "error", "Choose an existing active run configuration.", "model", {}, "runConfigurations");
        }
    }

    result.nodeCount = nodesOptional->size();
    if (!result.nodeCount) add(result, "emptyModel", "warning", "Add at least one node to begin building a model.");
    std::set<std::string> disabledNodeIds;
    // A computational-node provider's bindings to other nodes' states, as (node, state) pairs: checked
    // once every node's states are known, since a node may read one listed after it.
    std::vector<std::pair<std::string, std::string>> remoteNodeProviderBindings;
    // The states relationships' equations set (equationModel.outputs).
    std::set<std::string> relationshipStateIds;
    for (const auto& entry : *nodesOptional) {
        const auto& node = entry.second;
        const auto id = value(node, "id");
        const auto name = value(node, "name");
        registerId(id, "node", id, "Node \"" + (name.empty() ? std::string("Untitled") : name) + "\"");
        nodesById[id] = &node;
        // A disabled node is inert from the engine's perspective (compileExecutionPlan skips it
        // entirely, same as if it had been deleted), so its own content isn't validated -- only
        // its ids, which must stay globally unique even while off so nothing collides whenever it
        // (or something added later) gets re-enabled.
        const bool nodeEnabled = value(node, "enabled") != "false";
        if (nodeEnabled) {
            const auto substepsValue = value(node, "numerics.substepsPerGlobalStep");
            if (!substepsValue.empty()) {
                try {
                    std::size_t consumed = 0;
                    const auto substeps = std::stoull(substepsValue, &consumed);
                    if (consumed != substepsValue.size() || !substeps || substeps > 10000) throw std::out_of_range("substeps");
                } catch (...) {
                    add(result, "nodeSubstepsInvalid", "error", "Node substeps per global step must be an integer from 1 through 10000.", "node", id, "numerics");
                }
            }
            const auto integration = value(node, "numerics.integration");
            if (!integration.empty() && integration != "explicit" && integration != "semiImplicit") {
                add(result, "nodeIntegrationInvalid", "error", "A node's integration must be explicit or semiImplicit.", "node", id, "numerics");
            } else if (integration == "semiImplicit" && node.get_child_optional("implementation")) {
                add(result, "nodeIntegrationInvalid", "error", "A node with a computational-node provider is integrated explicitly.", "node", id, "numerics");
            }
        } else {
            disabledNodeIds.insert(id);
        }
        const auto states = node.get_child_optional("states");
        if (nodeEnabled && (!states || states->empty())) add(result, "nodeStatesEmpty", "warning", "This node has no state variables.", "node", id, "states");
        if (states) for (const auto& stateEntry : *states) {
            const auto& state = stateEntry.second;
            const auto stateId = value(state, "id");
            const auto symbol = value(state, "symbol");
            registerId(stateId, "node", id, "State \"" + value(state, "name") + "\"");
            stateIds[id].insert(stateId);
            if (!nodeEnabled) continue;
            if (!std::regex_match(symbol, symbolPattern)) add(result, "stateSymbolInvalid", "error", "State symbol must be lower camel case.", "node", id, "states");
            else if (!stateSymbols[id].insert(symbol).second) add(result, "stateSymbolDuplicate", "error", "State symbol \"" + symbol + "\" is duplicated in this node.", "node", id, "states");
        }
        // Per-node: (outputStateId, [stateIds its bindings reference]) for this node's own
        // setsValue ("algebraic") source terms -- checked for a dependency cycle or self-reference
        // once the whole sourceTerms loop below finishes, mirroring compileExecutionPlan's own
        // dependency-ordering pass exactly (see executionPlan.cpp) so a user hits this validator's
        // clear error message before ever reaching that pass's defensive throw.
        std::vector<std::pair<std::string, std::vector<std::string>>> algebraicCandidates;
        if (const auto terms = node.get_child_optional("sourceTerms")) for (const auto& termEntry : *terms) {
            const auto& term = termEntry.second;
            registerId(value(term, "id"), "node", id, "Source term");
            std::set<std::string> sourceParameterSymbols;
            std::set<std::string> sourceParameterIds;
            if (const auto parameters = term.get_child_optional("parameters")) for (const auto& parameterEntry : *parameters) {
                const auto& parameter = parameterEntry.second;
                registerId(value(parameter, "id"), "node", id, "Source-term parameter \"" + value(parameter, "name") + "\"");
                sourceParameterIds.insert(value(parameter, "id"));
                validateSharedLink(parameter, "node", id, "sourceTerms");
                if (!nodeEnabled) continue;
                const auto symbol = value(parameter, "symbol");
                if (!std::regex_match(symbol, symbolPattern)) add(result, "parameterSymbolInvalid", "error", "Parameter symbol must be lower camel case.", "node", id, "sourceTerms");
                else if (!sourceParameterSymbols.insert(symbol).second) add(result, "parameterSymbolDuplicate", "error", "Source-term parameter symbols must be unique.", "node", id, "sourceTerms");
                const auto mode = value(parameter, "mode");
                if (mode != "constant" && mode != "live") add(result, "parameterModeInvalid", "error", "Parameter mode must be constant or live.", "node", id, "sourceTerms");
                if (parameter.get_child_optional("tuning")) {
                    const auto minimum = parameter.get_optional<double>("tuning.minimum");
                    const auto maximum = parameter.get_optional<double>("tuning.maximum");
                    const auto initial = parameter.get_optional<double>("value");
                    if (!minimum || !maximum || !initial || !std::isfinite(*minimum) || !std::isfinite(*maximum) ||
                        !(*minimum < *maximum) || *initial < *minimum || *initial > *maximum) {
                        add(result, "parameterTuningInvalid", "error", "Tunable parameter fitting bounds require minimum < maximum and an initial value within the bounds.", "node", id, "sourceTerms");
                    }
                }
                if (mode == "live" && parameter.get_child_optional("control")) {
                    const auto minimum = parameter.get_optional<double>("control.minimum");
                    const auto maximum = parameter.get_optional<double>("control.maximum");
                    const auto step = parameter.get_optional<double>("control.step");
                    const auto initial = parameter.get_optional<double>("value");
                    if (!minimum || !maximum || !step || !initial || !std::isfinite(*minimum) || !std::isfinite(*maximum) ||
                        !std::isfinite(*step) || !(*minimum < *maximum) || !(*step > 0) || *initial < *minimum || *initial > *maximum) {
                        add(result, "parameterControlInvalid", "error", "Live parameter slider settings require minimum < maximum, step > 0 and an initial value within the bounds.", "node", id, "sourceTerms");
                    }
                }
            }
            if (!nodeEnabled) continue;
            const auto termImplementation = term.get_child_optional("implementation");
            const auto termImplementationKind = termImplementation ? value(*termImplementation, "kind") : "equation";
            {
                const bool termProgrammable = termImplementationKind == "cpp" || termImplementationKind == "python";
                const auto termOutputStateId = value(term, termProgrammable ? "implementation.output.stateId" : "expressionModel.output.stateId");
                if (!termOutputStateId.empty()) {
                    stateContributorCounts[termOutputStateId] += 1;
                    if (value(term, "setsValue") == "true") {
                        setsValueStateIds.insert(termOutputStateId);
                        std::vector<std::string> referencedStateIds;
                        // A provider may read any state it binds; an equation only the ones it uses.
                        std::optional<std::set<std::string>> usedSymbols;
                        if (!termProgrammable) {
                            usedSymbols.emplace();
                            if (const auto mathJson = term.get_child_optional("expressionModel.mathJson")) collectMathJsonSymbols(*mathJson, *usedSymbols);
                        }
                        if (const auto bindings = term.get_child_optional(termProgrammable ? "implementation.bindings" : "expressionModel.bindings")) {
                            for (const auto& bindingEntry : *bindings) {
                                const auto& binding = bindingEntry.second;
                                if (value(binding, "kind") != "state") continue;
                                if (usedSymbols && !usedSymbols->contains(value(binding, "symbol"))) continue;
                                referencedStateIds.push_back(value(binding, "stateId"));
                            }
                        }
                        algebraicCandidates.emplace_back(termOutputStateId, std::move(referencedStateIds));
                    }
                }
            }
            if (termImplementationKind != "equation" && termImplementationKind != "cpp" && termImplementationKind != "python") {
                add(result, "sourceKindInvalid", "error", "Source term implementation kind must be equation, cpp or python.", "node", id, "sourceTerms");
            }
            if (termImplementationKind == "cpp" || termImplementationKind == "python") {
                if (value(*termImplementation, "providerApiVersion") != "1") {
                    add(result, "providerApiVersionInvalid", "error", "Programmable source terms require provider API version 1.", "node", id, "sourceTerms");
                }
                if (value(*termImplementation, "source").empty()) {
                    add(result, "providerSourceEmpty", "error", "Programmable source terms require inline source.", "node", id, "sourceTerms");
                }
                // Unlike an edge, a source term has no other endpoint to read from, so zero
                // declared bindings is not itself an error (e.g. a constant contribution).
                // It only warrants a warning when the source still looks like the untouched,
                // generated template — a signal the author has not started implementing it —
                // and that warning clears as soon as real source is written, binding or not.
                std::set<std::string> providerKeys;
                const auto providerBindings = termImplementation->get_child_optional("bindings");
                const bool hasBindings = providerBindings && !providerBindings->empty();
                if (!hasBindings && value(*termImplementation, "source").find("TODO: read") != std::string::npos) {
                    add(result, "sourceTermImplementationIncomplete", "warning",
                        "This programmable source term has no input bindings and still contains the generated template.",
                        "node", id, "sourceTerms");
                }
                if (providerBindings) for (const auto& bindingEntry : *providerBindings) {
                    const auto& binding = bindingEntry.second;
                    const auto key = value(binding, "key");
                    if (!std::regex_match(key, providerKeyPattern)) {
                        add(result, "providerBindingKeyInvalid", "error", "Provider input keys must be lower camel case.", "node", id, "sourceTerms");
                    } else if (!providerKeys.insert(key).second) {
                        add(result, "providerBindingKeyDuplicate", "error", "Provider input key \"" + key + "\" is duplicated.", "node", id, "sourceTerms");
                    }
                    if (value(binding, "kind") == "parameter") {
                        if (!sourceParameterIds.contains(value(binding, "parameterId"))) add(result, "providerBindingMissing", "error", "Provider binding references a missing source-term parameter.", "node", id, "sourceTerms");
                    } else if (value(binding, "kind") != "state" || !stateIds[id].contains(value(binding, "stateId"))) {
                        add(result, "providerBindingMissing", "error", "Provider binding references a missing local state.", "node", id, "sourceTerms");
                    }
                }
                const auto outputKey = value(*termImplementation, "output.key");
                const auto outputStateId = value(*termImplementation, "output.stateId");
                if (outputKey.empty() || !std::regex_match(outputKey, providerKeyPattern)) {
                    add(result, "providerOutputKeyInvalid", "error", "Provider output key must be lower camel case.", "node", id, "sourceTerms");
                }
                if (outputStateId.empty() || !stateIds[id].contains(outputStateId)) {
                    add(result, "providerOutputMissing", "error", "Provider output must reference an existing local state.", "node", id, "sourceTerms");
                }
                continue;
            }
            const auto state = value(term, "state");
            if (!stateSymbols[id].contains(state)) add(result, "sourceStateMissing", "error", "Source term references a missing state.", "node", id, "sourceTerms");
            if (value(term, "expression").empty()) add(result, "sourceExpressionEmpty", "error", "Source term requires an expression.", "node", id, "sourceTerms");
            const auto mathJson = term.get_child_optional("expressionModel.mathJson");
            if (!mathJson) add(result, "sourceExpressionInvalid", "error", "Source term requires a valid executable expression.", "node", id, "sourceTerms");
            else {
                std::set<std::string> executableSymbols;
                if (const auto bindings = term.get_child_optional("expressionModel.bindings")) {
                    for (const auto& binding : *bindings) {
                        executableSymbols.insert(value(binding.second, "symbol"));
                        if (value(binding.second, "kind") == "parameter") {
                            if (!sourceParameterIds.contains(value(binding.second, "parameterId"))) add(result, "sourceBindingMissing", "error", "Source term binding references a missing parameter.", "node", id, "sourceTerms");
                        } else if (value(binding.second, "kind") == "time") {
                            // Simulation time -- always available, nothing to resolve.
                        } else if (!stateIds[id].contains(value(binding.second, "stateId"))) {
                            add(result, "sourceBindingMissing", "error", "Source term binding references a missing local state.", "node", id, "sourceTerms");
                        }
                    }
                }
                std::vector<std::string> errors;
                validateMathJson(*mathJson, executableSymbols, errors);
                if (!errors.empty()) add(result, "sourceExpressionInvalid", "error", errors.front(), "node", id, "sourceTerms");
            }
            if (!stateIds[id].contains(value(term, "expressionModel.output.stateId"))) {
                add(result, "sourceOutputMissing", "error", "Source term requires an existing output state.", "node", id, "sourceTerms");
            }
        }
        if (!algebraicCandidates.empty()) {
            std::unordered_map<std::string, std::size_t> algebraicIndexByStateId;
            for (std::size_t index = 0; index < algebraicCandidates.size(); ++index) {
                algebraicIndexByStateId[algebraicCandidates[index].first] = index;
            }
            bool selfReferenceFound = false;
            for (const auto& [outputStateId, referencedStateIds] : algebraicCandidates) {
                if (std::find(referencedStateIds.begin(), referencedStateIds.end(), outputStateId) != referencedStateIds.end()) {
                    selfReferenceFound = true;
                }
            }
            if (selfReferenceFound) {
                add(result, "setsValueSelfReference", "error",
                    "A source term that sets its value directly may not reference its own state.", "node", id, "sourceTerms");
            } else {
                std::vector<int> visitState(algebraicCandidates.size(), 0); // 0=unvisited, 1=visiting, 2=done
                bool cycleFound = false;
                std::function<void(std::size_t)> visit = [&](std::size_t index) {
                    if (cycleFound || visitState[index] == 2) return;
                    if (visitState[index] == 1) { cycleFound = true; return; }
                    visitState[index] = 1;
                    for (const auto& referencedStateId : algebraicCandidates[index].second) {
                        const auto found = algebraicIndexByStateId.find(referencedStateId);
                        if (found != algebraicIndexByStateId.end()) visit(found->second);
                    }
                    visitState[index] = 2;
                };
                for (std::size_t index = 0; index < algebraicCandidates.size() && !cycleFound; ++index) visit(index);
                if (cycleFound) {
                    add(result, "setsValueAlgebraicLoop", "error",
                        "Two or more source terms that set their value directly form a dependency cycle, which has no defined solution.",
                        "node", id, "sourceTerms");
                }
            }
        }
        if (nodeEnabled) {
            if (const auto implementation = node.get_child_optional("implementation")) {
                const auto kind = value(*implementation, "kind");
                if (kind != "python" && kind != "cpp") {
                    add(result, "nodeProviderKindInvalid", "error",
                        "Computational-node provider implementation kind must be python or cpp.",
                        "node", id, "implementation");
                }
                if (value(*implementation, "providerApiVersion") != "1") {
                    add(result, "providerApiVersionInvalid", "error", "Programmable computational-node providers require provider API version 1.", "node", id, "implementation");
                }
                if (value(*implementation, "source").empty()) {
                    add(result, "providerSourceEmpty", "error", "Programmable computational-node providers require inline source.", "node", id, "implementation");
                }
                // Same "zero bindings is legitimate, but warn if it also still looks untouched"
                // stance as edges/source terms: a computational-node provider may legitimately
                // compute purely from parameters or time -- except a node has no parameter
                // concept to bind against, so this is really "purely from time or constants".
                std::set<std::string> nodeProviderKeys;
                const auto providerBindings = implementation->get_child_optional("bindings");
                const bool hasBindings = providerBindings && !providerBindings->empty();
                if (!hasBindings && value(*implementation, "source").find("TODO: read") != std::string::npos) {
                    add(result, "nodeProviderImplementationIncomplete", "warning",
                        "This computational-node provider has no input bindings and still contains the generated template.",
                        "node", id, "implementation");
                }
                // Collected alongside the ordinary per-binding checks below so the setsValue
                // self-reference check after the outputs loop can tell whether any of this
                // provider's own (shared, not per-output) input bindings reads a state one of its
                // setsValue outputs also targets -- see that check for why this matters.
                std::set<std::string> nodeProviderBindingStateIds;
                if (providerBindings) for (const auto& bindingEntry : *providerBindings) {
                    const auto& binding = bindingEntry.second;
                    const auto key = value(binding, "key");
                    if (!std::regex_match(key, providerKeyPattern)) {
                        add(result, "providerBindingKeyInvalid", "error", "Provider input keys must be lower camel case.", "node", id, "implementation");
                    } else if (!nodeProviderKeys.insert(key).second) {
                        add(result, "providerBindingKeyDuplicate", "error", "Provider input key \"" + key + "\" is duplicated.", "node", id, "implementation");
                    }
                    if (value(binding, "kind") == "parameter") {
                        // A node has no parameters of its own: its provider reads project-level shared ones.
                        if (value(binding, "sharedParameterId").empty()) {
                            add(result, "providerBindingParameterNotShared", "error",
                                "A computational-node provider binds only shared parameters, by sharedParameterId: a node has no parameters of its own.", "node", id, "implementation");
                        } else if (!sharedParameterIds.contains(value(binding, "sharedParameterId"))) {
                            add(result, "sharedParameterMissing", "error", "Provider binding \"" + key + "\" links to a shared parameter that does not exist.", "node", id, "implementation");
                        }
                    } else if (value(binding, "kind") != "state" || value(binding, "stateId").empty()) {
                        add(result, "providerBindingMissing", "error", "Provider binding references a missing state.", "node", id, "implementation");
                    } else if (stateIds[id].contains(value(binding, "stateId"))) {
                        nodeProviderBindingStateIds.insert(value(binding, "stateId"));
                    } else {
                        remoteNodeProviderBindings.emplace_back(id, value(binding, "stateId"));
                    }
                }
                // Unlike an edge/source term's single output, a computational-node provider
                // declares N named outputs -- each needs its own key-uniqueness check, and at
                // least one is required since zero outputs would mean the provider contributes
                // nothing at all, defeating the point of owning a node's dynamics. An output may
                // additionally carry setsValue (see docs/projectSchema.md), mirroring a source
                // term's own setsValue flag: its state becomes a genuine algebraic one rather than
                // a derivative contribution, so it's folded into the same stateContributorCounts/
                // setsValueStateIds machinery the sourceTerms loop above already populates, and
                // gets the same sole-contributor check at the bottom of this function.
                std::set<std::string> outputKeys;
                bool nodeProviderSelfReference = false;
                const auto outputs = implementation->get_child_optional("outputs");
                if (!outputs || outputs->empty()) {
                    add(result, "nodeProviderOutputsEmpty", "error", "A computational-node provider must declare at least one named output.", "node", id, "implementation");
                } else for (const auto& outputEntry : *outputs) {
                    const auto& output = outputEntry.second;
                    const auto key = value(output, "key");
                    if (key.empty() || !std::regex_match(key, providerKeyPattern)) {
                        add(result, "nodeProviderOutputKeyInvalid", "error", "Provider output key must be lower camel case.", "node", id, "implementation");
                    } else if (!outputKeys.insert(key).second) {
                        add(result, "nodeProviderOutputKeyDuplicate", "error", "Provider output key \"" + key + "\" is duplicated.", "node", id, "implementation");
                    }
                    const auto outputStateId = value(output, "stateId");
                    if (!stateIds[id].contains(outputStateId)) {
                        add(result, "nodeProviderOutputMissing", "error", "Provider output must reference an existing local state.", "node", id, "implementation");
                    } else {
                        stateContributorCounts[outputStateId] += 1;
                        if (value(output, "setsValue") == "true") {
                            setsValueStateIds.insert(outputStateId);
                            // A setsValue output reading its own target state back through one of
                            // this provider's (shared, per-node not per-output) bindings would make
                            // it a hidden, substep-count-dependent recurrence rather than a genuine
                            // algebraic value -- exactly the same reasoning as an ordinary source
                            // term's own self-reference rejection above, just checked against a
                            // shared binding list instead of one expression's own bindings.
                            if (nodeProviderBindingStateIds.contains(outputStateId)) nodeProviderSelfReference = true;
                        }
                    }
                }
                if (nodeProviderSelfReference) {
                    add(result, "setsValueSelfReference", "error",
                        "A computational-node-provider output that sets its state's value directly may not also be one of that provider's own input bindings.",
                        "node", id, "implementation");
                }
            }
        }
    }

    // Another node's state, read through the step's synchronization snapshot as an edge reads it: it
    // must exist, on a node that is enabled (a disabled node's states are never allocated).
    for (const auto& [nodeId, stateId] : remoteNodeProviderBindings) {
        const auto owner = std::find_if(stateIds.begin(), stateIds.end(), [&](const auto& entry) { return entry.second.contains(stateId); });
        if (owner == stateIds.end()) {
            add(result, "providerBindingMissing", "error", "Provider binding references a missing state.", "node", nodeId, "implementation");
        } else if (disabledNodeIds.contains(owner->first)) {
            add(result, "providerBindingStateDisabled", "error", "Provider binding reads a state of a disabled node.", "node", nodeId, "implementation");
        }
    }

    result.edgeCount = edgesOptional->size();
    for (const auto& entry : *edgesOptional) {
        const auto& edge = entry.second;
        const auto id = value(edge, "id");
        registerId(id, "edge", id, "Relationship \"" + value(edge, "name") + "\"");
        const auto sourceNode = value(edge, "source.nodeId");
        const auto targetNode = value(edge, "target.nodeId");
        // Counts this edge's contribution(s) towards stateContributorCounts (see its declaration
        // above) for the setsValue "sole contributor" check -- a directed edge targets one state
        // (role/stateId); a bidirectional edge also reciprocates onto the other endpoint.
        const auto countEdgeContribution = [&](const std::string& role, const std::string& stateId) {
            if (stateId.empty()) return;
            stateContributorCounts[stateId] += 1;
            if (value(edge, "directionality") != "bidirectional") return;
            const auto otherNodeId = role == "target" ? sourceNode : targetNode;
            const auto otherStateField = role == "target" ? "source.stateId" : "target.stateId";
            auto otherStateId = value(edge, otherStateField);
            if (otherStateId.empty()) otherStateId = firstStateIdOf(nodesById, otherNodeId);
            if (!otherStateId.empty()) stateContributorCounts[otherStateId] += 1;
        };
        // An edge is inert -- and its content unvalidated -- if it's disabled itself, or either
        // endpoint node is (an edge into a disabled node can't contribute to anything either,
        // exactly as if it had been deleted alongside that node).
        const bool edgeEnabled = value(edge, "enabled") != "false" &&
            !disabledNodeIds.contains(sourceNode) && !disabledNodeIds.contains(targetNode);
        if (edgeEnabled) {
            if (!stateIds.contains(sourceNode)) add(result, "edgeSourceMissing", "error", "Relationship source node no longer exists.", "edge", id, "source");
            if (!stateIds.contains(targetNode)) add(result, "edgeTargetMissing", "error", "Relationship target node no longer exists.", "edge", id, "target");
            if (!sourceNode.empty() && sourceNode == targetNode) add(result, "edgeSelfConnection", "error", "A relationship must connect two different nodes.", "edge", id, "target");
        }
        const auto sourceState = value(edge, "source.stateId");
        const auto targetState = value(edge, "target.stateId");
        if (edgeEnabled) {
            if (!sourceState.empty() && !stateIds[sourceNode].contains(sourceState)) add(result, "edgeSourceStateMissing", "error", "Relationship source state no longer exists.", "edge", id, "source");
            if (!targetState.empty() && !stateIds[targetNode].contains(targetState)) add(result, "edgeTargetStateMissing", "error", "Relationship target state no longer exists.", "edge", id, "target");
        }
        std::set<std::string> parameters;
        std::set<std::string> parameterIds;
        if (const auto parameterList = edge.get_child_optional("parameters")) for (const auto& parameterEntry : *parameterList) {
            const auto& parameter = parameterEntry.second;
            registerId(value(parameter, "id"), "edge", id, "Parameter \"" + value(parameter, "name") + "\"");
            parameterIds.insert(value(parameter, "id"));
            validateSharedLink(parameter, "edge", id, "parameters");
            if (!edgeEnabled) continue;
            const auto symbol = value(parameter, "symbol");
            if (!std::regex_match(symbol, symbolPattern)) add(result, "parameterSymbolInvalid", "error", "Parameter symbol must be lower camel case.", "edge", id, "parameters");
            else if (!parameters.insert(symbol).second) add(result, "parameterSymbolDuplicate", "error", "Parameter symbol \"" + symbol + "\" is duplicated.", "edge", id, "parameters");
            const auto mode = value(parameter, "mode");
            if (mode != "constant" && mode != "live") add(result, "parameterModeInvalid", "error", "Parameter mode must be constant or live.", "edge", id, "parameters");
            // Orthogonal to mode -- a parameter can be marked as a digital-twin fitting target
            // (its value is a candidate the optimizer varies) independent of whether it's also a
            // live-adjustable slider during a run. Presence of "tuning" is what marks it tunable.
            if (parameter.get_child_optional("tuning")) {
                const auto tuningMinimum = parameter.get_optional<double>("tuning.minimum");
                const auto tuningMaximum = parameter.get_optional<double>("tuning.maximum");
                const auto tuningInitialValue = parameter.get_optional<double>("value");
                if (!tuningMinimum || !tuningMaximum || !tuningInitialValue || !std::isfinite(*tuningMinimum) || !std::isfinite(*tuningMaximum) ||
                    !(*tuningMinimum < *tuningMaximum) || *tuningInitialValue < *tuningMinimum || *tuningInitialValue > *tuningMaximum) {
                    add(result, "parameterTuningInvalid", "error", "Tunable parameter fitting bounds require minimum < maximum and an initial value within the bounds.", "edge", id, "parameters");
                }
            }
            if (mode == "live" && parameter.get_child_optional("control")) {
                const auto minimum = parameter.get_optional<double>("control.minimum");
                const auto maximum = parameter.get_optional<double>("control.maximum");
                const auto step = parameter.get_optional<double>("control.step");
                const auto initialValue = parameter.get_optional<double>("value");
                if (!minimum || !maximum || !step || !initialValue || !std::isfinite(*minimum) || !std::isfinite(*maximum) ||
                    !std::isfinite(*step) || !std::isfinite(*initialValue) || !(*minimum < *maximum) || !(*step > 0) ||
                    *initialValue < *minimum || *initialValue > *maximum) {
                    add(result, "parameterControlInvalid", "error", "Live parameter slider settings require minimum < maximum, step > 0 and an initial value within the bounds.", "edge", id, "parameters");
                }
            }
        }
        if (!edgeEnabled) continue;
        // A relationship with several equations, each setting a state of one of its endpoints from
        // the bindings and the definitions (named intermediate quantities) before it.
        if (const auto outputs = edge.get_child_optional("equationModel.outputs")) {
            validateAlgebraicRelationship(result, edge, *outputs, stateIds, parameterIds, sourceNode, targetNode, id, relationshipStateIds);
            continue;
        }
        const auto implementation = edge.get_child_optional("implementation");
        const auto implementationKind = implementation ? value(*implementation, "kind") : "equation";
        if (implementationKind != "equation" && implementationKind != "cpp" && implementationKind != "python") {
            add(result, "providerKindInvalid", "error", "Relationship implementation kind must be equation, cpp or python.", "edge", id, "implementation");
        }
        if (implementationKind == "cpp" || implementationKind == "python") {
            if (value(*implementation, "providerApiVersion") != "1") {
                add(result, "providerApiVersionInvalid", "error", "Programmable relationships require provider API version 1.", "edge", id, "implementation");
            }
            if (value(*implementation, "source").empty()) {
                add(result, "providerSourceEmpty", "error", "Programmable relationships require inline source.", "edge", id, "implementation");
            }
            // A relationship's provider need not read any bound value either (e.g. a constant
            // or purely time-based contribution), so zero bindings is not itself an error. It
            // only warrants a warning when the source still looks like the untouched, generated
            // template — a signal the author has not started implementing it — and that warning
            // clears as soon as real source is written, binding or not.
            std::set<std::string> providerKeys;
            const auto providerBindings = implementation->get_child_optional("bindings");
            const bool hasBindings = providerBindings && !providerBindings->empty();
            if (!hasBindings && value(*implementation, "source").find("TODO: read") != std::string::npos) {
                add(result, "providerImplementationIncomplete", "warning",
                    "This programmable relationship has no input bindings and still contains the generated template.",
                    "edge", id, "implementation");
            }
            if (providerBindings) for (const auto& bindingEntry : *providerBindings) {
                const auto& binding = bindingEntry.second;
                const auto key = value(binding, "key");
                if (!std::regex_match(key, providerKeyPattern)) {
                    add(result, "providerBindingKeyInvalid", "error", "Provider input keys must be lower camel case.", "edge", id, "implementation");
                } else if (!providerKeys.insert(key).second) {
                    add(result, "providerBindingKeyDuplicate", "error", "Provider input key \"" + key + "\" is duplicated.", "edge", id, "implementation");
                }
                if (value(binding, "kind") == "parameter") {
                    if (!parameterIds.contains(value(binding, "parameterId"))) {
                        add(result, "providerBindingMissing", "error", "Provider binding references a missing parameter.", "edge", id, "implementation");
                    }
                } else if (value(binding, "kind") == "state") {
                    const auto bindingNode = value(binding, "nodeId");
                    const auto states = stateIds.find(bindingNode);
                    if ((bindingNode != sourceNode && bindingNode != targetNode) || states == stateIds.end() ||
                        !states->second.contains(value(binding, "stateId"))) {
                        add(result, "providerBindingMissing", "error", "Provider binding references a missing endpoint state.", "edge", id, "implementation");
                    }
                } else {
                    add(result, "providerBindingKindInvalid", "error", "Provider binding kind must be state or parameter.", "edge", id, "implementation");
                }
            }
            validateProviderOutput(result, *implementation, stateIds, sourceNode, targetNode, id);
            countEdgeContribution(value(*implementation, "output.role"), value(*implementation, "output.stateId"));
            continue;
        }
        if (const auto bindings = edge.get_child_optional("equationModel.bindings")) for (const auto& bindingEntry : *bindings) {
            const auto& binding = bindingEntry.second;
            if (value(binding, "kind") == "parameter") {
                if (!parameterIds.contains(value(binding, "parameterId"))) add(result, "edgeBindingMissing", "error", "Equation binding references a missing parameter.", "edge", id, "equation");
            } else if (value(binding, "kind") == "time") {
                // Simulation time -- always available, nothing to resolve.
            } else {
                const auto bindingNode = value(binding, "nodeId");
                if ((bindingNode != sourceNode && bindingNode != targetNode) || !stateIds[bindingNode].contains(value(binding, "stateId"))) {
                    add(result, "edgeBindingMissing", "error", "Equation binding references a missing endpoint state.", "edge", id, "equation");
                }
            }
        }
        const auto latex = value(edge, "equationModel.latex").empty() ? value(edge, "equation") : value(edge, "equationModel.latex");
        if (latex.empty()) add(result, "edgeEquationEmpty", "error", "Relationship requires an equation.", "edge", id, "equation");
        else if (nodesById.contains(sourceNode) && nodesById.contains(targetNode)) {
            auto errors = equationErrors(edge, *nodesById[sourceNode], *nodesById[targetNode]);
            const auto mathJson = edge.get_child_optional("equationModel.mathJson");
            if (!mathJson) errors.push_back("Equation requires a valid executable expression.");
            else {
                std::set<std::string> executableSymbols;
                if (const auto bindings = edge.get_child_optional("equationModel.bindings")) {
                    for (const auto& binding : *bindings) executableSymbols.insert(value(binding.second, "symbol"));
                }
                validateMathJson(*mathJson, executableSymbols, errors);
            }
            if (!errors.empty()) {
                std::ostringstream message;
                for (std::size_t index = 0; index < errors.size(); ++index) message << (index ? " " : "") << errors[index];
                add(result, "edgeEquationInvalid", "error", message.str(), "edge", id, "equation");
            }
        }
        const auto outputState = value(edge, "equationModel.output.stateId");
        if (!outputState.empty()) {
            const auto role = value(edge, "equationModel.output.role");
            if (role != "source" && role != "target") add(result, "edgeOutputMissing", "error", "Equation output role must be source or target.", "edge", id, "output");
            const auto& candidates = role == "source" ? stateIds[sourceNode] : stateIds[targetNode];
            if (!candidates.contains(outputState)) add(result, "edgeOutputMissing", "error", "Choose an existing state updated by this equation.", "edge", id, "output");
            countEdgeContribution(role, outputState);
        } else if (targetState.empty()) {
            add(result, "edgeOutputMissing", "error", "Choose the state updated by this equation.", "edge", id, "output");
        }
    }
    // A state relationships set takes nothing else: no rate, no source term, no provider.
    for (const auto& stateId : relationshipStateIds) {
        if (stateContributorCounts[stateId] == 0) continue;
        const auto ownerNode = std::find_if(stateIds.begin(), stateIds.end(), [&](const auto& entry) { return entry.second.contains(stateId); });
        add(result, "algebraicStateMixed", "error",
            "A state set by relationships' equations is the sum of what they set, and takes no other contribution.",
            "node", ownerNode != stateIds.end() ? ownerNode->first : std::string{});
    }
    if (!relationshipStateIds.empty() && std::none_of(result.issues.begin(), result.issues.end(), [](const auto& item) { return item.severity == "error"; })) {
        try {
            static_cast<void>(compileExecutionPlan(document));
        } catch (const std::exception& error) {
            add(result, std::string(error.what()).find("form a loop") != std::string::npos ? "algebraicLoop" : "modelCompileFailed", "error", error.what(), "model", "");
        }
    }
    for (const auto& stateId : setsValueStateIds) {
        if (stateContributorCounts[stateId] == 1) continue;
        const auto ownerNode = std::find_if(stateIds.begin(), stateIds.end(),
            [&](const auto& entry) { return entry.second.contains(stateId); });
        add(result, "setsValueNotSoleContributor", "error",
            "A source term or computational-node-provider output that sets its state's value directly must be the only contribution to that state.",
            "node", ownerNode != stateIds.end() ? ownerNode->first : std::string{});
    }
    // Pre-run phase of docs/proposals/numericalStabilityDiagnostics.md: a local, linearized
    // Explicit Euler stability check per node, against the active run configuration's step size.
    // Only attempted once every structural check above has already run, and only when there is a
    // concrete step size to check against (see activeGlobalTimeStep's own comment). Compiling the
    // document here is new: nothing else in this function needs a compiled ExecutionPlan, only the
    // raw ptree -- but assessNodeStability needs the same resolved bindings/parameters/dependency
    // ordering compileExecutionPlan already produces, and reproducing that logic against the ptree
    // directly would duplicate it rather than reuse it. A document that fails to compile for any
    // reason (most already reported above as a distinct error, a few not) is caught and simply
    // skipped here -- this pass is a heuristic addition, never the reason a document is invalid.
    const auto validSoFar = std::none_of(result.issues.begin(), result.issues.end(), [](const auto& item) { return item.severity == "error"; });
    if (activeGlobalTimeStep && validSoFar) {
        try {
            const auto plan = compileExecutionPlan(document);
            for (const auto& node : plan.nodes) {
                const auto assessment = assessNodeStability(node, plan.initialStates, *activeGlobalTimeStep);
                if (!assessment) continue;
                const auto nodeId = std::to_string(assessment->nodeId);
                if (!assessment->stable) {
                    const auto resolved = assessment->dominantParameter
                        ? resolveAttributedParameter(document, *assessment->dominantParameter) : std::nullopt;
                    std::ostringstream message;
                    message << "This node's dynamics may be unstable at its current substep count (amplification factor "
                            << assessment->maxAmplificationFactor << " > 1 per global step)";
                    if (resolved) message << " -- driven mainly by " << resolved->phrase;
                    const auto symbol = stateSymbol(document, assessment->dominantStateId);
                    if (assessment->unconditionallyUnstable) {
                        message << " -- no substep count can stabilize this with Explicit Euler ("
                                << (symbol.empty() ? "its dominant state" : "'" + symbol + "'") << " has a genuinely growing mode) "
                                << "-- this looks like a modeling or gain-tuning issue rather than a numerics one; check whether "
                                << "this dynamics is intentionally unstable before adjusting numerics.";
                    } else {
                        message << " -- consider raising this node's numerics.substepsPerGlobalStep to at least " << *assessment->requiredSubsteps;
                        if (!symbol.empty()) message << " ('" << symbol << "' needs that many to stabilize)";
                        message << ", converting " << (symbol.empty() ? "a fast state" : "'" + symbol + "'") << " to setsValue, or moving "
                                << (symbol.empty() ? "fast dynamics" : "its dynamics") << " onto their own node.";
                    }
                    auto& issue = add(result, "numericsPotentiallyUnstable", "warning", message.str(), "node", nodeId, "numerics");
                    if (resolved) issue.attributedParameter = resolved->location;
                } else if (assessment->stiffnessRatio && *assessment->stiffnessRatio > 1000) {
                    std::ostringstream message;
                    message << "This node is stable but stiff (fastest/slowest rate ratio " << *assessment->stiffnessRatio
                            << ") -- one state's dynamics are much faster than another's on the same node, forcing a smaller "
                            << "step than the slower dynamics alone would need.";
                    add(result, "numericsStiffModel", "warning", message.str(), "node", nodeId, "numerics");
                }
            }
        } catch (const std::exception&) {
            // Some other, already-reported structural problem (or a genuinely uncompilable
            // document this pass has no business diagnosing) -- nothing to add here.
        }
    }
    result.valid = std::none_of(result.issues.begin(), result.issues.end(), [](const auto& item) { return item.severity == "error"; });
    return result;
}

}
