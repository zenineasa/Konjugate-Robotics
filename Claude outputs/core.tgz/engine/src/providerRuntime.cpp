/* Copyright © 2026 Zenin Easa Panthakkalakath */

#include "providerRuntime.hpp"
#include "cppToolchain.hpp"
#include "relationshipProvider.pb.h"
#include "konjugate/providerSharedMemoryChannel.hpp"
#include "konjugate/providerInProcessAbi.hpp"

#include <boost/property_tree/json_parser.hpp>
#include <boost/property_tree/ptree.hpp>
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <memory>
#include <mutex>
#include <openssl/evp.h>
#include <span>
#include <stdexcept>
#include <string>
#ifdef _WIN32
#include <windows.h>
#include <io.h>
#include <process.h>
#include <fcntl.h>
using ssize_t = intptr_t;
using pid_t = int;
#else
#include <cerrno>
#include <dlfcn.h>
#include <fcntl.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#endif
#include <unordered_map>

#include <vector>

namespace konjugate {
namespace {

using namespace konjugate::provider::protocol;

void writeFramed(int fd, const google::protobuf::MessageLite& message) {
    const auto size = static_cast<std::uint32_t>(message.ByteSizeLong());
    const unsigned char header[4] = {
        static_cast<unsigned char>((size >> 24) & 0xff),
        static_cast<unsigned char>((size >> 16) & 0xff),
        static_cast<unsigned char>((size >> 8) & 0xff),
        static_cast<unsigned char>(size & 0xff)
    };
    if (::write(fd, header, 4) != 4) {
        throw std::runtime_error("Failed to write frame header to provider process.");
    }
    std::string payload;
    if (!message.SerializeToString(&payload)) {
        throw std::runtime_error("Failed to serialize message for provider process.");
    }
    std::size_t written = 0;
    while (written < payload.size()) {
        const auto result = ::write(fd, payload.data() + written, payload.size() - written);
        if (result <= 0) throw std::runtime_error("Failed to write payload to provider process.");
        written += static_cast<std::size_t>(result);
    }
}

bool readExact(int fd, char* buffer, std::size_t size) {
    std::size_t readCount = 0;
    while (readCount < size) {
        const auto result = ::read(fd, buffer + readCount, size - readCount);
        if (result <= 0) return false;
        readCount += static_cast<std::size_t>(result);
    }
    return true;
}

bool readFramed(int fd, ProviderToEngine& message) {
    unsigned char header[4];
    if (!readExact(fd, reinterpret_cast<char*>(header), 4)) return false;
    const std::uint32_t size = (static_cast<std::uint32_t>(header[0]) << 24) |
                               (static_cast<std::uint32_t>(header[1]) << 16) |
                               (static_cast<std::uint32_t>(header[2]) << 8) |
                                static_cast<std::uint32_t>(header[3]);
    std::string payload(size, '\0');
    if (!readExact(fd, payload.data(), size)) return false;
    return message.ParseFromString(payload);
}

std::string sha256Hex(const std::string& data) {
    unsigned char digest[EVP_MAX_MD_SIZE];
    unsigned int digestLength = 0;
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    const bool ok = context &&
        EVP_DigestInit_ex(context, EVP_sha256(), nullptr) == 1 &&
        EVP_DigestUpdate(context, data.data(), data.size()) == 1 &&
        EVP_DigestFinal_ex(context, digest, &digestLength) == 1;
    if (context) EVP_MD_CTX_free(context);
    if (!ok) throw std::runtime_error("Failed to hash a C++ relationship provider's inline source.");

    static const char hex[] = "0123456789abcdef";
    std::string result(static_cast<std::size_t>(digestLength) * 2, '0');
    for (unsigned int index = 0; index < digestLength; ++index) {
        const auto position = static_cast<std::size_t>(index) * 2;
        result[position] = hex[(digest[index] >> 4) & 0xf];
        result[position + 1] = hex[digest[index] & 0xf];
    }
    return result;
}

// Python needs no build step, but an inline implementation authored in the editor is still
// literal source text, not a path — it must be written to a real .py file before it can be
// passed to `python3 -m konjugate <path>`. A provider source that already names an existing
// file (as used by references to standalone, non-inline scripts) is passed through as-is.
// Cached alongside compiled C++ providers, by the same source-hash scheme.
std::string preparePythonProviderSource(const std::string& source, const ProviderConfiguration& config) {
    std::error_code existsError;
    if (std::filesystem::exists(source, existsError) && !existsError) return source;

    const auto hash = sha256Hex(source);
    const std::filesystem::path buildRoot = config.buildDirectory.empty()
        ? std::filesystem::temp_directory_path() / "konjugateProviders"
        : std::filesystem::path(config.buildDirectory);
    const auto providerDirectory = buildRoot / hash;
    const auto sourcePath = providerDirectory / "relationship.py";

    if (!std::filesystem::exists(sourcePath)) {
        std::filesystem::create_directories(providerDirectory);
        std::ofstream sourceFile(sourcePath, std::ios::trunc);
        if (!sourceFile) throw std::runtime_error("Failed to write Python provider source to " + sourcePath.string());
        sourceFile << source;
    }
    return sourcePath.string();
}

// executable pairs the inline source with providerWorker.cpp into a standalone process (used
// by the pipe and shared-memory transports); sharedLibrary pairs it with
// providerInProcessShim.cpp into a dlopen()'d/LoadLibrary()'d relationship-shaped plugin (used
// by the in-process transport); nodeSharedLibrary pairs it with providerInProcessNodeShim.cpp
// into a dlopen()'d/LoadLibrary()'d NODE-shaped plugin (N inputs, M named outputs, optional
// checkpoint/restore -- see providerInProcessAbi.hpp's two distinct vtables). All three live
// under the same source-hash build directory, just as different filenames, so choosing a
// different mode/shape for the same source never collides with a previously-built artifact of
// another kind.
enum class CppProviderArtifactKind { executable, sharedLibrary, nodeSharedLibrary };

// Compiles an inline C++ relationship's source, together with the public SDK header and one of
// Konjugate's glue wrappers, into a native provider artifact. The build is cached on disk by a
// hash of the source text AND the glue file's own content, so repeated runs of the same inline
// implementation only pay the compile cost once -- but a Konjugate upgrade that changes the glue
// file itself (a shim bug fix, an SDK change) still invalidates a previously-compiled artifact
// rather than silently reusing code built against the old glue forever, since the fixed OS temp
// directory this caches under (see buildRoot below) is not itself versioned by Konjugate's own
// version number. This is a minimal first build pipeline: it does not yet run declared
// conformance tests or record compiler identity/artifact hash in the project.
std::string buildCppProvider(const std::string& source, const ProviderConfiguration& config, CppProviderArtifactKind kind) {
    if (config.cppSdkPath.empty()) {
        throw std::runtime_error(
            "A C++ relationship provider requires providers.cpp.sdkPath to locate the Konjugate C++ SDK.");
    }

    const bool sharedLibrary = kind != CppProviderArtifactKind::executable;
    const std::string glueFile = kind == CppProviderArtifactKind::nodeSharedLibrary ? "providerInProcessNodeShim.cpp"
        : kind == CppProviderArtifactKind::sharedLibrary ? "providerInProcessShim.cpp" : "providerWorker.cpp";
    // A node-shaped artifact's generated glue dlopen()s a second, external library of its own
    // (e.g. an imported FMU's own compiled binary) -- on Linux that symbol lives in libdl, which
    // (unlike macOS's libSystem or Windows' LoadLibrary) is not linked in by default.
    const bool needsDynamicLoaderLibrary = kind == CppProviderArtifactKind::nodeSharedLibrary;
    const std::filesystem::path sdkRoot(config.cppSdkPath);
    const auto gluePath = sdkRoot / "src" / glueFile;

    std::ifstream glueStream(gluePath, std::ios::binary);
    if (!glueStream) throw std::runtime_error("Failed to read the provider glue file at " + gluePath.string());
    const std::string glueContent((std::istreambuf_iterator<char>(glueStream)), std::istreambuf_iterator<char>());

    const auto hash = sha256Hex(source + '\0' + glueContent);
    const std::filesystem::path buildRoot = config.buildDirectory.empty()
        ? std::filesystem::temp_directory_path() / "konjugateProviders"
        : std::filesystem::path(config.buildDirectory);
    const auto providerDirectory = buildRoot / hash;
#ifdef _WIN32
    const auto artifactPath = providerDirectory / (sharedLibrary ? "provider.dll" : "provider.exe");
#elif defined(__APPLE__)
    const auto artifactPath = providerDirectory / (sharedLibrary ? "provider.dylib" : "provider");
#else
    const auto artifactPath = providerDirectory / (sharedLibrary ? "provider.so" : "provider");
#endif

    if (!std::filesystem::exists(artifactPath)) {
        std::filesystem::create_directories(providerDirectory);
        const auto sourcePath = providerDirectory / "relationship.cpp";
        std::ofstream sourceFile(sourcePath, std::ios::trunc);
        if (!sourceFile) throw std::runtime_error("Failed to write C++ provider source to " + sourcePath.string());
        sourceFile << source;
        sourceFile.close();

        cppToolchain::buildNativeArtifact(sourcePath, gluePath, sdkRoot / "include",
            artifactPath, sharedLibrary, config.cppCompiler,
            kind == CppProviderArtifactKind::nodeSharedLibrary ? "the C++ computational-node provider" : "the C++ relationship provider",
            needsDynamicLoaderLibrary);
    }

    return artifactPath.string();
}

} // anonymous namespace

class ProviderBackend {
public:
    virtual ~ProviderBackend() = default;
    virtual void addInstance(std::uint64_t instanceId, const std::vector<CompiledBinding>& bindings) = 0;
    virtual void sendInitialization() = 0;
    virtual std::vector<std::pair<std::uint64_t, double>> evaluateBatch(
        std::uint64_t sequence, double simulationTime, double stepSize,
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>& evaluations) = 0;
    virtual void shutdown() noexcept = 0;

    // Throwing defaults: only PipeProviderBackend (the transport Python computational-node
    // providers always use) overrides these. SharedMemoryProviderBackend/InProcessProviderBackend
    // never receive these calls in practice, since createProviderBackend only routes cppProvider
    // tasks to them and node-provider tasks are always pythonProvider this release.
    virtual std::vector<std::pair<std::string, double>> evaluateNode(
        std::uint64_t instanceId, double simulationTime, double stepSize, std::span<const double> inputs) {
        static_cast<void>(instanceId);
        static_cast<void>(simulationTime);
        static_cast<void>(stepSize);
        static_cast<void>(inputs);
        throw std::runtime_error("This provider transport does not support computational-node providers.");
    }
    virtual std::vector<std::byte> requestCheckpoint(std::uint64_t instanceId) {
        static_cast<void>(instanceId);
        throw std::runtime_error("This provider transport does not support computational-node checkpointing.");
    }
    virtual void requestRestore(std::uint64_t instanceId, std::span<const std::byte> payload) {
        static_cast<void>(instanceId);
        static_cast<void>(payload);
        throw std::runtime_error("This provider transport does not support computational-node restore.");
    }
};

// Owns one spawned provider process's control pipe: spawn, protocol handshake, the initialize
// round trip, the pipe evaluateBatch round trip (the hot path for PipeProviderBackend; used by
// SharedMemoryProviderBackend only for handshake/initialize/shutdown, never for evaluation),
// and shutdown. Both backends below compose one of these rather than duplicating process
// lifecycle handling.
class ProviderControlChannel {
public:
    ProviderControlChannel(std::string processKey, ContributionImplementation implementation,
                           std::string sourcePath, const ProviderConfiguration& config,
                           std::vector<std::pair<std::string, std::string>> extraEnvironment = {})
        : processKey_(std::move(processKey)), implementation_(implementation), sourcePath_(std::move(sourcePath)) {
        spawn(config, extraEnvironment);
        performHandshake();
    }

    ~ProviderControlChannel() { close(); }
    ProviderControlChannel(const ProviderControlChannel&) = delete;
    ProviderControlChannel& operator=(const ProviderControlChannel&) = delete;

    const std::string& processKey() const noexcept { return processKey_; }

    void sendInitialize(const InitializeRequest& request) {
        if (request.instances_size() == 0) return;
        EngineToProvider msg;
        *msg.mutable_initialize() = request;
        writeFramed(stdinFd_, msg);

        ProviderToEngine resp;
        if (!readFramed(stdoutFd_, resp)) {
            throw std::runtime_error("Provider process " + processKey_ + " closed stdout during initialization.");
        }
        if (resp.has_failure()) {
            throw std::runtime_error("Provider process initialization failed: " + std::string(resp.failure().message()));
        }
        if (!resp.has_initialize()) {
            throw std::runtime_error("Unexpected response to initialization from provider process " + processKey_);
        }
    }

    std::vector<std::pair<std::uint64_t, double>> evaluateBatchOverPipe(
        std::uint64_t sequence, double simulationTime, double stepSize,
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>& evaluations) {
        EngineToProvider msg;
        auto* batch = msg.mutable_evaluate_batch();
        batch->set_sequence(sequence);
        batch->set_simulation_time(simulationTime);
        batch->set_step_size(stepSize);

        for (const auto& [instId, inputs] : evaluations) {
            auto* eval = batch->add_evaluations();
            eval->set_instance_id(instId);
            for (const auto val : inputs) eval->add_inputs(val);
        }

        writeFramed(stdinFd_, msg);

        ProviderToEngine resp;
        if (!readFramed(stdoutFd_, resp)) {
            throw std::runtime_error("Provider process " + processKey_ + " closed pipe during evaluateBatch.");
        }
        if (resp.has_failure()) {
            throw std::runtime_error("Provider process evaluation failed: " + std::string(resp.failure().message()));
        }
        if (!resp.has_evaluate_batch()) {
            throw std::runtime_error("Unexpected response to evaluateBatch from provider process " + processKey_);
        }

        std::vector<std::pair<std::uint64_t, double>> results;
        for (const auto& contrib : resp.evaluate_batch().contributions()) {
            results.emplace_back(contrib.instance_id(), contrib.value());
        }
        return results;
    }

    // A node has at most one provider task, so this always carries exactly one NodeEvaluation:
    // there is no cross-instance batching benefit here the way evaluateBatchOverPipe has across
    // multiple relationship-provider instances sharing one process.
    std::vector<std::pair<std::string, double>> sendNodeEvaluate(
        std::uint64_t instanceId, double simulationTime, double stepSize, std::span<const double> inputs) {
        EngineToProvider msg;
        auto* request = msg.mutable_node_evaluate();
        request->set_sequence(0);
        request->set_simulation_time(simulationTime);
        request->set_step_size(stepSize);
        auto* evaluation = request->add_evaluations();
        evaluation->set_instance_id(instanceId);
        for (const auto value : inputs) evaluation->add_inputs(value);

        writeFramed(stdinFd_, msg);

        ProviderToEngine resp;
        if (!readFramed(stdoutFd_, resp)) {
            throw std::runtime_error("Provider process " + processKey_ + " closed pipe during nodeEvaluate.");
        }
        if (resp.has_failure()) {
            throw std::runtime_error("Provider process node evaluation failed: " + std::string(resp.failure().message()));
        }
        if (!resp.has_node_evaluate()) {
            throw std::runtime_error("Unexpected response to nodeEvaluate from provider process " + processKey_);
        }

        std::vector<std::pair<std::string, double>> results;
        for (const auto& contribution : resp.node_evaluate().contributions()) {
            if (contribution.instance_id() != instanceId) continue;
            for (const auto& output : contribution.outputs()) {
                results.emplace_back(output.key(), output.value());
            }
        }
        return results;
    }

    std::vector<std::byte> sendCheckpoint(std::uint64_t instanceId) {
        EngineToProvider msg;
        msg.mutable_checkpoint()->set_instance_id(instanceId);
        writeFramed(stdinFd_, msg);

        ProviderToEngine resp;
        if (!readFramed(stdoutFd_, resp)) {
            throw std::runtime_error("Provider process " + processKey_ + " closed pipe during checkpoint.");
        }
        if (resp.has_failure()) {
            throw std::runtime_error("Provider process checkpoint failed: " + std::string(resp.failure().message()));
        }
        if (!resp.has_checkpoint() || resp.checkpoint().instance_id() != instanceId) {
            throw std::runtime_error("Unexpected response to checkpoint from provider process " + processKey_);
        }

        const auto& payload = resp.checkpoint().payload();
        std::vector<std::byte> bytes(payload.size());
        std::transform(payload.begin(), payload.end(), bytes.begin(),
            [](char byte) { return static_cast<std::byte>(byte); });
        return bytes;
    }

    void sendRestore(std::uint64_t instanceId, std::span<const std::byte> payload) {
        EngineToProvider msg;
        auto* request = msg.mutable_restore();
        request->set_instance_id(instanceId);
        request->set_payload(std::string(reinterpret_cast<const char*>(payload.data()), payload.size()));
        writeFramed(stdinFd_, msg);

        ProviderToEngine resp;
        if (!readFramed(stdoutFd_, resp)) {
            throw std::runtime_error("Provider process " + processKey_ + " closed pipe during restore.");
        }
        if (resp.has_failure()) {
            throw std::runtime_error("Provider process restore failed: " + std::string(resp.failure().message()));
        }
        if (!resp.has_restore() || resp.restore().instance_id() != instanceId || !resp.restore().restored()) {
            throw std::runtime_error("Unexpected response to restore from provider process " + processKey_);
        }
    }

    void close() noexcept {
#ifdef _WIN32
        if (hProcess_ == NULL) return;
#else
        if (pid_ <= 0) return;
#endif
        // Best-effort: this whole function is noexcept, and the fds get closed unconditionally
        // right below regardless of whether the provider ever answers the shutdown handshake.
        try {
            EngineToProvider msg;
            msg.mutable_shutdown();
            writeFramed(stdinFd_, msg);
            ProviderToEngine resp;
            readFramed(stdoutFd_, resp);
        } catch (...) {} // NOLINT(bugprone-empty-catch)

        if (stdinFd_ != -1) { ::close(stdinFd_); stdinFd_ = -1; }
        if (stdoutFd_ != -1) { ::close(stdoutFd_); stdoutFd_ = -1; }

#ifdef _WIN32
        DWORD waitResult = WaitForSingleObject(hProcess_, 1000);
        if (waitResult == WAIT_TIMEOUT) {
            TerminateProcess(hProcess_, 1);
        }
        CloseHandle(hProcess_);
        hProcess_ = NULL;
        pid_ = -1;
#else
        int status = 0;
        ::waitpid(pid_, &status, WNOHANG);
        pid_ = -1;
#endif
    }

private:
#ifdef _WIN32
    void spawn(const ProviderConfiguration& config, const std::vector<std::pair<std::string, std::string>>& extraEnvironment) {
        HANDLE hChildStd_IN_Rd = NULL;
        HANDLE hChildStd_IN_Wr = NULL;
        HANDLE hChildStd_OUT_Rd = NULL;
        HANDLE hChildStd_OUT_Wr = NULL;

        SECURITY_ATTRIBUTES saAttr;
        saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
        saAttr.bInheritHandle = TRUE;
        saAttr.lpSecurityDescriptor = NULL;

        if (!CreatePipe(&hChildStd_OUT_Rd, &hChildStd_OUT_Wr, &saAttr, 0)) {
            throw std::runtime_error("Failed to create stdout pipe for provider process.");
        }
        if (!SetHandleInformation(hChildStd_OUT_Rd, HANDLE_FLAG_INHERIT, 0)) {
            CloseHandle(hChildStd_OUT_Rd);
            CloseHandle(hChildStd_OUT_Wr);
            throw std::runtime_error("Failed to set handle info for stdout pipe.");
        }

        if (!CreatePipe(&hChildStd_IN_Rd, &hChildStd_IN_Wr, &saAttr, 0)) {
            CloseHandle(hChildStd_OUT_Rd);
            CloseHandle(hChildStd_OUT_Wr);
            throw std::runtime_error("Failed to create stdin pipe for provider process.");
        }
        if (!SetHandleInformation(hChildStd_IN_Wr, HANDLE_FLAG_INHERIT, 0)) {
            CloseHandle(hChildStd_OUT_Rd);
            CloseHandle(hChildStd_OUT_Wr);
            CloseHandle(hChildStd_IN_Rd);
            CloseHandle(hChildStd_IN_Wr);
            throw std::runtime_error("Failed to set handle info for stdin pipe.");
        }

        // CreateProcessA below passes a NULL environment block, which inherits this process's
        // environment, so setting variables here (rather than building an explicit block) is
        // sufficient for both PYTHONPATH and any shared-memory channel names a backend needs.
        for (const auto& [name, value] : extraEnvironment) {
            SetEnvironmentVariableA(name.c_str(), value.c_str());
        }

        std::string commandLine;
        if (implementation_ == ContributionImplementation::pythonProvider) {
            std::string pythonExe = config.pythonInterpreter.empty() ? "python3" : config.pythonInterpreter;
            // The resolved python3 may be a distribution (Anaconda, a pyenv shim, ...) with no
            // knowledge of Konjugate's SDK; put it on PYTHONPATH explicitly rather than relying on
            // the package being installed into whichever interpreter is found.
            if (!config.pythonSdkPath.empty()) {
                char existingPythonPath[32768];
                const auto existingLength = GetEnvironmentVariableA("PYTHONPATH", existingPythonPath, sizeof(existingPythonPath));
                const std::string pythonPath = existingLength > 0
                    ? config.pythonSdkPath + ";" + std::string(existingPythonPath, existingLength) : config.pythonSdkPath;
                SetEnvironmentVariableA("PYTHONPATH", pythonPath.c_str());
            }
            commandLine = "\"" + pythonExe + "\" -m konjugate \"" + sourcePath_ + "\"";
        } else {
            commandLine = "\"" + sourcePath_ + "\"";
        }

        BOOL bSuccess = FALSE;
        PROCESS_INFORMATION piProcInfo;
        ZeroMemory(&piProcInfo, sizeof(PROCESS_INFORMATION));

        auto tryCreateProcess = [&](const std::string& cmd) -> BOOL {
            STARTUPINFOA siStartInfo;
            ZeroMemory(&siStartInfo, sizeof(STARTUPINFOA));
            siStartInfo.cb = sizeof(STARTUPINFOA);
            siStartInfo.hStdInput = hChildStd_IN_Rd;
            siStartInfo.hStdOutput = hChildStd_OUT_Wr;
            siStartInfo.hStdError = GetStdHandle(STD_ERROR_HANDLE);
            siStartInfo.dwFlags |= STARTF_USESTDHANDLES;

            std::vector<char> cmdLineBuf(cmd.begin(), cmd.end());
            cmdLineBuf.push_back('\0');

            return CreateProcessA(
                NULL,
                cmdLineBuf.data(),
                NULL,
                NULL,
                TRUE,
                0,
                NULL,
                NULL,
                &siStartInfo,
                &piProcInfo
            );
        };

        bSuccess = tryCreateProcess(commandLine);
        if (!bSuccess && implementation_ == ContributionImplementation::pythonProvider) {
            std::string pythonExe = config.pythonInterpreter.empty() ? "python3" : config.pythonInterpreter;
            if (pythonExe == "python3") {
                std::string fallbackCommandLine = "\"python\" -m konjugate \"" + sourcePath_ + "\"";
                bSuccess = tryCreateProcess(fallbackCommandLine);
            }
        }

        CloseHandle(hChildStd_IN_Rd);
        CloseHandle(hChildStd_OUT_Wr);

        if (!bSuccess) {
            CloseHandle(hChildStd_IN_Wr);
            CloseHandle(hChildStd_OUT_Rd);
            throw std::runtime_error("Failed to spawn provider process: " + std::to_string(GetLastError()));
        }

        CloseHandle(piProcInfo.hThread);

        stdinFd_ = _open_osfhandle(reinterpret_cast<intptr_t>(hChildStd_IN_Wr), _O_WRONLY | _O_BINARY);
        stdoutFd_ = _open_osfhandle(reinterpret_cast<intptr_t>(hChildStd_OUT_Rd), _O_RDONLY | _O_BINARY);
        hProcess_ = piProcInfo.hProcess;
        pid_ = static_cast<pid_t>(piProcInfo.dwProcessId);
    }
#else
    void spawn(const ProviderConfiguration& config, const std::vector<std::pair<std::string, std::string>>& extraEnvironment) {
        int inPipe[2];
        int outPipe[2];
        if (::pipe(inPipe) != 0 || ::pipe(outPipe) != 0) {
            throw std::runtime_error("Failed to create pipes for provider process.");
        }

        pid_ = ::fork();
        if (pid_ < 0) {
            throw std::runtime_error("Failed to fork provider process.");
        }

        if (pid_ == 0) {
            // Child process
            ::dup2(inPipe[0], STDIN_FILENO);
            ::dup2(outPipe[1], STDOUT_FILENO);
            ::close(inPipe[0]); ::close(inPipe[1]);
            ::close(outPipe[0]); ::close(outPipe[1]);

            for (const auto& [name, value] : extraEnvironment) ::setenv(name.c_str(), value.c_str(), 1);

            if (implementation_ == ContributionImplementation::pythonProvider) {
                std::string pythonExe = config.pythonInterpreter.empty() ? "python3" : config.pythonInterpreter;
                // The resolved python3 may be a distribution (Anaconda, a pyenv shim, ...) with no
                // knowledge of Konjugate's SDK; put it on the child's PYTHONPATH explicitly rather
                // than relying on the package being installed into whichever interpreter is found.
                if (!config.pythonSdkPath.empty()) {
                    const char* existingPythonPath = std::getenv("PYTHONPATH");
                    const std::string pythonPath = existingPythonPath && *existingPythonPath
                        ? config.pythonSdkPath + ":" + existingPythonPath : config.pythonSdkPath;
                    ::setenv("PYTHONPATH", pythonPath.c_str(), 1);
                }
                std::vector<const char*> args;
                args.push_back(pythonExe.c_str());
                args.push_back("-m");
                args.push_back("konjugate");
                args.push_back(sourcePath_.c_str());
                args.push_back(nullptr);
                ::execvp(pythonExe.c_str(), const_cast<char* const*>(args.data()));
                if (pythonExe == "python3") {
                    // No override was configured and "python3" itself was not found; some
                    // platforms only provide the interpreter as "python".
                    args[0] = "python";
                    ::execvp("python", const_cast<char* const*>(args.data()));
                }
            } else {
                std::vector<const char*> args;
                args.push_back(sourcePath_.c_str());
                args.push_back(nullptr);
                ::execvp(sourcePath_.c_str(), const_cast<char* const*>(args.data()));
            }
            std::perror("execvp failed");
            ::_exit(127);
        }

        // Parent process
        ::close(inPipe[0]);
        ::close(outPipe[1]);
        stdinFd_ = inPipe[1];
        stdoutFd_ = outPipe[0];
    }
#endif

    void performHandshake() {
        EngineToProvider msg;
        auto* handshake = msg.mutable_handshake();
        handshake->set_protocol_version(1);
        handshake->set_provider_api_version(1);
        writeFramed(stdinFd_, msg);

        ProviderToEngine resp;
        if (!readFramed(stdoutFd_, resp)) {
            throw std::runtime_error("Provider process " + processKey_ + " failed handshake (no response).");
        }
        if (resp.has_failure()) {
            throw std::runtime_error("Provider process handshake failed: " + std::string(resp.failure().message()));
        }
        if (!resp.has_handshake()) {
            throw std::runtime_error("Unexpected response to handshake from provider process " + processKey_);
        }
    }

    std::string processKey_;
    ContributionImplementation implementation_;
    std::string sourcePath_;
    pid_t pid_ = -1;
#ifdef _WIN32
    HANDLE hProcess_ = NULL;
#endif
    int stdinFd_ = -1;
    int stdoutFd_ = -1;
};

class PipeProviderBackend final : public ProviderBackend {
public:
    PipeProviderBackend(std::string processKey, ContributionImplementation implementation,
                        std::string sourcePath, const ProviderConfiguration& config)
        : channel_(std::move(processKey), implementation, std::move(sourcePath), config) {}

    void addInstance(std::uint64_t instanceId, const std::vector<CompiledBinding>& bindings) override {
        auto* inst = initializeReq_.add_instances();
        inst->set_instance_id(instanceId);
        for (const auto& binding : bindings) inst->add_input_keys(binding.symbol);
    }

    void sendInitialization() override { channel_.sendInitialize(initializeReq_); }

    std::vector<std::pair<std::uint64_t, double>> evaluateBatch(
        std::uint64_t sequence, double simulationTime, double stepSize,
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>& evaluations) override {
        // Multiple relationship instances sharing this worker may be evaluated from
        // different execution-plan threads in the same synchronization step; the pipe
        // round-trip is not reentrant, so concurrent callers must be serialized here.
        std::lock_guard<std::mutex> lock(mutex_);
        return channel_.evaluateBatchOverPipe(sequence, simulationTime, stepSize, evaluations);
    }

    void shutdown() noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        channel_.close();
    }

    std::vector<std::pair<std::string, double>> evaluateNode(
        std::uint64_t instanceId, double simulationTime, double stepSize, std::span<const double> inputs) override {
        std::lock_guard<std::mutex> lock(mutex_);
        return channel_.sendNodeEvaluate(instanceId, simulationTime, stepSize, inputs);
    }

    std::vector<std::byte> requestCheckpoint(std::uint64_t instanceId) override {
        std::lock_guard<std::mutex> lock(mutex_);
        return channel_.sendCheckpoint(instanceId);
    }

    void requestRestore(std::uint64_t instanceId, std::span<const std::byte> payload) override {
        std::lock_guard<std::mutex> lock(mutex_);
        channel_.sendRestore(instanceId, payload);
    }

private:
    ProviderControlChannel channel_;
    InitializeRequest initializeReq_;
    std::mutex mutex_;
};

#ifndef _WIN32
// Uses shared memory plus a pair of named POSIX semaphores for the hot evaluateBatch path
// instead of the pipe, cutting the fixed per-round-trip cost (a syscall pair plus a scheduler
// wake) that dominates when many contributions share one provider process. Handshake,
// initialize and shutdown still go over the same pipe-based control channel as
// PipeProviderBackend: those are rare, so there is nothing to gain by moving them, and reusing
// the existing protocol there keeps this class small. POSIX-only: this mode is never selected
// on Windows, where ProviderRuntime falls back to PipeProviderBackend.
class SharedMemoryProviderBackend final : public ProviderBackend {
public:
    SharedMemoryProviderBackend(std::string processKey, ContributionImplementation implementation,
                                std::string sourcePath, const ProviderConfiguration& config)
        : resources_(processKey),
          channel_(std::move(processKey), implementation, std::move(sourcePath), config, resources_.environment()) {}

    void addInstance(std::uint64_t instanceId, const std::vector<CompiledBinding>& bindings) override {
        auto* inst = initializeReq_.add_instances();
        inst->set_instance_id(instanceId);
        for (const auto& binding : bindings) inst->add_input_keys(binding.symbol);
    }

    void sendInitialization() override { channel_.sendInitialize(initializeReq_); }

    std::vector<std::pair<std::uint64_t, double>> evaluateBatch(
        std::uint64_t sequence, double simulationTime, double stepSize,
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>& evaluations) override {
        static_cast<void>(sequence);
        std::lock_guard<std::mutex> lock(mutex_);

        std::vector<std::pair<std::uint64_t, double>> results;
        results.reserve(evaluations.size());

        // The channel's slot array has a fixed size, so a batch larger than that capacity is
        // sent as multiple round trips rather than growing the shared struct without bound.
        for (std::size_t offset = 0; offset < evaluations.size(); offset += provider::sharedmem::kMaxSlots) {
            const auto count = std::min(provider::sharedmem::kMaxSlots, evaluations.size() - offset);
            auto* channel = resources_.channel;
            channel->slotCount = static_cast<std::uint32_t>(count);
            channel->simulationTime = simulationTime;
            channel->stepSize = stepSize;
            channel->failed = false;

            for (std::size_t index = 0; index < count; ++index) {
                const auto& [instanceId, inputs] = evaluations[offset + index];
                if (inputs.size() > provider::sharedmem::kMaxInputsPerSlot) {
                    throw std::runtime_error(
                        "A provider input list exceeds the shared-memory transport's fixed capacity.");
                }
                auto& slot = channel->slots[index];
                slot.instanceId = instanceId;
                slot.inputCount = static_cast<std::uint32_t>(inputs.size());
                std::copy(inputs.begin(), inputs.end(), slot.inputs);
            }

            if (::sem_post(resources_.requestSemaphore) != 0) {
                throw std::runtime_error("Failed to signal provider process " + channel_.processKey() + " for evaluation.");
            }
            while (::sem_wait(resources_.responseSemaphore) != 0) {
                if (errno != EINTR) {
                    throw std::runtime_error("Failed waiting on provider process " + channel_.processKey() + " for a result.");
                }
            }

            if (channel->failed) {
                throw std::runtime_error("Provider process " + channel_.processKey() +
                    " failed during shared-memory evaluation: " + std::string(channel->errorMessage));
            }
            for (std::size_t index = 0; index < count; ++index) {
                results.emplace_back(channel->slots[index].instanceId, channel->slots[index].output);
            }
        }
        return results;
    }

    void shutdown() noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        channel_.close();
    }

private:
    // Owns the shared-memory region and the two named semaphores used to hand evaluation
    // requests/responses across the process boundary. Declared before channel_ so it is
    // constructed first (the worker needs these names as environment variables at spawn time)
    // and destroyed last: member destruction runs in reverse declaration order, so channel_'s
    // shutdown (which waits for the worker's shutdown acknowledgement over the pipe, sent only
    // after the worker has stopped touching shared memory) always completes before this tears
    // the mapping down.
    struct SharedResources {
        std::string shmName;
        std::string requestSemaphoreName;
        std::string responseSemaphoreName;
        int shmFd = -1;
        provider::sharedmem::Channel* channel = nullptr;
        sem_t* requestSemaphore = SEM_FAILED;
        sem_t* responseSemaphore = SEM_FAILED;

        explicit SharedResources(const std::string& processKey) { create(processKey); }
        ~SharedResources() { destroy(); }
        SharedResources(const SharedResources&) = delete;
        SharedResources& operator=(const SharedResources&) = delete;

        std::vector<std::pair<std::string, std::string>> environment() const {
            return {
                {provider::sharedmem::kSharedMemoryEnvVar, shmName},
                {provider::sharedmem::kRequestSemaphoreEnvVar, requestSemaphoreName},
                {provider::sharedmem::kResponseSemaphoreEnvVar, responseSemaphoreName},
            };
        }

        void create(const std::string& processKey) {
            static std::atomic<std::uint64_t> counter{0};
            static_cast<void>(processKey);
            // macOS enforces a short (31-character, including the slash) limit on sem_open()
            // names, so these stay compact rather than embedding the process key.
            const auto token = std::to_string(::getpid()) + "_" +
                std::to_string(counter.fetch_add(1, std::memory_order_relaxed));
            shmName = "/kjs" + token;
            requestSemaphoreName = "/kjq" + token;
            responseSemaphoreName = "/kjr" + token;

            shmFd = ::shm_open(shmName.c_str(), O_CREAT | O_EXCL | O_RDWR, 0600);
            if (shmFd < 0) throw std::runtime_error("Failed to create a shared-memory provider channel.");
            if (::ftruncate(shmFd, sizeof(provider::sharedmem::Channel)) != 0) {
                destroy();
                throw std::runtime_error("Failed to size a shared-memory provider channel.");
            }
            void* mapped = ::mmap(nullptr, sizeof(provider::sharedmem::Channel),
                                  PROT_READ | PROT_WRITE, MAP_SHARED, shmFd, 0);
            if (mapped == MAP_FAILED) {
                destroy();
                throw std::runtime_error("Failed to map a shared-memory provider channel.");
            }
            // shm_open + ftruncate zero-fills new POSIX shared memory, which already matches
            // Channel's intended default state, so no placement-new is needed: both this
            // process and the worker just reinterpret the mapping as a Channel*. (There is no
            // fully portable way to construct a C++ object shared across address spaces;
            // treating the mapping as plain, semaphore-guarded POD bytes sidesteps that.)
            channel = reinterpret_cast<provider::sharedmem::Channel*>(mapped);

            requestSemaphore = ::sem_open(requestSemaphoreName.c_str(), O_CREAT | O_EXCL, 0600, 0);
            if (requestSemaphore == SEM_FAILED) {
                destroy();
                throw std::runtime_error("Failed to create a shared-memory provider request semaphore.");
            }
            responseSemaphore = ::sem_open(responseSemaphoreName.c_str(), O_CREAT | O_EXCL, 0600, 0);
            if (responseSemaphore == SEM_FAILED) {
                destroy();
                throw std::runtime_error("Failed to create a shared-memory provider response semaphore.");
            }
        }

        void destroy() noexcept {
            if (requestSemaphore != SEM_FAILED) {
                ::sem_close(requestSemaphore);
                ::sem_unlink(requestSemaphoreName.c_str());
                requestSemaphore = SEM_FAILED;
            }
            if (responseSemaphore != SEM_FAILED) {
                ::sem_close(responseSemaphore);
                ::sem_unlink(responseSemaphoreName.c_str());
                responseSemaphore = SEM_FAILED;
            }
            if (channel) {
                ::munmap(channel, sizeof(provider::sharedmem::Channel));
                channel = nullptr;
            }
            if (shmFd >= 0) {
                ::close(shmFd);
                shmFd = -1;
            }
            if (!shmName.empty()) ::shm_unlink(shmName.c_str());
        }
    };

    SharedResources resources_;
    ProviderControlChannel channel_;
    InitializeRequest initializeReq_;
    std::mutex mutex_;
};
#endif

// Loads the provider directly into the engine process via dlopen()/LoadLibrary() and calls it
// through the C ABI in providerInProcessAbi.hpp — no IPC, no worker process. This is the
// fastest transport by a wide margin, but it gives up process isolation entirely: a crash,
// hang, or stack overflow in the provider's own code takes the whole engine process with it,
// so ProviderExecutionMode::inProcess is meant to stay an explicit opt-in for providers the
// caller already trusts, never a default. Available on Windows too (LoadLibrary/GetProcAddress
// carry none of SharedMemoryProviderBackend's cross-process-synchronization-primitive
// portability concerns), so this is not POSIX-gated the way that backend is.
class InProcessProviderBackend final : public ProviderBackend {
public:
    InProcessProviderBackend(std::string processKey, ContributionImplementation implementation,
                             std::string libraryPath, const ProviderConfiguration& config)
        : processKey_(std::move(processKey)) {
        static_cast<void>(implementation);
        static_cast<void>(config);
        loadLibrary(libraryPath);
        instance_ = vtable_->create();
        if (!instance_) {
            const std::string message = vtable_->lastError(nullptr);
            unloadLibrary();
            throw std::runtime_error("Failed to construct in-process provider '" + processKey_ + "': " + message);
        }
    }

    ~InProcessProviderBackend() override { unload(); }

    void addInstance(std::uint64_t instanceId, const std::vector<CompiledBinding>& bindings) override {
        std::vector<std::string> keys;
        keys.reserve(bindings.size());
        for (const auto& binding : bindings) keys.push_back(binding.symbol);
        pendingInstances_.emplace_back(instanceId, std::move(keys));
    }

    void sendInitialization() override {
        for (const auto& [instanceId, keys] : pendingInstances_) {
            std::vector<const char*> keyPointers;
            keyPointers.reserve(keys.size());
            for (const auto& key : keys) keyPointers.push_back(key.c_str());
            if (!vtable_->initializeInstance(instance_, instanceId, keyPointers.data(),
                                             static_cast<std::uint32_t>(keyPointers.size()))) {
                throw std::runtime_error("In-process provider '" + processKey_ + "' failed to initialize an instance: " +
                    std::string(vtable_->lastError(instance_)));
            }
        }
        pendingInstances_.clear();
    }

    std::vector<std::pair<std::uint64_t, double>> evaluateBatch(
        std::uint64_t sequence, double simulationTime, double stepSize,
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>& evaluations) override {
        static_cast<void>(sequence);
        // There is no IPC to serialize here, but user-authored provider code is not guaranteed
        // thread-safe (e.g. it may hold mutable member state a real relationship implementation
        // updates across calls); matching the concurrency guarantee the other two backends
        // already give such code, calls stay serialized here too rather than silently imposing
        // a new thread-safety requirement on existing provider implementations.
        std::lock_guard<std::mutex> lock(mutex_);
        std::vector<std::pair<std::uint64_t, double>> results;
        results.reserve(evaluations.size());
        for (const auto& [instanceId, inputs] : evaluations) {
            double value = 0;
            if (!vtable_->evaluateInstance(instance_, instanceId, simulationTime, stepSize,
                                           inputs.data(), static_cast<std::uint32_t>(inputs.size()), &value)) {
                throw std::runtime_error("In-process provider '" + processKey_ + "' evaluation failed: " +
                    std::string(vtable_->lastError(instance_)));
            }
            results.emplace_back(instanceId, value);
        }
        return results;
    }

    void shutdown() noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        unload();
    }

private:
    void loadLibrary(const std::string& path) {
#ifdef _WIN32
        handle_ = ::LoadLibraryA(path.c_str());
        if (!handle_) throw std::runtime_error("Failed to load in-process provider library '" + path + "'.");
        auto entryPoint = reinterpret_cast<KonjugateInProcessProviderV1Fn>(
            ::GetProcAddress(handle_, kKonjugateInProcessProviderEntryPoint));
#else
        handle_ = ::dlopen(path.c_str(), RTLD_LOCAL | RTLD_NOW);
        if (!handle_) {
            throw std::runtime_error("Failed to load in-process provider library '" + path + "': " +
                std::string(::dlerror()));
        }
        auto entryPoint = reinterpret_cast<KonjugateInProcessProviderV1Fn>(
            ::dlsym(handle_, kKonjugateInProcessProviderEntryPoint));
#endif
        if (!entryPoint) {
            unloadLibrary();
            throw std::runtime_error("In-process provider library '" + path + "' is missing its entry point.");
        }
        vtable_ = entryPoint();
        if (!vtable_) {
            unloadLibrary();
            throw std::runtime_error("In-process provider library '" + path + "' returned a null vtable.");
        }
    }

    void unloadLibrary() noexcept {
#ifdef _WIN32
        if (handle_) { ::FreeLibrary(handle_); handle_ = nullptr; }
#else
        if (handle_) { ::dlclose(handle_); handle_ = nullptr; }
#endif
        vtable_ = nullptr;
    }

    void unload() noexcept {
        if (instance_ && vtable_) {
            vtable_->shutdownProvider(instance_);
            vtable_->destroy(instance_);
            instance_ = nullptr;
        }
        unloadLibrary();
    }

    std::string processKey_;
    const KonjugateInProcessProviderV1* vtable_ = nullptr;
    void* instance_ = nullptr;
#ifdef _WIN32
    HMODULE handle_ = nullptr;
#else
    void* handle_ = nullptr;
#endif
    std::vector<std::pair<std::uint64_t, std::vector<std::string>>> pendingInstances_;
    std::mutex mutex_;
};

// The node-shaped counterpart to InProcessProviderBackend above: same dlopen()/LoadLibrary()
// mechanism, same "no crash isolation, opt-in only" tradeoff (see providerInProcessAbi.hpp and
// docs/providerExecution.md), but drives KonjugateInProcessNodeProviderV1 (N inputs, M named
// outputs, optional checkpoint/restore) instead of the relationship-shaped V1 -- overriding
// evaluateNode/requestCheckpoint/requestRestore rather than evaluateBatch.
class InProcessNodeProviderBackend final : public ProviderBackend {
public:
    InProcessNodeProviderBackend(std::string processKey, std::string libraryPath, const ProviderConfiguration& config)
        : processKey_(std::move(processKey)) {
        static_cast<void>(config);
        loadLibrary(libraryPath);
        instance_ = vtable_->create();
        if (!instance_) {
            const std::string message = vtable_->lastError(nullptr);
            unloadLibrary();
            throw std::runtime_error("Failed to construct in-process computational-node provider '" + processKey_ + "': " + message);
        }
    }

    ~InProcessNodeProviderBackend() override { unload(); }

    void addInstance(std::uint64_t instanceId, const std::vector<CompiledBinding>& bindings) override {
        std::vector<std::string> keys;
        keys.reserve(bindings.size());
        for (const auto& binding : bindings) keys.push_back(binding.symbol);
        pendingInstances_.emplace_back(instanceId, std::move(keys));
    }

    void sendInitialization() override {
        for (const auto& [instanceId, keys] : pendingInstances_) {
            std::vector<const char*> keyPointers;
            keyPointers.reserve(keys.size());
            for (const auto& key : keys) keyPointers.push_back(key.c_str());
            if (!vtable_->initializeInstance(instance_, instanceId, keyPointers.data(),
                                             static_cast<std::uint32_t>(keyPointers.size()))) {
                throw std::runtime_error("In-process computational-node provider '" + processKey_ + "' failed to initialize an instance: " +
                    std::string(vtable_->lastError(instance_)));
            }
        }
        pendingInstances_.clear();
    }

    std::vector<std::pair<std::uint64_t, double>> evaluateBatch(
        std::uint64_t, double, double,
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>&) override {
        throw std::runtime_error("In-process computational-node provider '" + processKey_ + "' does not support relationship-shaped batch evaluation.");
    }

    std::vector<std::pair<std::string, double>> evaluateNode(
        std::uint64_t instanceId, double simulationTime, double stepSize, std::span<const double> inputs) override {
        std::lock_guard<std::mutex> lock(mutex_);
        if (outputKeys_.empty()) cacheOutputKeys();
        std::vector<double> outValues(outputKeys_.size(), 0.0);
        if (!vtable_->evaluateInstance(instance_, instanceId, simulationTime, stepSize,
                                       inputs.data(), static_cast<std::uint32_t>(inputs.size()),
                                       outValues.data(), static_cast<std::uint32_t>(outValues.size()))) {
            throw std::runtime_error("In-process computational-node provider '" + processKey_ + "' evaluation failed: " +
                std::string(vtable_->lastError(instance_)));
        }
        std::vector<std::pair<std::string, double>> results;
        results.reserve(outputKeys_.size());
        for (std::size_t index = 0; index < outputKeys_.size(); ++index) results.emplace_back(outputKeys_[index], outValues[index]);
        return results;
    }

    std::vector<std::byte> requestCheckpoint(std::uint64_t instanceId) override {
        std::lock_guard<std::mutex> lock(mutex_);
        std::uint32_t size = 0;
        if (!vtable_->requestCheckpoint(instance_, instanceId, nullptr, 0, &size)) {
            throw std::runtime_error("In-process computational-node provider '" + processKey_ + "' declined checkpointing: " +
                std::string(vtable_->lastError(instance_)));
        }
        std::vector<std::uint8_t> buffer(size);
        std::uint32_t written = 0;
        if (!vtable_->requestCheckpoint(instance_, instanceId, buffer.data(), static_cast<std::uint32_t>(buffer.size()), &written)) {
            throw std::runtime_error("In-process computational-node provider '" + processKey_ + "' failed to fill its checkpoint buffer: " +
                std::string(vtable_->lastError(instance_)));
        }
        std::vector<std::byte> result(written);
        std::memcpy(result.data(), buffer.data(), written);
        return result;
    }

    void requestRestore(std::uint64_t instanceId, std::span<const std::byte> payload) override {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!vtable_->requestRestore(instance_, instanceId,
                                     reinterpret_cast<const std::uint8_t*>(payload.data()),
                                     static_cast<std::uint32_t>(payload.size()))) {
            throw std::runtime_error("In-process computational-node provider '" + processKey_ + "' failed to restore from a checkpoint: " +
                std::string(vtable_->lastError(instance_)));
        }
    }

    void shutdown() noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        unload();
    }

private:
    void cacheOutputKeys() {
        const auto count = vtable_->outputCount(instance_);
        outputKeys_.reserve(count);
        for (std::uint32_t index = 0; index < count; ++index) outputKeys_.emplace_back(vtable_->outputKey(instance_, index));
    }

    void loadLibrary(const std::string& path) {
#ifdef _WIN32
        handle_ = ::LoadLibraryA(path.c_str());
        if (!handle_) throw std::runtime_error("Failed to load in-process computational-node provider library '" + path + "'.");
        auto entryPoint = reinterpret_cast<KonjugateInProcessNodeProviderV1Fn>(
            ::GetProcAddress(handle_, kKonjugateInProcessNodeProviderEntryPoint));
#else
        handle_ = ::dlopen(path.c_str(), RTLD_LOCAL | RTLD_NOW);
        if (!handle_) {
            throw std::runtime_error("Failed to load in-process computational-node provider library '" + path + "': " +
                std::string(::dlerror()));
        }
        auto entryPoint = reinterpret_cast<KonjugateInProcessNodeProviderV1Fn>(
            ::dlsym(handle_, kKonjugateInProcessNodeProviderEntryPoint));
#endif
        if (!entryPoint) {
            unloadLibrary();
            throw std::runtime_error("In-process computational-node provider library '" + path + "' is missing its entry point.");
        }
        vtable_ = entryPoint();
        if (!vtable_) {
            unloadLibrary();
            throw std::runtime_error("In-process computational-node provider library '" + path + "' returned a null vtable.");
        }
    }

    void unloadLibrary() noexcept {
#ifdef _WIN32
        if (handle_) { ::FreeLibrary(handle_); handle_ = nullptr; }
#else
        if (handle_) { ::dlclose(handle_); handle_ = nullptr; }
#endif
        vtable_ = nullptr;
    }

    void unload() noexcept {
        if (instance_ && vtable_) {
            vtable_->shutdownProvider(instance_);
            vtable_->destroy(instance_);
            instance_ = nullptr;
        }
        unloadLibrary();
    }

    std::string processKey_;
    const KonjugateInProcessNodeProviderV1* vtable_ = nullptr;
    void* instance_ = nullptr;
#ifdef _WIN32
    HMODULE handle_ = nullptr;
#else
    void* handle_ = nullptr;
#endif
    std::vector<std::pair<std::uint64_t, std::vector<std::string>>> pendingInstances_;
    std::vector<std::string> outputKeys_;
    std::mutex mutex_;
};

#ifdef __EMSCRIPTEN__
extern "C" {
// Synchronous call into JS: Module.evaluatePythonProviderBridge (src/webPythonProviderBridge.mjs)
// dispatches to a Pyodide-backed interpreter and returns before this call returns, since Pyodide
// code execution (once loaded) is itself synchronous from JS's point of view. The returned
// buffer is malloc'd on the JS side (via _malloc/stringToUTF8) and must be freed by the caller.
EM_JS(char*, wasmDispatchPythonProviderRequest, (const char* requestJson), {
    const request = UTF8ToString(requestJson);
    let responseJson;
    try {
        if (typeof Module.evaluatePythonProviderBridge !== 'function') {
            throw new Error('The Python provider bridge is not available in this build.');
        }
        responseJson = Module.evaluatePythonProviderBridge(request);
    } catch (error) {
        responseJson = JSON.stringify({
            ok: false, code: 'bridgeFailure',
            message: (error && error.message) ? String(error.message) : String(error),
            fatal: true
        });
    }
    const length = lengthBytesUTF8(responseJson) + 1;
    const buffer = _malloc(length);
    stringToUTF8(responseJson, buffer, length);
    return buffer;
});
}

// The web edition's Python-provider transport (docs/proposals/webEdition.md, phase 4): there is
// no OS process to fork into inside a browser tab, so this calls directly into a Pyodide-backed
// interpreter running in the same JS context as the engine, via the synchronous EM_JS call
// above, instead of PipeProviderBackend's fork+pipe+protobuf transport. The wire shape here is
// plain JSON (not protobuf) -- see engine/sdk/python/konjugate/_webBridge.py for the other side
// of this exact contract; it reuses __main__.py's own per-message handlers unchanged, so
// behavior matches the native pipe transport exactly, just without the process/framing overhead.
// C++ providers are entirely unaffected: createProviderBackend only ever routes non-cppProvider
// (i.e. python) tasks here.
//
// boost::property_tree's JSON writer quotes every leaf value as a string (it has no numeric
// type of its own) -- _webBridge.py tolerates that on its end (see its _int/_float helpers)
// rather than this class hand-rolling a numeric-aware JSON writer.
class WasmPyodideProviderBackend final : public ProviderBackend {
public:
    WasmPyodideProviderBackend(std::string processKey, std::string providerSource)
        : processKey_(std::move(processKey)) {
        boost::property_tree::ptree request;
        request.put("kind", "create");
        request.put("processKey", processKey_);
        request.put("source", providerSource);
        dispatch(request);
    }

    void addInstance(std::uint64_t instanceId, const std::vector<CompiledBinding>& bindings) override {
        boost::property_tree::ptree keys;
        for (const auto& binding : bindings) {
            boost::property_tree::ptree key;
            key.put_value(binding.symbol);
            keys.push_back({"", key});
        }
        boost::property_tree::ptree instance;
        instance.put("instanceId", instanceId);
        instance.add_child("inputKeys", keys);
        pendingInstances_.push_back({"", instance});
    }

    void sendInitialization() override {
        boost::property_tree::ptree request;
        request.put("kind", "initialize");
        request.put("processKey", processKey_);
        request.add_child("instances", pendingInstances_);
        dispatch(request);
        pendingInstances_.clear();
    }

    std::vector<std::pair<std::uint64_t, double>> evaluateBatch(
        std::uint64_t sequence, double simulationTime, double stepSize,
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>& evaluations) override {
        boost::property_tree::ptree request;
        request.put("kind", "evaluateBatch");
        request.put("processKey", processKey_);
        request.put("sequence", sequence);
        request.put("simulationTime", simulationTime);
        request.put("stepSize", stepSize);
        request.add_child("evaluations", encodeEvaluations(evaluations));
        const auto response = dispatch(request);
        std::vector<std::pair<std::uint64_t, double>> results;
        for (const auto& [key, item] : response.get_child("contributions")) {
            static_cast<void>(key);
            results.emplace_back(item.get<std::uint64_t>("instanceId"), item.get<double>("value"));
        }
        return results;
    }

    std::vector<std::pair<std::string, double>> evaluateNode(
        std::uint64_t instanceId, double simulationTime, double stepSize, std::span<const double> inputs) override {
        boost::property_tree::ptree request;
        request.put("kind", "evaluateNode");
        request.put("processKey", processKey_);
        request.put("sequence", 0);
        request.put("simulationTime", simulationTime);
        request.put("stepSize", stepSize);
        const std::vector<std::pair<std::uint64_t, std::span<const double>>> evaluations{{instanceId, inputs}};
        request.add_child("evaluations", encodeEvaluations(evaluations));
        const auto response = dispatch(request);
        std::vector<std::pair<std::string, double>> outputs;
        for (const auto& [key, contribution] : response.get_child("contributions")) {
            static_cast<void>(key);
            for (const auto& [outputKey, outputValue] : contribution.get_child("outputs")) {
                outputs.emplace_back(outputKey, outputValue.get_value<double>());
            }
        }
        return outputs;
    }

    std::vector<std::byte> requestCheckpoint(std::uint64_t instanceId) override {
        boost::property_tree::ptree request;
        request.put("kind", "checkpoint");
        request.put("processKey", processKey_);
        request.put("instanceId", instanceId);
        const auto response = dispatch(request);
        return decodeBase64(response.get<std::string>("payloadBase64"));
    }

    void requestRestore(std::uint64_t instanceId, std::span<const std::byte> payload) override {
        boost::property_tree::ptree request;
        request.put("kind", "restore");
        request.put("processKey", processKey_);
        request.put("instanceId", instanceId);
        request.put("payloadBase64", encodeBase64(payload));
        dispatch(request);
    }

    void shutdown() noexcept override {
        try {
            boost::property_tree::ptree request;
            request.put("kind", "shutdown");
            request.put("processKey", processKey_);
            dispatch(request);
        } catch (const std::exception& error) {
            std::cerr << "Failed to shut down web Python provider '" << processKey_ << "': " << error.what() << '\n';
        }
    }

private:
    static boost::property_tree::ptree encodeEvaluations(
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>& evaluations) {
        boost::property_tree::ptree array;
        for (const auto& [instanceId, inputs] : evaluations) {
            boost::property_tree::ptree values;
            for (double value : inputs) {
                boost::property_tree::ptree item;
                item.put_value(value);
                values.push_back({"", item});
            }
            boost::property_tree::ptree entry;
            entry.put("instanceId", instanceId);
            entry.add_child("inputs", values);
            array.push_back({"", entry});
        }
        return array;
    }

    static std::string encodeBase64(std::span<const std::byte> payload) {
        static const char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        std::string result;
        result.reserve(((payload.size() + 2) / 3) * 4);
        std::size_t index = 0;
        while (index + 3 <= payload.size()) {
            const auto b0 = static_cast<unsigned>(payload[index]);
            const auto b1 = static_cast<unsigned>(payload[index + 1]);
            const auto b2 = static_cast<unsigned>(payload[index + 2]);
            result += table[b0 >> 2];
            result += table[((b0 & 0x03) << 4) | (b1 >> 4)];
            result += table[((b1 & 0x0f) << 2) | (b2 >> 6)];
            result += table[b2 & 0x3f];
            index += 3;
        }
        const auto remaining = payload.size() - index;
        if (remaining == 1) {
            const auto b0 = static_cast<unsigned>(payload[index]);
            result += table[b0 >> 2];
            result += table[(b0 & 0x03) << 4];
            result += "==";
        } else if (remaining == 2) {
            const auto b0 = static_cast<unsigned>(payload[index]);
            const auto b1 = static_cast<unsigned>(payload[index + 1]);
            result += table[b0 >> 2];
            result += table[((b0 & 0x03) << 4) | (b1 >> 4)];
            result += table[(b1 & 0x0f) << 2];
            result += "=";
        }
        return result;
    }

    static std::vector<std::byte> decodeBase64(const std::string& encoded) {
        static const auto table = [] {
            std::array<int, 256> map{};
            map.fill(-1);
            const char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
            for (int index = 0; index < 64; ++index) map[static_cast<unsigned char>(alphabet[index])] = index;
            return map;
        }();
        std::vector<std::byte> result;
        result.reserve((encoded.size() / 4) * 3);
        int buffer = 0;
        int bits = 0;
        for (char character : encoded) {
            if (character == '=') break;
            const auto value = table[static_cast<unsigned char>(character)];
            if (value < 0) continue;
            buffer = (buffer << 6) | value;
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                result.push_back(static_cast<std::byte>((buffer >> bits) & 0xff));
            }
        }
        return result;
    }

    boost::property_tree::ptree dispatch(const boost::property_tree::ptree& request) {
        std::ostringstream requestStream;
        boost::property_tree::write_json(requestStream, request, false);
        char* responsePointer = wasmDispatchPythonProviderRequest(requestStream.str().c_str());
        const std::string responseJson(responsePointer);
        std::free(responsePointer);

        boost::property_tree::ptree response;
        std::istringstream responseStream(responseJson);
        boost::property_tree::read_json(responseStream, response);
        if (!response.get<bool>("ok", false)) {
            throw std::runtime_error("Web Python provider '" + processKey_ + "' failed: " +
                response.get<std::string>("message", "unknown error"));
        }
        return response;
    }

    std::string processKey_;
    boost::property_tree::ptree pendingInstances_;
};

extern "C" {
// Plain synchronous calls into JS, exactly like wasmDispatchPythonProviderRequest above -- unlike
// that first attempt at this (an earlier revision of this file tried to spawn the compiled
// provider as a live Wasmer-hosted OS process, which needs a genuinely async bridge since
// @wasmer/sdk's process stdin/stdout are real Promise-based Streams), the web edition's C++
// provider (see src/webCppProviderBridge.mjs) is instead a WASI-exports build of the SAME
// engine/src/providerWorker.cpp glue file PipeProviderBackend spawns natively (see that file's
// own __wasi__-gated section), instantiated directly via WebAssembly.instantiate() and called
// through its exported functions -- there is no process, no Stream, and therefore no async
// boundary left at evaluation time: compiling that module (the only genuinely async step, since
// it needs a real clang fetched from Wasmer's registry) happens entirely ahead of callMain(), in
// webEngineAdapter.mjs's ensureCppProvidersReady(); everything below runs after that, fully
// synchronously.
//
// A JS-side bridge failure (an unknown processKey, an exception constructing/calling the
// instance) is signaled by returning a null pointer / *outResponseLength == 0, deliberately not
// by throwing across the EM_JS boundary (matching wasmDispatchPythonProviderRequest's own
// defensive style, which returns a JSON {ok:false} value rather than relying on a thrown JS
// error surviving the crossing into a C++ exception) -- zero bytes never occurs for a real
// protocol response (every dispatchMessage() response wraps at least a field tag), so it is an
// unambiguous sentinel here.
EM_JS(unsigned char*, wasmDispatchCppProviderRequest,
      (const char* processKey, const unsigned char* requestBytes, int requestLength, int* outResponseLength), {
    const key = UTF8ToString(processKey);
    const request = HEAPU8.slice(requestBytes, requestBytes + requestLength);
    let response;
    try {
        if (typeof Module.dispatchCppProviderBridge !== 'function') {
            throw new Error('This web build has no C++ provider bridge installed.');
        }
        response = Module.dispatchCppProviderBridge(key, request);
    } catch (error) {
        console.error(`Web C++ provider '${key}' bridge failure:`, error);
        response = null;
    }
    if (!response || response.length === 0) {
        HEAP32[outResponseLength >> 2] = 0;
        return 0;
    }
    const buffer = _malloc(response.length);
    HEAPU8.set(response, buffer);
    HEAP32[outResponseLength >> 2] = response.length;
    return buffer;
});

// The one-time counterpart to wasmDispatchCppProviderRequest above: hands the provider's raw C++
// source text to the JS bridge, which compiles (if not already cached for this exact source) and
// instantiates it, then calls its konjugateProviderCreate() export -- see
// engine/src/providerWorker.cpp's __wasi__-gated section and src/webCppProviderBridge.mjs. Also
// signals failure via a null return rather than a thrown JS error, for the same reason as above.
EM_JS(char*, wasmRegisterCppProvider, (const char* processKey, const char* sourceUtf8), {
    const key = UTF8ToString(processKey);
    const source = UTF8ToString(sourceUtf8);
    let errorMessage = null;
    try {
        if (typeof Module.registerCppProviderBridge !== 'function') {
            throw new Error('This web build has no C++ provider bridge installed.');
        }
        Module.registerCppProviderBridge(key, source);
    } catch (error) {
        errorMessage = String(error?.message ?? error);
    }
    if (errorMessage === null) return 0;
    const length = lengthBytesUTF8(errorMessage) + 1;
    const buffer = _malloc(length);
    stringToUTF8(errorMessage, buffer, length);
    return buffer;
});
}

// The web edition's C++-provider transport (docs/proposals/webEdition.md, phase 5): a copy of
// engine/src/providerWorker.cpp -- the SAME glue file PipeProviderBackend spawns natively -- is
// compiled to a WASI-exports build (see that file's own __wasi__-gated section) and instantiated
// directly via WebAssembly.instantiate() instead (see src/webCppProviderBridge.mjs), speaking the
// exact same framed-protobuf wire format ProviderControlChannel builds above; only the transport
// differs (a direct synchronous export call instead of a pipe fd), not the protocol -- so this
// class's message-building intentionally mirrors ProviderControlChannel's/PipeProviderBackend's
// own methods field-for-field.
//
// createProviderBackend only ever routes relationship-shaped (isNodeShaped == false) cppProvider
// tasks here: node-shaped C++ providers have no worker-process protocol support even natively
// (see createProviderBackend's own comment on WasmPyodideProviderBackend above) and fail clearly
// instead, matching that existing native limitation rather than inventing new behavior for the
// web build.
class WasmCppProviderBackend final : public ProviderBackend {
public:
    WasmCppProviderBackend(std::string processKey, const std::string& providerSource)
        : processKey_(std::move(processKey)) {
        // Registers this process's source with the JS bridge (compiles it once, on demand, and
        // instantiates the resulting WASI-exports module -- see
        // src/webCppProviderBridge.mjs) before anything else talks to it.
        char* errorPointer = wasmRegisterCppProvider(processKey_.c_str(), providerSource.c_str());
        if (errorPointer) {
            const std::string message(errorPointer);
            std::free(errorPointer);
            throw std::runtime_error("Failed to prepare web C++ provider '" + processKey_ + "': " + message);
        }

        EngineToProvider handshake;
        auto* h = handshake.mutable_handshake();
        h->set_protocol_version(1);
        h->set_provider_api_version(1);
        const auto resp = dispatch(handshake);
        if (!resp.has_handshake()) {
            throw std::runtime_error("Unexpected response to handshake from web C++ provider '" + processKey_ + "'");
        }
    }

    void addInstance(std::uint64_t instanceId, const std::vector<CompiledBinding>& bindings) override {
        auto* inst = initializeReq_.add_instances();
        inst->set_instance_id(instanceId);
        for (const auto& binding : bindings) inst->add_input_keys(binding.symbol);
    }

    void sendInitialization() override {
        if (initializeReq_.instances_size() == 0) return;
        EngineToProvider msg;
        *msg.mutable_initialize() = initializeReq_;
        const auto resp = dispatch(msg);
        if (!resp.has_initialize()) {
            throw std::runtime_error("Unexpected response to initialization from web C++ provider '" + processKey_ + "'");
        }
    }

    std::vector<std::pair<std::uint64_t, double>> evaluateBatch(
        std::uint64_t sequence, double simulationTime, double stepSize,
        const std::vector<std::pair<std::uint64_t, std::span<const double>>>& evaluations) override {
        // Mirrors PipeProviderBackend::evaluateBatch's own locking: multiple relationship
        // instances sharing this process may be evaluated from different execution-plan threads
        // in the same synchronization step, and the bridge round trip is not reentrant.
        std::lock_guard<std::mutex> lock(mutex_);
        EngineToProvider msg;
        auto* batch = msg.mutable_evaluate_batch();
        batch->set_sequence(sequence);
        batch->set_simulation_time(simulationTime);
        batch->set_step_size(stepSize);
        for (const auto& [instId, inputs] : evaluations) {
            auto* eval = batch->add_evaluations();
            eval->set_instance_id(instId);
            for (const auto val : inputs) eval->add_inputs(val);
        }
        const auto resp = dispatch(msg);
        if (!resp.has_evaluate_batch()) {
            throw std::runtime_error("Unexpected response to evaluateBatch from web C++ provider '" + processKey_ + "'");
        }
        std::vector<std::pair<std::uint64_t, double>> results;
        for (const auto& contrib : resp.evaluate_batch().contributions()) {
            results.emplace_back(contrib.instance_id(), contrib.value());
        }
        return results;
    }

    void shutdown() noexcept override {
        try {
            std::lock_guard<std::mutex> lock(mutex_);
            EngineToProvider msg;
            msg.mutable_shutdown();
            dispatch(msg);
        } catch (const std::exception& error) {
            std::cerr << "Failed to shut down web C++ provider '" << processKey_ << "': " << error.what() << '\n';
        }
    }

private:
    ProviderToEngine dispatch(const EngineToProvider& request) {
        std::string payload;
        if (!request.SerializeToString(&payload)) {
            throw std::runtime_error("Failed to serialize a message for web C++ provider '" + processKey_ + "'");
        }
        int responseLength = 0;
        unsigned char* responsePointer = wasmDispatchCppProviderRequest(
            processKey_.c_str(), reinterpret_cast<const unsigned char*>(payload.data()),
            static_cast<int>(payload.size()), &responseLength);
        if (!responsePointer || responseLength == 0) {
            throw std::runtime_error("The web C++ provider bridge failed for '" + processKey_ + "' (see the browser console).");
        }
        ProviderToEngine response;
        const bool parsed = response.ParseFromArray(responsePointer, responseLength);
        std::free(responsePointer);
        if (!parsed) {
            throw std::runtime_error("Failed to parse a response from web C++ provider '" + processKey_ + "'");
        }
        if (response.has_failure()) {
            throw std::runtime_error("Web C++ provider '" + processKey_ + "' failed: " + std::string(response.failure().message()));
        }
        return response;
    }

    std::string processKey_;
    InitializeRequest initializeReq_;
    std::mutex mutex_;
};
#endif

namespace {

// Each tier is only attempted for cppProvider tasks in its matching (or a higher) execution
// mode; any construction failure — including a mode simply not being available on this
// platform — falls back down the chain (inProcess -> sharedMemoryWorker -> pipeWorker) so a
// single unsupported/misconfigured host never blocks a whole run. Python providers always use
// the pipe backend: neither faster transport has a story for an interpreted language.
//
// isNodeShaped distinguishes a NodeProviderTask from a ContributionTask -- both can carry
// implementation == cppProvider, but they need different artifacts (a node-shaped shim exports a
// different ABI/entry point, see providerInProcessNodeShim.cpp) and different execution
// guarantees: providerWorker.cpp has no node-provider protocol handling for C++ at all (only the
// Python worker speaks those messages), so a node-shaped cpp task deliberately gets NO
// worker-process fallback chain -- it either runs in-process or fails clearly, rather than
// falling through into pipe/shared-memory code that doesn't understand it.
std::unique_ptr<ProviderBackend> createProviderBackend(const std::string& key, ContributionImplementation implementation,
                                                        const std::string& providerSource, const ProviderConfiguration& config,
                                                        bool isNodeShaped) {
    if (implementation == ContributionImplementation::cppProvider && isNodeShaped) {
        if (config.executionMode != ProviderExecutionMode::inProcess) {
            throw std::runtime_error(
                "C++ computational-node provider '" + key + "' requires the in-process provider execution mode.");
        }
        const auto libraryPath = buildCppProvider(providerSource, config, CppProviderArtifactKind::nodeSharedLibrary);
        return std::make_unique<InProcessNodeProviderBackend>(key, libraryPath, config);
    }
    if (implementation == ContributionImplementation::cppProvider) {
        if (config.executionMode == ProviderExecutionMode::inProcess) {
            try {
                const auto libraryPath = buildCppProvider(providerSource, config, CppProviderArtifactKind::sharedLibrary);
                return std::make_unique<InProcessProviderBackend>(key, implementation, libraryPath, config);
            } catch (const std::exception& error) {
                std::cerr << "Falling back from the in-process provider transport for '" << key << "': " << error.what() << '\n';
            }
        }
#ifndef _WIN32
        if (config.executionMode == ProviderExecutionMode::inProcess ||
            config.executionMode == ProviderExecutionMode::sharedMemoryWorker) {
            try {
                const auto executablePath = buildCppProvider(providerSource, config, CppProviderArtifactKind::executable);
                return std::make_unique<SharedMemoryProviderBackend>(key, implementation, executablePath, config);
            } catch (const std::exception& error) {
                std::cerr << "Falling back to the pipe provider transport for '" << key << "': " << error.what() << '\n';
            }
        }
#endif
    }
#ifdef __EMSCRIPTEN__
    // A browser tab has no OS process to fork/exec a real python3 interpreter into (see
    // WasmPyodideProviderBackend's own comment above) -- python-kind tasks (relationship- or
    // node-shaped alike, matching PipeProviderBackend's own scope below) route to the Pyodide
    // bridge instead, passing providerSource directly rather than writing it to a file: there is
    // no separate process that needs a real path argument here.
    if (implementation != ContributionImplementation::cppProvider) {
        return std::make_unique<WasmPyodideProviderBackend>(key, providerSource);
    }
    // Relationship-shaped C++ providers route to the WASM/Wasmer bridge (see
    // WasmCppProviderBackend above); node-shaped ones have no worker-process protocol support
    // even natively (see this function's own header comment) and fail clearly here too, rather
    // than falling through into the native buildCppProvider()/PipeProviderBackend path below,
    // which cannot work in a browser (no host compiler, no fork/exec).
    if (!isNodeShaped) {
        return std::make_unique<WasmCppProviderBackend>(key, providerSource);
    }
    throw std::runtime_error(
        "C++ computational-node provider '" + key + "' is not supported in the web edition "
        "(no worker-process protocol for node-shaped C++ providers, even natively).");
#endif
    const auto launchPath = implementation == ContributionImplementation::cppProvider
        ? buildCppProvider(providerSource, config, CppProviderArtifactKind::executable)
        : preparePythonProviderSource(providerSource, config);
    return std::make_unique<PipeProviderBackend>(key, implementation, launchPath, config);
}

} // namespace

ProviderRuntime::ProviderRuntime(ProviderConfiguration configuration)
    : configuration_(std::move(configuration)) {}

ProviderRuntime::~ProviderRuntime() {
    shutdown();
}

void ProviderRuntime::initialize(const ExecutionPlan& plan) {
    if (initialized_) return;

    for (const auto& node : plan.nodes) {
        for (const auto& task : node.contributions) {
            if (task.implementation == ContributionImplementation::equation) continue;

            const std::string key = providerProcessKey(task);
            auto& proc = processes_[key];
            if (!proc) {
                proc = createProviderBackend(key, task.implementation, task.providerSource, configuration_, false);
            }

            const std::uint64_t instanceId = nextInstanceId_++;
            taskInstanceIds_[task.sourceId] = instanceId;

            proc->addInstance(instanceId, task.bindings);
        }

        // A programmable ("sets the value") algebraic task is evaluated through the exact same
        // evaluateBatch()/providerProcessKey()/sourceId lookup path as an ordinary programmable
        // contribution (see applyAlgebraicTasks in executionPlan.cpp) -- it must be registered
        // here identically, or its first evaluation throws "Task not registered in ProviderRuntime."
        for (const auto& task : node.algebraicTasks) {
            if (task.implementation == ContributionImplementation::equation) continue;

            const std::string key = providerProcessKey(task);
            auto& proc = processes_[key];
            if (!proc) {
                proc = createProviderBackend(key, task.implementation, task.providerSource, configuration_, false);
            }

            const std::uint64_t instanceId = nextInstanceId_++;
            taskInstanceIds_[task.sourceId] = instanceId;

            proc->addInstance(instanceId, task.bindings);
        }

        if (node.nodeProvider) {
            // NOLINTNEXTLINE(bugprone-unchecked-optional-access) -- guarded by the if() directly above.
            const auto& task = *node.nodeProvider;
            const auto& key = task.providerProcessKeyCache;
            auto& proc = processes_[key];
            if (!proc) {
                proc = createProviderBackend(key, task.implementation, task.providerSource, configuration_, true);
            }

            const std::uint64_t instanceId = nextInstanceId_++;
            // Safe to share this EntityId-keyed map with edge/source-term sourceId entries above:
            // docs/projectSchema.md guarantees ids are unique across nodes, states, source terms,
            // edges, parameters and run configurations project-wide.
            taskInstanceIds_[task.nodeId] = instanceId;

            proc->addInstance(instanceId, task.bindings);
        }
    }

    for (auto& [key, proc] : processes_) {
        proc->sendInitialization();
    }

    initialized_ = true;
}

std::vector<std::pair<std::string, double>> ProviderRuntime::evaluateNode(
    const NodeProviderTask& task, std::span<const double> inputs, double simulationTime, double stepSize) {
    const auto processIt = processes_.find(task.providerProcessKeyCache);
    if (processIt == processes_.end()) {
        throw std::runtime_error("Computational-node provider task not registered in ProviderRuntime.");
    }
    const auto instanceIt = taskInstanceIds_.find(task.nodeId);
    if (instanceIt == taskInstanceIds_.end()) {
        throw std::runtime_error("Computational-node provider task not registered in ProviderRuntime.");
    }
    return processIt->second->evaluateNode(instanceIt->second, simulationTime, stepSize, inputs);
}

std::vector<std::byte> ProviderRuntime::requestNodeCheckpoint(const NodeProviderTask& task) {
    const auto processIt = processes_.find(task.providerProcessKeyCache);
    if (processIt == processes_.end()) {
        throw std::runtime_error("Computational-node provider task not registered in ProviderRuntime.");
    }
    const auto instanceIt = taskInstanceIds_.find(task.nodeId);
    if (instanceIt == taskInstanceIds_.end()) {
        throw std::runtime_error("Computational-node provider task not registered in ProviderRuntime.");
    }
    return processIt->second->requestCheckpoint(instanceIt->second);
}

void ProviderRuntime::requestNodeRestore(const NodeProviderTask& task, std::span<const std::byte> payload) {
    const auto processIt = processes_.find(task.providerProcessKeyCache);
    if (processIt == processes_.end()) {
        throw std::runtime_error("Computational-node provider task not registered in ProviderRuntime.");
    }
    const auto instanceIt = taskInstanceIds_.find(task.nodeId);
    if (instanceIt == taskInstanceIds_.end()) {
        throw std::runtime_error("Computational-node provider task not registered in ProviderRuntime.");
    }
    processIt->second->requestRestore(instanceIt->second, payload);
}

std::vector<double> ProviderRuntime::evaluateBatch(const std::vector<const ContributionTask*>& tasks,
                                                    const std::vector<std::span<const double>>& inputs,
                                                    double simulationTime,
                                                    double stepSize) {
    if (tasks.empty()) return {};
    if (tasks.size() != inputs.size()) {
        throw std::runtime_error("A provider batch evaluation received mismatched tasks and inputs.");
    }

    const auto& key = providerProcessKey(*tasks.front());
    auto processIt = processes_.find(key);
    if (processIt == processes_.end()) {
        throw std::runtime_error("Task not registered in ProviderRuntime.");
    }
    auto& proc = processIt->second;

    // Spans, not copies: every backend only ever reads these values (serializing them onto a
    // pipe/into shared memory/straight into a C-ABI call), and inputs outlives this whole call,
    // so there is no need to heap-allocate a fresh vector per task just to hand it downstream.
    std::vector<std::pair<std::uint64_t, std::span<const double>>> evaluations;
    evaluations.reserve(tasks.size());
    for (std::size_t index = 0; index < tasks.size(); ++index) {
        const auto* task = tasks[index];
        // Every task passed to a single call is expected to share the same provider process;
        // evaluateContributionTasks groups them that way before calling in, and re-deriving the
        // key here is cheap insurance against a future caller breaking that invariant.
        if (providerProcessKey(*task) != key) {
            throw std::runtime_error("A provider batch evaluation mixed tasks from different provider processes.");
        }
        const auto instIt = taskInstanceIds_.find(task->sourceId);
        if (instIt == taskInstanceIds_.end()) {
            throw std::runtime_error("Task not registered in ProviderRuntime.");
        }
        evaluations.emplace_back(instIt->second, inputs[index]);
    }

    const auto results = proc->evaluateBatch(tasks.front()->sequence, simulationTime, stepSize, evaluations);
    if (results.size() != tasks.size()) {
        throw std::runtime_error("A provider process returned a different number of contributions than requested.");
    }

    // Every backend returns results in the same order the evaluations were submitted (the pipe
    // worker and the shared-memory eval loop both process their request slots in order;
    // InProcessProviderBackend iterates evaluations directly), so results can be zipped back to
    // tasks positionally rather than reassociated through a per-call hash map. The instance-id
    // check below is cheap insurance against a future backend breaking that invariant, not a
    // reason to keep the O(n) map around for the common case.
    std::vector<double> ordered;
    ordered.reserve(tasks.size());
    for (std::size_t index = 0; index < results.size(); ++index) {
        if (results[index].first != evaluations[index].first) {
            throw std::runtime_error("A provider process returned contributions out of the requested order.");
        }
        ordered.push_back(results[index].second);
    }
    return ordered;
}

void ProviderRuntime::shutdown() noexcept {
    if (shutdown_) return;
    shutdown_ = true;
    for (auto& [key, proc] : processes_) {
        if (proc) proc->shutdown();
    }
    processes_.clear();
}

bool planRequiresProviders(const ExecutionPlan& plan) {
    for (const auto& node : plan.nodes) {
        if (node.nodeProvider) return true;
        for (const auto& task : node.contributions) {
            if (task.implementation != ContributionImplementation::equation) return true;
        }
        for (const auto& task : node.algebraicTasks) {
            if (task.implementation != ContributionImplementation::equation) return true;
        }
    }
    return false;
}

} // namespace konjugate
