/* Copyright © 2026 Zenin Easa Panthakkalakath */

#pragma once

#include <boost/property_tree/ptree.hpp>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <limits>
#include <memory>
#include <span>
#include <stdexcept>
#include <unordered_map>
#include <utility>
#include <vector>

namespace konjugate {

using EntityId = std::uint64_t;
using EntityValues = std::unordered_map<EntityId, double>;
using StateValues = std::vector<double>;
using NodeParameterValues = std::vector<std::vector<double>>;

enum class ExpressionOperation {
    literal,
    symbol,
    add,
    multiply,
    negate,
    divide,
    power,
    squareRoot,
    absolute,
    exponential,
    logarithm,
    sine,
    cosine,
    tangent,
    arcsine,
    arccosine,
    arctangent,
    // Arctan2(y, x): the angle of the point (x, y), from -pi to pi.
    arctangent2,
    hyperbolicTangent,
    minimum,
    maximum,
    // Piecewise support: MathJSON "Which" (LaTeX \begin{cases}) plus the comparisons and logic
    // its conditions are built from. Comparisons and logic evaluate to 1 or 0; the validator only
    // allows them in condition positions, so they never leak into a numeric result.
    conditional,
    less,
    lessEqual,
    greater,
    greaterEqual,
    equal,
    notEqual,
    logicalAnd,
    logicalOr,
    logicalNot
};

struct CompiledExpression {
    ExpressionOperation operation = ExpressionOperation::literal;
    double literal = 0;
    std::string symbol;
    std::size_t symbolIndex = std::numeric_limits<std::size_t>::max();
    std::vector<CompiledExpression> arguments;

    double evaluate(const std::vector<double>& symbols) const;
    std::size_t operationCount() const noexcept;
};

// simulationTime: an equation's time binding ({ kind: "time" }) -- the substep's start time for a
// differential contribution, its end time for an algebraic (setsValue) one.
enum class BindingSource { localState, synchronizationSnapshot, parameter, simulationTime };
enum class ContributionImplementation { equation, cppProvider, pythonProvider };

struct CompiledBinding {
    std::string symbol;
    BindingSource source = BindingSource::localState;
    EntityId valueId = 0;
    std::size_t valueIndex = std::numeric_limits<std::size_t>::max();
    std::size_t parameterIndex = std::numeric_limits<std::size_t>::max();
};

struct ParameterSchedule;

struct CompiledParameter {
    EntityId id = 0;
    double value = 0;
    bool live = false;
    // The id live overrides and schedules are keyed by. Equal to `id` for an ordinary parameter;
    // for one linked to a project-level shared parameter it is that shared parameter's id, so a
    // single control value reaches every relationship that links to it.
    EntityId controlId = 0;
    // A shared parameter's stored schedule (sharedParameters[].schedule, docs/projectSchema.md):
    // the parameter's own value then follows this series over simulation time instead of being a
    // constant. Live overrides and recorded interventions still take precedence over it, exactly as
    // they do over a constant value. Shared, since every parameter linked to the same shared one
    // compiles to the same schedule.
    std::shared_ptr<const ParameterSchedule> schedule = nullptr;
};

// A recorded, timestamped intervention (docs/resultExploration.md's "Parameter interventions"),
// distinct from RunControl::parameterValues' instantaneous overrides: the parameter's effective
// value becomes a function of simulationTime rather than a single most-recently-set scalar. When
// more than one schedule exists for the same parameter (a later intervention layered onto an
// earlier one), the one with the latest startTime that has already begun governs -- see
// resolveParameterValues' selection logic in executionPlan.cpp.
struct ParameterSchedule {
    enum class Mode { step, ramp, pulse, piecewise };
    EntityId parameterId = 0;
    Mode mode = Mode::step;
    double startTime = 0;
    // Ramp: time to reach targetValue. Pulse: width of the pulse. Unused for step/piecewise.
    double duration = 0;
    // Step/ramp/pulse target; ignored for piecewise.
    double targetValue = 0;
    // Ramp's starting value and pulse's outside-the-window value.
    double baseValue = 0;
    // Piecewise only: explicit, chronologically sorted {time, value} points, linearly
    // interpolated and edge-held outside their range (the same convention as
    // src/providerTemplate.mjs's replayProviderSource()).
    std::vector<std::pair<double, double>> samples;
    // Piecewise only: hold each sample's value until the next sample's time (a staircase) rather
    // than interpolating -- for a series of per-period rates, such as a daily volume, whose total
    // over each period must be kept.
    bool hold = false;
};

double evaluateParameterSchedule(const ParameterSchedule& schedule, double simulationTime);

struct ContributionTask {
    std::size_t sequence = 0;
    EntityId sourceId = 0;
    EntityId outputStateId = 0;
    std::size_t outputStateIndex = std::numeric_limits<std::size_t>::max();
    std::vector<CompiledBinding> bindings;
    std::vector<CompiledParameter> parameters;
    CompiledExpression expression;
    ContributionImplementation implementation = ContributionImplementation::equation;
    std::string providerSource;
    std::string providerOutputKey;
    // Precomputed once by bindTask() at plan-compile time: providerProcessKey() used to
    // concatenate "cpp:"/"py:" with the entire inline source text on every single evaluation
    // call, which is invisible next to an IPC round trip but was measurable overhead in its
    // own right once nothing else dominates (e.g. the in-process transport). Empty for
    // equation tasks, which never call providerProcessKey().
    std::string providerProcessKeyCache;
    // True for the complementary contribution a bidirectional edge applies to its other
    // endpoint: the same computed value, sign-flipped, since what leaves one node enters the
    // other. False for every other contribution (source terms, directed edges, and a
    // bidirectional edge's own primary output).
    bool negateOutput = false;
};

// Contributions sharing the same (implementation, providerSource) run in the same worker
// process/library, so callers group tasks by this key before batching them into one
// evaluateBatch call rather than one round trip per contribution.
const std::string& providerProcessKey(const ContributionTask& task);

struct NodeProviderOutputBinding {
    std::string key;
    EntityId stateId = 0;
    std::size_t stateIndex = std::numeric_limits<std::size_t>::max();
    // Mirrors a source term's own setsValue (see NodeExecutionPlan::algebraicTasks and
    // docs/projectSchema.md's setsValue paragraph): by default an output's returned number is a
    // derivative, folded additively into its target state like any other contribution. When true,
    // the engine instead writes that same number directly into the target state every substep -- a
    // plain replacement, never integrated -- after the substep's contributions have been evaluated,
    // so they read the value from before it. The provider is evaluated once per substep, at its start
    // time t with step h, and a setsValue output is its value at t + h: a co-simulation step (advance
    // over [t, t + h] on inputs read at t, then report), as an imported FMU's fmi2DoStep is. The node
    // then records it beside its other states at t + h. Unlike a setsValue source term, it is not
    // recomputed after the step's last update or settled before the first step (either would call the
    // provider again for an interval it has already advanced over): a node's initial value for such a
    // state is its value at the start. This makes it a genuine algebraic state rather than the
    // Euler-specific pseudo-derivative trick FMI import used before this field existed (see
    // src/fmiResolver.mjs). No SDK change: NodeOutputCollector::addGradient's value is reinterpreted
    // exactly like a source term's addGradient value is.
    bool setsValue = false;
};

// Owns ALL the dynamics of one node, unlike ContributionTask which owns one scalar derivative
// into one state: evaluated once per substep, returns N named outputs (one per declared output),
// each either folded additively into its own target state as a derivative, or -- when that
// output's binding has setsValue set -- written directly into its target state as a genuine
// algebraic value. A node has at most one of these. Python-only for now (see providerRuntime.cpp);
// implementation is retained (rather than assumed) so a future C++ node-provider slice only has
// to add a branch here, not a new field.
struct NodeProviderTask {
    EntityId nodeId = 0;
    ContributionImplementation implementation = ContributionImplementation::pythonProvider;
    std::string providerSource;
    std::string providerProcessKeyCache; // "py:" + providerSource, same scheme as ContributionTask
    // This node's own states (read as the node advances, like a source term's), other nodes'
    // states (read from the step's synchronization snapshot, like an edge's), or project-level
    // shared parameters (a node has no parameters of its own), each one entry of `parameters`.
    std::vector<CompiledBinding> bindings;
    // The shared parameters the bindings read, one each however many bindings read it: live
    // values, stored schedules and recorded interventions reach them as they reach any parameter.
    std::vector<CompiledParameter> parameters;
    std::vector<NodeProviderOutputBinding> outputs; // N named outputs -> this node's own states
};

class ProviderEvaluator {
public:
    virtual ~ProviderEvaluator() = default;
    // Every task in a single call must share the same providerProcessKey(); the caller
    // (evaluateContributionTasks) is responsible for grouping them that way. Results are
    // returned in the same order as tasks/inputs.
    virtual std::vector<double> evaluateBatch(const std::vector<const ContributionTask*>& tasks,
                                              const std::vector<std::span<const double>>& inputs,
                                              double simulationTime,
                                              double stepSize) = 0;

    // Throwing defaults, not pure virtual: existing ProviderEvaluator doubles (tests, the
    // benchmark harness) that never exercise computational-node providers need not implement
    // these. A real caller only reaches them when a plan actually contains a NodeProviderTask.
    virtual std::vector<std::pair<std::string, double>> evaluateNode(
        const NodeProviderTask&, std::span<const double> inputs, double simulationTime, double stepSize) {
        static_cast<void>(inputs);
        static_cast<void>(simulationTime);
        static_cast<void>(stepSize);
        throw std::runtime_error("This provider evaluator does not support computational-node providers.");
    }
    virtual std::vector<std::byte> requestNodeCheckpoint(const NodeProviderTask&) {
        throw std::runtime_error("This provider evaluator does not support computational-node checkpointing.");
    }
    virtual void requestNodeRestore(const NodeProviderTask&, std::span<const std::byte>) {
        throw std::runtime_error("This provider evaluator does not support computational-node restore.");
    }
};

struct NodeExecutionPlan {
    EntityId nodeId = 0;
    std::size_t substeps = 1;
    // numerics.integration "semiImplicit": within each substep the node's states are updated one
    // after another in the order the node lists them, each from contributions evaluated with the
    // states already updated before it (so a position listed after its speed moves with the new
    // speed: semi-implicit, or symplectic, Euler). Otherwise every state is updated together from
    // the substep's starting values (explicit Euler).
    bool semiImplicit = false;
    std::vector<EntityId> stateIds;
    std::vector<std::size_t> stateIndexes;
    std::vector<ContributionTask> contributions;
    // Source terms authored as "sets the value" rather than "updates the derivative" -- a genuine
    // algebraic state (in the Differential-Algebraic-Equation sense), never integrated via any
    // solver's update rule. Stored in dependency-resolved order (an algebraic task may bind
    // another algebraic task's own output state, e.g. "y = 2x, z = y + 1" -- z's task follows y's
    // here) so applyAlgebraicTasks() can evaluate them once, in this order, before any ordinary
    // (differential) contribution in the same substep, with each write immediately visible to
    // whatever comes after it. Never contains edges (edges always contribute a derivative) --
    // see docs/projectSchema.md's `setsValue` paragraph and
    // docs/proposals/causalInferenceInputReplay.md for why this needs to be a genuinely
    // recomputed-fresh value rather than a solver-specific derivative trick.
    std::vector<ContributionTask> algebraicTasks;
    std::optional<NodeProviderTask> nodeProvider;
    std::size_t estimatedOperationsPerSubstep = 0;
    // True when any parameter of this node's tasks follows a stored schedule, so its values are
    // re-resolved every substep (as they are while an intervention is recorded).
    bool hasParameterSchedules = false;
};

// An algebraic relationship: an edge whose equations set states of its two endpoints (rather than
// adding a rate to one), with named intermediate quantities (definitions) its equations may share.
// See docs/projectSchema.md. Every state is read from the plan's whole state vector: all algebraic
// relationships are evaluated together at each synchronization instant, in dependency order, so a
// chain of them across many nodes settles within the instant.
struct AlgebraicRelationship {
    EntityId edgeId = 0;
    // States (source synchronizationSnapshot, valueIndex the plan's index), parameters and time.
    std::vector<CompiledBinding> bindings;
    std::vector<CompiledParameter> parameters;
    // Each reads the bindings (symbols 0 .. bindings.size() - 1) and earlier definitions (symbol
    // bindings.size() + k for definition k).
    std::vector<CompiledExpression> definitions;
};

// One equation of an algebraic relationship: its value is added to its state, which every
// algebraic relationship writing it sums (and nothing else writes).
struct AlgebraicOutput {
    std::size_t relationship = 0;
    EntityId outputStateId = 0;
    std::size_t outputStateIndex = std::numeric_limits<std::size_t>::max();
    CompiledExpression expression;
    // The definitions it needs, directly or through other definitions, in ascending order.
    std::vector<std::size_t> definitions;
};

struct ExecutionPlan {
    std::vector<AlgebraicRelationship> algebraicRelationships;
    // In the order they are evaluated: every output writing a state comes before any output reading it.
    std::vector<AlgebraicOutput> algebraicOutputs;
    // The states algebraic relationships set, each the sum of its outputs.
    std::vector<std::size_t> algebraicStateIndexes;
    StateValues initialStates;
    std::unordered_map<EntityId, EntityId> stateNodes;
    std::unordered_map<EntityId, std::size_t> stateIndexes;
    std::vector<EntityId> stateIds;
    std::vector<NodeExecutionPlan> nodes;
    std::vector<std::size_t> taskSubmissionOrder;
};

struct EvaluatedContribution {
    std::size_t sequence = 0;
    std::size_t outputStateIndex = 0;
    double value = 0;
};

ExecutionPlan compileExecutionPlan(const boost::property_tree::ptree& document);

std::vector<std::size_t> planTaskSubmissionOrder(const std::vector<NodeExecutionPlan>& nodes);

// localStates is only ever read here -- but a nodeProvider output with setsValue needs to write its
// target state directly (see NodeProviderOutputBinding::setsValue), exactly like
// applyAlgebraicTasks does. Rather than taking localStates by mutable reference (which would force
// every caller, including every existing test, to supply a named lvalue instead of a plain
// brace-init StateValues), such a write is appended to algebraicNodeProviderWrites instead -- a
// caller-supplied out-parameter, nullptr by default -- as a (stateIndex, value) pair for the caller
// to apply once this call returns, exactly how integrateNode already applies the derivatives it
// gets back from reduceContributions. A setsValue nodeProvider output encountered with a null
// algebraicNodeProviderWrites throws rather than silently discarding the write.
std::vector<EvaluatedContribution> evaluateContributionTasks(
    const NodeExecutionPlan& node,
    const StateValues& localStates,
    const StateValues& synchronizationSnapshot,
    const NodeParameterValues& parameterValues,
    double simulationTime = 0,
    double stepSize = 0,
    ProviderEvaluator* providerEvaluator = nullptr,
    std::vector<std::pair<std::size_t, double>>* algebraicNodeProviderWrites = nullptr,
    const std::vector<double>* nodeProviderParameterValues = nullptr);

// The values of a computational-node provider's parameters (NodeProviderTask::parameters) at
// simulationTime, resolved as every other parameter is: live overrides, recorded interventions and
// stored schedules first, else the shared parameter's value.
std::vector<double> resolveNodeProviderParameterValues(const NodeProviderTask& task, const EntityValues& liveParameterValues,
                                                       const std::vector<ParameterSchedule>& activeSchedules = {}, double simulationTime = 0);

// activeSchedules/simulationTime default to {}/0 so every existing call site (mostly tests
// exercising a single substep in isolation) keeps its previous flat-override-only behavior
// unchanged -- an empty schedule list can never match, so resolution falls through exactly as
// before. Only simulationRunner.cpp's main loop (via integrateNode) passes real schedules.
NodeParameterValues resolveParameterValues(const NodeExecutionPlan& node, const EntityValues& liveParameterValues,
                                            const std::vector<ParameterSchedule>& activeSchedules = {}, double simulationTime = 0);
// Shared by evaluateContributionTasks (indexed by position in node.contributions) and
// applyAlgebraicTasks (indexed by position in node.algebraicTasks) -- two structurally separate
// lists, so each needs its own resolved-values vector rather than sharing one keyed by a single
// shared index space.
NodeParameterValues resolveParameterValues(const std::vector<ContributionTask>& tasks, const EntityValues& liveParameterValues,
                                            const std::vector<ParameterSchedule>& activeSchedules = {}, double simulationTime = 0);

std::vector<std::pair<std::size_t, double>> reduceContributions(
    std::vector<EvaluatedContribution> contributions);

// A node's genuine algebraic states (see NodeExecutionPlan::algebraicTasks): recomputes each task
// in algebraicTasks, in the caller-supplied (already dependency-sorted) order, and writes the
// result directly into localStates.at(task.outputStateIndex) -- a plain replacement, never
// accumulated, never divided by stepSize. Because each write lands in the same localStates array
// every later algebraic task and every ordinary (differential) contribution in this same substep
// reads from, this composes with any solver: there is no derivative or stepSize-dependent
// arithmetic here at all, unlike the Euler-specific pseudo-derivative trick this replaces. Always
// intra-node (see compileExecutionPlan's dependency-ordering comment) -- takes no
// synchronizationSnapshot because a source term's bindings are never cross-node. `evaluationTime` is
// the instant localStates represent: the value is g(x, t) at one instant, so it always agrees with
// the states it is stored beside. stepSize is only passed on to a programmable term's provider.
void applyAlgebraicTasks(const std::vector<ContributionTask>& algebraicTasks, StateValues& localStates,
                         const NodeParameterValues& parameterValues, double evaluationTime, double stepSize,
                         ProviderEvaluator* providerEvaluator);

struct NodeIntegrationResult {
    StateValues states;
    std::uint64_t computeNanoseconds = 0;
};

// Owns one node's full substep loop for one global step: seeds localStates from the frozen
// synchronizationSnapshot, then per substep applies algebraic tasks (recomputed fresh, see above)
// before evaluating and Euler-integrating the node's ordinary differential contributions. Shared
// verbatim by the serial/thread-pool backend (simulationRunner.cpp) and the partitioned backend
// (partitionRuntime.cpp, which wraps this with its own node index) so the two can never silently
// diverge on this logic.
// activeSchedules defaults to {} (no effect on callers that pass none). Every backend passes the
// run's active schedules: the partitioned one hands them to each partition worker
// (partitionRuntime.cpp), so an intervention applies whichever backend a run is given.
NodeIntegrationResult integrateNode(const NodeExecutionPlan& node,
                                    const StateValues& synchronizationSnapshot,
                                    const EntityValues& liveParameterValues,
                                    double simulationTime,
                                    double synchronizationStep,
                                    ProviderEvaluator* providerEvaluator = nullptr,
                                    const std::vector<ParameterSchedule>& activeSchedules = {});

// Sets every node's algebraic states in `states` (the global state vector) from its other states at
// `time`, before a run's first step or its first step after a restart. A stored algebraic value --
// an initial value, or one computed under parameters a fork has since changed -- need not match
// its expression, and other nodes read it through the synchronization snapshot before its own node
// recomputes it. `stepSize` is only passed on to programmable terms' providers.
// Sets every state algebraic relationships set: each to zero, then each output's value added, in
// dependency order, from `states` (which it updates), at simulationTime.
void evaluateAlgebraicRelationships(const ExecutionPlan& plan, StateValues& states, const EntityValues& liveParameterValues,
                                    const std::vector<ParameterSchedule>& activeSchedules, double simulationTime);

void settleAlgebraicStates(const ExecutionPlan& plan, StateValues& states, const EntityValues& liveParameterValues,
                           double time, double stepSize, ProviderEvaluator* providerEvaluator = nullptr,
                           const std::vector<ParameterSchedule>& activeSchedules = {});

}
