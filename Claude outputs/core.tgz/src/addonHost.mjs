/* Copyright © 2026 Zenin Easa Panthakkalakath */

export const visualizerApiVersion = 1;
const addonIdPattern = /^[a-z][A-Za-z0-9]*(?:\.[a-z][A-Za-z0-9]*)+$/;
const commandIdPattern = /^[a-z][A-Za-z0-9]*$/;
const allowedToolstripConditions = new Set(['always', 'resultsActive']);
const allowedContributionContexts = new Set(['resultSession']);

const allowedPermissions = new Set([
    'results.read',
    'timeline.read',
    'timeline.seek',
    'selection.read',
    'results.live.read',
    'simulation.status.read',
    'simulation.pacing.read',
    'simulation.pacing.control',
    'results.export',
    'project.data',
    'settings.store'
]);

// Optional behaviours a result visualizer may depend on, listed in its `requires` as a launcher lists its own: a
// version of Konjugate that does not know one refuses the visualizer.
// projectData: with project.data, getProjectData and setProjectData keep the visualizer's own data with the project.
// addonSettings: with settings.store, getSettings and setSettings keep its settings for the user, in every project.
export const visualizerFeatures = new Set(['projectData', 'addonSettings']);
export const maximumVisualizerDataBytes = 1024 * 1024;

// Optional behaviours a launcher may depend on. A launcher lists the ones it needs in `requires`, and a version of Konjugate that does not
// know one of them refuses the launcher, rather than ignoring the entry and running it without what it needs.
// parameterSchedules: the engine follows a shared parameter's stored schedule (docs/projectSchema.md),
// so a launcher whose importer writes schedules can refuse a version that would run them as constants.
// scenarioForkTime: runScenario accepts the window's own fork time (forkAt).
// suppliedPerParameter: supplied data may be given per parameter (supplied.byParameter), so one scenario can change
// several parameters, each for its own entities along its own paths.
// scenarioEveryBackend: a scenario's changes apply whichever execution backend the engine chooses for the model. Up to
// 1.1.10 the partitioned backend ignored them, so a fork of a model the planner partitioned was its baseline again; a
// launcher whose results are read as "nothing changed" can refuse such a version.
// binaryInputs: an importer file role may be binary (a large file given to the importer as bytes), and an importer may
// return derived text files that take its place among the inputs.
// multipleBinaryInputs: a binary role may also be `multiple`, its files given to the importer together.
// importProgress: an importer may say how far it has got (helpers.progress), and the window hears it with onProgress.
// storedFiles: a launcher with files.store keeps large files for the user (downloaded, or brought in from disk) and
// gives them to its importer as binary inputs (addonFileStore.mjs).
export const launcherFeatures = new Set(['scenarioOverrides', 'runRecord', 'projectSession', 'parameterSchedules', 'scenarioForkTime', 'suppliedPerParameter', 'fetchCache', 'keepSession', 'openLink', 'scenarioEveryBackend', 'binaryInputs', 'multipleBinaryInputs', 'importProgress', 'storedFiles', 'nodeProviderInputs', 'pythonCheck', 'algebraicRelationships']);
const launcherPermissions = new Set(['data.import', 'scenario.run', 'model.open', 'results.export', 'pages.open', 'analysis.infer', 'network.fetch', 'project.data', 'links.open', 'files.store']);
const contributionIdPattern = /^[a-z][A-Za-z0-9]*$/;

function safeRelativePath(path, description, extensions) {
    if (typeof path !== 'string' || !path || path.startsWith('/') || path.split(/[\\/]/).includes('..')) {
        throw new Error(`The launcher ${description} must be a relative path inside the add-on directory.`);
    }
    if (extensions && !extensions.some((extension) => path.endsWith(extension))) throw new Error(`The launcher ${description} must end in ${extensions.join(' or ')}.`);
    return path;
}

// A launcher add-on opens a guided starting window instead of visualizing results (see
// docs/proposals/launcherAddons.md). Everything it may refer to -- importers, scenarios, help pages,
// sample files -- is declared here as data, and the window can only name a declared id; it can never
// supply a path or a URL of its own.
export function validateLauncherManifest(manifest) {
    if (manifest.apiVersion !== visualizerApiVersion) throw new Error(`Unsupported launcher API version: ${manifest.apiVersion}.`);
    if (!addonIdPattern.test(manifest.addonId ?? '') || !manifest.name || !manifest.version || !manifest.entry) throw new Error('The launcher manifest is incomplete.');
    safeRelativePath(manifest.entry, 'entry', ['.html']);
    const permissions = manifest.permissions ?? [];
    if (!permissions.every((permission) => launcherPermissions.has(permission))) throw new Error('The launcher requests an unsupported permission.');
    const requires = manifest.requires ?? [];
    if (!Array.isArray(requires) || !requires.every((feature) => typeof feature === 'string')) throw new Error('A launcher\'s requires must be a list of names.');
    const missing = requires.filter((feature) => !launcherFeatures.has(feature));
    if (missing.length) throw new Error(`This launcher needs ${missing.join(', ')}, which this version of Konjugate does not provide. Update Konjugate to use it.`);
    // Fetching from the internet is allowed only from hosts the manifest names, so what a launcher can reach is
    // readable before it is installed.
    const exactHosts = (list) => Array.isArray(list) && list.length && list.every((host) => /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i.test(host));
    if (permissions.includes('network.fetch')) {
        if (!exactHosts(manifest.network?.hosts)) throw new Error('A launcher that fetches from the internet must list the exact host names it may reach in network.hosts.');
    } else if (manifest.network !== undefined) throw new Error('A launcher may declare network hosts only with the network.fetch permission.');
    // So is opening a page in the user's browser: only on hosts the manifest names, so where a launcher can send the user
    // is readable before it is installed too.
    if (permissions.includes('links.open')) {
        if (!exactHosts(manifest.links?.hosts)) throw new Error('A launcher that opens pages in the browser must list the exact host names it may open in links.hosts.');
    } else if (manifest.links !== undefined) throw new Error('A launcher may declare link hosts only with the links.open permission.');
    const contributes = manifest.contributes ?? {};
    const toolstrip = contributes.toolstrip ?? [];
    if (toolstrip.length !== 1 || !commandIdPattern.test(toolstrip[0].commandId ?? '') || !toolstrip[0].label || !toolstrip[0].tooltip ||
        toolstrip[0].when !== 'always' || (toolstrip[0].contexts ?? []).length) {
        throw new Error('A launcher must contribute exactly one always-visible toolstrip command with no result context.');
    }
    const unique = (items, key, description) => {
        const seen = new Set();
        for (const item of items) {
            if (!contributionIdPattern.test(item?.[key] ?? '') || seen.has(item[key])) throw new Error(`The launcher has an invalid or duplicated ${description} id.`);
            seen.add(item[key]);
        }
    };
    const importers = contributes.importers ?? [];
    unique(importers, 'importerId', 'importer');
    for (const importer of importers) {
        if (!importer.name) throw new Error('A launcher importer needs a name.');
        safeRelativePath(importer.entry, 'importer entry', ['.mjs']);
        const files = importer.files ?? [];
        if (!files.length) throw new Error('A launcher importer must declare the files it reads.');
        unique(files, 'role', 'importer file role');
        for (const file of files) {
            if (!file.label) throw new Error('A launcher importer file needs a label.');
            if (file.multiple !== undefined && typeof file.multiple !== 'boolean') throw new Error('A launcher importer file\'s multiple must be true or false.');
            // A binary role takes large files as bytes (a map extract, say; several, with `multiple`, as for a city on a
            // border whose map comes in one extract for each country), which the importer reads once and turns
            // into text files of its other roles: it has no sample and is not kept with a session.
            if (file.binary !== undefined && typeof file.binary !== 'boolean') throw new Error('A launcher importer file\'s binary must be true or false.');
            if (file.binary && (file.sample !== undefined || file.required)) throw new Error('A binary importer file is optional, with no sample.');
            for (const sample of file.sample === undefined ? [] : [file.sample].flat()) safeRelativePath(sample, 'importer sample', null);
            if (Array.isArray(file.sample) && !file.multiple) throw new Error('Only a file role that accepts several files can list several samples.');
        }
    }
    const scenarios = contributes.scenarios ?? [];
    unique(scenarios, 'scenarioId', 'scenario');
    for (const scenario of scenarios) {
        if (!scenario.name || !scenario.description || !Number.isFinite(scenario.forkAt) || scenario.forkAt < 0 || !Number.isFinite(scenario.runTime) || !(scenario.runTime > scenario.forkAt)) {
            throw new Error('A launcher scenario needs a name, a description, a fork time and a longer run time.');
        }
        if (scenario.choose !== undefined && !scenario.choose?.label) throw new Error('A launcher scenario choice needs a label.');
        if (scenario.effects !== undefined && (!Array.isArray(scenario.effects) || !scenario.effects.every((line) => typeof line === 'string'))) {
            throw new Error('A launcher scenario\'s effects must be a list of sentences.');
        }
        if (!Array.isArray(scenario.interventions) || !scenario.interventions.length) throw new Error('A launcher scenario needs at least one intervention.');
        for (const intervention of scenario.interventions) {
            // A `supplied` target is filled in by the window when it runs the scenario: either a fixed value for the entities it
            // names, or (samples: true) a path of values over time for each of them, followed by the parameter as a piecewise schedule.
            const supplied = intervention.target === 'supplied';
            const validValue = supplied
                ? (intervention.samples === true) !== Number.isFinite(intervention.value)
                : Number.isFinite(intervention.value) !== Number.isFinite(intervention.fractionOfMaximum);
            if (!contributionIdPattern.test(intervention.parameter ?? '') || !['chosen', 'all', 'global', 'supplied'].includes(intervention.target) ||
                !validValue || (intervention.at !== undefined && !(intervention.at >= 0)) ||
                (intervention.duration !== undefined && !(intervention.duration > 0))) {
                throw new Error('A launcher scenario intervention needs a parameter, a target (chosen, all, global or supplied), an optional delay and duration, and exactly one of value or fractionOfMaximum (a supplied target takes a value, or samples: true).');
            }
        }
    }
    const pages = contributes.pages ?? [];
    unique(pages, 'pageId', 'page');
    for (const page of pages) {
        if (!page.label) throw new Error('A launcher page needs a label.');
        safeRelativePath(page.entry, 'page entry', ['.html']);
    }
    return structuredClone(manifest);
}

export function validateAddonManifest(manifest) {
    if (manifest?.kind === 'launcher') return validateLauncherManifest(manifest);
    if (!manifest || manifest.kind !== 'resultVisualizer') throw new Error('The add-on is not a result visualizer.');
    if (manifest.apiVersion !== visualizerApiVersion) throw new Error(`Unsupported visualizer API version: ${manifest.apiVersion}.`);
    if (!addonIdPattern.test(manifest.addonId ?? '') || !manifest.name || !manifest.version || !manifest.entry) throw new Error('The visualizer manifest is incomplete.');
    if (manifest.entry.startsWith('/') || manifest.entry.split(/[\\/]/).includes('..')) {
        throw new Error('The visualizer entry must remain inside its add-on directory.');
    }
    const permissions = manifest.permissions ?? [];
    if (!permissions.every((permission) => allowedPermissions.has(permission))) {
        throw new Error('The visualizer requests an unsupported permission.');
    }
    const requires = manifest.requires ?? [];
    if (!Array.isArray(requires) || !requires.every((feature) => typeof feature === 'string')) throw new Error('A visualizer\'s requires must be a list of names.');
    const missing = requires.filter((feature) => !visualizerFeatures.has(feature));
    if (missing.length) throw new Error(`This visualizer needs ${missing.join(', ')}, which this version of Konjugate does not provide. Update Konjugate to use it.`);
    const contributions = manifest.contributes?.toolstrip ?? [];
    if (contributions.length !== 1) throw new Error('A version 1 result visualizer must contribute exactly one toolstrip command.');
    const commandIds = new Set();
    contributions.forEach((contribution) => {
        const contexts = contribution.contexts ?? [];
        if (!commandIdPattern.test(contribution.commandId ?? '') || commandIds.has(contribution.commandId) ||
            !contribution.label || !contribution.tooltip || !allowedToolstripConditions.has(contribution.when ?? 'always') ||
            !contexts.every((context) => allowedContributionContexts.has(context)) ||
            !contexts.includes('resultSession') || contribution.when !== 'resultsActive') {
            throw new Error('The add-on contains an invalid toolstrip contribution.');
        }
        commandIds.add(contribution.commandId);
    });
    return structuredClone(manifest);
}

export const validateVisualizerManifest = validateAddonManifest;

export function publicToolstripContributions(manifest) {
    return (manifest.contributes?.toolstrip ?? []).map((contribution) => ({
        addonId: manifest.addonId,
        addonName: manifest.name,
        commandId: contribution.commandId,
        label: contribution.label,
        tooltip: contribution.tooltip,
        symbol: contribution.symbol ?? '◇',
        when: contribution.when ?? 'always',
        contexts: [...(contribution.contexts ?? [])]
    }));
}

export function createVisualizerSession({ sessionId, projectName, result, nodes, edges = [], selectedNodeId, engineJobId = null, time = 0 }) {
    const signals = nodes.flatMap((node) => node.states.map((state) => ({
        signalId: state.id,
        entityId: node.id,
        entityName: node.title,
        name: state.label,
        symbol: state.symbol,
        unit: state.unit ?? ''
    })));
    return {
        sessionId,
        engineJobId,
        projectName,
        run: {
            name: result.configurationName,
            targetTime: Number(result.targetTime),
            outputInterval: Number(result.outputInterval),
            sampleCount: result.samples.length,
            lifecycle: result.lifecycle ?? 'completed',
            simulationTime: Number(result.simulationTime ?? result.targetTime),
            availableResultTime: Number(result.availableResultTime ?? result.targetTime),
            pacing: structuredClone(result.pacing ?? { mode: 'fastest', simulationSecondsPerWallSecond: 1 })
        },
        signals,
        // Structural model metadata (appearance, topology) -- static for the life of the
        // session, unlike signals/samples, so it's read once here rather than through a
        // separate time-varying endpoint.
        nodes: nodes.map(({ id, title, shape, color, rotation, scale, mesh, parts }) => ({ id, title, shape, color, rotation, scale, mesh, ...(parts ? { parts } : {}) })),
        edges: edges.map(({ id, title, sourceNodeId, targetNodeId }) => ({ id, title, sourceNodeId, targetNodeId })),
        samples: structuredClone(result.samples),
        selectedNodeId,
        time: Number(time)
    };
}

export function publicVisualizerContext(session) {
    return {
        apiVersion: visualizerApiVersion,
        sessionId: session.sessionId,
        projectName: session.projectName,
        run: structuredClone(session.run),
        nodes: structuredClone(session.nodes),
        edges: structuredClone(session.edges),
        selectedNodeId: session.selectedNodeId,
        time: session.time
    };
}

// What a result visualizer keeps with the project (docs/projectSchema.md, `addonData`): its own data, as the window
// gave it. Throws a message a user can act on.
export function buildVisualizerDataEntry({ addon, data, savedAt = new Date().toISOString() }) {
    const text = JSON.stringify(data ?? null);
    if (new TextEncoder().encode(text).length > maximumVisualizerDataBytes) throw new Error(`A visualizer may keep at most ${maximumVisualizerDataBytes / 1024 / 1024} MB with a project.`);
    return { version: 1, addonVersion: addon.version, savedAt, data: JSON.parse(text) };
}

// The visualizer's data from its entry, or null when the project keeps none (or an entry this version cannot read).
export function visualizerDataFromEntry(entry) {
    if (entry?.version !== 1 || !('data' in entry)) return null;
    return { data: structuredClone(entry.data), savedAt: entry.savedAt ?? null, addonVersion: entry.addonVersion ?? null };
}

export function readSignalSeries(session, signalIds, { startTime = 0, endTime = Infinity, maxPoints = 4000 } = {}) {
    const requested = new Set(signalIds);
    const metadata = session.signals.filter((signal) => requested.has(signal.signalId));
    const samples = session.samples.filter((sample) => sample.time >= startTime && sample.time <= endTime);
    const stride = Math.max(1, Math.ceil(samples.length / Math.max(2, maxPoints)));
    const selectedSamples = samples.filter((_sample, index) => index % stride === 0 || index === samples.length - 1);
    return metadata.map((signal) => ({
        ...signal,
        samples: selectedSamples.flatMap((sample) => {
            const state = sample.states.find((candidate) => candidate.stateId === signal.signalId);
            return state ? [{ time: Number(sample.time), value: Number(state.value) }] : [];
        })
    }));
}
