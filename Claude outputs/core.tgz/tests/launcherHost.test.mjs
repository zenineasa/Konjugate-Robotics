/* Copyright © 2026 Zenin Easa Panthakkalakath */

import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { validateAddonManifest } from '../src/addonHost.mjs';
import {
    binaryChoice, checkedDerived, storedFileKinds, checkedProgress, importerInputs, unreadableFile, maximumBinaryInputBytes, maximumBinaryTotalBytes,
    attachAddonData, buildSessionEntry, sessionInputs,
    checkForkTime, checkPythonModules, maximumPythonModules,
    checkRunLength,
    addressAllowed, applyOverrides, buildRunManifest, composeBranchSamples, decodeText, extractSeries, fetchAllowed, safeFileName, resolveInterventions, resultsToCsv, runImporter, runScenarioBranches, sha256
} from '../src/launcherHost.mjs';

const fixtureDirectory = join(dirname(fileURLToPath(import.meta.url)), 'fixtures', 'launcher');

const launcher = () => ({
    addonId: 'example.thermalStart', name: 'Thermal Start', version: '0.1.0', apiVersion: 1, kind: 'launcher', entry: 'index.html',
    permissions: ['data.import', 'scenario.run', 'model.open', 'results.export', 'pages.open'],
    contributes: {
        toolstrip: [{ commandId: 'openStart', label: 'Thermal', tooltip: 'Open Thermal Start', symbol: '◆', when: 'always', contexts: [] }],
        importers: [{ importerId: 'rooms', name: 'Rooms', entry: 'importers/rooms.mjs', files: [{ role: 'rooms', label: 'Rooms', required: true, sample: 'samples/rooms.csv' }] }],
        scenarios: [{
            scenarioId: 'coldDay', name: 'Cold day', description: 'The outside temperature drops.', forkAt: 5, runTime: 20,
            interventions: [{ parameter: 'outsideTemperature', target: 'global', value: 250 }]
        }],
        pages: [{ pageId: 'gettingStarted', label: 'Getting started', entry: 'help/gettingStarted.html' }]
    }
});

test('a well-formed launcher manifest is accepted', () => {
    assert.equal(validateAddonManifest(launcher()).kind, 'launcher');
});

test('a launcher manifest is rejected when it breaks the contract', () => {
    const rejects = (mutate, pattern) => {
        const manifest = launcher();
        mutate(manifest);
        assert.throws(() => validateAddonManifest(manifest), pattern);
    };
    rejects((m) => { m.permissions.push('model.write'); }, /unsupported permission/);
    rejects((m) => { m.contributes.toolstrip[0].when = 'resultsActive'; }, /always-visible toolstrip/);
    rejects((m) => { m.contributes.toolstrip[0].contexts = ['resultSession']; }, /always-visible toolstrip/);
    rejects((m) => { m.entry = '../index.html'; }, /relative path/);
    rejects((m) => { m.contributes.importers[0].entry = '/etc/importer.mjs'; }, /relative path/);
    rejects((m) => { m.contributes.importers[0].entry = 'importers/rooms.js'; }, /must end in \.mjs/);
    rejects((m) => { m.contributes.importers[0].files[0].sample = '../secret.csv'; }, /relative path/);
    rejects((m) => { m.contributes.importers[0].files[0].multiple = 'yes'; }, /multiple must be true or false/);
    rejects((m) => { m.contributes.importers[0].files[0].sample = ['a.csv', 'b.csv']; }, /several files/);
    rejects((m) => { m.contributes.importers.push({ ...m.contributes.importers[0] }); }, /duplicated importer/);
    rejects((m) => { m.contributes.scenarios[0].runTime = 3; }, /longer run time/);
    rejects((m) => { m.contributes.scenarios[0].interventions[0].target = 'nowhere'; }, /intervention/);
    rejects((m) => { m.contributes.scenarios[0].interventions[0].fractionOfMaximum = 0.5; }, /exactly one of value or fractionOfMaximum/);
    rejects((m) => { m.contributes.scenarios[0].choose = {}; }, /choice needs a label/);
    rejects((m) => { m.contributes.scenarios[0].effects = 'x'; }, /effects must be a list/);
    rejects((m) => { m.contributes.pages[0].entry = 'help/../../x.html'; }, /relative path/);
    rejects((m) => { m.apiVersion = 2; }, /Unsupported launcher API version/);
});

test('an importer runs in a worker, can read its own package JSON, and its output is checked', async () => {
    const importer = { entry: 'echoImporter.mjs' };
    const run = (text) => runImporter({ addonDirectory: fixtureDirectory, importer, files: [{ role: 'data', name: 'data.csv', text }], timeoutMilliseconds: 1500 });
    assert.deepEqual((await run('hello')).report.summary, { text: 'hello', extra: 7 });
    await assert.rejects(() => run('boom'), /The importer failed: boom/);
    await assert.rejects(() => run('bad'), /unexpected result/);
    await assert.rejects(() => run('hang'), /did not finish within/);
});

test('an importer can return only data, receive options, and build a model from construction operations', async () => {
    const importer = { entry: 'echoImporter.mjs' };
    const run = (text, options) => runImporter({ addonDirectory: fixtureDirectory, importer, files: [{ role: 'data', name: 'data.csv', text }], options, timeoutMilliseconds: 1500 });
    const first = await run('data-only', { stage: 'read' });
    assert.deepEqual(first.data, { received: 'read', files: 1 });
    assert.equal(first.document, undefined);
    const built = await run('operations');
    assert.equal(built.document.nodes[0].sourceTerms[0].expression, '-x');
    assert.equal(typeof built.data.references.x, 'number');
});

test('a launcher file role may accept several files and list several samples', () => {
    const manifest = launcher();
    Object.assign(manifest.contributes.importers[0].files[0], { multiple: true, sample: ['samples/a.csv', 'samples/b.csv'] });
    assert.equal(validateAddonManifest(manifest).kind, 'launcher');
});

test('a scenario can take values or paths of values that the window supplies', () => {
    const index = [
        { key: 'drive', scope: 'series', entity: 'Gold', sharedParameterId: 1, name: 'Drive (Gold)', live: true, minimum: -0.5, maximum: 0.5, value: 0 },
        { key: 'drive', scope: 'series', entity: 'Oil', sharedParameterId: 2, name: 'Drive (Oil)', live: true, minimum: -0.5, maximum: 0.5, value: 0 },
        { key: 'gain', scope: 'series', entity: 'Gold', sharedParameterId: 3, name: 'Gain (Gold)', live: true, minimum: 0, maximum: 20, value: 0 }
    ];
    const scenario = { name: 'Replay', interventions: [{ parameter: 'gain', target: 'supplied', value: 8 }, { parameter: 'drive', target: 'supplied', samples: true }] };
    const resolved = resolveInterventions(scenario, index, null, { entities: ['Gold'], samples: { Gold: [[0, 0.01], [1, 0.9], [2, -0.02]] } });
    assert.deepEqual(resolved.map((change) => [change.parameter, change.entity]), [['gain', 'Gold'], ['drive', 'Gold']]);
    assert.equal(resolved[0].value, 8);
    assert.deepEqual(resolved[1].samples, [{ time: 0, value: 0.01 }, { time: 1, value: 0.5 }, { time: 2, value: -0.02 }], 'Values are held to the parameter\'s range.');
    assert.throws(() => resolveInterventions(scenario, index, null, null), /needs the window to supply data/);
    assert.throws(() => resolveInterventions(scenario, index, null, { entities: ['Oil'], samples: { Oil: [[0, 1], [1, 2]] } }), /does not have for Oil|gain/);
    assert.throws(() => resolveInterventions(scenario, index, null, { entities: ['Gold'], samples: { Gold: [[0, 1]] } }), /at least two/);
    assert.throws(() => resolveInterventions(scenario, index, null, { entities: ['Gold'], samples: { Gold: [[0, 'x'], [1, 2]] } }), /at least two/);
});

test('supplied data can be given per parameter, each for its own entities along its own paths', () => {
    const index = [
        { key: 'open', scope: 'instance', entity: 'Lane A', sharedParameterId: 1, name: 'Open (Lane A)', live: true, minimum: 0, maximum: 1, value: 1 },
        { key: 'share', scope: 'instance', entity: 'Lane A', sharedParameterId: 2, name: 'Share (Lane A)', live: true, minimum: 0, maximum: 1, value: 0.5 },
        { key: 'share', scope: 'instance', entity: 'Lane B', sharedParameterId: 3, name: 'Share (Lane B)', live: true, minimum: 0, maximum: 1, value: 0.5 }
    ];
    const scenario = { name: 'Closure', interventions: [{ parameter: 'open', target: 'supplied', samples: true }, { parameter: 'share', target: 'supplied', samples: true }] };
    const resolved = resolveInterventions(scenario, index, null, { byParameter: {
        open: { entities: ['Lane A'], samples: { 'Lane A': [[0, 0], [10, 1]] } },
        share: { entities: ['Lane A', 'Lane B'], samples: { 'Lane A': [[0, 0], [10, 0.5]], 'Lane B': [[0, 1], [10, 0.5]] } }
    } });
    assert.deepEqual(resolved.map((change) => [change.parameter, change.entity, change.samples.map((sample) => sample.value)]), [
        ['open', 'Lane A', [0, 1]], ['share', 'Lane A', [0, 0.5]], ['share', 'Lane B', [1, 0.5]]
    ]);
    assert.throws(() => resolveInterventions(scenario, index, null, { byParameter: { open: { entities: ['Lane A'], samples: { 'Lane A': [[0, 0], [1, 1]] } } } }), /needs the window to supply data for "share"/);
    const manifest = launcher();
    manifest.requires = ['suppliedPerParameter'];
    assert.doesNotThrow(() => validateAddonManifest(manifest));
});

test('supplied values outside a parameter\'s range are held to it, and the change says how many', () => {
    const index = [{ key: 'arrivals', scope: 'instance', entity: 'Port', sharedParameterId: 1, name: 'Arrivals (Port)', live: true, minimum: 0, maximum: 100, value: 25 }];
    const scenario = { name: 'Diversion', interventions: [{ parameter: 'arrivals', target: 'supplied', samples: true }] };
    const [change] = resolveInterventions(scenario, index, null, { entities: ['Port'], samples: { Port: [[0, 25], [10, 400], [20, 400], [30, -5]] } });
    assert.deepEqual(change.samples.map((sample) => sample.value), [25, 100, 100, 0]);
    assert.deepEqual(change.clamped, { count: 3, of: 4, minimum: 0, maximum: 100 });
    const [inside] = resolveInterventions(scenario, index, null, { entities: ['Port'], samples: { Port: [[0, 25], [10, 90]] } });
    assert.equal(inside.clamped, undefined, 'nothing to report when every value fits');
});

test('a supplied intervention takes a value or samples, and not both or neither', () => {
    const withIntervention = (intervention) => { const manifest = launcher(); manifest.contributes.scenarios[0].interventions = [intervention]; return manifest; };
    assert.equal(validateAddonManifest(withIntervention({ parameter: 'drive', target: 'supplied', samples: true })).kind, 'launcher');
    assert.equal(validateAddonManifest(withIntervention({ parameter: 'gain', target: 'supplied', value: 8 })).kind, 'launcher');
    assert.throws(() => validateAddonManifest(withIntervention({ parameter: 'drive', target: 'supplied' })), /supplied target takes a value, or samples/);
    assert.throws(() => validateAddonManifest(withIntervention({ parameter: 'drive', target: 'supplied', samples: true, value: 1 })), /supplied target takes a value, or samples/);
});

test('scenario interventions resolve to concrete parameter changes', () => {
    const index = [
        { key: 'withdrawalRate', scope: 'institution', entity: 'Alder', sharedParameterId: 1, name: 'Withdrawal (Alder)', live: true, minimum: 0, maximum: 0.2 },
        { key: 'withdrawalRate', scope: 'institution', entity: 'Birch', sharedParameterId: 2, name: 'Withdrawal (Birch)', live: true, minimum: 0, maximum: 0.2 },
        { key: 'lending', scope: 'institution', entity: 'Alder', sharedParameterId: 3, name: 'Lending (Alder)', live: true, minimum: 0, maximum: 100 },
        { key: 'haircut', scope: 'global', sharedParameterId: 4, name: 'Haircut', live: true, minimum: 0, maximum: 1 },
        { key: 'fixed', scope: 'global', sharedParameterId: 5, name: 'Fixed', live: false }
    ];
    const scenario = { name: 'Stress', interventions: [
        { parameter: 'withdrawalRate', target: 'chosen', value: 0.05 },
        { parameter: 'lending', target: 'chosen', fractionOfMaximum: 0.5, at: 3 },
        { parameter: 'haircut', target: 'global', value: 5 }
    ] };
    const resolved = resolveInterventions(scenario, index, 'Alder');
    assert.deepEqual(resolved.map((change) => [change.sharedParameterId, change.value, change.at]), [[1, 0.05, 0], [3, 50, 3], [4, 1, 0]], 'Values are clamped to the parameter range.');
    assert.equal(resolveInterventions({ name: 'Run on all', interventions: [{ parameter: 'withdrawalRate', target: 'all', value: 0.01 }] }, index).length, 2);
    assert.throws(() => resolveInterventions(scenario, index, null), /choose one first/);
    assert.throws(() => resolveInterventions({ name: 'X', interventions: [{ parameter: 'absent', target: 'global', value: 1 }] }, index), /does not have/);
    assert.throws(() => resolveInterventions({ name: 'X', interventions: [{ parameter: 'fixed', target: 'global', value: 1 }] }, index), /cannot be changed during a run/);
});

const document = { nodes: [{ id: 1, name: 'Room', states: [{ id: 2, symbol: 'temperature', name: 'Temperature', unit: 'K' }] }], edges: [] };
const sample = (time, value) => ({ time, states: [{ stateId: 2, value }] });

test('a forked branch reads as one continuous history, and series and CSV come out in the expected shape', () => {
    const parent = [sample(0, 1), sample(1, 2), sample(2, 3), sample(3, 4)];
    const child = [sample(2, 30), sample(3, 40)];
    const composed = composeBranchSamples(parent, child, 2);
    assert.deepEqual(composed.map((item) => [item.time, item.states[0].value]), [[0, 1], [1, 2], [2, 30], [3, 40]]);
    assert.deepEqual(extractSeries(composed, document, ['temperature']), { Room: { temperature: [[0, 1], [1, 2], [2, 30], [3, 40]] } });
    assert.deepEqual(extractSeries(composed, document, ['humidity']), {});
    const csv = resultsToCsv([{ label: 'Base, line', samples: parent.slice(0, 1) }, { label: 'Cold', samples: child.slice(0, 1) }], document);
    assert.equal(csv, 'branch,time,node,state,unit,value\n"Base, line",0,Room,Temperature,K,1\nCold,2,Room,Temperature,K,30\n');
});

test('the run manifest records what produced a result', () => {
    const manifest = buildRunManifest({
        appVersion: '1.2.3', addon: { addonId: 'example.thermalStart', name: 'Thermal Start', version: '0.1.0' }, importerId: 'rooms',
        inputs: [{ role: 'rooms', name: 'rooms.csv', sha256: 'abc', bytes: 12, text: 'not recorded' }], contentText: '{"a":1}', document,
        config: { targetTime: 20 }, scenario: { scenarioId: 'coldDay', name: 'Cold day', description: 'd', forkAt: 5 }, chosenEntity: null,
        interventions: [{ sharedParameterId: 4, value: 250 }], files: { 'results.csv': { sha256: 'x', bytes: 1 } }
    });
    assert.equal(manifest.model.sha256, sha256('{"a":1}'));
    assert.deepEqual(manifest.inputs, [{ role: 'rooms', name: 'rooms.csv', sha256: 'abc', bytes: 12 }], 'The file text is never recorded, only its hash.');
    assert.equal(manifest.scenario.forkAt, 5);
    assert.equal(manifest.package.version, '0.1.0');
});

// A forked scenario against the real engine: a level fed by a shared live gain, doubled at the fork.
const enginePath = join(dirname(fileURLToPath(import.meta.url)), '..', 'out', 'engine', 'konjugateEngine');
test('a scenario forks the baseline at its time and changes a live shared parameter from there', { skip: !existsSync(enginePath) && 'the engine is not built' }, async () => {
    const { startEngineRun } = await import('../src/engineAdapter.mjs');
    const engineOptions = { applicationPath: join(dirname(fileURLToPath(import.meta.url)), '..'), resourcesPath: '', packaged: false };
    const node = (id, name, stateId) => ({ id, name, position: [0, 0, 0], sourceTerms: [], appearance: { type: 'primitive', shape: 'box', color: '#888888' }, states: [{ id: stateId, name: 'Level', symbol: 'level', initialValue: 0 }] });
    const project = {
        format: 'konjugate', version: 1, metadata: { units: 'SI' }, nodes: [node(1, 'Source', 2), node(3, 'Target', 4)],
        edges: [{
            id: 5, name: 'Feed', source: { nodeId: 1, stateId: 2 }, target: { nodeId: 3, stateId: 4 }, directionality: 'directed', equation: '\\mathrm{gain}',
            equationModel: { latex: '\\mathrm{gain}', output: { role: 'target', stateId: 4 }, bindings: [{ kind: 'parameter', parameterId: 6, symbol: 'gain' }], mathJson: 'gain' },
            parameters: [{ id: 6, name: 'Gain', symbol: 'gain', value: 1, mode: 'live', control: { minimum: 0, maximum: 10, step: 1 }, sharedParameterId: 7 }],
            appearance: { color: '#888888', offset: 0 }
        }],
        sharedParameters: [{ id: 7, name: 'Shared gain', symbol: 'gain', value: 1, mode: 'live', control: { minimum: 0, maximum: 10, step: 1 } }],
        runConfigurations: [{ id: 8, name: 'Default', globalTimeStep: 0.1, outputInterval: 0.5 }], activeRunConfigurationId: 8
    };
    const content = JSON.stringify(project);
    const config = { name: 'Baseline', targetTime: 10, globalTimeStep: 0.1, outputInterval: 0.5 };
    const baselineRun = await startEngineRun(content, config, engineOptions, { retainResult: true });
    const baselineResult = await baselineRun.completion;
    const baseline = { result: baselineResult, resultPath: baselineRun.resultPath, cleanup: baselineRun.cleanup };
    const scenario = { forkAt: 5, runTime: 10 };
    const { forkTime, child } = await runScenarioBranches({ content, config, scenario, interventions: [{ sharedParameterId: 7, value: 3, at: 0 }], baseline, engineOptions });
    assert.equal(forkTime, 5);
    const finalLevel = (samples) => samples.at(-1).states.find((state) => state.stateId === 4).value;
    assert.ok(Math.abs(finalLevel(baselineResult.samples) - 10) < 1e-6, 'Baseline: gain 1 for 10 days.');
    // Gain 1 for 5 days, then 3 for 5 days: 5 + 15 = 20.
    assert.ok(Math.abs(finalLevel(child.result.samples) - 20) < 0.2, `Scenario level ${finalLevel(child.result.samples)} should be about 20`);
    assert.equal(child.result.samples[0].time, 5, 'The forked run starts at the fork point.');
    await baseline.cleanup?.();
    await child.cleanup?.();
});

test('text is decoded as UTF-8, UTF-16 or, failing that, Windows-1252, and the encoding is reported', () => {
    assert.deepEqual(decodeText(Buffer.from('Crédit,1\n', 'utf8')), { text: 'Crédit,1\n', encoding: 'utf-8' });
    assert.deepEqual(decodeText(Buffer.from([0xEF, 0xBB, 0xBF, 0x41])).encoding, 'utf-8');
    assert.equal(decodeText(Buffer.from([0x43, 0x72, 0xE9, 0x64, 0x69, 0x74])).text, 'Crédit', 'A Windows-1252 é (0xE9) is not valid UTF-8.');
    assert.equal(decodeText(Buffer.from([0x43, 0x72, 0xE9, 0x64, 0x69, 0x74])).encoding, 'windows-1252');
    assert.deepEqual(decodeText(Buffer.from([0xFF, 0xFE, 0x41, 0x00, 0x42, 0x00])), { text: 'AB', encoding: 'utf-16le' });
});

const answer = (status, body = 'ok', headers = {}) => ({ status, ok: status >= 200 && status < 300, headers: new Headers(headers), arrayBuffer: async () => new TextEncoder().encode(body).buffer });

test('a fetch reaches only the hosts the manifest lists, over https, and follows redirects only within them', async () => {
    const calls = [];
    const fetchImpl = async (url) => { calls.push(url); return url.includes('start') ? answer(302, '', { location: '/next' }) : url.includes('away') ? answer(302, '', { location: 'https://evil.example/x' }) : answer(200, 'data'); };
    const hosts = ['data.example.com'];
    assert.equal(new TextDecoder().decode(await fetchAllowed({ url: 'https://data.example.com/file', hosts, fetchImpl })), 'data');
    assert.equal(new TextDecoder().decode(await fetchAllowed({ url: 'https://data.example.com/start', hosts, fetchImpl })), 'data');
    assert.deepEqual(calls.slice(-2), ['https://data.example.com/start', 'https://data.example.com/next']);
    await assert.rejects(() => fetchAllowed({ url: 'https://data.example.com/away', hosts, fetchImpl }), /may not connect to evil\.example/);
    await assert.rejects(() => fetchAllowed({ url: 'https://other.example.com/file', hosts, fetchImpl }), /may not connect to other\.example\.com/);
    await assert.rejects(() => fetchAllowed({ url: 'http://data.example.com/file', hosts, fetchImpl }), /Only https/);
    await assert.rejects(() => fetchAllowed({ url: 'https://user:pw@data.example.com/file', hosts, fetchImpl }), /user name or password/);
    await assert.rejects(() => fetchAllowed({ url: 'not a url', hosts, fetchImpl }), /not a web address/);
});

test('a fetch explains a missing symbol, rate limiting, a network failure and an oversized answer', async () => {
    const hosts = ['data.example.com'];
    const url = 'https://data.example.com/x';
    await assert.rejects(() => fetchAllowed({ url, hosts, fetchImpl: async () => answer(404) }), /404 \(not found: check the symbol\)/);
    await assert.rejects(() => fetchAllowed({ url, hosts, fetchImpl: async () => answer(429) }), /too many requests/);
    await assert.rejects(() => fetchAllowed({ url, hosts, fetchImpl: async () => { throw new Error('offline'); } }), /Could not reach data\.example\.com/);
    await assert.rejects(() => fetchAllowed({ url, hosts, fetchImpl: async () => answer(200, 'x', { 'content-length': String(6 * 1024 * 1024) }) }), /larger than the size limit/);
});

test('a launcher that fetches must list exact host names, and only such a launcher may list them', () => {
    const withNetwork = (mutate) => { const manifest = launcher(); manifest.permissions.push('network.fetch'); manifest.network = { hosts: ['query1.finance.yahoo.com'] }; mutate(manifest); return manifest; };
    assert.equal(validateAddonManifest(withNetwork(() => {})).kind, 'launcher');
    for (const hosts of [undefined, [], ['*.yahoo.com'], ['https://yahoo.com'], ['localhost'], ['a b.com']]) {
        assert.throws(() => validateAddonManifest(withNetwork((manifest) => { manifest.network = hosts === undefined ? undefined : { hosts }; })), /exact host names/);
    }
    assert.throws(() => validateAddonManifest({ ...launcher(), network: { hosts: ['example.com'] } }), /only with the network\.fetch permission/);
});

test('a launcher that opens pages in the browser must list exact host names, and only such a launcher may list them', () => {
    const withLinks = (mutate) => { const manifest = launcher(); manifest.permissions.push('links.open'); manifest.links = { hosts: ['www.google.com', 'www.openstreetmap.org'] }; mutate(manifest); return manifest; };
    assert.equal(validateAddonManifest(withLinks(() => {})).kind, 'launcher');
    for (const hosts of [undefined, [], ['*.google.com'], ['https://google.com'], ['localhost']]) {
        assert.throws(() => validateAddonManifest(withLinks((manifest) => { manifest.links = hosts === undefined ? undefined : { hosts }; })), /exact host names it may open in links\.hosts/);
    }
    assert.throws(() => validateAddonManifest({ ...launcher(), links: { hosts: ['www.google.com'] } }), /only with the links\.open permission/);
    // The page opened is checked as a fetch is: https, a listed host, no credentials.
    assert.equal(addressAllowed('https://www.google.com/maps/dir/?api=1&origin=1,2', ['www.google.com']), 'https://www.google.com/maps/dir/?api=1&origin=1,2');
    assert.throws(() => addressAllowed('http://www.google.com/maps', ['www.google.com']), /Only https/);
    assert.throws(() => addressAllowed('https://evil.example/maps', ['www.google.com']), /may not connect to evil\.example/);
});

test('a name for a fetched file cannot carry a path', () => {
    assert.equal(safeFileName('../../etc/passwd'), '.._.._etc_passwd');
    assert.equal(safeFileName('S&P 500'), 'S&P 500');
    assert.equal(safeFileName('  '), '');
});

const overrideIndex = [
    { key: 'withdrawalRate', scope: 'institution', entity: 'Alder', sharedParameterId: 1, name: 'Withdrawal (Alder)', live: true, minimum: 0, maximum: 1, value: 0 },
    { key: 'withdrawalRate', scope: 'institution', entity: 'Birch', sharedParameterId: 2, name: 'Withdrawal (Birch)', live: true, minimum: 0, maximum: 1, value: 0 },
    { key: 'baseHaircut', scope: 'global', sharedParameterId: 3, name: 'Haircut', live: true, minimum: 0, maximum: 1, value: 0.1 },
    { key: 'fixed', scope: 'global', sharedParameterId: 4, name: 'Fixed', live: false }
];
const declaredChange = { sharedParameterId: 1, name: 'Withdrawal (Alder)', parameter: 'withdrawalRate', entity: 'Alder', value: 0.015, at: 0, duration: 8, baseValue: 0 };

test('overrides change only what they name, and with none a scenario is exactly as declared', () => {
    const declaredList = [declaredChange];
    assert.equal(applyOverrides(declaredList, overrideIndex, null), declaredList);
    assert.equal(applyOverrides(declaredList, overrideIndex, {}), declaredList);
    const changed = applyOverrides(declaredList, overrideIndex, { withdrawalRate: { Alder: { value: 0.03, at: 2, duration: 5 }, Birch: { value: 0.01 } }, baseHaircut: { '*': { value: 0.4 } } });
    assert.deepEqual(changed.map((change) => [change.entity, change.value, change.at, change.duration]), [['Alder', 0.03, 2, 5], ['Birch', 0.01, 0, 0], [null, 0.4, 0, 0]]);
    assert.deepEqual(declaredList, [declaredChange], 'The declared list is not modified.');
    assert.deepEqual(applyOverrides(declaredList, overrideIndex, { withdrawalRate: { Alder: null } }), [], 'null removes a declared change.');
});

test('overrides are checked: unknown entities, parameters that cannot change during a run, and values that are not finite are refused', () => {
    assert.throws(() => applyOverrides([], overrideIndex, { withdrawalRate: { Nobody: { value: 0.1 } } }), /no "withdrawalRate" for Nobody/);
    assert.throws(() => applyOverrides([], overrideIndex, { fixed: { '*': { value: 1 } } }), /cannot be changed during a run/);
    assert.throws(() => applyOverrides([], overrideIndex, { withdrawalRate: { Alder: { value: Number.NaN } } }), /finite value/);
    assert.throws(() => applyOverrides([], overrideIndex, { withdrawalRate: { Alder: { value: 0.1, at: -1 } } }), /start and duration of zero or more/);
    assert.throws(() => applyOverrides([], overrideIndex, { withdrawalRate: { Alder: { value: 'x' } } }), /finite value/);
    assert.throws(() => applyOverrides([], overrideIndex, { withdrawalRate: 5 }), /must name the entities/);
    assert.equal(applyOverrides([], overrideIndex, { withdrawalRate: { Alder: { value: 7 } } })[0].value, 1, 'A value beyond the declared range is held to it as a backstop.');
});

test('the run manifest records importer options and overrides only when there are some', () => {
    const base = { appVersion: '1', addon: { addonId: 'a', name: 'A', version: '1' }, importerId: 'i', inputs: [], contentText: '{}', document: { nodes: [], edges: [] }, config: {}, scenario: null, interventions: [], files: {} };
    const plain = buildRunManifest(base);
    assert.equal('importerOptions' in plain || 'overrides' in plain, false, 'A run as declared records what it always did.');
    assert.equal(plain.manifestVersion, 1);
    const custom = buildRunManifest({ ...base, importerOptions: { network: 'frozen' }, overrides: { baseHaircut: { '*': { value: 0.4 } } } });
    assert.deepEqual(custom.importerOptions, { network: 'frozen' });
    assert.deepEqual(custom.overrides, { baseHaircut: { '*': { value: 0.4 } } });
    assert.equal('importerOptions' in buildRunManifest({ ...base, importerOptions: {} }), false);
});

test('a launcher may require features, and one this version does not have is refused with a message', () => {
    const withRequires = (requires) => { const manifest = launcher(); manifest.requires = requires; return manifest; };
    assert.equal(validateAddonManifest(withRequires(['scenarioOverrides', 'runRecord'])).kind, 'launcher');
    assert.equal(validateAddonManifest(withRequires(['openLink'])).kind, 'launcher');
    assert.equal(validateAddonManifest(withRequires(['scenarioEveryBackend'])).kind, 'launcher');
    assert.equal(validateAddonManifest(withRequires([])).kind, 'launcher');
    assert.throws(() => validateAddonManifest(withRequires(['scenarioOverrides', 'timeTravel'])), /needs timeTravel, which this version of Konjugate does not provide/);
    assert.throws(() => validateAddonManifest(withRequires('runRecord')), /list of names/);
});

test('a window may choose a run length up to a number of engine steps, in whatever unit the model counts time', () => {
    // A model in days with 0.1-day steps, as the fintech toolbox builds: 2,000 days is 20,000 steps.
    assert.equal(checkRunLength(2000, 5, 0.1), 2000);
    // A model in seconds with 15-minute steps: 90 days is 8,640 steps, and must be allowed.
    assert.equal(checkRunLength(90 * 86400, 10 * 86400, 900), 90 * 86400);
    assert.throws(() => checkRunLength(5, 5, 0.1), /The run length must be more than 5/);
    assert.throws(() => checkRunLength(Number.NaN, 0, 1), /The run length must be more than 0/);
    // Too many steps for a window to ask for in one run, whatever the unit.
    assert.throws(() => checkRunLength(600000, 0, 1), /at most 500000 \(500,000 steps of 1\)/);
    assert.throws(() => checkRunLength(20 * 365 * 86400, 0, 900), /at most 450000000 \(500,000 steps of 900\)/);
});

test('a launcher keeps its session with the project: its window state and its inputs, beside any other launcher\'s', () => {
    const inputs = [
        { role: 'roads', name: 'roads-1.json', text: '{"elements":[]}', encoding: 'utf-8', sha256: 'a', bytes: 15, url: 'https://overpass-api.de/api/interpreter?data=x', retrievedAt: '2026-10-01T10:00:00.000Z', path: '/secret/path' },
        { role: 'sites', name: 'sites.csv', text: 'name,kind\n', encoding: 'utf-8', sha256: 'b', bytes: 10, sample: true }
    ];
    const entry = buildSessionEntry({ addon: { version: '0.2.0' }, window: { kept: ['port:1'] }, inputs, savedAt: '2026-10-01T11:00:00.000Z' });
    assert.deepEqual(entry.window, { kept: ['port:1'] });
    assert.equal(entry.version, 1);
    assert.equal(entry.addonVersion, '0.2.0');
    assert.equal(entry.inputs[0].url, 'https://overpass-api.de/api/interpreter?data=x');
    assert.equal(entry.inputs[0].path, undefined, 'a file path on this computer is never written into the project');
    assert.equal(entry.inputs[1].sample, true);
    const content = attachAddonData(JSON.stringify({ format: 'konjugate', nodes: [], addonData: { 'other.addon': { version: 1 } } }), 'konjugate.logistics.toolbox', entry);
    const document = JSON.parse(content);
    assert.deepEqual(Object.keys(document.addonData).sort(), ['konjugate.logistics.toolbox', 'other.addon']);
    assert.throws(() => buildSessionEntry({ addon: { version: '1' }, window: { big: 'x'.repeat(3 * 1024 * 1024) }, inputs: [] }), /larger than the host keeps/);
});

test('a saved session gives back the inputs its launcher still declares, as pending files', () => {
    const importers = [{ importerId: 'region', files: [{ role: 'roads', multiple: true }, { role: 'places' }] }];
    const entry = { version: 1, inputs: [
        { role: 'roads', name: 'roads-1.json', text: '{}', url: 'https://overpass-api.de/x', retrievedAt: 't' },
        { role: 'roads', name: 'roads-2.json', text: '{}' },
        { role: 'places', name: 'places-1.json', text: '{}' },
        { role: 'gone', name: 'old.json', text: '{}' },
        { role: 'places', name: 'broken.json' }
    ] };
    const restored = sessionInputs(entry, importers);
    assert.deepEqual(restored.map((item) => item.key), ['roads::roads-1.json', 'roads::roads-2.json', 'places']);
    assert.equal(restored[0].file.url, 'https://overpass-api.de/x');
    assert.equal(restored[0].file.bytes, 2);
    assert.equal(sessionInputs(null, importers), null);
    assert.equal(sessionInputs({ version: 2, inputs: [] }, importers), null, 'an entry of a version this host does not know is left alone');
});

test('a launcher may ask for project.data and require projectSession', () => {
    const manifest = launcher();
    manifest.permissions = [...manifest.permissions, 'project.data'];
    manifest.requires = ['projectSession'];
    assert.doesNotThrow(() => validateAddonManifest(manifest));
});

test('a launcher may require fetchCache and keepSession, and a cached address is checked as a fetched one is', () => {
    const manifest = launcher();
    manifest.permissions = [...manifest.permissions, 'project.data', 'network.fetch'];
    manifest.network = { hosts: ['overpass-api.de'] };
    manifest.requires = ['fetchCache', 'keepSession'];
    assert.doesNotThrow(() => validateAddonManifest(manifest));
    assert.equal(addressAllowed('https://overpass-api.de/api/interpreter?data=x', ['overpass-api.de']), 'https://overpass-api.de/api/interpreter?data=x');
    assert.throws(() => addressAllowed('https://example.org/x', ['overpass-api.de']), /may not connect to example.org/);
    assert.throws(() => addressAllowed('http://overpass-api.de/x', ['overpass-api.de']), /Only https/);
    assert.throws(() => addressAllowed('not an address', ['overpass-api.de']), /not a web address/);
});

test('a launcher may require algebraicRelationships, for models whose relationships set states at each instant', () => {
    const manifest = launcher();
    manifest.requires = ['algebraicRelationships'];
    assert.doesNotThrow(() => validateAddonManifest(manifest));
    manifest.requires = ['algebraicRelationshipsLater'];
    assert.throws(() => validateAddonManifest(manifest));
});

test('the window may choose when a scenario starts, from the run\'s start up to its end', () => {
    assert.equal(checkForkTime(0, 90 * 86400), 0);
    assert.equal(checkForkTime(10 * 86400, 90 * 86400), 10 * 86400);
    for (const forkAt of [-1, 90 * 86400, Number.NaN, Infinity]) assert.throws(() => checkForkTime(forkAt, 90 * 86400), /The scenario must start at or after 0 and before the end of the run/);
    const manifest = launcher();
    manifest.requires = ['scenarioForkTime'];
    assert.doesNotThrow(() => validateAddonManifest(manifest));
});

test('a launcher may require parameterSchedules', () => {
    const manifest = launcher();
    manifest.requires = ['parameterSchedules'];
    assert.doesNotThrow(() => validateAddonManifest(manifest));
});

test('an importer may take a large file as bytes and return text files derived from it, which are checked', async () => {
    const importer = { entry: 'echoImporter.mjs', files: [{ role: 'data', label: 'Data', multiple: true }, { role: 'notes', label: 'Notes' }, { role: 'extract', label: 'Extract', binary: true }] };
    const run = (options) => runImporter({ addonDirectory: fixtureDirectory, importer, files: [{ role: 'extract', name: 'region.bin', data: Uint8Array.from([1, 2, 3, 250]) }], options, timeoutMilliseconds: 5000 });
    const result = await run();
    assert.deepEqual(result.data, { bytes: 4, isBytes: true, text: null });
    assert.deepEqual(result.derived, [{ role: 'data', name: 'from-extract.csv', text: 'bytes,sum\n4,256\n', source: 'region.bin' }]);
    // Only of its own roles that are not binary, as text, each named once, a single-file role once.
    await assert.rejects(() => run({ derive: [{ role: 'extract', name: 'x.bin', text: 'x' }] }), /only of its own roles that are not binary/);
    await assert.rejects(() => run({ derive: [{ role: 'elsewhere', name: 'x.csv', text: 'x' }] }), /only of its own roles/);
    await assert.rejects(() => run({ derive: [{ role: 'data', name: 'x.csv', text: 7 }] }), /must be text/);
    await assert.rejects(() => run({ derive: [{ role: 'data', name: 'x.csv', text: 'a' }, { role: 'data', name: 'x.csv', text: 'b' }] }), /two files where one is taken/);
    await assert.rejects(() => run({ derive: [{ role: 'notes', name: 'a.txt', text: 'a' }, { role: 'notes', name: 'b.txt', text: 'b' }] }), /two files where one is taken/);
    assert.equal((await run({ derive: [{ role: 'data', name: 'a.csv', text: 'a' }, { role: 'data', name: 'b.csv', text: 'b' }, { role: 'notes', name: '../n.txt', text: 'n' }] })).derived[2].name, '.._n.txt');
    assert.throws(() => checkedDerived(importer, [{ role: 'data', name: 'big.csv', text: 'x'.repeat(11 * 1024 * 1024) }]), /larger than the 10 MB limit/);
    assert.throws(() => checkedDerived(importer, Array.from({ length: 65 }, (_unused, index) => ({ role: 'data', name: `${index}.csv`, text: 'x' }))), /up to 64 files/);
    assert.ok(maximumBinaryInputBytes >= 600 * 1024 * 1024, 'a region\'s extract fits');
});

test('a binary file role is optional, with no sample, may take several files within a limit, and is not kept with a session', () => {
    let manifestWith;
    const withFile = (file) => { const manifest = launcher(); manifest.contributes.importers[0].files.push({ role: 'extract', label: 'Extract', accept: ['pbf'], ...file }); return manifest; };
    assert.equal(validateAddonManifest(withFile({ binary: true })).kind, 'launcher');
    assert.throws(() => validateAddonManifest(withFile({ binary: 'yes' })), /binary must be true or false/);
    assert.equal(validateAddonManifest(withFile({ binary: true, multiple: true })).kind, 'launcher', 'several, for a city whose map comes in two extracts');
    assert.throws(() => validateAddonManifest(withFile({ binary: true, required: true })), /optional, with no sample/);
    assert.throws(() => validateAddonManifest(withFile({ binary: true, sample: 'samples/x.pbf' })), /optional, with no sample/);
    // Each within the limit for one, and together within the limit for all: they are in the importer's memory at once.
    const mb = 1024 * 1024;
    assert.deepEqual(binaryChoice([{ path: '/maps/switzerland.osm.pbf', size: 548 * mb }, { path: '/maps/nord-ovest.osm.pbf', size: 593 * mb }], 'extract').map((entry) => [entry.name, entry.binary, entry.bytes]),
        [['switzerland.osm.pbf', true, 548 * mb], ['nord-ovest.osm.pbf', true, 593 * mb]]);
    assert.throws(() => binaryChoice([{ path: '/maps/europe.osm.pbf', size: 1100 * mb }], 'extract'), /europe\.osm\.pbf is larger than the 1024 MB limit\.$/);
    assert.throws(() => binaryChoice([{ path: '/a.osm.pbf', size: 900 * mb }, { path: '/b.osm.pbf', size: 900 * mb }, { path: '/c.osm.pbf', size: 900 * mb }], 'extract'), /These files come to 2,700 MB, more than the 2048 MB they may come to together\.$/);
    assert.equal(maximumBinaryTotalBytes, 2048 * mb);
    manifestWith = launcher();
    manifestWith.requires = ['multipleBinaryInputs'];
    assert.equal(validateAddonManifest(manifestWith).kind, 'launcher');
    const manifest = launcher();
    manifest.requires = ['binaryInputs'];
    assert.equal(validateAddonManifest(manifest).kind, 'launcher');
    const entry = buildSessionEntry({ addon: { version: '1' }, window: {}, inputs: [
        { role: 'extract', name: 'region.osm.pbf', path: '/somewhere/region.osm.pbf', binary: true, bytes: 500 * 1024 * 1024, sample: false },
        { role: 'roads', name: 'roads-1.json', text: '{"elements":[]}', encoding: 'utf-8', sha256: 'a', bytes: 15, source: 'region.osm.pbf' }
    ] });
    assert.deepEqual(entry.inputs.map((input) => input.name), ['roads-1.json']);
    // What was derived says what it was read from, and says so again when the session is restored.
    assert.equal(entry.inputs[0].source, 'region.osm.pbf');
    assert.equal(sessionInputs(entry, [{ files: [{ role: 'roads', multiple: true }, { role: 'extract', binary: true }] }])[0].file.source, 'region.osm.pbf');
});

test('a chosen file that cannot be read says why: gone, not allowed, or the reason given', () => {
    assert.equal(unreadableFile('a.osm.pbf', { code: 'ENOENT' }), 'a.osm.pbf could not be read: it is no longer where it was chosen. Choose it again.');
    assert.match(unreadableFile('a.osm.pbf', { code: 'EPERM' }), /^a\.osm\.pbf could not be read: Konjugate is not allowed to read that folder\. /);
    assert.match(unreadableFile('a.osm.pbf', { code: 'EACCES' }), /not allowed to read that folder/);
    assert.equal(unreadableFile('a.osm.pbf', { code: 'EIO' }), 'a.osm.pbf could not be read (EIO). Choose it again.');
});

test('binary files are given to an importer only for a run that asks for them, and stay chosen for the next', () => {
    const pending = [
        { role: 'roads', name: 'roads-extract-1.json', text: '{}' },
        { role: 'extract', name: 'switzerland.osm.pbf', path: '/maps/switzerland.osm.pbf', binary: true, bytes: 548 },
        { role: 'extract', name: 'nord-ovest.osm.pbf', path: '/maps/nord-ovest.osm.pbf', binary: true, bytes: 593 },
        { role: 'elsewhere', name: 'x.csv', text: '' }
    ];
    const roles = new Set(['roads', 'extract']);
    assert.deepEqual(importerInputs(pending, roles, { step: 'roads' }).map((file) => file.name), ['roads-extract-1.json'], 'a step that does not read them is not handed a gigabyte');
    assert.deepEqual(importerInputs(pending, roles, { step: 'extract', useBinaryFiles: true }).map((file) => file.name), ['roads-extract-1.json', 'switzerland.osm.pbf', 'nord-ovest.osm.pbf']);
    assert.deepEqual(importerInputs(pending, roles).map((file) => file.name), ['roads-extract-1.json']);
});

test('an importer says how far it has got, and the host passes it on checked, apart from its result', async () => {
    const heard = [];
    const result = await runImporter({ addonDirectory: fixtureDirectory, importer: { entry: 'echoImporter.mjs' }, files: [{ role: 'data', name: 'data.csv', text: 'progress' }], timeoutMilliseconds: 5000, onProgress: (progress) => heard.push(progress) });
    assert.deepEqual(result.data, { reported: true });
    assert.deepEqual(heard.map((item) => [item.done, item.total, item.message]), [[0, 4, 'part 0'], [1, 4, 'part 1'], [2, 4, 'part 2'], [3, 4, 'part 3'], [4, 4, 'part 4']], 'what is not a number is not passed on');
    assert.deepEqual(checkedProgress({ done: 7, total: 4, message: 'x'.repeat(300) }), { done: 4, total: 4, message: 'x'.repeat(200) });
    assert.equal(checkedProgress({ done: 1, total: 0 }), null);
    assert.equal(checkedProgress(null), null);
});

test('a launcher may keep files for the user with files.store, and require storedFiles', () => {
    const manifest = launcher();
    manifest.permissions = [...manifest.permissions, 'files.store'];
    manifest.requires = ['storedFiles', 'importProgress'];
    assert.equal(validateAddonManifest(manifest).kind, 'launcher');
});

test('a window keeping files names their endings: the dialog offers those, and another file is refused before any is copied', () => {
    const maps = storedFileKinds(['osm.pbf']);
    assert.deepEqual(maps.filters, [{ name: '.osm.pbf', extensions: ['pbf'] }]);
    maps.check('/maps/switzerland-261013.osm.pbf');
    maps.check('/maps/SWITZERLAND.OSM.PBF');
    assert.throws(() => maps.check('/maps/switzerland-latest-free.shp.zip'), /switzerland-latest-free\.shp\.zip was not kept: only \.osm\.pbf files are kept here\.$/);
    // The dialog goes by the last extension, so a .pbf of another kind gets through it, and is refused here.
    assert.throws(() => maps.check('/maps/tiles.vector.pbf'), /not kept/);
    assert.deepEqual(storedFileKinds(['csv', 'txt']).filters, [{ name: '.csv or .txt', extensions: ['csv', 'txt'] }]);
    // None named: any file, as before.
    assert.deepEqual(storedFileKinds(null).filters, []);
    storedFileKinds(undefined).check('/anything.bin');
    for (const wrong of [[], ['.osm.pbf'], ['osm/pbf'], 'pbf', [1]]) assert.throws(() => storedFileKinds(wrong), /up to 8 endings/);
});

test('a window can ask whether the providers\' Python imports the modules it needs, and is told which Python that is', async () => {
    const answering = (modules) => async (interpreter, args) => {
        assert.equal(args[0], '-c');
        return { code: 0, stdout: `${JSON.stringify({ version: '3.12.4', executable: '/usr/bin/python3', modules: Object.fromEntries(args.slice(2).map((name) => [name, modules[name]])) })}\n`, stderr: '' };
    };
    const found = await checkPythonModules({ interpreter: 'python3', modules: ['mujoco'], run: answering({ mujoco: { found: true, version: '3.16.0' } }) });
    assert.equal(found.found, true);
    assert.deepEqual(found.modules.mujoco, { found: true, version: '3.16.0' });
    assert.match(found.message, /^Python 3\.12\.4 at \/usr\/bin\/python3 has mujoco\.$/);
    const missing = await checkPythonModules({ interpreter: '/opt/py/bin/python', chosen: true, modules: ['mujoco', 'numpy'], run: answering({ mujoco: { found: false, error: "ModuleNotFoundError: No module named 'mujoco'" }, numpy: { found: true, version: '2.0' } }) });
    assert.equal(missing.modules.mujoco.found, false);
    assert.match(missing.message, /^mujoco is not importable in Python 3\.12\.4 .*the Python set under Provider toolchains/);
    // No Python at all, or one that fails, is said plainly, with every module counted missing.
    const absent = await checkPythonModules({ interpreter: 'python3', modules: ['mujoco'], run: async () => ({ code: -1, stdout: '', stderr: 'spawn python3 ENOENT' }) });
    assert.equal(absent.found, false);
    assert.equal(absent.modules.mujoco.found, false);
    assert.match(absent.message, /could not be run \(the Python found on the PATH.*\): spawn python3 ENOENT/);
    // Only import names, and not too many.
    for (const modules of [[], ['os; import x'], ['-c'], Array.from({ length: maximumPythonModules + 1 }, (_, index) => `m${index}`), 'mujoco']) {
        await assert.rejects(checkPythonModules({ interpreter: 'python3', modules, run: async () => assert.fail('Python should not be run.') }), /Name between 1 and/);
    }
});

test('the check runs a real Python, importing what is there and not what is not', { skip: process.platform === 'win32' && 'python3 is not assumed on Windows' }, async () => {
    const answer = await checkPythonModules({ interpreter: 'python3', modules: ['json', 'konjugate_no_such_module'] });
    if (!answer.found) return; // No python3 on this computer: the message says so, and there is nothing more to check.
    assert.equal(answer.modules.json.found, true);
    assert.equal(answer.modules.konjugate_no_such_module.found, false);
    assert.match(answer.modules.konjugate_no_such_module.error, /ModuleNotFoundError/);
});
